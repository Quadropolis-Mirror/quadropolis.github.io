to use these,put the pictures folder in the packages folder.then copy the contents of the pictures.cfg to the bottom of your maps cfg.then you will be able to use them on your map.or while in game 
type  /exec packages/pictures/pictures.cfg
