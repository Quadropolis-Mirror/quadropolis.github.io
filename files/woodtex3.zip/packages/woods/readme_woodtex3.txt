if you have downloaded a other "wood texture pack", you can add it with the other pack.


Copy the text of package.cfg, and paste in the original.

Do the same with package-nospec.cfg