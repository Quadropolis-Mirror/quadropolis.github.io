Noman... is an island. - By Pritchard 2-8-2013 v.06

A small, 2-4 player map that is intended for duels and the like. This is my first time making a map this small and condensed, and I need advice on weapon placement so that i can make this map better. Other than that, this map is basically done. No waypoints, because i couldn't be bothered making them and then deleting all the nodes from the times i fell off the map. 

UPDATE: changed fog and water settings.

UPDATE 2: Removed the health pickup in the center of the map, detailed the walls a bit, added banks of sand to make things more interesting, rotated the sky, changed texture at the edge of the map, rotated a spawn point and added a barrel and a mug.