Go to data folder open default_map_models.cfg and add this to the end! 
mmodel "zam/glazzangle"
mmodel "zam/glazzangle2"
mmodel "zam/glazzangle3"
mmodel "zam/glazzangle4"

This is My first models enjoy!
