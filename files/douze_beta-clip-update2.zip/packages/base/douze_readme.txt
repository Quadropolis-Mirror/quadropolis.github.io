Douze 41 A.D. - Beta version, 2nd update.

by makkE and stanze

Any other use than with the official Sauerbraten Game requires permission, write to :

makk_e@web.de