Lamiera a CTF map by Drekow

It is mind for Ctf-iCTF game, some really fast rush here.
v1.2

Remember that game modes that differ from CTF are not supported in this relase. Do it at your Risk ;)

Se you next.