Golden Temple - by Andrez

A totally balanced map set in a square temple. Partially inspired by 4Bit's Pistol Palace and a castle I saw long time ago during a school trip. Playable both in CTF/(T)KTF and FFA modes.


**License**
You are able to redistribuite this package as long this readme is included. No modifications allowed without my permission.

http://assaultcube.altervista.org or
assaultcube@altervista.org to contact me

Andrez