============================================================
Date:             13th August 2001.
file:             tp-egyptian.zip
author:           Sock 
email:            sock@planetquake.com
URL:              http://www.planetquake.com/simland
Version:          1.5

============================================================

COPYRIGHT NOTICES
-----------------

If you use any of these Egyptian shader/textures I kindly ask
YOU to give me credit for my work within your README file or
TEXT file distributed with your map/mod.

============================================================

Testing of Shaders
------------------

* All of the shaders included with this texture pack have been 
  tested with Q3 point release 1.27g.

============================================================

Instructions for using the Egyptian Texture Pack
---------------------------------------------------

** You must have installed the Q3 editor tools first **

1. Extract the tp-egyptian.zip file in the BASEQ3 directory.
   This will create 6 texture directory under the
   BASEQ3/TEXTURES directory as follows :-

   BASEQ3/TEXTURES/EGYPTSOC_FLOOR
   BASEQ3/TEXTURES/EGYPTSOC_MAT
   BASEQ3/TEXTURES/EGYPTSOC_SFX
   BASEQ3/TEXTURES/EGYPTSOC_TRIM
   BASEQ3/TEXTURES/EGYPTSOC_TRIMD
   BASEQ3/TEXTURES/EGYPTSOC_WALL
   
2. Goto the SCRIPTS sub-directory under the BASEQ3
   directory and find the following 
   file :- SHADERLIST.TXT.
   
3. Open this file up in a text editor and add the
   following line at the bottom of the file.
   
   EGYPTSOC
   
4. Close the file and open Q3Radiant and you should
   find on the texture menu the 1 new subdirectory.

For a full explaination of each texture/shader please
refer to the website.

Enjoy
Sock