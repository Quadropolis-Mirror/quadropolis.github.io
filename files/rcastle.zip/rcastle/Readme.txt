To install: 
Move the .ogz and .cfg file into the base folder.

Move the subz folder into the sounds folder.




skycastle Was originally made by Okicomputer.

Skycastle was altered and then renamed to rcastle.

rcastle was finished by Sub-Zero.

There have been some major changes, and name changes, This re-mod of skycastle is rcastle (royal castle).

This map was made to be an artistic map and nothing more. However the added work on it was to add beauty without sacrificing gameplay, quite unlike skycastle-r, though it also is an artistic map, but sacrifices gameplay for eyecandy. What this means is rcastle can be played on (though it is still not a suitable map to do so), all the while it is suppose to look good.

I have not added any pickups. The teleport models are currently respawn points (I assume I will have to update it because of future releases where they may seperate it from the single player aspect and make it fully multiplayer.

You should be able to access the entire map without pickups to "trickjump" you to places.

