Map:
ac_fetus4 

Author:
fetus

What to do:
Place both files into folder: C:/programfiles/AssaultCube/packages/maps

Play it and tell me what sucks.  If it's worth while, we can make it better.  Otherwise we'll trash it.


General Idea:
Just a map for smaller groups looking for a different map for the rotation.  

I still haven't gotten the hang of mapping yet-- you know, what elements make for fun play, etc.  For some reason, I tend to go cramped, rather than open.  Please help and let me know if anything is redeamable.

Thanks.