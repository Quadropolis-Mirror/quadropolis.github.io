 - thojoh370's Voice Package -

This package will, if extracted, replace aard's default voices. (If you have
installed someone else's voices in aard's voice directory, they will be replaced as well.)
Also, the sound that is bound to the message "Quad damage is over" will be replaced
with a voice saying the same as the echoed message.

If you can't hear the sounds, or if they are not loud enough to be heard, please report
it and I will make the voices louder - that can be arranged easily.

These voice clips are not made out of Aard's default voices - I have created these
voice files from the beginning.

Extract into the Sauerbraten directory in order to apply.

// thojoh370