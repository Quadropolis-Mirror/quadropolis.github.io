These tracks are from Mister M's album Core. They are used in map Anticube by Lord Kv.
I do not take credit for these songs in any way.
http://www.jamendo.com/en/list/a103482/core-soundtracks-vol-2
http://creativecommons.org/licenses/by-sa/3.0/
https://soundcloud.com/misterm
