}[Baxter's Weapon Mod]{
Rocket Laucher Converted to another Rocket Launcher
Shotgun Converted to a Pulse Rifle
Machine Gun Converted to An Assault Rifle
The other weapons!
Sometimes soon,maybe


//////////////Installation///////////////
I suggest you backup these folders|
in the hudguns folder                    |
chaing,rocket and shotg then         |
just replace those folders with       |
the ones in this zip archive            |
Have fun :P                                  |
/////////////////////////////////////////

