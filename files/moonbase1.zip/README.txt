Moonbase1 Sauerbraten Deathmatch Map

Design.................John Siar, a.k.a. shocktrooper
.......................mykilx

Editing and Textures...mykilx
.......................shocktrooper


new textures...........Yves Allaire aka evil lair  /more available at http://planetquake.com/hfx

/////////////////////////////////////////////////////////////////////////////////////////////////

Features;

New teleporter model
New textures by the reknowned evil lair
New crosshair
New skybox

/////////////////////////////////////////////////////////////////////////////////////////////////

Instructions;

Drop the folders into your sauerbraten directory.

/////////////////////////////////////////////////////////////////////////////////////////////////

Notes;

Dropping the /packages/models/teleporter file will not overwrite sauerbraten's original teleporter.  Instead it will move the current model to the CVS file in the same directory.
To replace the original simply copy and paste it back to /packages/models/teleporter.

Crosshair.png WILL overwrite the original and it is suggested you move the current crosshair to another directory before extracting if you wish to keep it.

/////////////////////////////////////////////////////////////////////////////////////////////////

What is to come;

New sci-fi themed ammo models
Hudguns to accompany the shocktrooper player mod
After these I will move on to making capture maps and mods, exclusively


For best results on older systems set resolution to 640x480