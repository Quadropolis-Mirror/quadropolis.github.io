Boxed In by theButcher

My first map.
A smallish normalmapped map loosely based off of Block City from Mario Kart Double Dash.
Might be good for 1-on-1.
The config script is copied from deathtek's and slightly modified.