Please extract this zip to your sauerbraten folder. Enjoy the map and thanks for downloading!

-Madrick