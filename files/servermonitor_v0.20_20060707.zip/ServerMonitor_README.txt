The ServerMonitor is a client MOD of Sauerbraten.

This version (0.2x) is for the 2006-06-11 release of the engine
and will only report servers using that protocol.

It was written by MeatROme 2006-07-07,
sorry for the delay ;-)

It responds to following parameters 

 -sX : will loop X times
 -o  : will omit running an update from the master server

The Windows BAT(ch) file simply opens stdout in a Wordpad,
the two linux BASH scripts are two variants, both only output the last loop.
use_servermonitor is the basic variant, say_servermonitor is a little more colourful.

Enjoy!