To install: Simply place minimaze.cfg and minimaze.ogz in your packages/base folder.

To play: Well, I assume you know how to vote for maps? :P

To edit: Don't.

To contact me: Send an email to felion@xtra.co.nz (Yep, NZ = New Zealand). But if it's about this map, post a comment to the map on Quadropolis at http://www.quadropolis.us/node/373, assuming you have a Quadropolis account, otherwise you can just email me, or get an account.

I hope you enjoy this tiny but well smoothed map!

P.S: I may make another maze that's bigger, and has multiple floors sometime!