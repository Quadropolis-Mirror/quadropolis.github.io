//TNT barrel by Steve Eggleston, January 2008

//Set the following in your map.cfg

mapmodelreset 
mmodel "steve_e/barrels/tnt" 

