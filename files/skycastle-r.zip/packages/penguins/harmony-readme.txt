Title: Harmony Skybox
Author: SkiingPenguins
Creation Date: August 7, 2009
Files: 
harmony_up.jpg
harmony_dn.jpg
harmony_lf.jpg
harmony_rt.jpg
harmony_ft.jpg
harmony_bk.jpg
harmony-readme.txt
License: Creative Commons Attribution-Share Alike 3.0
License URL: http://creativecommons.org/licenses/by-sa/3.0/
Notes: Originally created for the first person shooter Cube 2: Sauerbraten.
Notes: This Readme MUST be included with the skybox images.