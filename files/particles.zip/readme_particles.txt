The particles included in this package are under the terms of the CC-BY-NC-SA license

* data/explosion.jpg
* data/flare.jpg
* data/lightning.jpg
* data/lensflares.png
* data/martin/ball1.png
* data/martin/ball2.png
* data/martin/ball3.png
* data/martin/base.png
* data/martin/smoke.png
* data/martin/spark.png

Changelog
=========

Release 2

Swapped two lensflares around, looks better now
Made lighting slightly more friendly to the blue colour channel
Used a cartoon shader on explosion.jpg. it now has a few 'holes' in it

Release 1

Initial release of particle replacement textures