Castlewars v.1.0 Final

// Sauerbraten Multiplayer Map
// Created by Z-ero_Xz (ZXZ)
// Assistance by DemiGod & Smogelore

-------------------------------

// Map size: Okay. That's medium size.
// Building time: Again many days... Sorry about that we let you wait so much.
// Map: First.
// Tested in: sauerbraten_2006_06_11_sp_edition

-------------------------------

Information:

 "This is our first map so don't blame us if it's awful! The map has been in development 
  since June. We have continued development every free time that we had and tried our best to do a 
  good map. Actually this map is tiny and looks like a piece of shit but it's better than you believe! 
  The lead developer of the map is Z-ero_Xz and some minor developers are DemiGod and Smogelore. 
  It was fun to create a map with many people! Have a fun playing Castlewars map! ;)"

-------------------------------

Map information:

 "A tiny RPG styled multiplayer map which have a lot of secret places, traps and prisons..."

-------------------------------

Known issues:

- "The map may encounter a little lag because of the mass of mapmodels.. (depending on your system power)."

-------------------------------

HOw to play:

1. Copy the castlewars.cfg file into your /Sauerbraten/packages/base/ -folder.

2. Start Sauerbraten and press "t" key and type:

/map castlewars

-------------------------------

By Z-ero_Xz
E-mail: t.v.katainen@hotmail.com