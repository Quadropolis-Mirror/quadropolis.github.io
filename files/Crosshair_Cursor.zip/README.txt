Crosshair Cursor by Sgt. Reaver

Installation:

1. Go to Sauerbraten's data folder.
2. Backup and replace "guicursor."



Made with GIMP 2