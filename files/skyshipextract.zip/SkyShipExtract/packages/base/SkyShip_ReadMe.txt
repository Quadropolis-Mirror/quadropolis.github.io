Game: Sauerbraten
Map: SkyShip
Creator: L. Tempris
=============================================================================================
Game:                   Sauerbraten (www.sauerbraten.org)
Map Name:               SkyShip
Building Time:          �125 working hours
Begin Building Date:    September 19, 2007
Completion Date:        June 10, 2008
Author:                 James "Leviscus Tempris" Steele Seeley
E-Mail:                 l._tempris@hotmail.com
=============================================================================================
Description:            Multi-purpose, mid. sized map, 5-10 players, a small 
                        airship like complex with Many 3D Textures on walls 
                        and such, floating in air also, with heavy-ish fog...
=============================================================================================
Textures:               All included with Sauerbraten
=============================================================================================
Music:                  All included with Sauerbraten
=============================================================================================
Map's Story:            For centuries, this war torn ship has remained, clans of all species
                        come here to settle their disagreements. This old ship, what once was
                        a transportation vehicle has been out fitted over the years and
                        turned into a multi purpose arena. Many come for sport others,
                        immortality in the history books. But the most popular sport here is
                        the death match. Who knows, maybe you'll be next...
=============================================================================================
Developer Notes:        1.0   1st public release -    Hope to see this map in action!
                                                      Dont have fog yet... sorry. 
                                                      Expect Updates-maybe
                        
                        1.2   2nd public release -    Added more mapmodels for looks.
                                                      Dont have fog yet... sorry.
                        
                        1.7   3rd public release -    Added an access bridge for 1st floor
                                                      near capture the flag areas
                                                      Dont have fog yet... sorry.

                        2.0   4th public release -    Yes!!! Finally 2.0 release! Added new 
                                                      roof access and high-rise bridges for
                                                      even more fighting fun!
                                                      Almost figured out how to get fog but
                                                      cant seem to be able to get it to play.

                        2.5   5th public release -    Actually got fog to play in map! Now
                                                      try sniping people from afar!
                                                      Dont know if I'll get to 3.0 release...
                        
                        3.0   6th public release -    Added greater fog distance, new skybox
                                                      and got rid of alot of pesky mapmodles!

                        3.2   7th public release -    Fixed some lazy mistakes. Now can play 
                                                      CTF with it!
=============================================================================================
How to install:
                        Place the map 'skyship.ogz' in ..Sauerbraten\packages\base\.
                        
                        Start Sauerbraten, press � (key under esc) to open the console, type  
                        'map skyship', press enter and you're all set.

=============================================================================================

If you have any sugestions of improvement, feel free to send a email to: 
l._tempris@hotmail.com

You can also edit and send me the edited version with your improvements listed in a Word or 
Notpad document.

Thanks-A-Bunch!!!  


=============================================================================================



=============================================================================================
=============================================================================================
Copyright & Permissions:Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. 
(www.sauerbraten.org)You are NOT allowed to commercially exploit this level, i.e. put it on 
a CD or any other electronic medium that is sold for money without my explicit permission!If 
you have a mapping website, and you want to upload this map in it, or if you're making a map 
pack and want to include this map, you're totally free to do so. Always remember to include 
all files unmodified. Especially this readme file.
=============================================================================================
=============================================================================================