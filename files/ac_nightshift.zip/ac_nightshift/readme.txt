ac_nightshift
by morph33n
release candidate 2

please do not edit or otherwise screw with this map...

that is all ;)