install it by extracting the folder into your Sauerbraten folder.

Please don't edit the map without first telling me, contact me at cchin256@hotmail.com. 