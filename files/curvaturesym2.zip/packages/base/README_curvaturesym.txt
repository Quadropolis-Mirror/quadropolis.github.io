CurvatureSym Release 2 01-16-2013
Map author: Pritchard

Curvaturesym is a small, symetrical map designed for a small playercount. It has multiple pathways through the map, which operates on two (and a half) layers. Most of the weapon types are represented, except for the rocket launcher. There is now a healthboost on the map.
BE AWARE that this map is by no means final. I am hoping to pick up as many tips on map creation as possible as overall I am quite new to it. Advice on playerstart placement, lighting, environtment map placement, weapon placement and general map layout is very welcome, and a comment on the quadropolis node for this map would be greatly appreciated!

Changes since first release (01-15-2013)

- Raised Ceiling and most door arches
- Made bridges and things... curvy-er
- Added highlights around light sources, replaced section of wall with chain-link fence (not sure if this is good), added some boxes, floor grates and air vents
- Moved grenades out on to bridge
- Moved Green armours: One deleted, one moved to center of hallway
- Widened Low Hall
- Added Waypoints!
- Probably something else I forgot :/
