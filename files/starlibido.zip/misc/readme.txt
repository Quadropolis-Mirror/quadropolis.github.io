This texture, "starllogo" by D.a.M.i.E.n. <daymeenn@gmail.com>, contains a
texture, originally made by Georges 'TRaK' Grondin <drognin@gmail.com>, it also
uses the font "Keania One" <http://www.google.com/webfonts/specimen/Keania+One>
by Julia Petretta <julia.petretta@googlemail.com>.

It is Copyright (c) 2009 Georges 'TRaK' Grondin <drognin@gmail.com>
and Copyright (c) 2012 Julia Petretta <julia.petretta@googlemail.com>
and Copyright (c) 2013 D.a.M.i.E.n. <daymeenn@gmail.com>

It is licensed under "MIT (Expat)" license.
To view a copy of this license, visit http://opensource.org/licenses/MIT

-----

Texture "light2" by D.a.M.i.E.n. <daymeenn@gmail.com> is a modified texture,
originally made by Georges 'TRaK' Grondin <drognin@gmail.com>

It is Copyright (c) 2009 Georges 'TRaK' Grondin <drognin@gmail.com>
and Copyright (c) 2013 D.a.M.i.E.n. <daymeenn@gmail.com>

It is licensed under "MIT (Expat)" license.
To view a copy of this license, visit http://opensource.org/licenses/MIT

-----

Texture "barlightclean" by D.a.M.i.E.n. <daymeenn@gmail.com> is a modified
texture, originally made by Luckystrike

It is Copyright (c) 2009-2013 Red Eclipse Team

It is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported
License.  To view a copy of this license, see cc-by-sa.txt or visit
http://creativecommons.org/licenses/by-sa/3.0/
