Some additional "vweps" for Sauerbraten
created by wurfel
2007-08-20

This mod adds 6 additional "vwep" (viewable weapon) md3 models for Sauerbraten's great "Ironsnout" character.
It includes a new chaingun, pistol, rifle, shotgun, rocket and grenade launcher.
The models are a bit crude but I think they might be useful in multiplayer. :D

To install and use this mod you have two possibilities.
First one (old):
Just extract this zip into your sauerbraten folder. Then start the game...
WARNING: This will overwrite the current vweps.
If you want to "uninstall" the mod later you need to backup the sauerbraten/packages/models/vwep folder.

Second one (new):
You extract this zip not directly into the sauerbraten folder but into sauerbraten/modvwep/.
Then start the game with the command line parameter "-kmodvwep" (see manual).
This way nothing gets overwritten (no need for backup) and it's a lot easier to "uninstall" the mod.
I recommend to use this way if you don't want to harm the original Sauerbraten data. :)

There are no extra textures because the skins provided by Sauerbraten's hudguns are used.
If you have modified the original hudguns the md3s here may use the wrong textures. :P

Try to have some fun...
