BLUE LAZ0RZ! By K1P57A 2011

------------------------------

blip_blue_flag.png
blip_blue.png
blip_grey.png
blip_red_flag.png
blip_red.png
items.png
radar.png

------------------------------

Copyright Kipperdesign 2011.
My personal copy right states...
"Use it for whatever the f* you want!! Just mention me :D"