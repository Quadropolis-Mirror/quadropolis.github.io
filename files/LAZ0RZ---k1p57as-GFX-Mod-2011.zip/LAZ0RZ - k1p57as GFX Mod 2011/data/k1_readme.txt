BLUE LAZ0RZ! By K1P57A 2011

------------------------------

background_decal.png
background_detail.png
background.png
guicursor.png
guioverlay.png
guiskin.png
guislider.png
loading_bar.png
loading_frame.png
mapshot_frame.png
teammate.png

------------------------------

Copyright Kipperdesign 2011.
My personal copy right states...
"Use it for whatever the f* you want!! Just mention me :D"