Map: Abandonment
Author: MoooseGuy

This is a map that works on all gametypes but it primarily designed for hectic instagib games with 4-8 people. Please do not edit or redistribute this map, or i will be forced to hunt you down and pop off your toes one by one. Have fun playing and be sure to give feedback :)

Notes: Map Completed on 10-1-08