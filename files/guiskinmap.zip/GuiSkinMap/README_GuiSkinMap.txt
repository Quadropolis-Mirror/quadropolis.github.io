Author:
    Tim (ThomasT) Thomas

Creation Date:
    2012/09/16

Version:
    1.0

Overview:
    The guiskin_map.png image is derived from the patch list array
    gui::patches[] in src/engine/3dgui.cpp.  It can be used to create a new
    gui skin for Sauerbraten.

    The gui::patches[] array is divided into 4 patch sets:
    0 - 8    The main body.
    9        A small patch for the top, connecting selected and unselected tabs.
    10-18    Selected tab.
    19-27    Unselected tab.

    The main body, selected tab, and unselected tab patch sets form 3x3
    non-uniform grids that divide each region into 9 patches: upper left,
    upper center, upper right, middle left, middle center, middle right,
    lower left, lower center, lower right.

    The numbers on the patch map image correspond to the appropriate
    gui::patches[] array entry.  (Note that the array index starts from 0.)
    The dimensions of each patch are pixel correct, so the image can be used
    directly as an underlay or overlay for guiding the development of the skin.

    To create a new gui skin, the border for each region must pass through the
    outer patch of each patch set.  The border must be designed so that if it
    is cut at the patch boundaries, the center parts and edge parts can be
    extended without noticeable seams.

Copyright and License:
    guiskin_map.png:
        Copyright (C) 2012 Tim Thomas
        Licensed CC-BY-SA 3.0:
            http://creativecommons.org/licenses/by-sa/3.0/

        You may use, modify, or distribute, as long as the author is credited
        for the original work.

    The Sauerbraten source code is covered by the ZLIB license:

       (http://www.opensource.org/licenses/zlib-license.php)

    Please see the file src/readme_source.txt in the Sauerbraten source
    distribution for full details.

    There is NO WARRANTY, to the extent permitted by law.
