      |
      _
  \ /   \ /      ! Sunset. Made by R4zor. !
 - |     | -
  / \ _ / \

      |

~ This map was made as an entry to the first Assaultcube Mapping Competition.

! TEXTURES !

~ The texture(s) of this map including "bluewoody", "bluewoody2", "crate" 
and "shutters" are texture(s) that were edited by myself. The original
creator is unknown. If you are or know the original creator, please contact
me at r4zorlive@live.com.au . Please refer to "Licenses" in the appropriate
folder.

~ The skymap "inhcanyons1" was created by Lady NightHawk of http://www.alusion-fr.com/an1ffa3.htm .
Credit to them for the skymap.

~ This map's custom textures are set over other textures, meaning
even if the player doesn't have the cfg's, the textures will still be
nice.

! INSTALLATION !

~ To Install ac_sunset:
	- place the folder "jaj" in packages/textures/skymaps
	- place the folder "r4zor" in packages/textures
	- place the files "ac_sunset" cfg and cgz into packages/maps
		-Alternitively you may just extract this into the ac folder; merging the folders.

! LICENSE !

~ This map has a freeware license - which is it is completely free.
However this map may not be distributed for any other game without my
personal permission, nor can it be edited and redistributed in any way
without my permission.

~ Hopefully you enjoy my map!

-R4zor