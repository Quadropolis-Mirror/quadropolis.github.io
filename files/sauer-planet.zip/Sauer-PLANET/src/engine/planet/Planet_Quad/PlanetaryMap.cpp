// also uses code from ScatterCPU.cpp
/*
Copyright (c) 2000, Sean O'Neil (s_p_oneil@hotmail.com)
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
* Neither the name of the project nor the names of its contributors may be
  used to endorse or promote products derived from this software without
  specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "StdAfx.h"
#include "PlanetaryMap.h"
#include "PlanetaryMapNode.h"

void CPlanetaryMap::Init(CPropertySet &prop)
{
	Cleanup();

	m_texArray.Init(TEXWID, HEIGHT_MAP_WIDTH, 3, GL_RGB, GL_UNSIGNED_BYTE); //crashes for GL_FLOAT
	m_shNoAtmosphere.Init("packages/planet/shaders/BumpVert.glsl", "packages/planet/shaders/BumpFrag.glsl");
	m_shGroundFromSpace.Init("packages/planet/shaders/BumpGroundFromSpaceVert.glsl", "packages/planet/shaders/BumpGroundFromSpaceFrag.glsl");
	m_shGroundFromAtmosphere.Init("packages/planet/shaders/BumpGroundFromAtmoVert.glsl", "packages/planet/shaders/BumpGroundFromAtmoFrag.glsl");
	m_shSkyFromSpace.Init("packages/planet/shaders/SkyFromSpaceVert.glsl", "packages/planet/shaders/SkyFromSpaceFrag.glsl");
	m_shSkyFromAtmosphere.Init("packages/planet/shaders/SkyFromAtmosphereVert.glsl", "packages/planet/shaders/SkyFromAtmosphereFrag.glsl");

	// Get all the simple properties for this planet
	sscanf(prop.GetProperty("position"), "%f, %f, %f", &m_vTranslate.x, &m_vTranslate.y, &m_vTranslate.z);
	m_fRadius = prop.GetFloatProperty("radius");
	m_fFrustumRadius = prop.GetFloatProperty("frustum.radius");
	m_fMaxHeight = prop.GetFloatProperty("max.height");
	m_fAtmosphereRadius = prop.GetFloatProperty("atmosphere.radius", 0.0f);
	if(m_fAtmosphereRadius > 0.0f)
	{
		sscanf(prop.GetProperty("atmosphere.wavelength"), "%f, %f, %f", &m_fWavelength[0], &m_fWavelength[1], &m_fWavelength[2]);
		m_fKr = prop.GetFloatProperty("atmosphere.Kr");
		m_fKm = prop.GetFloatProperty("atmosphere.Km");
		m_fEsun = prop.GetFloatProperty("atmosphere.Esun");
		m_fG = prop.GetFloatProperty("atmosphere.g");
	}

    //scatterCpu - should be here not in constructor..
    m_sphereInner.Init(m_fAtmosphereRadius, 50, 50);
    m_sphereOuter.Init(m_fAtmosphereRadius*1.025f, 100, 100);

    //must init the pixels too
    int ix;
    SVertex *pBuffer = m_sphereInner.GetVertexBuffer();
    for(ix=0; ix<m_sphereInner.GetVertexCount(); ix++) {
        pBuffer[ix].cColor = CColor(0.9f, 0.5f, 0.5f);
    }
    pBuffer = m_sphereOuter.GetVertexBuffer();
    for(ix=0; ix<m_sphereOuter.GetVertexCount(); ix++) {
        pBuffer[ix].cColor = CColor(0.5f, 0.5f, 0.9f);
    }

	// Now build the factories for this planet
	std::string strPrefix = prop.GetPrefix();
	int i;
	for(i=1; ; i++)
	{
		char szPrefix[256];
		sprintf(szPrefix, "%sfactory.%d.", strPrefix.c_str(), i);
		prop.SetPrefix(szPrefix);
		const char *pszType = prop.GetProperty("type");
		if(!pszType)
			break;

		CPlanetaryFactory *pFactory = (CPlanetaryFactory *)CObjectType::CreateObject(pszType);
		m_llFactories.push_back(pFactory);
		pFactory->Init(prop);
	}
	prop.SetPrefix(strPrefix.c_str());

	int nFace;
	for(nFace=0; nFace<6; nFace++)
		m_pRoot[nFace] = new CPlanetaryMapNode(this, nFace);
	m_pRoot[RightFace]->SetNeighbors(m_pRoot[TopFace], m_pRoot[BackFace], m_pRoot[BottomFace], m_pRoot[FrontFace]);
	m_pRoot[LeftFace]->SetNeighbors(m_pRoot[TopFace], m_pRoot[FrontFace], m_pRoot[BottomFace], m_pRoot[BackFace]);
	m_pRoot[TopFace]->SetNeighbors(m_pRoot[BackFace], m_pRoot[RightFace], m_pRoot[FrontFace], m_pRoot[LeftFace]);
	m_pRoot[BottomFace]->SetNeighbors(m_pRoot[FrontFace], m_pRoot[RightFace], m_pRoot[BackFace], m_pRoot[LeftFace]);
	m_pRoot[FrontFace]->SetNeighbors(m_pRoot[TopFace], m_pRoot[RightFace], m_pRoot[BottomFace], m_pRoot[LeftFace]);
	m_pRoot[BackFace]->SetNeighbors(m_pRoot[TopFace], m_pRoot[LeftFace], m_pRoot[BottomFace], m_pRoot[RightFace]);

}

void CPlanetaryMap::Cleanup()
{
	int nFace;
	for(nFace=0; nFace<6; nFace++)
	{
		if(m_pRoot[nFace])
			delete m_pRoot[nFace];
		m_pRoot[nFace] = NULL;
	}
	m_llFactories.clear();
}

void CPlanetaryMap::UpdateSurface(CVector vLightPos, CVector vCamera, CQuaternion qCamera, float fSplitPower, float fSplitFactor)
{
	//PROFILE("CPlanetaryMap::UpdateSurface", 2);
	CMatrix4 mView = BuildModelMatrix();
	glPushMatrix();
	glMultMatrixf(mView);
	m_frustum.Init();
	glPopMatrix();

	// Clear some counters for this update
	m_nSplits = 0;

	// Initialize the members used by the update
	m_vCameraPos = vCamera;
	m_vLightPos = m_qRotate.UnitInverse().TransformVector(vLightPos - m_vTranslate);
	m_vCamera = m_qRotate.UnitInverse().TransformVector(vCamera - m_vTranslate);
	m_qCamera = m_qRotate.UnitInverse() * qCamera;
	float fAltitude = m_vCamera.Magnitude();
	float fHorizonAltitude = CMath::Max(fAltitude-m_fRadius, m_fMaxHeight);
	m_fHorizon = sqrtf(fHorizonAltitude*fHorizonAltitude + 2.0f*fHorizonAltitude*m_fRadius);

	m_coordCamera.Init(m_vCamera, fAltitude);
	m_fSplitPower = fSplitPower;
	m_fSplitFactor = fSplitFactor;

	// Build an array of faces sorted by distance
	float fDistance[6];
	int nFace;
	for(nFace=0; nFace<6; nFace++)
		fDistance[nFace] = (m_pRoot[nFace]->HitTest(m_vCamera)) ? 0 : m_vCamera.DistanceSquared(m_pRoot[nFace]->GetVertex(40)->m_vPosition);
	m_nOrder[0] = 0; m_nOrder[1] = 1; m_nOrder[2] = 2; m_nOrder[3] = 3; m_nOrder[4] = 4; m_nOrder[5] = 5;
	for(int i=0; i<5; i++)
	{
		for(int j=0; j<5-i; j++)
		{
			if(fDistance[m_nOrder[j]] > fDistance[m_nOrder[j+1]])
				Swap(m_nOrder[j], m_nOrder[j+1]);
		}
	}

	// Now update the quad-tree (in order from nearest to farthest)
	for(nFace=0; nFace<6; nFace++)
		m_pRoot[m_nOrder[nFace]]->UpdateSurface();

	// Now update the factories (which may be handling surface objects)
	for(std::list<CPlanetaryFactory::Ref>::iterator it = m_llFactories.begin(); it != m_llFactories.end(); it++)
		(*it)->Update();
    glFinish();
}

void CPlanetaryMap::DrawSurface()
{
	//PROFILE("CPlanetaryMap::DrawSurface", 2);
	// Clear some counters for this render
	m_nObjects = 0;
	m_nTriangles = 0;
	m_nMaxDepth = 0;
	m_nNodes = 0;

	CMatrix4 mView = BuildModelMatrix();
	glPushMatrix(); LOG_GLERROR();
	glMultMatrixf(mView); LOG_GLERROR();

	bool bUseTexture;
	bUseTexture = m_pRoot[0]->HasTexture();
	//bUseTexture = false; //for debugging
	if(bUseTexture)
	{
		m_texArray.Flush(); LOG_GLERROR();
		glMatrixMode(GL_TEXTURE); LOG_GLERROR();
		m_texArray.Enable(); LOG_GLERROR();
	}

	// Draw the planet
	CGLShaderObject *pShader;
	if(IsInAtmosphere())
		pShader = &m_shGroundFromAtmosphere;
	else if(HasAtmosphere())
		pShader = &m_shGroundFromSpace;
	else
		pShader = &m_shNoAtmosphere;
	bool m_isPShaderValid = (IsPShaderValid() && pShader->IsValid());

	if(m_isPShaderValid)
	{
		pShader->Enable();
		InitScatteringShader(pShader); LOG_GLERROR();
	}
	else
	{
		glEnable(GL_LIGHTING); LOG_GLERROR();
		glEnable(GL_LIGHT0); LOG_GLERROR();
		glLightfv(GL_LIGHT0, GL_DIFFUSE, CQuaternion(1, 1, 1, 1)); LOG_GLERROR();
		glLightfv(GL_LIGHT0, GL_POSITION, CQuaternion(m_vLightPos.x, m_vLightPos.y, m_vLightPos.z, 1)); LOG_GLERROR();
	}

	// Then draw the objects in forward-Z order to minimize pixel overdraw
	for(int i=0; i<6; i++)
	{
	    m_nTriangles += m_pRoot[m_nOrder[i]]->DrawSurface();
	}

	if(m_isPShaderValid)
		pShader->Disable();
	else
		glDisable(GL_LIGHTING); LOG_GLERROR();

	// Draw the sky dome
	if(HasAtmosphere())
	{
		if(IsInAtmosphere())
			pShader = &m_shSkyFromAtmosphere;
		else
			pShader = &m_shSkyFromSpace;
		if(m_isPShaderValid)
		{
			pShader->Enable();
			InitScatteringShader(pShader); LOG_GLERROR();
			glFrontFace(GL_CW); LOG_GLERROR();
			glEnable(GL_BLEND); LOG_GLERROR();
			glBlendFunc(GL_ONE, GL_ONE); LOG_GLERROR();
			GLUquadricObj *pSphere = gluNewQuadric();
			gluSphere(pSphere, m_fAtmosphereRadius, 100, 100); LOG_GLERROR();
			gluDeleteQuadric(pSphere); LOG_GLERROR();
			glDisable(GL_BLEND); LOG_GLERROR();
			glFrontFace(GL_CCW); LOG_GLERROR();
			pShader->Disable(); LOG_GLERROR();
		}
		else
		{
			//glFrontFace(GL_CW); LOG_GLERROR();
			glEnable(GL_BLEND); LOG_GLERROR();
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); LOG_GLERROR();

            glPolygonMode(GL_FRONT, GL_FILL);

            // Update the color for the vertices of each sphere
            if (IsScatterCPU())
            {
                SVertex *pBuffer = m_sphereInner.GetVertexBuffer();
                int iz;
                for(iz=0; iz<m_sphereInner.GetVertexCount(); iz++)
                {
                    if((m_vCamera | pBuffer[iz].vPos) > 0)		// vCamera - Cheap optimization: Don't update vertices on the back half of the sphere
                        scatterSetColor(&pBuffer[iz]);
                }
                pBuffer = m_sphereOuter.GetVertexBuffer();
                for(iz=0; iz<m_sphereOuter.GetVertexCount(); iz++)
                {
                    if((m_vCamera | pBuffer[iz].vPos) > 0)		// vCamera - Cheap optimization: Don't update vertices on the back half of the sphere
                        scatterSetColor(&pBuffer[iz]);
                }
            }
            m_sphereInner.Draw();
            glFrontFace(GL_CW);
            m_sphereOuter.Draw();

			glDisable(GL_BLEND); LOG_GLERROR();
			glFrontFace(GL_CCW); LOG_GLERROR();

        }
	}

	if(bUseTexture)
	{
		glMatrixMode(GL_MODELVIEW); LOG_GLERROR();
		m_texArray.Disable();
	}

    glFinish();

	// Now draw the factories (which may be handling surface objects)
	for(std::list<CPlanetaryFactory::Ref>::iterator it = m_llFactories.begin(); it != m_llFactories.end(); it++)
		(*it)->Draw();

	glPopMatrix(); LOG_GLERROR();
	glFinish(); LOG_GLERROR();
}

float CPlanetaryMap::GetHeightAboveGround(const CVector &v)
{
	CVector vPos = m_qRotate.UnitInverse().TransformVector(v - m_vTranslate);
	float fAltitude = vPos.Magnitude();
	CPlanetaryMapCoord coord(vPos);
	for(int i=0; i<6; i++)
	{
		if(m_pRoot[i]->HitTest(coord))
			return fAltitude - m_pRoot[i]->GetHeight(coord);
	}
	return fAltitude - m_fRadius;
}

void CPlanetaryMap::scatterCpuStart()
{
    m_vLightDirection = m_vLightPos / m_vLightPos.Magnitude();

    m_nSamples = 4;		// Number of sample rays to use in integral equation
    m_Kr4PI = m_fKr*4.0f*PI;
    m_Km4PI = m_fKm*4.0f*PI;

    m_scfScale = 1 / (m_fOuterRadius - m_fInnerRadius); // there is already m_fScale in csrttransform

    m_fWavelength4[0] = powf(m_fWavelength[0], 4.0f);
    m_fWavelength4[1] = powf(m_fWavelength[1], 4.0f);
    m_fWavelength4[2] = powf(m_fWavelength[2], 4.0f);

    m_fRayleighScaleDepth = 0.25f;
    m_fMieScaleDepth = 0.1f;
    m_pbOpticalDepth.MakeOpticalDepthBuffer(m_fInnerRadius, m_fOuterRadius, m_fRayleighScaleDepth, m_fMieScaleDepth);
}

void CPlanetaryMap::scatterSetColor(SVertex *pVertex)
{
    CVector vPos = pVertex->vPos;

    // Get the ray from the camera to the vertex, and its length (which is the far point of the ray passing through the atmosphere)
    //CVector vCamera = CCameraTask::GetPtr()->GetPosition();
    CVector vCamera = m_vCamera; //m_vCamera - camera pos relative to planet?
    CVector vRay = vPos - vCamera;
    float fFar = vRay.Magnitude();
    vRay /= fFar;

    // Calculate the closest intersection of the ray with the outer atmosphere (which is the near point of the ray passing through the atmosphere)
    float B = 2.0f * (vCamera | vRay);
    float C = (vCamera | vCamera) - m_fOuterRadius*m_fOuterRadius;
    float fDet = CMath::Max(0.0f, B*B - 4.0f * C);
    float fNear = 0.5f * (-B - sqrtf(fDet));

    bool bCameraInAtmosphere = false;
    bool bCameraAbove = true;
    float fCameraDepth[4] = {0, 0, 0, 0};
    float fLightDepth[4];
    float fSampleDepth[4];
    if(fNear <= 0)
    {
        // If the near point is behind the camera, it means the camera is inside the atmosphere
        bCameraInAtmosphere = true;
        fNear = 0;
        float fCameraHeight = vCamera.Magnitude();
        float fCameraAltitude = (fCameraHeight - m_fInnerRadius) * m_scfScale;
        bCameraAbove = fCameraHeight >= vPos.Magnitude();
        float fCameraAngle = ((bCameraAbove ? -vRay : vRay) | vCamera) / fCameraHeight;
        m_pbOpticalDepth.Interpolate(fCameraDepth, fCameraAltitude, 0.5f - fCameraAngle * 0.5f);
    }
    else
    {
        // Otherwise, move the camera up to the near intersection point
        vCamera += vRay * fNear;
        fFar -= fNear;
        fNear = 0;
    }

    // If the distance between the points on the ray is negligible, don't bother to calculate anything
    if(fFar <= DELTA)
    {
        glColor4f(0, 0, 0, 1);
        return;
    }

    // Initialize a few variables to use inside the loop
    float fRayleighSum[3] = {0, 0, 0};
    float fMieSum[3] = {0, 0, 0};
    float fSampleLength = fFar / m_nSamples;
    float fScaledLength = fSampleLength * m_scfScale;
    CVector vSampleRay = vRay * fSampleLength;

    // Start at the center of the first sample ray, and loop through each of the others
    vPos = vCamera + vSampleRay * 0.5f;
    for(int i=0; i<m_nSamples; i++)
    {
        float fHeight = vPos.Magnitude();

        // Start by looking up the optical depth coming from the light source to this point
        float fLightAngle = (m_vLightDirection | vPos) / fHeight;
        float fAltitude = (fHeight - m_fInnerRadius) * m_scfScale;
        m_pbOpticalDepth.Interpolate(fLightDepth, fAltitude, 0.5f - fLightAngle * 0.5f);

        // If no light light reaches this part of the atmosphere, no light is scattered in at this point
        if(fLightDepth[0] < DELTA)
            continue;

        // Get the density at this point, along with the optical depth from the light source to this point
        float fRayleighDensity = fScaledLength * fLightDepth[0];
        float fRayleighDepth = fLightDepth[1];
        float fMieDensity = fScaledLength * fLightDepth[2];
        float fMieDepth = fLightDepth[3];

        // If the camera is above the point we're shading, we calculate the optical depth from the sample point to the camera
        // Otherwise, we calculate the optical depth from the camera to the sample point
        if(bCameraAbove)
        {
            float fSampleAngle = (-vRay | vPos) / fHeight;
            m_pbOpticalDepth.Interpolate(fSampleDepth, fAltitude, 0.5f - fSampleAngle * 0.5f);
            fRayleighDepth += fSampleDepth[1] - fCameraDepth[1];
            fMieDepth += fSampleDepth[3] - fCameraDepth[3];
        }
        else
        {
            float fSampleAngle = (vRay | vPos) / fHeight;
            m_pbOpticalDepth.Interpolate(fSampleDepth, fAltitude, 0.5f - fSampleAngle * 0.5f);
            fRayleighDepth += fCameraDepth[1] - fSampleDepth[1];
            fMieDepth += fCameraDepth[3] - fSampleDepth[3];
        }

        // Now multiply the optical depth by the attenuation factor for the sample ray
        fRayleighDepth *= m_Kr4PI;
        fMieDepth *= m_Km4PI;

        // Calculate the attenuation factor for the sample ray
        float fAttenuation[3];
        fAttenuation[0] = expf(-fRayleighDepth / m_fWavelength4[0] - fMieDepth);
        fAttenuation[1] = expf(-fRayleighDepth / m_fWavelength4[1] - fMieDepth);
        fAttenuation[2] = expf(-fRayleighDepth / m_fWavelength4[2] - fMieDepth);

        fRayleighSum[0] += fRayleighDensity * fAttenuation[0];
        fRayleighSum[1] += fRayleighDensity * fAttenuation[1];
        fRayleighSum[2] += fRayleighDensity * fAttenuation[2];

        fMieSum[0] += fMieDensity * fAttenuation[0];
        fMieSum[1] += fMieDensity * fAttenuation[1];
        fMieSum[2] += fMieDensity * fAttenuation[2];

        // Move the position to the center of the next sample ray
        vPos += vSampleRay;
    }

    // Calculate the angle and phase values (this block of code could be handled by a small 1D lookup table, or a 1D texture lookup in a pixel shader)
    float fAngle = -vRay | m_vLightDirection;
    float fPhase[2];
    float fAngle2 = fAngle*fAngle;
    float g2 = m_fG*m_fG;
    fPhase[0] = 0.75f * (1.0f + fAngle2);
    fPhase[1] = 1.5f * ((1 - g2) / (2 + g2)) * (1.0f + fAngle2) / powf(1 + g2 - 2*m_fG*fAngle, 1.5f);
    fPhase[0] *= m_fKr * m_fEsun;
    fPhase[1] *= m_fKm * m_fEsun;

    // Calculate the in-scattering color and clamp it to the max color value
    float fColor[3] = {0, 0, 0};
    fColor[0] = fRayleighSum[0] * fPhase[0] / m_fWavelength4[0] + fMieSum[0] * fPhase[1];
    fColor[1] = fRayleighSum[1] * fPhase[0] / m_fWavelength4[1] + fMieSum[1] * fPhase[1];
    fColor[2] = fRayleighSum[2] * fPhase[0] / m_fWavelength4[2] + fMieSum[2] * fPhase[1];
    fColor[0] = CMath::Min(fColor[0], 1.0f);
    fColor[1] = CMath::Min(fColor[1], 1.0f);
    fColor[2] = CMath::Min(fColor[2], 1.0f);

    // Last but not least, set the color
    pVertex->cColor = CColor(fColor[0], fColor[1], fColor[2]);
}
