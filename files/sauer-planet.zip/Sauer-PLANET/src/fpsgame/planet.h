// planet.h: implements rendering for planets
// most of code from Planet_Quad.cpp; Sean O'Neil
// binding with Sauer: :)n, 2009

/*
Copyright (c) 2000, Sean O'Neil (s_p_oneil@hotmail.com)
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
* Neither the name of the project nor the names of its contributors may be
  used to endorse or promote products derived from this software without
  specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

struct planetset
{
    fpsclient &cl;

    //for planet
	std::vector<CPlanetaryMap> m_vPlanet;
	int m_nPolygonMode;
	bool m_bUpdate;
	bool m_bHDR;
	bool m_bHDRSquare;
	float m_fSplitFactor;
	float m_fExposure;
	char confFile[240];
	bool m_isPlanetRendering;

	CGLShaderObject m_shHDR;
	CGLFrameBufferObject m_fb;
	CVector m_vLightPos;
    CLog logger; //must be a "class" var, else calls to LogInfo other than from main will not work.

    int planetTimerMs;

    struct planet : dynent
    {
        int etype, mapmodel;
        planetset *ms;

        planet(const entity &e, planetset *ms) :
            etype(e.type),
            mapmodel(e.attr2),
            ms(ms)
        {
            //this constructor runs when object instantiated (after press E),
            //not when model first placed in edit mode

            state = CS_ALIVE;
            type = ENT_INANIMATE;
            yaw = float((e.attr1+7)-(e.attr1+7)%15);

            const char *mdlname = mapmodelname(e.attr2);
            if(mdlname) setbbfrommodel(this, mdlname);

            char* tmss = &ms->confFile[0];
            sprintf(tmss, "packages/planet/%d.conf", e.attr1);
            conoutf("planet attr: (%d,%d,%d) %s %s", e.attr1, e.attr2, e.attr3, ms->confFile, mdlname);

            glFinish();
            ms->planetMain(); //does no drawing
            ms->planetStart();
            glFinish();
        }

    };

    planetset(fpsclient &cl) : cl(cl)
    {
        m_isPlanetRendering = false;
        planetTimerMs = 0;
        CCOMMAND(platform, "ii", (planetset *self, int *tag, int *newdir), self->triggerplatform(*tag, *newdir));
    }

    int planetMain() //int argc, char *argv[]
    {
        logger.Init(Debug, "Planet_Quad");
        LogInfo("Starting app1 (%s)", g_strBuildStamp.c_str());

        // from old code:
        // CKernel *pKernel = CKernel::Create();
        //pKernel->AddTask(CCameraTask::Create(50)); ...

        //from VideoTask.h::Start() ---
		GLenum err = glewInit();
		if(err != GLEW_OK)
		{
			LogCritical((const char *)glewGetErrorString(err));
			LogAssert(false);
			return false;
		} // ---

        return 0;
    }

	bool planetStart()
	{
		CSimpleHeightMapFactoryType::Load();
		CSimpleCraterFactoryType::Load();
		CSimpleColorMapFactoryType::Load();
		CMixedHeightMapFactoryType::Load();
		CGrassFactoryType::Load();

		/*CInputTask::GetPtr()->AddInputEventListener(this);
		CCameraTask::GetPtr()->SetPosition(CVector(0, 0, 15.0f));
		CCameraTask::GetPtr()->SetThrust(1.0f);*/
		m_nPolygonMode = GL_FILL;
		m_bHDR = true;
		m_bUpdate = true;
		m_fSplitFactor = 16.0f;
		m_fExposure = 2.0f;

		m_vPlanet.reserve(50);
		CPropertySet prop;
		prop.LoadFile(confFile); //"Planet_Quad.conf"
		for(int i=1; ; i++)
		{
			char szPrefix[256];
			sprintf(szPrefix, "planet.%d.", i);
			conoutf("szPrefix: %s", szPrefix);
			prop.SetPrefix(szPrefix);
			if(prop.GetProperty("position") == NULL)
				break;
			m_vPlanet.push_back(CPlanetaryMap());
			m_vPlanet.back().Init(prop);
		}

        /*const char *vendor = (const char *)glGetString(GL_VENDOR);*/
		extern SDL_Surface *screen;
		extern void gl_getvendor(char *invendor);
        char vendor[1024];
        gl_getvendor(&vendor[0]); //

		// ATI doesn't support rectangular textures in GLSL
		m_bHDRSquare = !strstr(vendor, "NVIDIA");
		if(strstr(vendor, "NVIDIA"))
		{
			m_fb.Init(screen->w, screen->h, GL_FLOAT_RGBA16_NV);
			if(m_fb.IsValid())
				m_shHDR.Init("packages/planet/shaders/HDRVert.glsl", "packages/planet/shaders/HDRRectFrag.glsl");
		}
		else if(strstr(vendor, "ATI"))
		{
			m_fb.Init(TEXWID, TEXHEI, GL_RGBA_FLOAT16_ATI);
			if(m_fb.IsValid())
				m_shHDR.Init("packages/planet/shaders/HDRVert.glsl", "packages/planet/shaders/HDRSquareFrag.glsl");
		}
		else
		{
			m_fb.Init(TEXWID, TEXHEI, GL_RGBA16F_ARB);
			if(m_fb.IsValid())
				m_shHDR.Init("packages/planet/shaders/HDRVert.glsl", "packages/planet/shaders/HDRSquareFrag.glsl");
		}

		m_vLightPos = CVector(-100, 0, 0);
		render_PlanetQuadUpdate(true); //must init, else crash w true/false switching.
		return true;
	}

	void planetStop()
	{
		m_fb.Cleanup();
		m_shHDR.Cleanup();
		m_vPlanet.clear();
		CPlanetaryObjectType::Unload();

		CSimpleHeightMapFactoryType::Unload();
		CSimpleCraterFactoryType::Unload();
		CSimpleColorMapFactoryType::Unload();
		CMixedHeightMapFactoryType::Unload();
		CGrassFactoryType::Unload();
	}

    void preloadplanets()
    {
        //loopi(NUMMONSTERTYPES) loadmodel(monstertypes[i].mdlname, -1, true);
    }

    vector<planet *> planets;

    void planetclear(int gamemode)
    {
        if(planets.length())
        {
            cleardynentcache();
            planets.deletecontentsp();
        }

        if (!m_vPlanet.empty()) planetStop();
        // if(!m_dmsp && !m_classicsp) return; //try show in all modes
        loopv(cl.et.ents)
        {
            const entity &e = *cl.et.ents[i];
            if(e.type!=PLANET) continue;
            planet *m = new planet(e, this);
            planets.add(m);
            m->o = e.o;
            entinmap(m);
            updatedynentcache(m);
        }
    }

    void triggerplatform(int tag, int newdir)
    {
        newdir = max(-1, min(1, newdir));
        loopv(planets)
        {
            planet *m = planets[i];
            if(m->state!=CS_ALIVE) continue;
            if(!newdir)
            {
                m->vel.neg();
            }
            else
            {
                m->vel = vec(0, 0, newdir*m->vel.z);
            }
        }
    }

    void update(int curtime)
    {
        if(!curtime) return;
        planetTimerMs += curtime;

        loopv(planets)
        {
            planet *m = planets[i];
            if(m->state!=CS_ALIVE) continue;
            else if(m->moving || (m->onplayer && (m->onplayer->state!=CS_ALIVE || m->lastmoveattempt <= m->onplayer->lastmove))) moveplayer(m, 1, true);
        }
    }

    void planetrender()
    {
        // render at larger time interval - 100 ms...
        bool dontskip = true;
        if (planetTimerMs < 200) dontskip = false;
        else planetTimerMs = 0;

        if(planets.length())
        {
            m_isPlanetRendering = true;

            loopv(planets)
            {
                planet &m = *planets[i];
                if(m.state!=CS_ALIVE) continue;
                vec o(m.o);
                o.z -= m.eyeheight;
                const char *mdlname = "carrot"; //old code to auto insert carrot
                if(!mdlname) continue;
                m.yaw += 0.5f; //animate carrot model - only yaw works, roll doesn't
                //rendermodel(NULL, mdlname, ANIM_MAPMODEL|ANIM_LOOP, o, m.yaw, 0, MDL_LIGHT | MDL_SHADOW | MDL_CULL_VFC | MDL_CULL_DIST | MDL_CULL_OCCLUDED, &m);
                //render_PlanetQuadUpdate4(o); //old test opengl drawing function
            }
            render_PlanetQuadUpdate(dontskip);
            glFinish();
            m_isPlanetRendering = false;
        }
    }

    //old test opengl drawing function - draws from pos of object to player.
    void render_PlanetQuadUpdate4(const vec &ino)
    {
        extern physent *camera1;
        extern void getcamorient(vec &wpos, vec &cdir, vec &cright, vec &cup, vec &co);
        vec co = camera1->o; //no good?
        vec worldpos, camdir, camright, camup, camo; //worldposseems to be loc of target?
        getcamorient(worldpos, camdir, camright, camup, camo);

        //save old vals
        int oldMode;
        glGetIntegerv( GL_MATRIX_MODE, &oldMode );
        GLboolean oldCullEnable = glIsEnabled(GL_CULL_FACE);

        glPushMatrix();
        glDisable(GL_CULL_FACE);
        glMatrixMode( GL_MODELVIEW );

        //.... draw here
        glLineWidth(2);
        glBegin(GL_TRIANGLE_STRIP);
        /*glColor3f(1,0.5f,0.5f);
        glVertex3f(0, 0, 0);
        glColor3f(0.5f,1,0.5f);
        glVertex3f(250, 0, 600);
        glColor3f(0.5f,0.5f,1);
        glVertex3f(250, 500, 600);
        glColor3f(1,0.1f,0.1f);
        glVertex3f(0, 0, 1000); */

        glColor3f(1,0.5f,0.5f);
        glVertex3f(ino.x, ino.y, ino.z);
        glColor3f(0.5f,1,0.5f);
        glVertex3f(ino.x+30, ino.y, ino.z+30);
        glColor3f(0.5f,0.5f,1);
        glVertex3f(ino.x, ino.y+30, ino.z+30);
        glColor3f(1,0.1f,0.1f);
        //glVertex3f(ino.x, ino.y, ino.z+60);
        //glVertex3f(co.x+10, co.y+10, co.z+10); //way off.. doesn't update
        //glVertex3f(camo.x, camo.y, camo.z); // also way off, doesn't update either.
        //glVertex3f(cl.player1->o.x, cl.player1->o.y, cl.player1->o.z); // doesn't appear at all
        glVertex3f(worldpos.x, worldpos.y, worldpos.z); // k, but is it target? Nope, seems OK..

        glEnd(); LOG_GLERROR();

        if (oldCullEnable) glEnable(GL_CULL_FACE);
        glMatrixMode( oldMode );
        glPopMatrix();
    }

    void render_PlanetQuadUpdate(bool dontskip)
    {

        int i;
        extern physent *camera1;
        extern SDL_Surface *screen;
        extern bool shadowmapping;

        if(shadowmapping) return;

        int oldMode;
        glGetIntegerv( GL_MATRIX_MODE, &oldMode );
        GLboolean oldTex2DMap;
        glGetBooleanv( GL_TEXTURE_2D, &oldTex2DMap );
        int oldTex2DBind;
        glGetIntegerv( GL_TEXTURE_BINDING_2D, &oldTex2DBind );

        GLboolean oldCullEnable = glIsEnabled(GL_CULL_FACE);
        GLboolean oldDepthTest = glIsEnabled(GL_DEPTH_TEST);
        GLboolean oldBlend = glIsEnabled(GL_BLEND);

        glDisable(GL_CULL_FACE);
        //glBindTexture(GL_TEXTURE_2D, 0); // unlink textures - this kills the blend
        if(m_bHDR && m_fb.IsValid())
        {
            m_fb.EnableFrameBuffer();
            if(m_bHDRSquare)
                glViewport(0, 0, TEXWID, TEXHEI); LOG_GLERROR();

            //clear framebuffer always, since we'll always draw planet surface triangles
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        }

        CVector vCamera = CVector(camera1->o.x, camera1->o.y, camera1->o.z);

        // Cheap collision detection/response (from old original code)
        /*CVector vCamera = CCameraTask::GetPtr()->GetPosition();
        for(i=0; i<(int)m_vPlanet.size(); i++)
        {
            if(m_vPlanet[i].GetHeightAboveGround(vCamera) < 0.0f)
                CCameraTask::GetPtr()->Bounce();
        }*/

        //Update the planets
        //TODO: CQuaternion(0.5f, 0.3f, 0.1f, 0.1f) should be
        //CCameraTask::GetPtr()->GetCamera().m_qRotate
        if (dontskip)
        {
            if(m_bUpdate)
            {
                for(i=0; i<(int)m_vPlanet.size(); i++)
                    m_vPlanet[i].UpdateSurface(m_vLightPos, vCamera, CQuaternion(0.5f, 0.3f, 0.1f, 0.1f), 1.25f, m_fSplitFactor);
            }
        }

        // Draw the planets
        glPolygonMode(GL_FRONT, m_nPolygonMode); LOG_GLERROR();
        for(i=0; i<(int)m_vPlanet.size(); i++)
            m_vPlanet[i].DrawSurface();
        glPolygonMode(GL_FRONT, GL_FILL); LOG_GLERROR();/**/

        //this below renders framebuffer to window
        if(m_bHDR && m_fb.IsValid())
        {
            //save old vals
            m_fb.DisableFrameBuffer();
            if(m_bHDRSquare)
                glViewport(0, 0, screen->w, screen->h);

            glPushMatrix();
            glLoadIdentity();
            glMatrixMode(GL_PROJECTION);
            glPushMatrix();
            glLoadIdentity();
            int nViewport[4];
            glGetIntegerv(GL_VIEWPORT, nViewport);
            glOrtho(0, nViewport[2], nViewport[3], 0, -1, 1);

            m_fb.EnableTexture();
            m_shHDR.Enable();
            m_shHDR.SetUniformParameter1f("fExposure", m_fExposure);
            m_shHDR.SetUniformParameter1i("s2Test", 0);

            glColor4f(1.0f, 1.0f, 1.0f, 1.0f); //affects blending color
            glEnable(GL_BLEND);												// enable blending
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);				// set alpha blending
            glBegin(GL_QUADS);
            {
                if(m_bHDRSquare)
                {
                    glTexCoord2f(0, 0); glVertex2i(0, screen->h);
                    glTexCoord2f(1, 0); glVertex2i(screen->w, screen->h);
                    glTexCoord2f(1, 1); glVertex2i(screen->w, 0);
                    glTexCoord2f(0, 1); glVertex2i(0,  0);
                }
                else
                {
                    glTexCoord2f(0, 0); glVertex2i(0, screen->h);
                    glTexCoord2f(screen->w, 0); glVertex2i(screen->w, screen->h);
                    glTexCoord2f(screen->w, screen->h); glVertex2i(screen->w, 0);
                    glTexCoord2f(0, screen->h); glVertex2i(0,  0);
                }
            }
            glEnd();
            glDisable(GL_BLEND);											// disable blending

            m_shHDR.Disable();
            m_fb.DisableTexture();

            glPopMatrix();
            glMatrixMode(GL_MODELVIEW); // ->commenting this screws the blending floor texture, even w unlink textures?
            glPopMatrix();

        }

        glBindTexture(GL_TEXTURE_2D, oldTex2DBind);
        if (oldTex2DMap) glEnable(GL_TEXTURE_2D); else glDisable(GL_TEXTURE_2D);

        if (oldCullEnable) glEnable(GL_CULL_FACE);
        glMatrixMode( oldMode );

        glFinish();
    }


};

