Sauer-planet v0.001 - demo of procedural planets in Sauerbraten

# INTRO
# PACKAGE CONTENTS
# PHOTO GALLERY
# USAGE
# CULPRITS / NOTES
# DETAILS
# COMPILING W/ CODEBLOCKS + MINGW UNDER WINDOWS
# WHY?? 


# INTRO

This package is a, not fully working, demonstration of procedural planets in the open-source engine Sauerbraten (http://www.sauerbraten.org/). It is based on CTF Edition (June 17, 2008) for Windows (http://downloads.sourceforge.net/sauerbraten/sauerbraten_2008_06_20_ctf_edition_win32_setup.exe), and includes sources, patch files and a Windows executable (a Sauerbraten installation is required to run the executable).   

The procedural code is taken almost verbatim from GPL'd code by Sean O'Neil from:
* [http://web.archive.org/web/20061104133933/http://www.sponeil.org/Sandbox-src.zip Sandbox Source Code]
* [http://web.archive.org/web/20061104133933/http://www.sponeil.org/Sandbox-exe.zip Sandbox Executables]

described in a series of articles on Gamasutra.com, "A real time procedural universe":

** [http://www.gamasutra.com/features/20010302/oneil_01.htm "A Real-Time Procedural Universe, Part 1: Generating Planetary Bodies"] 
** [http://www.gamasutra.com/features/20010810/oneil_01.htm Gamasutra - Features - "A Real-Time Procedural Universe, Part Two: Rendering Planetary Bodies"]
** [http://www.gamasutra.com/features/20020712/oneil_01.htm Gamasutra - Features - "A Real-Time Procedural Universe, Part Three: Matters of Scale"]
** [http://www.gamasutra.com/features/20060112/oneil_01.shtml Gamasutra - Feature - "A Real-Time Procedural Universe, Part Four: Dynamic Ground Textures and Objects"] 


# PACKAGE CONTENTS

The contents have the same layout as the directory structure for Sauerbraten on Windows - you can just copy the package contents (all dependencies should be there too) over to a Sauerbraten installation folder, and run sauerbraten_planet-mingw.bat to start the executable. The executable is compiled with Mingw using Codeblocks. 

Also, source code and a Codeblocks workspace project is provided - copying over should also replace the necessary files in Sauerbraten's source directory. There are also diff .patch files, both in respect to Sauerbraten CTF Edition (June 17, 2008) source, and in respect to Sandbox procedural planet code. 


# PHOTO GALLERY

http://img141.imageshack.us/gal.php?g=12sauerplanet07.png

http://img141.imageshack.us/my.php?image=12sauerplanet07.png


# USAGE

sauerbraten_planet-mingw.bat automatically starts a map called untitled (provided in packages/base), which is an empty map, in fps (first person shooter) mode of Sauerbraten. Once in it:
* Press E to activate edit mode
* (Alt: use /togpshade - see below)
* Choose a tile on the floor and type /newent planet 1
* Press E to exit edit mde
* Press E to enter edit mode again
* After a slight delay (and a noticeable framerate drop) the planets should start rendering. 
Then, look for two small dots overlaid on the screen, and fly towards them. You should eventually arrive to two spherical renderings like on: 
http://img141.imageshack.us/my.php?image=09sauerplanet05.png

Additional to the new entity type 'planet', there are some added commands for the in-game console: 
/togpshade N 
(N can be 0, 1, 2) - toggle different shading of planet atmosphere (hardware shader, software shader, software scatter shader) - see below
/moveme X Y Z
A command like /moveme 100 100 100 will try to take you to x=100, y=100, z=100 position in the game world, by tossing you there with high speed, in an attempt to overcome the physics engine :) It doesn't take you exactly to the required location, but close enough. (Current position of player is also rendered in the console). 


# CULPRITS / NOTES

- There is no interaction whatsoever with the planet renderings. 
- A serious crash of the GPU (at least on ATI Mobility Radeon) is caused by src\engine\planet/Planet_Quad/PlanetaryMapNode.cpp line 674: m_boVertex.Enable(&m_shape); unfortunately, it seems this step is required in order to properly render planet surfaces. So ... 
- ... There is a bug with the graphics, so the planet surfaces, although calculated, are not rendered. Only planet atmospheres are rendered on screen. 
- There is a bug with the planet atmospheres blending, so they are represented as a dense wireframe. 
- Using the /togpshade command while planets are rendered can result with a crash; use before planets are placed. 


# DETAILS

By executing the command

/newent planet N

in edit mode, and activating the planet entity (by exiting then enteirng edit mode), will read the text file named "N.conf" in packages/planet. So, '/newent planet 1' will read the provided packages/planet/1.conf file, which is a near copy of Planet_Quad.conf (from Sandbox sources). Each .conf file can contains information about multiple planets, and properties for each of them (such as noise map specifications). Note that rendered planets will not be placed in respect to the entity placeholder - but instead at the absolute coordinates specified in the .conf file. 

In the Sandbox sources: 
- the Planet_Quad project shows procedural surface generation based on a .conf file and uses a hardware shader for the atmosphere. Note that the code in this package was produced using a graphics card without support for hardware shaders, so the atmosphere is rendered as wireframe:

http://img139.imageshack.us/my.php?image=01planetquad01.png
http://img136.imageshack.us/my.php?image=02planetquad02.png

- The ScatterCPU project shows a software atmosphere scattering shader, which on the same graphics card is rendered like this: 

http://img91.imageshack.us/my.php?image=03scattercpu01.png
http://img78.imageshack.us/my.php?image=04scattercpu02.png

This demo package includes the code for both the hardware renderer and software scattering renderer (although due to the above blending bug, the software scattering renderer is also rendered as wireframe in this demo), which can be toggled using: 

/togpshade N

where N can be: 
 - 0 (hardware), http://img141.imageshack.us/my.php?image=09sauerplanet05.png (38-41 fps)**
 - 1 (software - simple), 
 - 2 (software scattering). http://img136.imageshack.us/my.php?image=11sauerplanet07b.png (8-10 fps)

** Note that 38-41 fps was obtained before any software rendering code was present at all - after the software rendering and the toggle, framerate drops to about 19 fps, regardless of the rendering method used. In both cases, a debug MingW executable under Win XP was used; initially at empty map, before planets are placed, it displays about 120 fps. You can also try editing the 1.conf file, and setting one of the planets to be 'big' - say at (1000,1000,1000), with a radius of 500 - in this case, speed can drop to 9 fps. 

From a Sauerbraten perspective, the planet class is a "dynamic entity" just as monsters (the planet.h file is based on monster.h) - this is so to allow for a possility to place and save "planets" in a map, using the map edit facilities of Sauerbraten - and the possibility to become a part of the physics engine. From the perspective of Sandbox procedural planet sources, it implements code in the Planet_Quad and ScatterCPU projects. 


# COMPILING W/ CODEBLOCKS + MINGW UNDER WINDOWS

You can use the provided CodeBlocks workspace (and project) file. Maybe not trivial (CodeBlocks 8.02), see: 
#11565: Menus not Building Correctly?
http://cubeengine.com/forum.php4?action=display_thread&thread_id=1&start=11558

So needs 
TDM-MinGW / TDM-GCC
(exe that can be unpacked with PeaZip):
http://sourceforge.net/project/downloading.php?group_id=200665&filename=tdm-mingw-1.902.0-f1.exe&a=36511655 

And also:
http://downloads.sourceforge.net/mingw/binutils-2.19.1-mingw32-bin.tar.gz 
http://downloads.sourceforge.net/mingw/mingw-utils-0.3.tar.gz
http://kent.dl.sourceforge.net/sourceforge/gnuwin32/libpng-1.2.35-lib.zip
http://kent.dl.sourceforge.net/sourceforge/glew/glew-1.5.1-win32.zip (must build from source)
http://www.libsdl.org/release/SDL-devel-1.2.13-mingw32.tar.gz
if there are problems.. 


# WHY?? 

I recently got to know Sauerbraten, and I found it to be most playable and smooth open source engine.. On the other hand, I'm fond of FPS, but not too much - I like a bit of adventure thrown in :) That is why I liked Freelancer - because it allowed the "seamless descent" from space to a planet, and had most of the "go shoot, go sell, go buy" mechanics.. 

So eventually, I'd love an open-source, single-player, open-ended game that would allow me to: 

1. Start on surface
2. Shoot some monsters
3. Get into a ship and launch to space
4. Go mine resources (or shoot ships)
5. Descent on surface
6. Shoot some monsters
7. Possibly go in a portal loading an FPS map; finishing or exiting it takes you back to planet surface
8. Go to NPC, sell booty, buy ammo
9. Go back to 1 :) 

And Sauerbraten actually provides most of this for me - except for the planets. So although I have very basic knowledge of C++ and OpenGL, when I saw how 'compatible' the sources for the Sandbox procedural planets and rest of Sauerbraten looked, it became almost an obsession to try and integrate them - at least as a proof of concept :) 

As both Sauerbraten and the procedural Sandbox code are open-source, my particular work in their integration is also under the same terms and conditions. 

:)n 2009

