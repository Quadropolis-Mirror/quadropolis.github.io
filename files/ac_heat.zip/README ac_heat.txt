***Heatwave, by Andrez
Medium-size night desert themed map; flag modes/FFA capable!


License
BY-NC-SA/3.0


More AC stuff at:
http://andrezweb.altervista.org/ac/
http://ac-akimbo.net