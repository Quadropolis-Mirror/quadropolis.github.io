Monster Pen map for Sauerbraten
11 January 2009 (2nd release)

Fred Bauer (fred.w.bauer@gmail.com)
Created with Sauerbraten svn revision 237.

This is my first attempt at a Sauerbraten map. I started with the idea of blowing the hell out of confined monsters for stress relief but now it's elaborate enough that someone else might enjoy it. It's playable as a SP game with nothing fancy, just arrange the intersection of monsters and ordinance.

Installation: All the textures and models are part of the standard sauerbraten distribution as far as I know. Just copy the monsterpen.ogz file to packages/base/ directory and "`sp monsterpen"
