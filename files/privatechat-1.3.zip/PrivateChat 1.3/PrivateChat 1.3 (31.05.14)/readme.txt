Instruductions:

- Write down following text into your autoexec.cfg (without "- "):
- exec privatechat.cfg
- Copy privatechat.cfg next to your redeclipse.bat
- Start Red Eclipse
- Press "M" (default) to open the gui.

Or:

- Copy autoexec.cfg and privatechat.cfg next to redeclipse.bat
- Start Red Eclipse
- Press "M" (default) to open the gui.

Thanks for downloading!!
PrivateChat by Frederik Shull �copyright 05/14.