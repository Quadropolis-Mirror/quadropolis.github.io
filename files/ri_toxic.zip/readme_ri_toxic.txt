
	RandumIdiot's AssaultCube Maps

_________________________
|			|
|	Who Am I	| Come to my site, full of guides, maps and
|			| other neat stuff for AssaultCube made by me.
|	  ????		|
|	 ??  ??		| http://www.ri-ac.co.nr/ 
|	    ??		|
|	   ??		| Enjoy!
|	   ??		|
|			|
|	   ??		|
|	   ??		| Contact: RandumIdiotMaps@gmail.com
|			|
| The real question is,	|
|     Who are you	|
_________________________


Don't know how to open this map in AssaultCube?
Friendly explanations @ http://www.ri-ac.co.nr/runmap


Mapname: ri_toxic
Version: 1.0
Released: Tuesday, 25th December, 2007.


Included files with this zip:
	1) ri_toxic.cgz
	2) readme_ri_toxic.txt


ri_toxic is RandumIdiot's first good map ever. High quality, nice 
layout. It has been released on the 25th of December, as a Christmas 
present to the AssaultCube community.

ri_toxic started out as an idea to create a half indoor, half outdoor 
map for ac that contained high up mapmodel's that players could walk 
around on to spectate the game (this seemed especially useful, so that 
clan members could judge a players techniques and skills before 
allowing a player to join the clan). This map was planned to be called 
ri_spectate.

Some time later, and I discovered that, spectate mode in AssaultCube 
0.94 was going to become reality and that version 0.94 was not too far 
away from release. This meant that the idea was scrapped. The map lost 
all of its spectator geometry and the map continued under the new name 
'ri_new' while I decided upon a new name.

So, over the past few months, this map has transformed from a crappy 
"spectate" idea, into this high quality, nice layout, ri_toxic map :)

Enjoy!


Special note: This map will be in the official 0.94 distribution of AC.


Want a story?
_____________
Once upon a time, there were people that wrecked havock and created a 
huge mess, destroying buildings, etc etc... they were known as RVSF
... and of course there were the terrorists, known as CLA.

CLA found a nice, recently abandoned storage complex. Most of 
the stuff stored there had been removed.. and that's what made it so 
perfect... Perfect for what? Why dumping toxic waste of course!

CLA had only just started dumping waste (which they were making 
thousands of dollars off) when RVSF got jealous and deployed themselves 
into the abandoned complex to gain control of it and carry out CLA's 
plans for their own profit.

What followed that? Why, havock of course!


_______________________________________________________________________
LICENSE

My maps and website contents are FREEWARE; however they remain copyrights 
of RandumIdiot (any content or parts derived from other works remain 
rights of their respective owners). The authors (RandumIdiot and any 
other respective owners) keeps all rights to them.

You may redistribute the maps unmodified on any media; the only changes 
you may make to them is recompression in different formats. You may only
use my maps in the original AssaultCube distributions (which can be found
at http://assault.cubers.net) and you may only redistribute them with 
the intention of using them in the original AssaultCube distributions.

If you wish to modify or use my maps in any other way, you must gain 
explicit permission from me. 
This can be done by emailing me at: RandumIdiotMaps@gmail.com
If you gain permission, you MUST abide by the terms and conditions.

The contents of "http://www.ri-ac.co.nr" can be redistributed under the 
following conditions:
	a) You post a link back to the original location of the resource
	   you copied.
	b) You state/recognise the original author(s).
	c) You do not mislead who the original author(s) were.

My maps and website contents are distributed in the hope that they will 
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty 
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. You may use them 
so long as you do not blame the authors for any damages incurred.

The only way that the above license does not adhere, is if you gain 
explicit permission from the author(s).

If any of this license confuses you, email for clarification at: 
						RandumIdiotMaps@gmail.com