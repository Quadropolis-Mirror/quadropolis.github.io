Copy /packages over your Sauerbraten/packages directory.

or 

Go into /packages/base and select suburb.ogz, suburb.cfg and suburb.jpg and copy them into your Sauerbraten/packages/base directory.