Pharoah is a map made by me (R4L) and my friend Tony (Jama) over coop edit mode. It was Tony's first map, and I think he did an amazing job with it.

Anyway, just extract the .cfg and .cgz files into your packages/maps folder.