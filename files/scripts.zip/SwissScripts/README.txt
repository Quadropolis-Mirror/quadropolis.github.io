/**
 * 
 * SwissScripts v1.0 by 'Swiss'
 * 
 * Please read the other READMEs to
 * get more informations about the package.
 * 
 * Many thanks to 'SomeDude'
 * 
 * 
 **

README



1) Place the 'exec.cfg' and the 'SwissScripts' Folder into the same as your autoexec.cfg
2) Add following line to the autoexec.cfg: 'exec exec.cfg'
3) Use your new avaliable commands ;)