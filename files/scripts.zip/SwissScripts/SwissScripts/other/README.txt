/**
 * All Scripts were made by 'Swiss'.
 * These Scripts are made to help other
 * Scripters make their work easier by using
 * less code in their Scripts.
 * 
 * Many thanks to 'SomeDude', who helped to
 * fix some of the Bugs.
 * 
 */

Description & Usage



character.cfg

* isLetter $arg1
	Returns wheter an Input is a Letter or not.
	(isLetter 1)		// 0
	(isLetter a)		// 1
	(isLetter H)		// 1

* isDigit $arg1
	Returns wheter an Input is a Digit or not.
	(isDigit 2)		// 1
	(isDigit h)		// 0

* isWhitespace $arg1
	Returns wheter an Input is a Whitespace or not.
	(isWhitespace 6)	// 0
	(isWhitespace :)	// 0
	(isWhitespace " ")	// 1

* isUpperCase $arg1
	Returns wheter an Input is an Upper-case Character or not.
	(isUpperCase 5)		// 0
	(isUpperCase h)		// 0
	(isUpperCase H)		// 1

* isLowerCase $arg1
	Returns wheter an Inupt is a Lower-case Character or not.
	(isLowerCase 5)		// 0
	(isLowerCase h)		// 1
	(isLowerCase H)		// 0



isNaN.cfg

* isNaN $arg1
	Returns wheter an Input is a Number or not.
	(isNaN 5)		// 0
	(isNaN -.5)		// 0
	(isNaN 5h)		// 1
	(isNaN -.)		// 1
	(isNaN 5.5.)		// 1
	(isNaN 5-5)		// 1



math.cfg

* abs $arg1
	Returns the absolute value of an Input.
	(abs 5)			// 5
	(abs -5)		// 5

* pov $arg1
	(pov 2 2)		// 4.0
	(pov 1.5 3)		// 3.375

* floor $arg1
	(floor 5.99)		// 5
	(floor 5)		// 5

* ceil $arg1
	(ceil 5.001)		// 6
	(ceil 5)		// 5

* round $arg1
	Rounds an Input and returns it.
	(round 5.001)		// 5
	(round 5.5)		// 6



strings.cfg

* base_convert $arg1 $from $to
	(base_convert 10 2 10)		// 2
	(base_convert 128 10 16)	// 80

* toMod $arg1 $to
	(toMod 2 2)			// 10
	(toMod 15 16)			// F

* toDec $arg1 $from
	(toDec 10 2)			// 2
	(toDec F 16)			// 15

* charAt $arg1
	Returns the n. Char.
	(charAt "Hello" 2)		// l
	(charAt "Hello" 4)		// o

* toUpperCase $arg1
	Converts an Input to Upper-case Letters.
	(toUpperCase "Hello")		// HELLO

* toLowerCase $arg1
	Converts an Input to Lower-case Letters.
	(toLowerCase "Hello")		// hello