The World War X readme!


included files
toxic.ogz
toxic.cfg
readme.txt

Install
Copy toxic.ogz and toxic.cfg into your Sauerbraten/packages/base folder

Play
Ingame press ` to bring down console and type map toxic to play

World War X is a multiplayer deathmatch/exploration type thing. there is a lot of traps and secrets. Have fun finding them all!

This map took one month to complete. It was created by Whobob and HootShay, doing coopedit.

LICENSE: 
You may distribute this map if it is in its unaltered form. Do not sell this map. You may re-compress using different archives, any changes beyond that require my explicit permission.

SAUERBRATEN LICENSE:
The Sauerbraten game is freeware, you may freely distribute the Sauerbraten archive/installer unmodified on any media. You may re-compress using different archival formats suitable for your OS (i.e. zip/tgz/rpm/deb/dmg), any changes beyond that require my explicit permission.
You may play Sauerbraten for any purpose as long as you don't blame me for any damages incurred.

Sauerbraten is (c) Wouter van Oortmerssen (aka Aardappel)
World War X is (c) Freeware Informer Games.

www.freewebs.com/figames

Questions or comments contact whobob121@yahoo.com
