Map:     Bridge-ctf
By:      Chasm
About:   A two bridge ctf map. Probably best suited to insta-ctf.
Credits: This map uses an almost unedited config file from aard3c so credit goes to the creator of that map for creating the pallet of rotated textures used. Also, thank you to FD clan for map testing and overall critic.
Version: 1.0 published Nov 8, 2009
Contact: If you have any questions, complaints, or requests; I can be reached by emailing sauer.chasm(at)gmail(dot)com
License: Hey do what you will with this, if you make something cool definetly give me credit and let me know so I can check it out and see what you've done. Have fun. Officially please consider this work Public domain.