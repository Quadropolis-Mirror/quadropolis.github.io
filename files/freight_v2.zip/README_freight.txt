11.08.2012

freight is an industrial themed capture the flag map for sauerbraten created by butch @quadropolis.us