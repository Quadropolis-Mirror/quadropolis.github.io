Models in this package are made by me (thesniperz09) a.k.a |BC|$N!P3R*
Original Textures from cgtextures and edited by me 

***********************************************
These file has been licensed under a the
"Creative Commons Deed / Attribution Non-commercial Share-Alike ( at-nc-sa )" 

You are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works

Under the following conditions:

"by" 	 -Attribution. You must give the original author credit.

"nc"	 -Non-Commercial. You may not use this work for commercial purposes.

"sa" 	 -Share Alike. If you alter, transform, or build upon this work,you may distribute the resulting work only under a licence identical to this one.

    * For any reuse or distribution, you must make clear to others the licence terms of this work.

***********************************************

E-mail: samitimez@gmail.com
