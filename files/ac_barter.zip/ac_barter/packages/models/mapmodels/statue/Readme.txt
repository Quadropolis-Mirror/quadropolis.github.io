===============================================================
S.A.S (Special Air Service)
Plug-in Quake2 player model
by HitmanDaz[MT]                  e-mail: daz@cybermodels.co.uk
(Darren Pattenden)                        www.cybermodels.co.uk 
================================================================
DESCRIPTION:
Based on the British anti-terrorist force,the Special Air Service,
this model is the official clan model of the UK Quake2 clan,
Minor Threat(http://dspace.dial.pipex.com/scanman).

INSTALLATION:
Unzip the files into a folder called SAS in your Quake2/baseq2/
players directory.
Copy all the sound files from the male player folder into your
SAS folder.


TOOLS USED:
3dstudio Max and character studio for modelling and animation.
Q2 modeller for compiling and NST and PaintShopPro for mapping and 
skinning.

COMMENTS:
Please consult me If you wish to use this model for anything other
than personal use.

CREDITS:
id software,Npherno for the awesome NST,Phillip Martin for the equally
essential Q2modeller and the boys at Planetquake.com/q2pmp.

Note: Additional skins created and model used with permission. Thanx Darren!!