Sounds for Sauerbraten build V.2.0.0 by Koi Kitsune2006

Permissions/Copyright
=======================================================================

-----------------------------------------------------------------------
Sound effects found within this folder is only for use of "The Sauerbraten Engine"! Any other uses of this file, please contact my e-mail. DarkFoxSoldier20@hotmail.com
-----------------------------------------------------------------------

What's new?
=======================================================================

-----------------------------------------------------------------------
Everything. Jumping, landing, getting hurt, voice acting is all enhanced using Adobe Audition. Hope you all enjoy the new Sound effects that have been totally revamped.

Reason for SFX Changes
=======================================================================

-----------------------------------------------------------------------
To add more flavor to Sauerbraten.
-----------------------------------------------------------------------

INSTALLATION
=======================================================================

-----------------------------------------------------------------------
Extract the sound folder into Sauerbraten/packages/sounds.
-----------------------------------------------------------------------

SFX Used
=======================================================================

-----------------------------------------------------------------------
Voice acting by Koi Kitsune2006

Other new SFX from

http://www.partnersinrhyme.com/
http://www.flashkit.com/index.shtml
http://www.geocities.com/SnowFlake_Productions
http://www.findsounds.com/
Realistic Weapon Sounds from FischKopF http://www.quadropolis.us/node/810
------------------------------------------------------------------------

Programs used
=======================================================================

-----------------------------------------------------------------------
Adobe Audition
Sound Recorder
-----------------------------------------------------------------------

Special Thanks
=======================================================================
The Cube community and Aardappel, creator of "The Cube Engine" and
Sauerbraten Engine.