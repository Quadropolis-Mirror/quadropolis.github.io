﻿Public Class main
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("Please enter a alias")
        Else
            Form1.alais = TextBox1.Text
            Form1.Show()
            Me.Hide()
        End If
    End Sub
End Class