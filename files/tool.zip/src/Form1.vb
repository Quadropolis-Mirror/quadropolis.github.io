Option Strict Off
Option Explicit On
Friend Class Form1
    Inherits System.Windows.Forms.Form
    Public alais As String
    Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
        If TextBox1.Text = "Directory:" Then
            MsgBox("Please browse for folder first")
        ElseIf TextBox1.Text = "Directory:" Then
            MsgBox("Please browse for folder first")
        Else
            Dim strStartPath As String
            strStartPath = FolderBrowserDialog1.SelectedPath
            ListFolder(strStartPath)
        End If
    End Sub

    Private Sub ListFolder(ByRef sFolderPath As String)
        Dim FS As New Scripting.FileSystemObject
        Dim FSfolder As Scripting.Folder
        Dim File As Scripting.File
        Dim i As Short

        FSfolder = FS.GetFolder(sFolderPath)
        Text1.Text = ""
        For Each File In FSfolder.Files
            System.Windows.Forms.Application.DoEvents()
            Dim ff As String
            ff = File.Name
            Text1.Text = Text1.Text + "texture 0" + " " + """" + alais + "/" + ff + """" + Environment.NewLine
        Next File
        FSfolder = Nothing
        Text1.Text = "//Files Generated With Sauerbraten Texture Generator, By: Graphitemaster" + Environment.NewLine + Environment.NewLine + Text1.Text
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Text1.Text.Replace("I:\Documents and Settings\Dale Weiler\Desktop\unstable\", "texture 0")
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Enabled = True
        FolderBrowserDialog1.ShowDialog()
        TextBox1.Text = FolderBrowserDialog1.SelectedPath
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If Text1.Text = "" Then
            MsgBox("Nothing to copy to clipboard")
        Else
            Text1.SelectAll()
            Text1.Copy()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Text1.Clear()
        TextBox1.Clear()
        TextBox1.Enabled = False
    End Sub
End Class