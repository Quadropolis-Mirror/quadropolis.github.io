___________Custom Built Assault Rifle_____________

Model and Textures by:		Timakrov Gunn
                 			redempting777@hotmail.com

Readme:					This is for Cube 2 Sauerbraten.
The way I had it installed required a lot of moving files and such, but I suggest you get/use either the CTF weapon models or the Solaris weapon models since this model is by itself.

The model was made in Misfit Model 3D and textures were made in GIMP 2.

Notes:					Mind my poor textures. I'm still learning to draw textures perfectly. I also have the normalmaps for the model, but I didn't include them in the cfg as of now because they seem to cause the game to crash. If anyone can take a look at the normalmaps and tell me what I did wrong, that would be much appreciated.

How-To Install:				You should probably have/get the Solaris/CTF weapon models, along with a special client like SuperSauer or the Crash Client. Just make a duplicate of the original file "chaing" (in case you want to switch back to the old chaingun) somewhere and move this chaing file to the Solaris/CTF weapon directory.

License info:				This is under the Creative Commons BY, which means you are free to do whatever to the model, as long as I'm credited, but really, it's better off as personal use.