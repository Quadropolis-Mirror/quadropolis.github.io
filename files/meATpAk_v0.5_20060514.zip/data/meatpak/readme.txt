_______________________________________________________________________________

                     ________________           _____   __    
     _____   ____   /  _  \__    ___/ ______   /  _  \ |  | __
    /     \_/ __ \ /  /_\  \|    |    \____ \ /  /_\  \|  |/ /
   |  Y Y  \  ___//    |    \    |    |  |_> >    |    \    < 
   |__|_|  /\___  >____|__  /____|    |   __/\____|__  /__|_ \
         \/     \/        \/          |__|           \/     \/

_______________________________________________________________________________

this will get you started ...

history :

v 0.1    :: 20060319 : begin of work
v 0.11   :: 20060429 : overhaul for new release
v 0.12   :: 20060507 : ready for release on quadropolis.us
v 0.13   :: 20060509 : fixed kedit botch
v 0.5    :: 20060514 : MapMenuMap and kedit tweaks with concepts, configs and
                       cubism by makkE - thanks dude!
___ _ __ _  _   _ 

 author contact : MeatROme@Count0.dynDNS.oRg
_______________________________________________________________________________

please read this manual at least once to understand basic operations.
basic setup should not take more than editing of your autoexec.cfg
individual plugins might require more of an effort though :)

Contents :

	[technical]
	
	- Installation ..................... first steps after download
	- Implementation ................... example autoexec.cfg
	
	[usage]
	
	- Quick-Start ...................... bare minimum
	
	- Introduction ..................... walk-through
	- plugin sections .................. [kbrdlay, persona, jukebox]
	
_______________________________________________________________________________

Installation :
--------------

decompress the archive into your $sauer$ folder - 
meaning the base game folder of your sauerbraten installation.

Only if you have 
a previous installation 
of this package 
should you get overwrite isssues - 
those should be okay.

 ! ! ! Keep Backups ! ! !

To activate the installation you need to modify your
autoexec.cfg in your $sauer$ folder.
If it does not exist, create one.
Add the line
exec meatpak.cfg
and fire up your sauerbraten.
You will notice quite a few lines of extra output -
do not worry : meATpAk is very customizable when it comes to the amount of
output.

-- -- --

For testing you can call 
meatpak.cfg from inside the game.

Thorough testing of what might not work 
that way has not been done to my knowledge.
Because things need to be defined in a orderly fashion;
e.g. music and keyboard definitions should be valid upon first startup 
or will not behave "as advertised"...
...meATpAk does it's best to ensure stable definitions across map loads and
engine restarts, but the engine still often behaves in unmanageable ways;
wether this is my incompetence or sign of immaturity of engine code is a 
matter for debate ;-)

Be Prepared 
To Rename/Delete
Your 
config.cfg 
In Case Of Any 
Stubborness

Like when something stops working suddenly and
will not be fixed by restarting sauerbraten;
this is a general tip to fix a "stubborn" sauerbraten.
If config.cfg is missing 
(like after you moved it somewhere for later spanking)
then it get's recreated by sauerbraten with default values.
config.cfg is useful to keep values between engine restarts.

_______________________________________________________________________________

Implementation :
----------------

Call meatpak.cfg from your autoexec.cfg.

Best as first line to ensure any following lines
take precedence over whatever the script-PAK settings are.

So your autoexec.cfg could look like this :
// >> MeatPAK >> 
exec meatpak.cfg
// << MeatPAK <<  

gamma 150
fov 110
maxroll 3
musicvol 40
soundvol 50
sensitivity 6
hidestats 1
screenres 800 600

_______________________________________________________________________________

Quick-Start :
-------------

Settings made in menus DO NOT get saved.
Care over your settings is your obligation,
manage them with your favourite text editor.
See the singular CFG files in this folder and 
it's children to find and tweak your configuration needs.

Basic Configuration is taken care of in meatpak/setup.cfg.

Set the path, the info-level and disable any plugins you don't require
right at the top of the file.

To modify the configuration 
of a specific plugin
you will have to look into it's 
subsection in the meatpak/setup.cfg.
In some cases into additional files in it's own subdirectory.

Most plugins define some own aliases - 
these are defined (for a plugin XYZ) -
in meatpak/XYZ/iniXYZ.cfg.
Under normal conditions you shouldn't touch these files.

Noteworthy Files (to edit):
   
 - the Keylay plugin is thought to be a base for you 
   to modify editor and game layouts to match your personal needs.

 - the Persona plugin lives and breathes by the files you place 
   in the subdir and requires you to add each filename 
   to be used into a list in meatpak/setup.cfg.
   
 and
 
 - the JukeBox plugin requires you to edit the 
   meatpak/jukebox/music.cfg file to play your own songs.


The following is an attempt at covering the basics, later editions of meATpAk
will hopefully also contain some form of documentation ...
... or how else should a user learn about the "musicstyle" alias or
what "radioswitch" (default binding KP2) does ... ?!? ... tell me that?

If you'd like to help with either documentation, bug reports or something -
please do! :)

For further help with the meATpAk you might find some here
meATpAk : quadropolis @ http://www.quadropolis.us/node/218/
or (more general sauerbraten)
on the engine webpage @ http://sauerbraten.org
in the official forum @ http://cubeengine.com/forum.php4
or the official irc # @ irc://quakenet.org:6667#sauerbraten

_______________________________________________________________________________

Introduction :
--------------

meATpAk is a bunch of scripts I initially wrote for my own benefit.
I am releasing them to the public - in the hope they will be either
useful, educational or even entertaining.
Since it is only human to make mistakes there will probably be quite a number
of them in this PAK.
Please do not hesitate to inform me of the fix. 

If you have started sauerbraten with an active meATpAk (see "Implementation")
then you should see output (F11 will toggle console) of the plugins firing up.

To modify these edit setup.cfg and - for example - change line 21:
alias MPAK_load_JUKEBOX 1
to show
alias MPAK_load_JUKEBOX 0
save the change and restart sauerbraten - the Jukebox plugin did not load.
Since this is the most difficult to adapt you might leave it off for now.

A first look behind the cogs & wheels of meATpAk is best gotten in the persona
plugin; let's first see what makes it tick.
line 152 ff. in setup.cfg:
two lists are aliased and 4 variables are set to 0
then MPload persona fires up the plugin automagically aware of your personal
schizophrenic tendencies.
the last to lines in the INI block for the persona plugin even generate some
menus for ease of use in-game.

MPload will call the 
$sauer$/data/meatpak/THIS/iniTHIS.cfg 
for a plugin called THIS.
So to find out more about the persona plugin you could load it's INI-CFG,
but it's very technical and you do not need to edit it.

For the persona.cfg it is interesting what you wrote into the lists in the
setup.cfg
and - for correct behaviour - that the files required actually exist.
The default value for the persona_list is (line 162 [setup.cfg])
alias MPpersona_list "default Ogro Gorgo"
If you look into meatpak/persona/ you will see the three names as CFG files.
To add another persona configuration simply copy the default.cfg and
rename to your liking (e.g. MyName.cfg) then modify the persona_list alias.
alias MPpersona_list "default MyName Ogro Gorgo"

Now - before you start naming your file "My Fabolous Name.cfg" - just because
your filesystem can cope with spaces ... 
the persona_list alias list _CAN NOT_ !
space is used as delimiter between elements of the list.
so all your personas must not have spaces in their filenames.

now edit your copy of the default.cfg (MyName.cfg),
change the lines for name and team,
they are not directly the commands to change them -
they would be "name" and "team" respectively,
but with meATpAk it is more useful to keep them ready for output in an alias.

the following three sets of aliases are for 
welcoming, warcry and insult quick-chat.
you simply press the key assigned to 
"greeting", "compliment" or "insult" and 
meATpAk will prepare the next of your 
predefined chat-messages ready for sending -
you just need to hit RETURN :)

I really like the way I handle this - ... see!? ... isn't it pretty? ;-)

Even easier to configure is the kbrdlay plugin.
There are two predefined distinct layout designs :
edit or in-game.
kedit and kgame are the respective cfg files.

The best way to find out 
about features of meATpAk is to read those two files;
find a key which is bound to something that looks interesting and 
try it out in sauerbraten.

If you're 
 - trying out new stuff or
 - modifying your configuration
it might help to set MPinfo.

Up it to 3 for a chatty meATpAk (line 12 in setup.cfg), 
turn it back to 1 or even 0 when you wish less verbosity.

_______________________________________________________________________________

Keyboard Layout Plugin [kbrdlay] :
----------------------------------

German Keys :
This whole PAK uses the german "Umlaut" keys as well as the "Scharfes S" key.
To be able to use these without getting irritating errors on the console
is to manually add the required keybindings to your $sauer$/data/keymap.cfg
These lines should be appended to it:

<SNIP>
// added by meATpAk
keymap 223 SZ ""
keymap 252 UE ""
keymap 246 OE ""
keymap 228 AE ""
</SNIP>

Of course - if you're not using a german keyboard this is _not_ required!

In that case you will almost surely want to modify any given occurence of
those keys used in - for example - the keyboard-layout plugin [kbrdlay].
Occurences should be (but might not be limited to):
kedit.cfg : lines 94-97
kgame.cfg : lines 38-41

See these files to find out about the keys to use with meATpAk.
Listing it all again here would be overhead.

_______________________________________________________________________________

Personality Profile Plugin [persona] :
--------------------------------------

This is an easy to use plugin.
Setup is equally easy.
To generate a new persona simply copy the file 
$sauer$/data/meatpak/persona/default.cfg
to a new file in the same directory.
Then edit the meatpak/setup.cfg to tell meATpAk about the new persona:

Find the line with "alias MPpersona_list" in it and add your new name to it.
<SNIP>
alias MPpersona_list "default alt1 alt2"
</SNIP>

These settings will be present in the menu to let you switch easily ...

_______________________________________________________________________________

JukeBox Plugin [jukebox] :
--------------------------

I really wanted this for myself. It's turned out to be quite complicated.
Also I guess a lot of people out there aren't going to like the "cons",
but ... as I said - for /me/ there _are_ "pros" ;-)

This plugin gives you a nice form of control 
over what you're hearing during the game. 
Default bindings use the numeric keypad [2, 3 & 6, 5 & 8] for jukebox-control.

You can even include your own music (OGG, MP3 or WAV).

Due to security restraints enforced by the engine,
you will have to create a directory for your private music which is 
below the base $sauer$/packages/ folder!

On linux this can easily be achieved with a soft-link, 
though it would suprise me if your actual filenames already fit the
scheme of the jukebox plugin (no spaces!) ... so you'd still have to
softlink each file for itself. 

In the end you'll have to configure every single song anyway -
so it's not really cheap to have your whole MP3 collection in sauer.

Beware:
Sadly restraints (like the size of a string (read "list")) apply,
which require us to prepare the files to be used especially for this jukebox.
Also these constraints will limit the maximum number of songs you'll be
able to load into the JukeBox - conservative use of characters is advisable :)

Let's say, you have 3 songs you would like to hear while playing.
Leaving soft-linking aside - which any *Nix-er will undoubtedly use without
my telling him/her how - we will assume the following.
To make this easier to follow I'll use "band_X_song_Y" filenames,
though "b1s1.mp3" would be far shorter - hence would allow more songs 
to be loaded into the JukeBox (see above) - but that'd be even more confusing.

The files 
 band_1_song_1.mp3, 
 band_2_song_1.mp3 and 
 band-2_song_2.mp3 
all exist in the folder $sauer$/packages/mysongs/
then you will need to edit 
$sauer$/data/meatpak/jukebox/music.cfg like so :

(find the line with "alias songdir" and modify it)
<SNIP>
alias songdir "fanatic mysongs"
</SNIP>

(then add following lines to the end of the file)
<SNIP>
// "mysongs"
addsong 1 [band_1_song_1.mp3] [DaFirstBand:SongsTitle]
addsong 1 [band_2_song_1.mp3] [AnotherBand:FirstSongName]
addsong 1 [band_2_song_2.mp3] [AnotherBand:SecondSongName]
</SNIP>

the "1" in these addsong lines refers to position of "mysongs" in the
songdir alias - fanatic is at position 0!
So if you add another folder your lines of addsong would use "2". Okay!?!
The second parameter is the filename, the third is a title.
I generally like to get the Band's name in there but you can shorten it as
much as you like (or need to [see above]).


_______________________________________________________________________________

