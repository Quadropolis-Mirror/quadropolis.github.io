Thanks to tech1soc for his textures,
perfect basis to apply my "button" style images on top.
Those images come either from the rest of sauerbraten,
or where ripped off webpages.
If you care to send me your improvements:
MeatROme@Count0.dynDNS.oRg


techlsoc said in his readme:

============================================================
Date:             26th November 2001.
author:           Sock 
email:            sock@planetquake.com
URL:              http://www.planetquake.com/simland
Version:          1.5

============================================================

COPYRIGHT NOTICES
-----------------

If you use any of these Tech1 shader/textures I kindly ask
YOU to give me credit for my work within your README file or
TEXT file distributed with your map/mod.

============================================================

