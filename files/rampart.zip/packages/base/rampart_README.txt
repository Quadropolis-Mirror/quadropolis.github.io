Rampart - By Pritchard 1-8-13 - v1.1

A medium (by sauerbraten standards) sized FFA map. No team spawns, no objective items, just neutral playerstarts, weapons, health and a green armour. I built the geometry for this map a long time ago, and almost finished texturing it too. I forgot about it/stopped playing sauer for a while, and then came back, picked it up and finished it over the past 2 days. I don't have many plans for future updates to this map, and my friends said i should release it so here it is. However, if you notice any bugs/exploits on it, feel free to leave a comment and i might update with a fix.

UPDATE: Fixed a missing texture, changed/removed some health pickups