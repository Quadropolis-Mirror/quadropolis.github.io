ReFrag by 7YearBitch

How to "install":

- Unzip '7year_refrag.zip'
- Copy content of folder '7year_refrag' into Sauerbraten install directory
    //On Linux: /home/username/.sauerbraten/
    //On Windows: Documents/My Games/sauerbraten/
    //On MacOS: it's a mistery... ^^
If asked to merge folders, click 'Merge'

Licence: Since you have this folder/.zip, use it any way you want.
I could not care less if you credit me or not. ^^

Thanks to all people who learned me to create maps, and to those who tested it.
Main inspiration for this map are Reissen and Access, Sauerbraten maps made by SATAN!!!

Have fun bois and gals ^^
