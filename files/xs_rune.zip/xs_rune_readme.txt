Rune Temple Ruins by Xsaii

Upload to Quadropolis: 2/10/08
version 1.0 (beta)

There is no .cfg file because it does not need one.
No new textures.

Under:
http://creativecommons.org/licenses/by-nc-sa/3.0/us/

(Free to distribute)
