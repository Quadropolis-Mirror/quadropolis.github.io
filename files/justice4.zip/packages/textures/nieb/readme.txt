Textures by Nieb.
Captain-Cannon logos by Geartrooper.

For use with Cube2:Sauerbraten only.

Made with sources from:
http://www.cgtextures.com/
http://www.imageafter.com/