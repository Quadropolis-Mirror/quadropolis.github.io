================================================================
Title          : Office
Filename       : cb-office.ogz
Author         : Ibrihim
Email Address  : visitor@carlbahr.com
To Run         : See "Additional help" below
================================================================
 Description:

 A complete finished eight story office complex.  This is my
 first map and I did it for learning and artistic experimenting.
 I added the DM spawn points later.
================================================================
 Additional help:

 Extract the files to "Sauerbraten/packages/base" directory
 In the game console, type /map cb-office
================================================================

* Play Information *

Single Player           : No
Deathmatch              : Yes
New Sounds              : No
New Graphics            : Map
New Music               : No
Cube Version            : Cube 2: Sauerbraten (Justice Edition)

* Construction *

Map                     : New level from scratch
Known Bugs              : None

================================================================
Licence:

(c) Copyright 2011: Brian Carl Bahr

CC-BY-3.0

 This work is licensed under the
 Creative Commons Attribution 3.0 Unported (CC BY 3.0) License.
 To view a copy of this license visit:
 
  http://creativecommons.org/licenses/by/3.0/

 or send a letter to:

  Creative Commons
  444 Castro Street  Suite 900
  Mountain View, California 94140
  USA
================================================================

