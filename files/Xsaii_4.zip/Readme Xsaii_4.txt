How to play this map:

Extract 'xsaii_4.ogz' and 'xsaii_4.cfg' into your 'Sauerbraten/packages/base' folder.

Run Sauerbraten as usual.

Press ` or t (as default) and enter '/map xsaii_4'

Have fun.





~Xsaii

Released on 01/2/2007.

Free to distribute as long as the map, cfg and this readme are together in one file and unedited.