-----------------------------------
-- general information ......... --
-----------------------------------

Title:     tennis
Engine:    Sauerbraten
Creators:  Apflstrudel and Hero, TC (conquerors.csmsites.com)
Version:   1.1

-----------------------------------
-- idea ........................ --
-----------------------------------

The idea was from a guy called Axel which I met on a coop-server. He had invited the main idea, after that, I and Apfl created this map and redesign the game rules.

Yes, right, this isn't an map like others! This is the map with a revolutionary kind of game rules - without modding the sourcecode!

-----------------------------------
-- The Sauerbraten-Tennis rules! --
-----------------------------------

Description of words:
refill - refill your ammo, armor and health on the refill station near the court.
by time - when a round is running

1. Goal of this game is, that you kill your enemy.
2. 2 Player play against each other with grenades. One Player serves from the back line, then he is allowed to move on his half of the court. In the next round, the other player will serve.
3. Only after one player has shot, the other is allowed to shoot one time!
4. After 5 shots from everyone, the players are allowed to jump around. Before a jump is a foul.
5. There are so many rounds to play, till one player has 4 points.
6. Points are given
- for a kill 
- for a suicide of the enemy (lava, etc)
- for a 2 fouls of the enemy
-> fouls are 
-> shoot at the net
-> don't serve from line
-> shoot more than one time on one turn
-> use the pistol/other weapons
-> refill by time 
-> change the 
-> jump before the 5th shot
7. Refill at the beginning and after each round. A round ends if somehone has got a point.
8. Change the sites after 2 rounds.
9. When the players run out of ammo, no one get a point and the round ends.
10. Special mode: Turn the big green field into lava. (coop-edit-mode required)

The game mode you can use is ffa.

-----------------------------------
-- install and play instructions --
-----------------------------------

Put the file tennis.ogz into \packages\base of your Sauerbraten folder. You can switch to it ingame by typing /map tennis .
This map is only senseful in Multiplayer. Be sure, that everyone has it. To share it with the people on your server, do that:
1. Take master (/setmaster 1) or coop with the master, if there is already one.
2. Change/make the master change the map to this one (/map tennis), in coop-edit mode. This mode is required!
3. Upload the map (/sendmap) and let the others first get the map (/getmap) and afterwards save the map (make them type /savemap tennis)
4. Restart the map (/map tennis), advised game mode is ffa. Now you and the others can take the ammo, taht's cause these steps are important.
5. Now you can play! :)

-----------------------------------
-- additional information ...... --
-----------------------------------

You can get help in the Thread in the The-Conquerors forum (http://the-conquerors.net/forum/) in the category "Sauerbraten Maps". Or you can write an e-mail to hero[at]the-conquerors[dot]net.

-----------------------------------
-- changelog ................... --
-----------------------------------

v. 1.1:
- less mapmodels for better performance


Have fun with this idea! :)
Hero