ac_turmoil 1.0 by R4L

- How to Install - 

Contained in this ZIP is the packages folder. Open this folder to reveal two more folders; called textures, and maps.

First, open the textures folder. Then open the skymaps folder. Copy the ac_complex Night folder to C:\Program Files\Assault Cube 1.0\packages\textures\skymaps, or where ever you have placed your Assault Cube directory.

Second, to install the map, open the packages folder, then the maps folder. Copy the two files, ac_turmoil.cgz and ac_turmoil.cfg, to C:\Program Files\Assault Cube 1.0\packages\maps, or where ever you have placed your Assault Cube directory.

Also, credits to whoever made the night skybox originally for ac_complex. ;)

- To Do List -

- Make the big slope (road) area detailed with more coverage instead of a big open area.
- Add more details to CLA base hallways.
- Get opinion on the amount of fog to use. Default for now is 180.
- Keep water or not.
- Better pickup placement?
- Might need to find better textures.
- More time-consuming details, like broken tiles, broken walls, etc...
- Possibly adding more places to go, although I don't think that's necessary.

That's it! Enjoy!