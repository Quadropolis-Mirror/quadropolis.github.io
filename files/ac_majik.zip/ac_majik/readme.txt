My first released map. Feel free to use it in your servers maprot. (Note: custom content) 

Have fun! 