By: |ice|sub-zero|L
Other: egyptsoc,rorscach,dg, and golgotha.
Any Updates To Their Textures: They are now PNG's                                           

(note: This has been updated, updates include: It has a CFG. It has new textures. I fixed the CFG bugs so every texture works. I changed the colour (in hex code/RBG) to 255, 255, 255, (or in HTML) FFFFFF and 000000. Also I fixed the uncapped letters a-e to have better balance.)

Email: matthewkcolspac@gmail.com

Texture Types: PNG,png.

Problems: it can only be readable on two sides.
Other: bugs in CFG caused some textures to not show up.
Resolve: re-checked my CFG to work correctly.

All Textures: a b c d e f g h i j k l m no p q r s t u v w x y z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z 1 2 3 4 5 6 7 8 9 , . / ; ' [ ] \ = - ! @ # $ % ^ & * ( ) _ + { } | : " < > ? redbuten (mixed with floor_lava2.jpg from dg), gb, rb, rg. and so on, it now also includes a blank (black) texture as a "space".


Other Problems: none that I know of. 

What Was Used To Make Them: GIMP

Colors In HTML Code: FFFFFF and 000000 (execpt the other textures that have green,red,yellow,blue and orange)

Time Spent: unknown.

all types of files: I am using a "compressed" (ZIP) file for other people to download, and I myself am using a "filefolder".

Name Of folder "sub"

How To Use: go to your CFG (in-game console, you start at main "GUI" then click the "edit" butten on the GUI, then you go to the tab "CFG") then you type exec packages/sub/package.cfg then you click "exec" 

I think that is all there is to ask or say, if you have any problems email me at my email. please enjoy and have a nice day.

                               - |ice|sub-zero|L