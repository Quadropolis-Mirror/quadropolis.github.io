The two script files
 - entfogcol.cfg
and
 - entbodies.cfg
are suggested helpers/wrappers for your editing pleasure.

To enable them:
 - unpack the ZIP into your sauerbraten installation
 - edit (or create) autoexec.cfg and append the following two lines
    exec entfogcol.cfg // basic aliases
    exec entbodies.cfg // GUI (optional)

-- -- --

The entfogcol.cfg ..
.. defines two useful wrappers for colour-values:
ergb is for use with e.g. particle entities.
With values 0x000..0xFFF or 0..15 for each channel the usage works like so:
ergb R G B
example:
echo (ergb 12 12 4)
newent 4 280 30 (ergb 15 0 0)

and frgb is for e.g. fogcolours.
With values 0x000000..0xFFFFFF) or 0..255 for each channel the usage works like so:
frgb R G B
example:
fogcolour (frgb 8 32 245)
fogcolour (frgb 255 255 255)

-- -- --

The entbodies.cfg ..
.. defines a set of GUI-menus to ease creation of those
(still experimental in parts) bodies of particles;
the shorthand alias "sgeb" will "showgui [Entity Bodies]" and everything else, hopefully, folows from there.
The submenus have been adapted by apflstrudl to now hold speaking values instead of the unhelpful numeric values of the first release (for direction of those particle 4 entities. Thanks!

-- -- --

Enjoy!
MeatROme

2007-10-25 : first release
2007-11-02 : adaptation by apflstrudl
