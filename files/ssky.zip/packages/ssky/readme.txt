skybox "toxic" made by: [Soul]Sub-Z0|TO

helped by: skiingpenguins script for "Frame Rendering"

this have been tested and all of it should be correct.
-----------------------------------------------------------------------------------------------
skybox "river-c" made by: [Soul]Sub-Z0|TO

helped by: skiingpenguins script for "Frame Rendering"

this have been tested and all of it should be correct.
-----------------------------------------------------------------------------------------------
these skyboxes are all in PNG (png) formatting so as to have the best graphics possible. if you have a question, comment, or complaint, please refer to my email at: matthewkcolspac@gmail.com


               -Matthew