This model was custom-made, for the "4b" map-pack, by geartrooper and reworked by makkE.
MeatROme based the three gold/silver/bronze skins on geartrooper's original "patch" skin,
makkE did some masks for all of them and cleaned up some model specific stuff I couldn't explain ;)

Thanks guys! More powa 2 ya ...

MeatROme
