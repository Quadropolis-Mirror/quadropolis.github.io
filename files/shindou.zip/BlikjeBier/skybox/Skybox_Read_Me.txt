=====================================================================
Date:             oktober 2006
file:             Sea Skybox
author:           Robert "BlikjeBier" van der Veeke
email:            -- // -- Contact me at Quadrapolis
URL:              -- // --
Version:          1.0

=====================================================================
Copyright & Permissions:

If you use this skybox I kindly ask YOU to give me credit for my work within your README file or TEXT file distributed with your map/mod. Also include this README file with the Skybox files.

=====================================================================
Additional notes:

This is my first skybox, the setting is at the bottom of the seafloor, yes you can also do that with Terragen, just add a lot of blue mist and power down the sun (ie, less strenght).

As Makke wrote on Quadrapolis, use these settings.

skybox_ft -- pitch = 0, head = 0
skybox_lf -- pitch = 0, head = 90
skybox_bk -- pitch = 0, head = 180
skybox_rt -- pitch = 0, head = 270
skybox_dn -- pitch = -90, head = 270
skybox_up -- pitch = 90, head = 270

And set your magnification setting to "1".

You can use ACDSee for the conversion from BMP to JPG, mind you to set the quality the highest level, otherwise you will get artefacts on your skybox, and those made by ACDSee are gross.