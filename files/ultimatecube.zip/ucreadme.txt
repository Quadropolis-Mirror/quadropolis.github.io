Ultimate Cube 1.0 Readme

UC is a map pack of maps for Cube that never made the release and never will, as Cube is discontinued.

There is a total of 40 new maps, with an updated menus.cfg included.
This pack also contains SilentFox's sound pack and makkE's old items pack.

To install, extract into your Cube directory.

The following people have contributed to this pack (in alphabetical order):

007
Acieeed
CC_machine
disturbed
DTurboKiller LT
enigma_0Z
Heretic
junebug
makkE
Max Of S2D
Nexus
Philipp
Raelus
RatBoy
Ridge Racer
shadow
SilentFox
sparr
staffy
wolf

Anyway have fun with this pack!
Passa