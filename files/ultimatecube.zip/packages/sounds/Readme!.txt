Sounds for Cube and Sauerbraten V.1.1 by SilentFox
http://s15.invisionfree.com/Way_of_the_Gun/index.php?act=idx

Permissions/Copyright
=======================================================================

-----------------------------------------------------------------------
Sound effects found within this folder is only for use of "The cube
Engine"! Any other uses of this file, please contact my e-mail.
DarkFoxSoldier20@hotmail.com
-----------------------------------------------------------------------

Reason for SFX Changes
=======================================================================

-----------------------------------------------------------------------
I thought that some of the SFX were sort of wierd. Getting hit, landing
on your feet, collecting items sounded plain. So I added flavor to cube
in my own way, I have changed certain portions of the SFX data base. I hope
you like them! Please read below for more information regarding the SFX
changes.
-----------------------------------------------------------------------

INSTALLATION
=======================================================================

-----------------------------------------------------------------------
You have to place the sound effects in the correct folders individually.
If not then you can also just try and replace the folders instead to
see if that works. Packages/Sounds
-----------------------------------------------------------------------

SFX Used
=======================================================================

-----------------------------------------------------------------------
Voice acting by SilentFox

Other new SFX from

http://www.partnersinrhyme.com/
http://www.flashkit.com/index.shtml
http://www.geocities.com/SnowFlake_Productions
http://www.findsounds.com/
------------------------------------------------------------------------

Programs used
=======================================================================

-----------------------------------------------------------------------
Adobe Audition
Sound Recorder
-----------------------------------------------------------------------

Special Thanks
========================================================================
The Cube community and Aardappel, creator of "The Cube Engine".