Castle:

Install by extracting it to ~/cube/packages/
Access by typing /map enig4 in the chat function