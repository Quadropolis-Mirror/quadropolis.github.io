Alien Ship:

Install by extracting it to ~/cube/packages/
Access by typing /map enig1 in the chat function