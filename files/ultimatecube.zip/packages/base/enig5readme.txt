Abandoned Building:

Install by extracting it to ~/cube/packages/
The skybox and map will go into their proper folders

Access by typing /map enig5 in the chat function

This map also contains a custom skybox by "necros" .