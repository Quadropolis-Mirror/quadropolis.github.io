================================================================
Matrix
================================================================
Author: Ridge Racer
Email Address: ridge_racer@comcast.net
Web Site: http://www.ridgeracer.tk/
================================================================
Installation
================================================================
unzip the full contents of the zip file to your /packages/base
folder. To load the map enter "/map matrix". Make sure if
you are online that you enter "/sendmap" as I would appreciate
it if you distributed my map to others.
================================================================
Description
================================================================
This map was designed after the lobby scene in the movie
"The Matrix". A setting commonly mimiced in many other games,
which is finally gettin' to cube. To build this map, I made all
the measurements myself, taking notes from the movie. I also
felt like experimenting with the idea of an enclosed staging
area as no other mapper to my knowledge has done that.
================================================================
Compatability
================================================================
Single Player: No
DMSP: Yes
Death Match: Yes
Rick-Bots: Yes (bots navigate spawns in a matter of seconds)
Bugs: Metal-detectors and conveyor-belts remain partially
unfinished due to technical limitations in cube.
================================================================
Authors may NOT use this level as a base to build levels.
================================================================
I personally feel that if you dont make a map from scratch it
looses any uniqueness (pyramids). If you feel that a part of the
map needs improvement though, feel free to contact me.