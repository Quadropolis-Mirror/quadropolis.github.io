Texture08 made by Cole AKA "DogDancing" is free to use in other maps for AssaultCube.
But must include this readme.
Contact: Dogdancing1992@gmail.com