

textures:            Robert "BlikjeBier" van der Veekes' with the exception of the light-fixture
                     That one is by rorschach

			   The snow-texture Clear Snow and Dirty snow wich
			   served as a basis for the other snow-textures 			   have been downloaded from 							   Http://www.cgtextures.com/

			   The Concrete and Metals are from various sources

                     Textures & Skyboxes are free to use as long as             
                     they are not commercially exploited. Mention 
                     Http://www.cgtextures.com/ and me as source 
                     of the textures in your Read Me file <--- see i can read :)
 