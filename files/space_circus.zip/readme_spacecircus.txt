This is a very old map of mine that I created about 1 or 2 years ago.
The full name of this map is "Space Circus" and it's intended as a fast paced, 2 - 8 player, (open) arena map.
The skybox is as well custom made by me (AverageJoe). 
The pictures that I used for it are property of the NASA: http://www.nasa.gov/audience/formedia/features/MP_Photo_Guidelines.html

Special thanks to all former mX (mappin Xdream) members.
