___________----1----_____________



M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        Original Picture
Model:           Old one shoot rifle
                 Old rifle

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----2----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        Darthvim
Model:           RL-25
                 My own creation

Readme:          This model is made for cube.
                 

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----3----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        DarthVim
Model:           Chaingun 
                 Oldschool Style

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----4----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        DarthVim
Model:           Double-Barreled-Shotgun 
                 My own creation

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   




Thanks to the community for their help :)
Special thanks to (mixed)  

Blehbear, Nickster, Carsten, AARD :), Erold, Drakker,Yax ___, Pushplay, Eihrul, Sirlivealot,Gleeb, my family, my brother :) and all the others i forgot to mention, please tell me and don't be angry on me ;) )


