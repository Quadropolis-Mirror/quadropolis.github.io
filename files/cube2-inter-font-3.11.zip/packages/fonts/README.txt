High-resolution Inter font, generated using cube2font.
Based on Inter 3.11, downloaded from <https://github.com/rsms/inter/releases>.

This font uses slightly thinner outlines than the default font,
which makes it especially suited to high-resolution displays.

Inter is licensed under the SIL OFL 1.1, see `LICENSE.Inter.txt` for details.

Development note: After generating the font using `cube2font` (see the
first line of `default.cfg` for the command used), change `32 64` to `64 128`
on the second line and add a line with `fontscale 64` below.
Otherwise, the displayed font will be too large.
