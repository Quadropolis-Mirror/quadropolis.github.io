 just put in main suerbraten folder,start game and type  /monstermodels.cfg
 you now should have 11 tabs in the (menu/editing/ents/models) menu.