Mapmodels logos by Geartrooper.
-cannon_copter
-cc_screen
-decals

Mapmodels by Nieb.
-block
-cabinet
-cc_table
-console1
-exit-sign
-pad
-poster
-railings
-switch
-vending
-vent

For use with Cube2:Sauerbraten only.

Textures made with sources from:
http://www.cgtextures.com/
http://www.imageafter.com/