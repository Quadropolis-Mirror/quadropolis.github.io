coulee skybox by Mayhem  Licensed under CC-BY-SA 3.0

	I used Bryce 6 to create this skybox along with textures from various free download sites.

	Enjoy!
