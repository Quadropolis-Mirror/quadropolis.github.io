Because it's always a good idea to include a readme, and because i got 
packaging problem when I first upload this map on quadropolis, I make a readme.

The map called spiralz2 is only an extended version of spiralz. I added 2 others 
"spiralz" (one match with a dome), two da vinci's stairs (one is high enough to let 
a player jump without collide with the ceiling), and include them in a tower, or 
just round them a little.

As with the original map, feels free to learn how to do, to copy and paste in a
playable map, etc.