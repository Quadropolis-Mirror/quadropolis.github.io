Lamba Core
By Sweetmisery
2007

My fifth Sauerbraten Map. This map is based on the game Half-life


Swe�tMisery