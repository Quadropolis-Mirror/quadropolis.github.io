27.08.12

facility23 is a futuristic ctf map for Cube 2 Sauerbraten created by butch at quadropolis.us

This map requires additional textures by Philip Klestav. 
Download them at http://quadropolis.us/node/3163