This is a smaller CTF map for Sauerbraten.

It is copied from Red Faction, there it's a very popular CTF map.

It's not like the original one, because it would be too fast for sauer.

I changed a texture of rorschach, so that there is the nice ctf red/blue schema.

Hope you like it! Have fun playing :P