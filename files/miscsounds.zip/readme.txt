pain and death sounds by mIscreant
__________________________________

Back up data/sounds.cfg. Then just extract this zip to your sauerbraten folder.