Sounds for Sauerbraten build V.1.2.1 by Koi Kitsune2006

Permissions/Copyright
=======================================================================

-----------------------------------------------------------------------
Sound effects found within this folder is only for use of "The Sauerbraten Engine"! Any other uses of this file, please contact my e-mail. DarkFoxSoldier20@hotmail.com
-----------------------------------------------------------------------

What's new?
=======================================================================

-----------------------------------------------------------------------
Changed the jumping, landing, and pain noises. Also moddified the Grenade Launcher and pistol. When you see the hand cock back the Grenade launcher, you will hear it. This sound pack has abit more
maturity in the sounds for the player.

Reason for SFX Changes
=======================================================================

-----------------------------------------------------------------------
I thought that some of the SFX were sort of wierd. Getting hit, landing
on your feet, collecting items sounded plain. So I added flavor to cube
in my own way, I have changed certain portions of the SFX data base. I hope you like them! Please read below for more information regarding the SFX changes.
-----------------------------------------------------------------------

INSTALLATION
=======================================================================

-----------------------------------------------------------------------
Extract the sound folder into Sauerbraten/packages/sounds. You need
Winrar to extract the files.
-----------------------------------------------------------------------

SFX Used
=======================================================================

-----------------------------------------------------------------------
Voice acting by Koi Kitsune2006

Other new SFX from

http://www.partnersinrhyme.com/
http://www.flashkit.com/index.shtml
http://www.geocities.com/SnowFlake_Productions
http://www.findsounds.com/
------------------------------------------------------------------------

Programs used
=======================================================================

-----------------------------------------------------------------------
Adobe Audition
Sound Recorder
-----------------------------------------------------------------------

Special Thanks
=======================================================================
The Cube community and Aardappel, creator of "The Cube Engine" and
Sauerbraten Engine.