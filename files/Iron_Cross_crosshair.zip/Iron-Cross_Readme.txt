This is my first release, ever, and I hope you like it.

The reason I made this crosshair is that i felt that none of the available crosshairs were good enough. I called it Iron Cross because it resembles an Iron cross.

Installation

1. Copy ALL the files into �C:\Program Files\Sauerbraten\data.�

Contact me on langlo73@hotmail.com if you wonder about anything (it's okay I have riddicilously lot of sparetime.)