#!/bin/sh
#SAUER_DIR, should be .
SAUER_DIR=.
#SAUER_PASS, just set a password for admin, if it contains spaces, place it in "" eg "hack me"
SAUER_PASS="hack me"
#SAUER_CLIENT, set the maximum number clients eg "4"
SAUER_CLIENT=8
#SAUER_NAME, the name of your server in the server GUI
SAUER_NAME="Sauerbraten Server"
#SAUER_SERVER, eg linux, native, the prefix of the executable.
SAUER_SERVER=linux

if [ -x ${SAUER_DIR}/${SAUER_SERVER}_server ]
then
	cd ${SAUER_DIR}
	exec ${SAUER_DIR}/${SAUER_SERVER}_server -p"${SAUER_PASS}" -c"${SAUER_CLIENT}" -n"${SAUER_NAME}" $@
else
	if [ -x ${SAUER_DIR}/bin_unix/${SAUER_SERVER}_server ]
	then
		cd ${SAUER_DIR}
		exec ${SAUER_DIR}/${SAUER_SERVER}_server -p"${SAUER_PASS}" -c"${SAUER_CLIENT}" -n"${SAUER_NAME}" $@
	else
		echo "Configure this properly yoo n00b"
		sleep 2
		echo "it might just be that the script is in the wrong place, check that it isn't"
		sleep 2
		echo "You'd want to make sure this is in the / of your sauer directory,"
		echo "as this script it poorly written and doesn't change to that directory, as it assumes you're already in it"
		exit 1
	fi
fi

