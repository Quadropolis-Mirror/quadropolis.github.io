***Frozen Cave - by Andrez***

**DESCRIPTION**
Map set in a frozen complex, with a partial cave.
Entstats:
 155 light
 30 playerstart, 10 CLA, 10 RVSF, 10 FFA
 3 pistol
 5 ammobox
 3 grenades
 4 health
 5 helmet
 1 akimbo
 129 mapmodel, 29 clipped
 3 ladder
 2 ctf-flag, 1 CLA, 1 RVSF
 32 sound
 18 clip
 18 plclip
total entities: 408

**LICENSE**
BY-NC-SA


http://andrezweb.altervista.org/ac/
http://ac-akimbo.net
