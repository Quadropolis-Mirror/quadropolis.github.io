/// Crosshair Menus v1.3 READ ME ///		Finished June 6, 2009

Hello!  This is the READ ME for my crosshair menus.  This file contains a simple contract, instructions, who made what, what may come next in the next version, and all that fun stuff.

Concept and menu by..	Maddog1906 (Billiam)


// Crosshair Authors //

Mad-Hairs	Maddog1906 (Billiam)
MX Crosshairs	MX <-- His special mod ONLY applies to his crosshairs

"nadecook"	luckystrikerx
"neospace"	Cryx
"highres"	1brunobruce
"highres2"	marvin2k

REFER TO LICENSES FOR ALL CROSSHAIRS ABOVE

// Instructions (Installation) //

1) Put all the packaged stuff in the appropriate place
(crosshairs go in "data" and the mx folder goes in "packages")

2) Type "exec crosshair.cfg" without quotes in your autoexec.cfg

3) (THIS IS OPTIONAL..)
Open the menus.cfg, scroll down till you reached the "options" section.
Scroll down till you find "crosshair fx"
Copy and paste (guibutton "crosshair menu" "showgui crosshair") without parentheses.  (This will allow you to open the crosshair menu from the options menu in the game)


// Contract //
By downloading this file, you have agreed to follow the following..

1) If you distribute a copy of this script WITH OUT changes, Maddog1906 (Billiam) and all the people included in this package have to be credited.

2) If you distribute a copy of this script WITH changes (this includes adding crosshairs directly to the menu), you must send a copy to Maddog1906 (Billiam) before you can post it.

3) If you break rules 1 and 2, your content is to be removed.

4) If you want to have crosshairs added to this menu, send it zipped and in transparency PNG format and emial it to Maddog1906@aim.com.  If I or anyone else who tries it, likes it, I may include it in the next update.  I may modify it unless you say otherwise.  If so, I'll send a copy back to you for approval.  
YOU WILL GET FULL CREDIT FOR YOUR CROSSHAIR(S).


// Notes //
- Not all crosshairs have team crosshairs
- Default key bind = "o"


// Load-a-Crosshair Instructions //

1) Put your made crosshair in the "My_Crosshairs" folder (located in data/crosshairs)

2) type in the crosshair file name in the correct box (put .png end)
- DO NOT change the text before for that is the file path.  You may only change it if your crosshair is in a different folder, otherwise, it won't work

3) Click LOAD and enjoy


// Future To-Do //

- More crosshairs!
- JadeMatrix's approval for next set
- Improve Load-a-crosshair
- Tag crosshairs to weapons
- Edit crosshair (an arrow) applied to all crosshairs
+ Also have a toggle for it (ON/OFF button)
- Advanced options

I'm fully aware that MX was able to toggle an edit crosshair his crosshairs already but I'm trying to do that for any crosshair in the entire menu plus the ones you can load in load-a-crosshair.

Contact me on quad for questions and/or criticism 

	- Maddog1906 aka Billiam



