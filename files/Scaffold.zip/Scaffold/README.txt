oh hello there, i guess you want to know how to load this map. well let me tell you then

step 1 - copy the .jpg file and the .ogz file

step 2 - go to your home folder, you have to show hidden files and folders. the sauerbraten folder will be hidden
		in windows - go to control panel and change the settings there to show
		in linux - press "ctrl h" in your home folder

step 3 - go to the directory packages/base in the sauerbraten folder which is in your home folder, and paste the files into there

step 4 - to load the map in sauerbraten, go into edit mode and type the command /map Scaffold

step 5 - come back and say how this map can be improved

and most important of all, have fun

AcidPenguin waz ere
