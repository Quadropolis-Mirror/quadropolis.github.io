**Medina - by Andrez**
A desert-themed map, nothing special. Flag/FFA modes capable.


**Installation**
Put ac_medina.cgz and .cfg in your packages/maps folder, and ac_medina.jpg in your packages/maps/preview folder.

**Changelog from beta to final**
* laddered palm tree
* some details added here and there
* window added in the gastank room

Have fun!
Andrez