================================================================
The marine for the 'Paranoid' Q2 mod (www.Planetquake.com/Paranoid)
Plug-in Quake2 player model
by HitmanDaz             e-mail: daz@darren-pattenden.cix.co.uk
(Darren Pattenden)      www.cybermodels.co.uk/html/dazhome.html 
================================================================
DESCRIPTION:
This marine was created for the Paranoid Q2 mod (www.Planetquake.com
/Paranoid).Go download it.It really is sumthin' special.Plus you
get to play with Benny Elmeks' awesome Brood PPM.
Inspired by colonial marines in films such as 'Aliens' and 
'Starship Troopers',I've been meaning to bring this guy to your 
screens for a while.He's harder than Hudson tho'.  :-) The id male,
bloody nice peice o' work tho' he is,always looked kinda unprepared
for battle to me.

INSTALLATION:
Unzip the files into a folder called Marine in your Quake2/baseq2/
players directory.

SKINS:
The original USMC.pcx is by me,Centurion.pcx by Neal 'Guplik' Corbett 
(guplik@pmail.net)and Reece.pcx by Steve 'Massivebitch' Irvine
(Steve.Irvine@CoreLAN.com)

TOOLS USED:
3dstudio Max2 and character studio for modelling and animation.
Q2 modeller for compiling and NST and PaintShopPro for mapping and 
skinning.Skinview is a bloody handy tool too.

CREDITS:
id software,Npherno for the awesome NST,Phillip Martin for the equally
essential Q2modeller and as ever the staff and messageboard regulars
at Planetquake.com/q2pmp.Some eagle eyed folks might also notice the 
striking resemblance to the id male arms.I stole 'em and tweaked 'em!
Oh and thanks to Bad Moon for sorting out the weapon skin linking!

STUFF:
Please consult me If you wish to use this model for anything other
than personal use.

Oh and check this URL in April 99 > www.Siliconchick.com

Later

Daz
www.cybermodels.co.uk/html/dazhome.html