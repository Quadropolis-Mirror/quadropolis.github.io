Spider Dalek PPM for Quake2

Okay, here is, I think the first ever Quake2 model I did. It was for a Doctor Who Total Conversion which has now, I think, sadly gone by the way-side. I built a standard Dalek aswell, which was more accurate than the two existing ones but as there are already two and as the standard model doesn't lend itself to Quake2 anyway (not being able to duck and all), I won't be releaseing it. 

The Spider Dalek is a derivative of the mechanical menace from the British Sci-Fi TV series, Doctor WHO (see Dalek and Dalek-X PPMs). It was borne from a conversation with Sysop CoreY Clemmow on Compuserve's Sci-Fi forum. He mentioned that the Paul McGann TV movie version of Doctor WHO would originally have featured 'Spider Daleks'. I asked CoreY if any concept designs existed for the creatures. He replied that they didn't and so I decided to have a go myself. My original design was a little more flamboyant than this, but just as the BBC had financial restrictions, so too, I have triangle restrictions. I have sent the designs to Terry Nation's estate and also the BBC. I also showed John Peel, Author of 'War of the Daleks' - the first novel to feature the Spiders. It met with approval from all sides.

Known problems:

The PPM itself, as I say is an early one, my first finished, useable Quake2 model. I didn't know about 255 square skins back then. Also I don't believe it crouches quite low enough.

So, here I present it to you for your general fragging pleasure. Now... I need to make an Abslom Daak model - anyone want to make a chainsaw mod?

I have also included several sound files for extra atmosphere.
 
Spider Dalek PPM

Triangles  551
Skins 1 renegade dalek skin.
Alternative sounds - 9 taken from various places on the internet.
CTF - NO
V-WEP - NO
Team Skins - NO

To install unzip the zip file into the Quake2/baseq2/players folder. The zipfile will automatically create a folder called spider_dalek and place the relevant files inside.
 
made using 3DStudio MAX and Bones Pro.
Skin made in Paint Shop Pro 4.0

Visit the Spider Dalek Project at 
dspace.dial.pipex.com/scarecrow/crowsnest

Email me at 
scarecrow@dial.pipex.com