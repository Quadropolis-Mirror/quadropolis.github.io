Fixed up some small issues.

--

This new update ought to solve a few of the problems that the original had. I've added a small area to the level, and new playerstarts, and I've greatly increased the detail of the area surrounding the map, which should make it less ugly. Lighting has changed too, with a warmer, more natural colour being the goal.

!! This map now requires the Skyrim HD Flora Mapmodels mod !!
http://quadropolis.us/node/3709
http://www.mediafire.com/?x2ckzvtwnccxs9x



--

This is probably the most effort I've ever put into a single map, so I hope you guys like it. Kingdom is a small FFA map, and I tried to do a few things differently with this one. This map is an attempt to increase the vertical play of my maps, and overall there was a bigger focus on layout before i started building details. Anyway, there are undoubtedly problems with this map, so I'm marking it as a beta release. Please point out anything you notice, or any positive suggestions you might have!