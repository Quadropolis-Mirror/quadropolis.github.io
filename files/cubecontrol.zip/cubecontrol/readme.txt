CubeControl


--English--
extract the files to a folder of your choice in Sauerbraten/ and change the folder variable in include.cfg to the name depending on your foldername.
if you extract it to cubecontrol you dont have to change anything
When youre done, add exec folder/include.cfg to your autoexec.cfg.


--German--

Extrahiere die Dateien in einen beliebigen Ordner in Sauerbraten/, anschlie�end �nderst du die folder variable in der include.cfg zu dem namen deines Ordners.
Wenn du den gesamten ordner Cubecontrol extrahierst, musst du nichts �ndern.
Bist du mit dem fertig brauchst du nur noch in deiner autoexec.cfg  exec folder/include.cfg hinzuf�gen.