===========================================================================================
                              RatBoy's Full-Of-Action Cubic Maps
===========================================================================================
File Details:

Game:                AssaultCube (assault.cubers.net)
Game Version:        1.0.2
Map Name:            Filthy RatTrap
Map Version:         Retail 1.3
Building Time:       Two weeks.
Release Date:        May 14, 2009
Author:              Pablo "RatBoy" Ciamarra
E-Mail:              ratboymaps@gmail.com
Description:         A medium sized map set in an industrial sector with three different
                     factories and a lot of street action.
Player Amount:       6-10

===========================================================================================
Aditional Credits:

MapModels:
- Game package by Shane Nieb, makkE, JCDPC, dcp & Toca.

SkyBox:
- "At Sea" by "Kell" (monster_kell@hotmail.com)

Textures:
- Game package by arcitool, Boeck, makkE, NOCTUA Graphics, Chris Zastrow, 
  Jonathon Clark & The Golgotha Team.
- White window by Timothy Andrew "unDuLe" Wilson (undule@tampabay.rr.com)
- Modifications by myself.

===========================================================================================
Map's Story:

 This place was long ago a very nice location, with a shoe factory and two storage
facilities, it was a very productive zone of the city. But one day the manager of the shoe
factory was murdered with a shoe in his throat. The crime was never solved, and the factory
closed down.

 After that the RVSF took over one of the storage facilities, and ever since this become a
dangerous place. Recently the CLA has installed themselves in the other facility,
unleashing a rough war in the whole zone.

 The manager of the shoe factory was buried with the shoe in his throat and a statue was
made in his memory.

===========================================================================================
Developer Notes:

- The goal with this map for me was to start it and finish it before I went on vacations, 
  that would be just one week, and of course in that time make a respetable map with
  the default texture set.

- Nobody is perfect. This map could have and probably has bugs, either graphical or of
  gameplay. If you happen to spot any bug, regardless how insignificant it may be, you're
  welcome to send a notice to my mail so I can fix it in a future version. Thanks.

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to AssaultCube main folder.

Mannually:
"models" & "textures" folders go into "AssaultCube\packages\" folder.
"ac_rattrap.cfg" and "ac_rattrap.cgz" should go into "AssaultCube\packages\maps\" folder.

===========================================================================================
Version History:

Retail 1.1:
- Texture misplace corrected for v0.91.
- Added neat new mapmodels everywhere, by the hand of dcp.
- A few new detailing here and there.

Retail 1.2:
- Corrected stucked playerstarts.
- Some graphical details here and there.
- Better balance of pickups.
- Corrected some minor bugs.
- Removed and replaced obstacles.

Retail 1.3:
- Expanded corridors, doors and rooms for better gameplay.
- Modified the third building, added some new routes and rooms.
- More detail and scenery by the grace of Toca's new models.
- Re-made some lights of the level, playerstarts and entities.

===========================================================================================
Copyright & Permissions:

Cube Engine by Wouter van Oortmerssen aka Aardappel. (www.cubeengine.com)
AssaultCube Game by Rabid Viper Productions. (action.cubers.net)

This level is copyrighted by Pablo Ciamarra 2006-2009.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================