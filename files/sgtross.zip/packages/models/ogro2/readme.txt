This model and skins are released under CC:BY:ND license.
SGT. Ross is my second attempt at a playermodel, still working out the kinks.
So basically it's a replacement for the Ogro, so just rename the original "Ogro2" folder & put this one in its place. I used Geartrooper's Mr.Fixit as a base and performed surgery & this is the result, kinda ugly but its's the best I can do for now.
I take no credit for the MR.FIXIT sections of this model.
If you have questions or comments, contant Pyccna on Quadropolis.us