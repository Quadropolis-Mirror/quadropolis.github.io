there are 2 maps stored in these folders. one is Fragatron. Fragatron is a space themed map that is made up of various platforms. the other map, c_cf stands for colonial forts capture. it is night and 2 forts seperated by a creek and many trees are at battle. the are not many secrets on others but the real secret is learning how to get around quickly and efficiently.

all content created by zoozie (with a little help from tomcat) except for the skyboxes and the original versions of the trail textures. (read the readme under DG for details.)

special thx to:
DG - for providing these trail textures to use
Tomcat - for helping with the bridge and giving creative insight.
