these trail textures were in the DG folder under packages and i rotated them in order to use them. thx to DG (im not sure who he is) for creating these awesome textures
