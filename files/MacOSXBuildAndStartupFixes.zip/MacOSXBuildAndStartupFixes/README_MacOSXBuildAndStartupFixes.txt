Author:
    Tim (ThomasT) Thomas

Creation Date:
    2012/09/08

Version:
    1.0

Overview:
    This package addresses the following issues with the SVN release of
    Sauerbraten:
    1) The SVN release contains out-of-date SDL frameworks.
    2) The SVN release's src/xcode/English.lproj/MainMenu.nib is a compiled nib
       that cannot be edited.
    3) Game startup on Mac OS X unnecessarily displays a Cocoa window before
       starting the game.

Solutions:
    1) The Justice Edition contains SDL frameworks sufficient for a successful
       compile.  Those frameworks are repackaged in this package.
    2) The Justice Edition contains an uncompiled MainMenu.nib that is a
       drop in replacement for the SVN MainMenu.nib.  Again, it is simply
       repackaged in this package.
    3) Launcher.m is modified to only show the Cocoa startup window if the
       command key is pressed at launch.

Implementation Details (Launcher.m):
    The changes to Launcher.m are very very minimal:
    1) applicationDidFinishLaunching is changed to
       applicationWillFinishLaunching.  This avoids the brief flicker of the
       Cocoa window being quickly displayed and hidden.
    2) testNoLauncher is changed to detect if the option key is pressed
       during startup:

        NSUInteger flags = ([NSEvent modifierFlags] & NSDeviceIndependentModifierFlagsMask);
        BOOL modifierKeyPressed = (0 != (flags & NSCommandKeyMask));
        if (run || !modifiedKeyPressed)
        {
            // [...]
        }

Build Instructions:
    1) Replace the existing src/xcode/English.lproj/MainMenu.nib with the one
       in this package.
    2) Replace the existing SDL_image.framework, SDL_mixer.framework and
       SDL.framework in src/xcode/Frameworks with the ones in this package.
    3) Replace the existing src/xcode/Launcher.m with the one in this package.
    4) Build as usual.

    Note:  Before replacing any of these files, you should make backups of the
    originals, and also verify that the SVN versions haven't already been
    updated with these or similar fixes, or have other changes.

Copyright and License:
    All files in this package carry the same copyright and license as
    Sauerbraten, specifically, the ZLIB license:

       (http://www.opensource.org/licenses/zlib-license.php)

    Please see the file src/readme_source.txt in the Sauerbraten source
    distribution for full details.

    There is NO WARRANTY, to the extent permitted by law.
