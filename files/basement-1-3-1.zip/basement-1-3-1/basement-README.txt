================================================================================
BASEMENT 1.3.1  by Draakhond (and Zaaikort)
--------------------------------------------------------------------------------

INSTALLATION

* Do NOT REPLACE any folders by these,
  instead add the contents to the appropriate subfolders of your Sauerbraten.

* For this map we prefer the 2008 edition of Sauerbraten.

* If you have an older version of Basement installed, remove all of that first.

* Optional:
  2008: add "mode -2" to autoexec.cfg, also recommended: "startmenu 0",
  2009: add "mode -3" to autoexec.cfg.
  This will cause Sauerbraten to start any map in classical Single Player mode.

--------------------------------------------------------------------------------

* To play, select "maps" in the launcher.

* The game should start in SP mode, if not, type "t/ sp basement".

* Control your movements with
  the 4 arrow keys together with the 4 mouse directions and left/right click.
   
* For menu, press Esc.

--------------------------------------------------------------------------------

Map name:  BASEMENT

Version:   1.3.1
           Built for Cube2/Sauerbraten 2008,
           keep an eye on zaaikort.nl for mods and more maps.

Mode:      classical Single Player mode

Textures:  Most are from the standard collection, especially by Gor.
           Several are made by Draakhond and Zaaikort. 
Models:    Some models are made by Draakhond.

Author:    Draakhond (and Zaaikort) 2007~2010
Website:   zaaikort.nl
Contact:   zaaikort@zaaikort.nl
License:   Creative Commons Attribution-NonCommercial-NoDerivs 3.0
           http://creativecommons.org/licenses/by-nc-nd/3.0/

--------------------------------------------------------------------------------

History:   1.1
           - Adaptation for Quadropolis.
        
           1.2
           - Fixed wrong floor texture when running on Sauerbraten 2009.
           - Fixed a floating torch.

           1.3
           - Homebrew textures added, partly replacing standard ones.
           - Config rearranged completely.
           - More details added.
           - One monster added.
           - Player start adjusted.
           - Hud command removed from config.
           - Some minor texture mistakes fixed.

           1.3.1
           - Door posts added.

--------------------------------------------------------------------------------

Description:


Most of the Cube2 users seem to like a Quake style multiplayer massacre, but
fortunately it's also possible to build a classical single player game with the
emphasis on solving puzzles rather than just killing monsters. 

"Basement" and "Klodser" are two very different games created by Draakhond and
Zaaikort using Cube2, also known as Sauerbraten. We hope you enjoy playing them
as much as we did designing them!


BASEMENT is a small but complete game. Try to play it all the way and don't
spoil it by going into edit mode.

Like in the original early 3D-game "Wolfenstein" your goal is to escape from an
underground prison. Once you've figured out how to unlock the doors and get to
ammunition, it won't be that hard to eliminate the monsters, although you'll
probably need a first-aid-kit from the secret room. "Basement" also takes some
inspiration from "Tomb Raider". Brute force alone won't be enough to bring the
game to an end, you'll have to think hard to find your way out of the confusing
labyrinth.

================================================================================