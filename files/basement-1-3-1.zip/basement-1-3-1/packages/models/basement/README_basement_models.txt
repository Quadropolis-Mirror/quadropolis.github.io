Mapmodels for Basement 1.3 / 1.3.1
----------------------------------

These models are built by Draakhond,
using modified existing textures (ivy leaf is from 'dcp').
