Texture package for Basement 1.3.1
----------------------------------

These textures are made from scratch by Draakhond and Zaaikort,

only the brick wall background is Gor's ST_GK_005_cc.jpg from the standard collection,
and rusty red is derived from Rorschach.