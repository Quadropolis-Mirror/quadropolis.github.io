Macintosh: To install, just right click "Sauerbraten.app" (control click for single button mouse) and select "Show Package Contents", then open "Contents", then open "Resources". Just drag "sauerbraten.icns" into "Resources" to replace it. Please note that if your dock contain "Sauerbraten.app", you will have to take it out, find "Sauerbraten.app", and put back in to see any change in the icon. This Icon is made for Mac OS X 10.5 (Leopard), if installing doesn't work on a Mac OS X 10.4 or lower, then you can make your own icon by using "sauerbraten.png".

Window: No support. Can be installed, but would require modification to the "sauerbraten.png" to a different file size and type (I don't know how).

Linux: The "sauerbraten.png" is the icon, but I don't know how to install it, sorry.