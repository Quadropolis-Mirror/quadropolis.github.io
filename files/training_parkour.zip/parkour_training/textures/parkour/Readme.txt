Readme
--------------

Original texture by makkE, modified by $N!P3R*