-------------------------------------------------------------------------------

ReVamp Experiment
by MeatROme

2006-09-16

-------------------------------------------------------------------------------

This is just a proof-of-concept.
It's usability in a real map-PAK is next to nothing :(

-------------------------------------------------------------------------------

 History :
-----------

Originally - in previous releases of sauerbraten -
variables defined in a maps config were stored in config.cfg;
more recently they get purged upon the load of a new map.

So the original trick of using "state variables" no longer works.
Since this really annoyed me - me being such a scripting fanatic -
I just had to prove it could still be done.

-------------------------------------------------------------------------------

 Installation :
----------------

 - unzip into your sauerbraten folder
 - run sauerbraten and call "/sp revamp/revamp0"

-------------------------------------------------------------------------------

 Usage :
---------

 On revamp/revamp0 you will only see a star filled sky,
 but on your console a command has been prepared for you.
 Trust me and hit ENTER.

 You will then get transported into the actual map which we will "revamp".

 It just contains some bare geometry, two teleports & their destinations,
 as well as a "regular" trigger and the end-of-level-trigger.

 When you hit the trigger you will
 a) move back a few steps but almost right away forward again,
    the gamespeed will drop to 50% and the console will remind you to hit ENTER
    This is _really_ important - it doesn't work any other way.
    This is also the reason why it has no real value for anything;
    I'd consider such a setup intolerable as a player myself!

 b) through hitting ENTER you internally increment the "state flag"

 c) through moving forward you will hit the end-of-level trigger

 d) you get transported into _the same_ map, but it will look different.
    That is what this demo is about - it shows you can reuse geometry,
    but handle it's visuals depending on the "state flag" (RMix).

 After having shown you this 3 times, 
 you finally get back to a real game of sauerbraten DMSP.
 Or - if you modified at the top of the cfg - whatever you want to play :)

-------------------------------------------------------------------------------

This is dedicated to junebug - to whom I tried to be a smart-ass,
telling him he could cut down map-PAK size with an "easy scripting trick".
Yeah, well ... so much for that.

-------------------------------------------------------------------------------

author contact : MeatROme@Count0.dynDNS.oRg

you are free to use any of the stuff in this package for your benefit,
if you can find a use for it you've certainly deserved it! ;)

I'd appreciate it if you referenced me in some way, but could I ever check!?!

-------------------------------------------------------------------------------

