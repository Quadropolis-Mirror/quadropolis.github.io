Taj Mahal by Tyros
Big thanks to DarkStar for fixing texture problem and providing the .cfg file :)

The Taj Mahal is a mausoleum located in Agra, India. More information is here:
http://en.wikipedia.org/wiki/Taj_Mahal

This is another map of mine in which I tried to make a close copy of the Taj Mahal.
Some of the textures are my own, and some from http://www.m3corp.com

Installation:

Extract the folder "tyros_textures" to your "Sauerbraten/packages" directory
Extract the .ogz, .cfg, and .jpg files to "Sauerbraten/packages/base" directory
In the game console, type /map taj_mahal

Hope you enjoy it!