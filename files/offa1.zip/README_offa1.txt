The White Fortress - offa1 By Dairy King (Otto) and Jake. 
Credits are as follows -
Layout - Otto
Texturing - Otto
Ideas - Otto, Jake
Item Placement - Otto
Lighting - Jake
Sounds - Jake 
Details - Jake

So about 50% for each, as always =D

You are allowed to edit this map in anyway and ditribute it as long as you give credit to me and Jake. And of course you cannot try to sell it ;D


Enjoy!
