Killcore3 by KI113R and Redon
License: Creative Commons BY-NC-SA
You are free to edit and distribute this map, as long as you give KI113R and Redon credit for the original map.
You are not allowed to use the map for commercial purposes.

"green" skybox created by Hazel Whorley.
This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
License.
The sky box may be used for non-commercial purposes only. You're free to use
and modify it otherwise. Please acknowledge credit in the map/mod readme file.