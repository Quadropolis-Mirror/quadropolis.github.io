 For all the skin artists out there who wanted their readme files
 distibuted with this, I am sorry.  It is for legal reasons (every
 last one of you had the name of the action star and movie.  It made
 it really risky for us and for you.)

 People, these skins are the result of other people's hard work.  They
 contributed them for our use and we apprciate that.  Please do not rip
 these or anything without finding out who made them. (go to the homepage
 http://action.telefragged.com and ask on our messageboard.)  It is 
 pretty lame if you rip them off without their permission.