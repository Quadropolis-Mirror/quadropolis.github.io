model by deathstar
texture by mitaman (c)