_____________________________________
Quake II CrackWhore - Steed's Contest
�������������������������������������
models : psteed@idsoftware.com
  pics : aniichel@hotmail.com
 sound : Dan & Cari Elkins, Randy Perry, Gudlyf and Mike Weatherton
 extra : eavy@earthling.net

Well the day your mother has been dreading has arrived. I've done
three versions of my little crackwhore for your fragging pleasure.
The skins were done in a rush so be easy on the criticism. After all
I ain't no Adrianator :]

The Contest Winner:
Her name is Anna Niichel and she happens to work at another game
company believe it or not. I chose her as the one because her pics
embodied the spirit of the model I built based on homage to the Crack
Whore Clan 'lo so many moons ago. Check out her pics then send her
mail at "aniichel@hotmail.com" to make her feel special (whoohoo!)

Thanks again for everyone who got involved with the Contest and for
those of you understand it was done in chest...er jest and in no way
is it a slight on chicks...er women.

I want to thank Dan and Cari Elkins, Randy Perry, Gudlyf and
especially Mike Weatherton for some cool CW sounds.

EAVY was kind enough to fix our wench so she can be played with...er
played correctly and in CTF.
____________________________
Steed's CW Skin Pack Contest
����������������������������
psteed@idsoftware.com
redwood@stomped.com
2@2design.org
eavy@earthling.net

The Contest Winners:

1st: [Jaysin] by Jason Brunner (jaysin@shaw.wave.ca)

I pick his as first because I love the face he did for the menu and
his skin comes the closest to what she's all about.

2nd: [bklann3] by Brad Klann (ss@telefragged.com)

I picked this for second because this guy is the best artist from the
bunch and optimizes the use of gl with his technique.  I'm a sucker
for nurses I only wish he had put red hair on her instead of blond.

3rd: [sumaww] by Rowan Crawford (sumaleth@frag.com)

He wins because I love Wonder Woman.

[bklann1] by Brad Klann (ss@telefragged.com)

[bklann2] by Brad Klann (ss@telefragged.com)

[bklann7] by Brad Klann (ss@telefragged.com)

[harpax] by Matt D'Elia (delia@halcyon.com)

[shades] by (unknown)

[stuffy] by Ryan Dobson (ryan@bluestar.com.au)

[sumabeth] by Rowan Crawford (sumaleth@frag.com)

[tks-cw-swamp-s] by Tom K. Stathopoulos (t-stathopoulos@nwu.edu)

CTF:

[tks-cw-blue] by Tom K. Stathopoulos (t-stathopoulos@nwu.edu)

[tks-cw-red] by Tom K. Stathopoulos (t-stathopoulos@nwu.edu)

Hats off to all the people who entered and made it hard to narrow my
picks down to ten.

 -- ps @ http://www.idsoftware.com/psteed
