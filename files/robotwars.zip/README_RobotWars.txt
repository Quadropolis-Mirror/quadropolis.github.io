******************************
RobotWars by Zapherone/RoofGuy
******************************

 This is my third map ever. I've put the most amount of work into it but the least amount of hours. (Compared to my other maps)

	The map was orginally called HillZone, but after adding the two robots from another one of my maps to the background, I figured RobotWars 

would be a more suitable title. There's also a bit of Metroid influence incorporated into the retro robot. GameTypes include: CTF, Capture, and DeathMatch.

 Feel free to tamper with the map but please do not re-distribute it. I don't want a ton of re-posts with little changes all over the site.

I appreciate it, and enjoy the map!  