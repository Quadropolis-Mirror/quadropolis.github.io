=================
City Pool Version 1.5
Map by super_chiken
=================
Host your next frag-fest in sleepy Sauerbraten City. This map is focused on the suburbs with the pool in the center
=================
To install:
Copy the both folders into your Sauerbraten Directory. Click "Yes to all" if it asks to overwrite. It will not overwrite anything! You do not need to copy the mod folder if you do not have SauerMod installed.
=================
Requirements:
Sauerbraten "Summer Edition" or higher
=================
Optional:
SauerMod Version .30 for Summer Edition or higher
=================
Changelog for version 1.5
Beds were clipped so you can't walk through them.
Pond looks more natural
Jumppads removed for the diving boards
Changed ground textures for the Pool
Sloped the bottoms of the stairs for the apartments
Redesigned the waterslide
***Bonus!*** Botroutes for SauerMod!****

Special thanks to apflstrudl for the excellent suggestions!

================
This map is protected by the Creative Commons 3.0 Attributive-No Commercial-No Deriative Works Lisence
================
Thank you for downloading City Pool Version 1.5!
www.freewebs.com/figames/
figames.forumsvibe.com
