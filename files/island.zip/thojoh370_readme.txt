 -=[ ISLAND ]=-

Welcome to the Island! We've docked at the shore to take a look
at the strange building. Hmm... it seems to be some kind of armory...
Maybe you think there's no armour, but you can find them if you're
smart enough... Good luck! And you - the boat provides health.