This is symmetry , 
an symmtric map , playable at all modes. If you dont like symmetric maps you should delete this one, because it wont fit your thoughts.

This is UPDATE 1:

-more light sources 
-clip
-.......

=========================================================================================================================================
Greetings, by Mysterious

26.01.2010 18:42