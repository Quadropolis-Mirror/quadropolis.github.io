------------------------------------------Updates-----------------------------------------------

In this version of odejoy, I managed to update a few things. I fixed some of the texture mistakes
and added particle effects to the tourches and blue lights. The particles for those lights seemed
to have darkened in the new release, so it does not look as good, but still satisfactory. I think
this map nears completion, this is my restored classic cube map and I think it has turned out well,
and i hope to see some of you playing it!

-----------------------------------------How to install----------------------------------------

Put odejoy.ogz and odejoy.cfg in the Sauerbraten/packages/base folder. Enjoy.
