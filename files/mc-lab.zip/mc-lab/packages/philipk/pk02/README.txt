PK02 - Quake IV texture set by Philip Klevestav
www.philipk.net | philipk@philipk.net

***

If you want a HL2 Source version of this set goto: www.philipk.net.

***

Feel free to edit the textures and make additions in any way that suits you.
Have fun.

Thanks to mnemjc for fixing some broken materials!

**********************************************************************************

config-file for sauerbraten and p1nokjo_light01_glow.jpg by p1nokjo

ps: i also made some glow textures a little bit darker, so they look better in sauerbraten