Created By: xgmx
Sunday, February 11, 2007

Extract in your Xfire folder, then if it asks you to overwrite anything say yes, then launch Xfire or if you have Xfire already on just logout and exit Xfire, then launch it again.

Note: Do not download any Xfire patches.