Abandoned Factory:

Install by extracting it to ~/cube/packages/
Access by typing /map enig2 in the chat function

This map also contains a custom skybox (I don't remember where I got it)