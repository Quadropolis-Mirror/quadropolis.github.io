===============================================================================
                            Pottery World - Cubic Maps
===============================================================================
Details:

Game:                Cube [http://www.cubeengine.com/]
Map Name:            KatreZ
Version:             Retail 1.1
Building Time:       About three weeks.
Release Date:        April 2006
Author:              Pablo "RatBoy" Ciamarra
E-Mail:              ratboy_jo@hotmail.com
WebSite:             http://www.pottery-world.com.ar/
Story:               KatreZ was the nickname of the processing and storage
                     facility of the Feather War Factory. After years of making
                     soldier toys, the whole factory closed, but the owned
                     rented this zone for deathmatch battles to keep earning
                     some money from the forgotten factory.
Description:         A rather large free for all map, for 8-12
                     players or even more I think. It's set in a
                     futuristic but rusty type of storage facility...thing.
WQD Count:           Top of 5000 at the bigger areas, between 200 and 2000 in
                     the rest of the level.
Textures:            Iikka "Fingers" Keranen, Sock, Than & John Fitzgibbons.
Skybox:              "Myghty Pete" [http://petes-oasis.com]
Music:               Marc "Fanatic" Pullen [http://fanaticalproductions.net]

===============================================================================
Instalation:

Extract to the main Cube folder.

If you don't have subfolders activated, here's how you do it manually:
The "katrez" folder goes into "Cube\packages\"
The "katrez.cfg" and "katrez.cgz" inside "base" folder should go into
"Cube\packages\base\". That is all.

===============================================================================
Notes:

- About the name, I really suck at picking up names so I wrote the first
  thing that passed through my mind.
- If you find any bug please report it to my mail.
- If this level gets any kind of hosting, review or wathever, I would
  like to know where =).
- Lightning will suck forever.

===============================================================================
Version History:

Retail 1.0:
- Notable graphical changes, much more detail everywhere.
- New area on the train tracks.
- Worked more on the lightning.
- Custom skybox and changed music theme.
- Entities well placed.

Retail 1.1
- Really minimal bug fixes. You won't even notice them.

===============================================================================
Copyright & Permissions:

This level is copyrighted by Pablo Ciamarra 2006.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!

You MAY distribute this level through any electronic network (internet,
FIDO, local BBS etc.), provided you include this file and leave the archive
intact.

===============================================================================