===============================================================================
                            Pottery World - Cubic Maps
===============================================================================
Details:

Game:                Cube (http://www.cubeengine.com/)
Map Name:            Lifepool
Version:             1.0
Building Time:       One Week
Release Date:        April 2006
Author:              NEXUS
E-Mail:              F14_A_Tomcat@hotmail.com
WebSite:             http://www.pottery-world.com.ar/
Description:         This is actually a map made by my brother a long time ago.
                     It's simple and plain but nice, and that's why I decided
                     to publish it since he didn't want to.
Textures:            Iikka "Fingers" Keranen (Original Cube release)
Skybox:              Sock (Original Cube release)

===============================================================================
Instalation:

Extract both .cfg & .cgz files to the folder "Cube\packages\base\"

===============================================================================
Notes:

- If you find any significant bug please report it to my mail.
- If this level gets any kind of hosting, review or wathever, I would
  like to know where =)

===============================================================================
Copyright & Permissions:

This level is copyrighted by NEXUS 2006.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!

You MAY distribute this level through any electronic network (internet,
FIDO, local BBS etc.), provided you include this file and leave the archive
intact.

===============================================================================