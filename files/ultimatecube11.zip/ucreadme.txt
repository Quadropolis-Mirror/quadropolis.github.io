Ultimate Cube 1.1 Readme

UC is a map pack of maps for Cube that never made the release and never will, as Cube is discontinued.

There is a total of 40 new maps, with an updated menus.cfg included.
It also reverts the item models pack back to old skool Cube items, with makkE's revamped model pack.

To install, extract into your Cube directory. Simple as that. :)

The following people have contributed to this pack (in alphabetical order):

007
Acieeed
CC_machine
disturbed
DTurboKiller LT
enigma_0Z
gimi
Heretic
junebug
makkE
MisterCat
Max Of S2D
Nexus
Philipp
Raelus
RatBoy
Ridge Racer
shadow
sharky
sparr
staffy
wolf

Changes from 1.1:
Added 11 new maps, including babel by sharky, and another 10 awesome maps by MisterCat.
Removed SilentFox's sound pack, figured half the point of Ultimate Cube was to bring back the ol'Cube.
Removed kkjump2, its an SP map, Ultimate Cube is focused on MP.

Have fun with this pack!
Passa