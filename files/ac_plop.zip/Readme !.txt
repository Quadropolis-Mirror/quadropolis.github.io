        ac_plop by #eXa*|Brett(concept design) and #eXa*|#DarKnoT*(finshions) 


Do not broke the ac mapping rules
Do not modify the map. 

If We saw this one modified, you'll be blacklisted on some servers




      Visit www.explosive-alliance.c.la