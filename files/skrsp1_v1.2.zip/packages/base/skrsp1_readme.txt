MELTDOWN (skrsp1) - Readme
----------------------------------------------------------------
http://quadropolis.us/node/3860
----------------------------------------------------------------
Title		: Meltdown (skrsp1)

Author		: James 'Skur' Rucks

E-mail		: jamesleerucks@gmail.com

Release Date	: 2013-10-14

Version		: 1.2

License		: CC BY-NC-SA 3.0

If you include this map in a mappack or publish it on your website you HAVE to include this readme file.
----------------------------------------------------------------
A Singleplayer campaign for Cube 2: Sauerbraten (sauerbraten.org)

Special thanks to Yves 'evillair' Allaire and Gregor Koch for the textures.
----------------------------------------------------------------
This map was created as entry for the Singleplayer Mapping Contest 2013 on Quadropolis.us (quadropolis.us/node/3838)

I recorded a time-lapse video of making it which can soon be found on youtube.com
----------------------------------------------------------------

Happy fragging!

 -Skur