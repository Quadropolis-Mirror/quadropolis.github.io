=============================================
SPACETUBE - A MAP FOR CUBE 2: SAUERBRATEN
=============================================

DESCRIPTION:  A map to play in Cube 2: Sauerbraten on ffa, teamplay... (no SP).
------------

INSTRUCTIONS:
-------------
Linux (Ubuntu 10.x, Linux Mint 9...):
1-With root rights copy de spacetube.jpg and spacetube.ogz to folder: file sysrem/usr/lib/games/sauerbraten/packages/base
2-The map in the main menu: edit de text file, into de folder file sysrem/usr/lib/games/sauerbraten/data/menus.cfg and write spacetube into the line: mainmaps = "spacetube complex ..." Attention: No capital letters and spaces in the map name. Alternately, you can run the map in console ingame, type letter t to open text chat and write: /map spacetube
3-Play the game
Windows:
1-copy de spacetube.jpg and spacetube.ogz to c:/program files/cube2/packages/base
2-The map in the main menu: edit de text file, into de folder cube2/data/menus.cfg and write spacetube into the line: mainmaps = "complex spacetube ..." Attention: No capital letters and spaces in the map name. Alternately, you can run the map in console ingame, type letter t to open text chat and write: /map spacetube
3-Play the game
Mac:
I don't have a Mac (too expensive...).

INSTRUCCIONS:
-------------
Linux (Ubuntu 10.x, Linux Mint 9...):
1-Amb drets de superusuari copia spacetube.jpg i spacetube.ogz a la carpeta: Sistema de fitxers/usr/lib/games/sauerbraten/packages/base
2-Per seleccionar el mapa en el menú principal: editar el fitxer de text, de la carpeta Sistema de fitxers/usr/lib/games/sauerbraten/data/menus.cfg i escriu spacetube a la línia on digui: mainmaps = "spacetube complex ..." Atenció: No poseu majúscules ni espais en el nom del mapa. Alternativament, pots iniciar el mapa des de consola durant el joc, escriu la lletra t per obrir el xat i escriu: /map spacetube
3-A jugar
Windows:
1-copia spacetube.jpg i spacetube.ogz a la carpeta: c:/program files/cube2/packages/base i escriu spacetube a la línia on digui: mainmaps = "spacetube complex ..." Atenció: No poseu majúscules ni espais en el nom del mapa. Alternativament, pots iniciar el mapa des de consola durant el joc, escriu la lletra t per obrir el xat i escriu: /map spacetube
3-A jugar
Mac:
No tinc un Mac (massa car...).

INSTRUCCIONES:
-------------
Linux (Ubuntu 10.x, Linux Mint 9...):
1-Con derechos de superusuario copia spacetube.jpg y spacetube.ogz en la carpeta: Sistema de archivos/usr/lib/games/sauerbraten/packages/base
2-Para seleccionar el mapa en el menu principal: editar el archivo de texto, de la carpeta Sistema de archivos/usr/lib/games/sauerbraten/data/menus.cfg y escribir spacetube en la línea donde ponga: mainmaps = "spacetube complex ..." Atención: No pongais mayusculas ni espacios en el nombre del mapa. Alternativamente, puede iniciar el mapa desde consola durante el juego, escribe la lletra t para abrir el chat y escribe: /map spacetube
3-A jugar
Windows:
1-copia spacetube.jpg y spacetube.ogz en la carpeta: c:/program files/cube2/packages/base y escribe spacetube en la línea donde ponga: mainmaps = "spacetube complex ..." Atención: No pongais mayusculas ni espacios en el nombre del mapa. Alternativamente, puede iniciar el mapa desde consola durante el juego, escribe la lletra t para abrir el chat y escribe: /map spacetube
3-A jugar
Mac:
No tengo un Mac (està muy caro...).

CREDITS:
--------
Author: Catalanoic
Website/blog: http://www.ruta66.bloc.cat
Email: catalanoic @ gmail dot com
Game: Cube 2: Sauerbraten
OS: Linux/Win/Mac
Note: Sorry for my bad english




