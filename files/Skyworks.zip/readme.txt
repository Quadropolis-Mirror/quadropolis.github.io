"Skyworks" by miscreant
--------------------------------------------
This is a slightly updated version. 

Added:

-Two jumppads (one for easier roof access).
-Wider paths near the top.
-More ammo and health.
-Crates on the ground level.
-Some texture fixes. (Some textures still aren't right, I know.)
-More lights for a less "cold" feel.
-Changed lightprecision.
-Clipped the tops of the walls and other areas that needed it.
-Rearranged some pickups.
-Other minor crap that I can't remember.
---------------------------------------------

To Open:

1) Copy the map file (OGZ file "skyworks") to this directory: Program Files>Sauerbraten>Packages>Base
2) Run Sauerbraten, type "/map skyworks".
---------------------------------------------

I hope this map is playable on a variety of systems, although I'm afraid older hardware may explode. Just a heads up. :P

Have fun!