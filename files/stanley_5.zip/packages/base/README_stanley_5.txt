This is an artistic map set in Ancient Egypt.

It was made in coopedit on a private server by James Stanley, Maximilian Krupa, and Dracion (who wishes to remain anonymous). It plays fairly well on DMSP, but best on multiplayer. There are four towers surrounding a central courtyard with corridors linking them. The top of the towers contain rifle spawns and a pool, the middle is an MG post, and the bottom is a spawn and teleport area.

To install the map, go to your sauerbraten install directory and extract the zip file. Provided you don't already have a map named stanley_5, nothing should be overwritten.

Contact me on jamesstanley@bluebottle.com for more information.