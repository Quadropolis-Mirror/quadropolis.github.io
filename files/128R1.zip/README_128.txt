128 Spheres by VastLite - February 15, 2010 (Trooper)

	(There are really 205, I know) This map is the culmination of a bunch of different creations the majority of which are spheres. I have 11 different ones in total, sizes 3-12 but not one of each. Some were too frustrating/didn't look good so I skipped the size all together. There are even some sizes that have more than one version. I tired to color them interestingly but some of them look a little odd at cetain sizes (The stretched cubes make the texurtures look bad.) If you can't tell, this is a concept map, it's not really meant to be "played" on. It's also a work-in-progress, I mean to make most of them hollow but have only gotten around to half or so. I also come up with stuff I would want to add every now and then. So in summary, this is just a collection of interesting shapes and colors not meant to be too serious of a map.

-VastLite (vastlite@gmail.com or "vastlite" on xfire)

EDIT 1: Fixed geometry errors. (2/16/10)