README
--------------------

Thank you for downloaded this map ;)



ac_zone_beta2 made by $N!P3R*



Map based for DM // TDM



Please do not edit this map 



.-=2008=-.

