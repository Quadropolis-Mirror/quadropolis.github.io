Thanks for downloading the action packed map "Orgosville!"
Please give the best rating you can. Just extract these files into your
sauerbraten/base folder.