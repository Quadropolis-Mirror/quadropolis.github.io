This was made by w00tclan.  Not everyone pitched in, as this was made in 1 hour.  Jake-w00t, uber-w00t, 3dit-lee-w00t, and w00t
helped texture map.  Original idea was w00t's, and the map was made by w00t.  (Thanks w00t peepz, you helped make a long texturing
job short!)  This is for instagib, its not a pretty map, but it gets the instagib job done.  There is good cover, an overhead clip,
good player start points.  Wherever there is a fire particle, that is a jumppad.  Enjoy the map! =)

~w00t


THIS IS BETA VERSION





Put .cfg and .ogz (if you want .jpg (it dont do anything) in (default for windows) C:\program files\sauerbraten\packages\base

If you dont have it in ur default, or u dont have a windows machine, put in ur sauerbraten folder, packages, then base.  Your all set!
Just type /map w00w00t ingame to vote, or load it.



	<('.'<) (^'.'^) (>'.')> kirby w00tang