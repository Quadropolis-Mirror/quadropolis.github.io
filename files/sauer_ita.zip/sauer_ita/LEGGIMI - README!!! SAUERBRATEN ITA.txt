***SAUERBRATEN 100% ITALIANO***
questo pack contiene: 
- men� tradotti totalmente in italiano
- client (32/64 bit) tradotto quasi interamente

***INSTALLAZIONE***
Prima effettua un backup dei file:
-bin
   - sauerbraten.exe
-bin64
   - sauerbraten.exe
-data
   - game_fps.cfg
   - menus.cfg

E quindi sostituisci quelli presenti in questo pack con gli originali

NON MI ASSUMO ALCUNA RESPONSABILITA' DERIVANTI DA MALFUNZIONAMENTI; IL BACKUP VA SEMPRE EFFETTUATO! ;)

by Andrez
http://andrezweb.altervista.org