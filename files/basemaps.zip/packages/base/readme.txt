------------------------------------------------
Basemap 1 - Created by Darkstar
------------------------------------------------

This map is designed to be used as a template for map designers. 
You may edit all elements of this map and redistribute as your own without the need for credit.
Please do NOT redistribute this map if it has not been edited.

This map comes as geometry only.
All lighting, skyboxes, fog and textures are not set. This is for the owner of the map to do.
The map has been checked for bugs and smoothed so that it looks clean when lit,
but geometry may be buggy if you edit with a small grid size.
It's advised that you optimise the map before you edit:
[ F3 ---> Optimise Map ]

Thank you for your support. 