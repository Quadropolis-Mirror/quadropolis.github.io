I found these on the internet as free WAV downloads. Sorry, no link ATM.
MeatROme
