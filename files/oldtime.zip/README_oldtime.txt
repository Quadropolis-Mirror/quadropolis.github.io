No story written 'til now.
The work is still in progress, so bugs may appear, lightning problems could be found, the mountains quite look disappointing, etc.
But we'll fix it.
Map made by FlorianGerman, Seppz0r and Chrisz0r.
All credits go to them, and any content of the map or any part of the script may not be copied.
Thanks for you sympathy :D.

Update 1, 17.05.2010:
	-Added a few lights, fixed light positions of other ones
	-New ladders
	-Fixed some bugs
	-Decreepied a little part of the mountains
	-Deleted some weapons, weapon flood was far to high
	-Textures at some locations fixed
	-A few other things, which aren't worth to be mentioned :)


Contact:
Christian T.
ossimc@hotmail.de
xfire: chrisz0r94
Ingame: Seppz0r / Chrisz0r