------- The City by Tyros{X3} and meddick {X3} -------
	Map for Sauerbraten
	This is my first real map I decided to share with people
	The music is my own
	For best look I recommend turn on glass reflection in options menu

	Instructions:
	Extract .ogz, .cfg, and .jpg files to Sauerbraten/packages/base directory
	Extract the folder "tyros_music" to Sauerbraten/packages directory
	In the game, type /map the_city

	Have fun! :)