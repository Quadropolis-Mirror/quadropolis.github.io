CON8(Beta 10/25/09) by Aquamarine 
for Sauerbraten Trooper Edition{http://www.sauerbraten.org}

Underground Base with Helipad. Suitable for Protect, CTF and Deathmatch. Package includes a few custom sounds and textures.

Special Thanks to Wormwood(Hail Satan) for the Tarp-Covered-Crate model as well as the Spiral Staircase.

----------------------------------------------------
Installation: Extract CON8.zip -Inside you will find these folders and files. Add them to your PACKAGES directory:

AQUA-add this folder to the root of your Packages folder (packages/aqua)

BASE(map file, screenshot, waypoints, map-config)-add these files to your Packages/Base folder.

SOUNDS/AQUA- add this to the Packages/Sounds Folder(packages/sounds/aqua)

-or simply drop the packages folder onto your Sauerbraten directory 8)
----------------------------------------------------

Gameplay Tips:
-You can reach the Health from below if you shotgun/rifle jump. Rifle jump again from there and reach the upper walkways and a shortcut to the flag.
-Grab the Grenades and spam the enemy from above.
-You can shoot from behind the grate in the pipe where the Chaingun is hidden.
-Have Fun!