This map took a full 2 months to construct. It's my baby :P


It's intended mostly for INSTA CTF but can be played on ctf, regen capture, instagib, and deathmatch because I threw a few bases and ammos in there. 

This is my first real map (but my second submitted to the site).

In the packages/kretren folder you'll find a few random things I put in there. Firstly there's a few new skyboxes you can keep in the folder or drag into the main Sauer packages folder. They're pretty good, but I can't take credit for them. 

The source is here, where you can get other skyboxes:

http://eliteforce2.filefront.com/file/Sorbets_Skybox_Pack;84704

The others are tectures I took from other folders. They don't work, but it'd be nice if they became textures because they look cool as-is.

Enjoy!

-Kretren