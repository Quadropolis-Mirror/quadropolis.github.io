*********************************************
Sauerbraten Enterprise Level FAQ
Version 1.0 Release
Release Date: May 23, 2008
*********************************************









*********************************************
Credits:
Level Design by: Joseph �Dangerstripe Dan� 
Textures by: Joseph �Dangerstripe Dan�
                     McCian
FAQ by: Joseph �Dangerstripe Dan�
*********************************************








*********************************************
System Requirements:
A PC capable of running Saurbraten. REALLY REALLY well. It works fine on our computers, your mileage may vary.

A copy of Sauerbraten open source freeware game engine.
*********************************************










*********************************************
Installation:
The folder is set up using standard Quadropolis map distribution requirements.
However, please not that for *nix systems, the level and directory use a capitol "E" in Enterprise. A map command would be /map Enterprise/Enterprise, etc
*********************************************




*********************************************
FAQ
*********************************************

Q: What exactly is this thing?

I decided to create the Starship Enterprise (NCC-1701, no bloody �A�, �B�, �C�, or �D�) as a FPS level. The entire ship, front to back, top to bottom. To scale (or as close to it as we could do with the Cube engine)





Q: How big is this thing exactly?
Exactly? No clue. Rough estimates are about 2 million square feet give or take.




Q: 2 MILLION? WTF were you THINKING?
Not much, really. Mostly how I just wanted to finish the blasted thing and do something else.





Q: Can you give me a better idea of the size?
OK, try this. There are 26 decks on the ship. The largest decks are decks 6 and 7 (the big part of the primary hull). Each of those decks has about 12 to 13 acres of space. 

The flight deck of the USS Nimitz is about 4.5 acres.


Q: How long did this take you?
About 22 months, but that was on and off (mostly off). I would say that the final version had about 1000+ man hours of work in it.




Q: How come the ship isn't fully rounded?
The sauerbraten engine is an amazing game engine capable of creating huge game levels with lots of detail and amazing lighting effects. However, it's called the �cube� engine for a reason- everything in there is a square. It's hard to make a true circle out of a square, so we improvised as best we could. You will notice a lot of the interior geometry is based off of right angles for this reason- it was both easier and faster.




Q: If this is an FPS level, it sucks. It's too big, the weapons are too far apart, etc etc etc.
That's because although it was built as an FPS level, it was never really intended for serious death match action. I built it just to build it. Actually, part of it was I wanted to learn how to use the Saurbraten map editor. This is my first map with it. Well, the first one I finished anyway. I started this project about a week after I first start playing with Suaerbraten.




Q: The maintenance areas seem a tad large, and oddly shaped.
They weren't there originally. When I first started building the map, decks 6 and 7 were an octagon, like decks 4, 5, 8, 9, and 10. We figured out how to do a crude digital rounding, and so rounded out decks 6 and 7 which ended up adding some space in the corners, and then figured out how to do a smooth rounding which added even more space that was not easily accessible, so I made them into maintenance areas. 

With the secondary hull, you might notice that there are virtually no maintenance corridors on the bottom half of the ship; That's because when I used the new rounding technique to round out the hull, the top half of the ship had already been done and ended up gaining some space. The bottom half of the hull was mostly empty when I did that, so the rooms were just resized to fit the new space.




Q: Why is sick bay is green?
The same reason that the main transporter rooms are purple- that's the color they were in the TV show.




Q: The texturing of the map looks vary basic

I was following the theme of the show. Since Star Trek was one of the early TV shows filmed in color, they tended to use a lot of bright, solid, and simple colors on their sets. I was simply following true to form.
Hey, can you do the <insert name of absurdly large ship, building, or object here> next?
Probably not. Not because I can't, but I think I just don't want to. So don't ask. I will NOT do the  Galactica, Babylon 5, Red Dwarf, or Rama.




Q: Wait a minute- I don't remember <random humorous thing inserted into the ship for comedic value here> being on the Enterprise!
2 million square feet is a lot of square feet. After a while, you just get bored and make things to keep you sane. To bad it didn't work...




Q: Do you have a list of all of the jokes, homages, and other �humorous� things in the map?
I have one, but I don't plan to share it. I figure you will have more fun just poking around and seeing what all is there.




Q: What are those stripes on the floor?
In watching an old episode of Star Trek, I noticed that there were narrow bands of color on the floor. Not knowing what to do with those, I made them into a sort of �you are here� sign; If you know how to read them, you can get an idea of where you are by looking at the band patterns. No, I won't tell you what they mean. You should figure that out by yourself.




Q: Hey, I've got the Enterprise Blueprints, and your level doesn't match them!
Tough. I had to improvise quite a bit.




Q: Hey, my Enterprise Blueprints show the Photon Torpedoes on the lower side of the primary hull, and you have them on the top! Die in a fire!
The exterior placement of weapons, as well as the sizing of the ship, were taken from the 1975 Starfleet Technical Manual by Franz Joseph. His plans are the only ones officially endorsed by Paramount. If your plans differ, they are wrong.

That being said, his plans didn't always agree with the show or the miniatures used in filming. However, I had to pick a starting point and go from there.




Q: The secondary hull looks too big.
I know. However, it was sized in accordance with Franz Joseph's plans. Thus, the size is correct, even though it looks more like the secondary hull from ST: TMP and later films and not the original series.




Q: The Hanger Deck looks too small

That was intentional; If you follow the scale of the ship model, the hanger deck is something like 60 feet tall and looks all out of proportion when you are walking around in it. I cut it down to about 30 feet and it looked a lot better.

This leads into the next question...


Q: The shuttle is too small for the hanger deck
That's not a problem with me, that was the show that had it wrong. For the shuttle to be as large as it appeared to be in the show in relation to the ship, it would have to be nearly 20 feet tall and over 100 feet long. Since the shuttles in relation to the actors are the size of a large van, I had to pick a scale that made sense and stick to it.

As a side note, it appears that in the movies they figured out the scale problem, which is why the shuttlebay seemed to hold so much more stuff in things like Star Trek 5 than it did in the TV show.




Q: Where are the Jeffries Tubes?

As I understand it from looking through various incarnations of blueprints and plans, the Jeffries tubes primarily went to the warp nacelles. Since you couldn't fit up an angled nacelle that was less than 5 blocks high or so (throwing the scale WAY off), I just left them out. Sorry.




Q: Why can't I get to decks 1 or 26 via ladders?

The bridge is simple enough- you can't get there because there is no room for a ladder, nor was there a way to get from the ladder to the bridge in the show. Deck 26 was because by the time I got down to 26, there wasn't a good space to connect decks 25 and 26 together.




Q: There are some areas on the top of the primary hull that are messed up. Why didn't you fix them?
There is some sort of geometry problem in the map. I have fixed those damaged ridges, but every time I do a light calc they get messed back up again.




Q: The impulse engines look like the ones from the movies and not from the TV series.
Yeah, when I tried to build the ones from the TV show they just looked stupid.




Q: Hey, [Random Thing from Ship] doesn't look like I think it should!
I'm going to combine all further gripes about the ship design into this one question. A lot of things that don't look like the show either don't look like the show because of limitations in the game engine, limitations in my skill level, or they didn't look good when made according to the original spec. And some of what's left may simply be a goof; For example, the chairs are supposed to be made out of blue plastic instead of gray. I didn't realize my mistake until I had about 20 bajillion of the suckers in place, and didn't feel like tracking them all down and changing them.




Q: Why the Enterprise? Are you some sort of Star Trek headcase?
No. I like the show, but for me this was just a challenge to see if I could do it.




Q: What are those colored cubes in the bowling alley?
Bowling balls, of course. See, that was a joke of sorts; I am using the cube engine to make the map, so I  made the bowling balls cubes.




Q: Wait a minute- there's not a bowling alley on the Enterprise!
Yes there is. You never saw it, but it was mentioned in the episode �The Naked Time�




Q: I thought you said you weren't a Star Trek nut, and yet here you go quoting episode titles.
I looked the title up on Wikipedia.




Q: Why don't the turbolifts work as turbolifts?
The start of the map predates lift support in Sauerbraten. By the time they added it, I had already set up teleporter stations in the lifts to use instead. It would have been too much work to re-engineer the lift shafts to work with something else.





Q: Why aren't there any doors?
Dude- there is something like 1000 to 1500 door frames in the map. To add doors, first I would need to create a Star Trek door model and animate it. This is beyond my skill (I am not a model maker). Then, I would have to VERY CAREFULLY place 1500 doors in the ship. This is beyond my patience. Then I would need to add the triggers to open said doors. And don't even get me started on adding SOUNDS to the doors. All of this would have added a few months to the release date.

I just wanted to be done with this thing. If you want to add doors, be my guest. 






*********************************************
Final Note
*********************************************
Feel free to distribute, modify, or change this map as you see fit, but I would ask that you include this FAQ (with whatever updates you feel you need to add for any changes you made). If you do anything really cool with the map, let me know- I would love to see it. 


*********************************************
Contact Info:
*********************************************
Comments? Questions? Drop me a message on the Sauerbraten forums or email me at jmpizzitola@yahoo.com.