Title: Camper
Author: Nik Mirza/ WindAstella
License : CC-BY

Extract the file to your sauerbraten folder. Backup Ogro2 folder since it will be overwritten camper file.

The model is still WIP. I included the source for anyone to do anything with it, just credit me if you make
anything with it.

Contact: nik96mirza@gmail.com