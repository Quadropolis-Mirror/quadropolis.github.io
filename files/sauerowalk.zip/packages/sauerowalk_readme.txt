sauerowalk by rabe (2015) - [original map aerowalk for quake by preacher/hubster]

installation:
- copy the content of the base folder in this zip to the base folder in your user directory
- install the e6-texturepack (http://quadropolis.us/node/2778, version: 25th Sept. 2012)
- install the e7-texturepack (http://quadropolis.us/node/2790, version: 23th Sept. 2012)

credits:
- preacher and hubster for the map
- evillair for the textures
- all mappers and players, who gave me feedback

contact:
- pm rabe at quadropolis.us or sauerworld.net