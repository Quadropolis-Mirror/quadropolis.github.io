***Baustelle (ac_baust) by Andrez***
Map set in an industrial and slightly urban theme.
Flag/FFA modes
10 CLA/ 10 RVSF/ 20 FFA spawnpoints.

**License***
BY-NC-SA/3.0


**Resources and links**
http://andrezweb.altervista.org/ac/ 
- my AC stuff page (not up to date)

http://ac-akimbo.net
- AC maps, models, mods...