                        __  |__,  ___         __  
               (__(__( (__( |  \ (__/_ (__(_ |__)
                                             |
2007-10-05 [instagibwake@gmail.com]

This content is distributed under the following Creative Commons License.
             Attribution-NonCommercial-ShareAlike 3.0 Unported

You are free:

 * to Share — to copy, distribute and transmit the work
 * to Remix — to adapt the work
        
Under the following conditions:
        
 * Attribution. You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 * Noncommercial. You may not use this work for commercial purposes.
 * Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.
 * For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do this is with a link to this web page.
 * Any of the above conditions can be waived if you get permission from the copyright holder.
 * Nothing in this license impairs or restricts the author's moral rights.
                                                      
                                                      
///////////////////////////////////////////////////////Attributes to http://www.wakeup-4-life.de

wake5 aka Greyskull is a fast map meant to be played 1on1 FFA or instagib but it is fun with up to four players. rocket/rifle/grenade/cg-jumps are encouraged!


Developers:
	wakeup

Testers:
        Drakas
        solea
        daMfr0^
        makkE
        rocknrol
