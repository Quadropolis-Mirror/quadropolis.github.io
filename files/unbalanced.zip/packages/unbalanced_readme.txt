unbalanced by rabe (2015) - [original map unbalanced for warsow by acid]

installation:
- copy the content of the base folder in this zip to the base folder in your user directory

credits:
- acid for the map
- all mappers and players, who gave me feedback

contact:
- pm rabe at quadropolis.us or sauerworld.net