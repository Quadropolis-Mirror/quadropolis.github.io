Palace Gardens


(Version 3) 

Created by Garak on July 1st, 2009.


Designed for CTF, but the map can be used with other game modes as well.
--------------------------------------
It has been reported that the frame rate can be low in the main garden area.  If so, lowering the graphical settings of the water may help.