Map seafight by teammate(hase)

At first you have to put the files in the right area of your AssaultCube
directory.

-----------------------------------------------------------------

You find 3 several parts of the map in this .zip folder.

copy and past the way like this:

seafight.cgz & seafight.cfg 
--> .../AssaultCube/packages/maps
there is where you have to put in this two data files

next step:
copy folder "jaj"
and past in this direction
--> .../AussaultCube/packages/textures/skymaps
there is where you have to put in this one folder

-----------------------------------------------------------------

After that,
you start the game an write this:
/map seafight

-----------------------------------------------------------------

Enjoy playing!!!
;-)
