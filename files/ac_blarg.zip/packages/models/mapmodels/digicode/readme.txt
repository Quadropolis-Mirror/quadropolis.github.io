Mapmodel from AlienArena2007
skin & scale modified by DES|Cleaner