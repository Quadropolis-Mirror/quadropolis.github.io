***ac_civic (Civic centre) by Andrez***

*ABOUT
Huge urban/industrial with small areas of sewer theme. 
Flag/FFA modes capable, with up to 20 players.

Entstats:
 259 light
 40 playerstart, 10 CLA, 10 RVSF, 20 FFA
 4 pistol
 6 ammobox
 4 grenades
 5 health
 4 helmet
 1 armour
 1 akimbo
 215 mapmodel, 61 clipped
 2 ladder
 2 ctf-flag, 1 CLA, 1 RVSF
 54 sound
 36 clip
 3 plclip
 3 days of map editing
total entities: 636

*LICENSE
CC BY-NC-SA 3.0 ---- http://creativecommons.org/licenses/by-nc-sa/3.0/

*INFO
More AC stuff at
http://andrezweb.altervista.org/ac/
http://ac-akimbo.in
