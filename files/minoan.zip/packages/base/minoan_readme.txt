Minoan - By J Windecker, Catelite, and RaZgRiZ. 
This entire maze was made by hand, every last wall. There are Zero loops, and no path will ever meet another with the exception of the beginning of the path. 

My own level of sanity ( Jake ) was -47 at the time this was finished, not sure about Catelite or RaZgRiZ. Any ratings to this map will be divided by three and subtracted from the sanity of each of the makers.

Anybody who cares to detail the map is free to do so, there is too much to do and I for one am not crazy enough to even try. 