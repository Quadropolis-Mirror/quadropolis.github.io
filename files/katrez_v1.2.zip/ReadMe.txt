===========================================================================================
                                     RatBoy's Cubic Maps
===========================================================================================
File Details:

Game:                Cube (www.cubeengine.com)
Game Version:        29-08-2005
Game Mode:           DeathMatch
Map Name:            KatreZ
Map Version:         Retail 1.2
Building Time:       About a month.
Release Date:        May 11, 2007
Author:              Pablo "RatBoy" Ciamarra
E-Mail:              ratboy_jo@hotmail.com
Description:         A rather large free for all map, for 8-12 players or even more I
                     think. It's set in a futuristic but rusty type of storage facility...
                     thing.
WQD Count:           Top of 5000 at the bigger areas, between 200 and 2000 in the rest of
                     the level.
Textures:            Iikka "Fingers" Keranen, Sock, Than & John Fitzgibbons.
                     Custom modified textures by myself.
Skybox:              "Myghty Pete"
                     (http://petes-oasis.com)
Music:               Marc "Fanatic" Pullen (Orginal Cube Soundtrack)
                     (http://fanaticalproductions.net)

===========================================================================================
Map's Story:

  Long ago, before the deathmatch was considered as a legal sport, a war raging for conquer
Identi planet took place in the Estrada system. During this war the human race built a
base of operations in the close small Avarax planet, and with it the Feather War Factory,
destined to supply the soldiers with vehicles, equipment and of course, weapons.

  After the war finished, the Feather War Factory had some legal issues and went down like
an extinct eagle. The factory closed, and the owner, desperated and without money, heard
about this so called "deathmatch arenas", so he supplied the processing and storage
facility of the factory (aka KatreZ) for deathmacth matches.

===========================================================================================
Developer Notes:

- I really, awfully suck at picking up names for my creations. The only things I can pick
  are about something that the name reminds me, or the theme of it, but for this one, I
  picked the first incoherent thing that came up in my mind, and that's why KatreZ.

- Since mappers aren't perfect, neither am I, this map could have some graphical bugs or
  gameplay ones too. So for that, feedback to my mail regarding this point will be very
  apreciated, also any opinion in general about the map will be apreciated.

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to Cube main folder.

Mannually:
"ratboy" folder goes inside "Cube\packages\" folder.
"katrez.cfg" and "katrez.cgz" should go into "Cube\packages\base" folder.

===========================================================================================
Version History:

Retail 1.0:
- Notable graphical changes, much more detail everywhere.
- New area on the train tracks.
- Worked more on the lightning.
- Custom skybox and changed music theme.
- Entities well placed.

Retail 1.1:
- Really minimal bug fixes. You won't even notice them.

Retail 1.2:
- Added some detail with the Sauerbraten version's textures.
- Added some general detail everywhere.
- Remade the lightning, now it looks decent enough for Cube.

===========================================================================================
Copyright & Permissions:

Cube Engine by Wouter van Oortmerssen aka Aardappel. (www.cubeengine.com)

This level is copyrighted by Pablo Ciamarra 2006-2007.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================