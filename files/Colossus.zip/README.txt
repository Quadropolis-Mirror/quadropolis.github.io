Put the files into folder /maps 
Map "Colossus" created by mariana and Raizen in 07/2009.
Enjoy!