Clauntrastophobia
A Sauerbraten Multiplayer Map
By NightWind with help from TheFalcon
http://nightwind.t35.com/sauerbraten.htm

This map is the first I made. It's kinda random, since I didn't have any
fixed layout or design ideas - I was just playing with the engine.
Suited for four to eight players in any mode, because of all the corridors
and stuff.

-NightWind