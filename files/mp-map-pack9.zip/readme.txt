Thanks for downloading.

The license of this map pack is basically the GPL v2 (http://www.gnu.org/licenses/gpl2.html) 
For more specific terms view the maps config (.cfg) file.



sCaSd
