********
README:
********

**************************
Jord's Custom Mod Pack 2.
**************************
Released 16th March 2008.
**************************

Original Models (Such as Barrel, Mait Sign) have been skinned and modelled by MakkE.
These models have only been edited by Jord.

-----------
Quick Chat
-----------

Quick chat is made by Jord, and can be found under Multiplayer, Quick Chat menu in 
AssaultCube. 

The Commands for Quick Chat include:


Incoming!
Sorry!
Watch out!
Lol!
:)
:(
:\

A sub-menu in Quick Chat is Team Tactical Chat. These chat messages include:

Fire at Will!
Cease Fire
Fall In
Regroup
Stop TEAMKILLING me!
Follow me
Cover me!
I'm going for the flag!
Fire in the Hole!
I have the flag, don't shoot me!

This Quick Chat feature has also been binded to the F1 key, for even easier and quicker access. 

---------------------------------------
Custom Map Models (Originals By MakkE)
---------------------------------------

These mapmodels have been custom made off of MakkE's models. 

--

Yes, these are the same map models as in Jord's Custom Mod Pack 1, but are here for you to use.
However, there are 2 new ones, and the originals are by makkE, of course.

The new ones are:
Electric Sign
Poisonous Barrel

All of the map models are available in the Menu under Editing > Mapmodels.

-----
Menu
-----

In the menu.cfg, there is some new features. With the Quick Chat, some fix-ups and a new menu to help new players
who are new to the game and at being master. This menu has a quick guide showing how to set up a map and mode.

This is available under Multiplayer > Change Map/Mode > Help... or Multiplayer > Change Map/Mode > [Any] > Other...

Also, there is a Key Bind for the Quick Chat menu (as said above) which is F1, which will automaticly pop-up the 
Quick Chat menu in-game. 

A fix that I have done is in the Editing > Pickups I have added Grenades, so you don't have to keep typing /newent 
grenades 1 all the time.

----------
Key Binds
----------

There are some key binds that you may find useful in this mod pack.
These key binds are:

F1                        - Open Quick Chat menu
F12, Print Screen         - Take a screenshot
F4, M                     - Get map (also clears secure maps)
F2                        - Open Team Tactical Chat menu

--------------
[Mapname].cfg
--------------

This config file is for you to copy and use for any map. This includes all mapmodels in it. Where the [mapname]
is goes your map's name, of course, and take out the brackets. Then paste it in the packages/maps folder.

*IMPORTANT* 
If you do this, make sure you send the .cfg file and your extras with your map, so every other user has the right adjustments for
your map!

---------
Textures
---------

There are also some custom textures in this mod pack, made by Jord (me). Please refer to the 'Permissions' document in 
the folder with the textures 'Jord folder' if you want to use my textures.

These textures are:

grass                  - Just a tropical looking fresh grass texture.
bitumen_with_leaves    - A greyish road with autumn leaves on it.
leafs                  - A texture full of autumn leaves (good for making a pile of autumn leaves).
bitumen                - A normal road or path texture.
grass2                 - A darker, more dense version of grass (above).
red                    - A plain red.
blue                   - A plain blue.
green                  - A plain green.
yellow                 - A plain yellow.



-----------
Crosshairs
-----------

In this mod pack, there are also some crosshairs, which are available under Player Setup > Set Crosshair menu in-game.

These crosshairs are:

+_dot.png
tri_cross.png
tri_cross_with_dot.png
X-cross.png
+_dot(green).png
+_dont(blue).png
-------------------------------------------
Questions, Comments, problems or Feedback?
-------------------------------------------

If you have any questions, comments, problems or feedback, please don't hesitate to email me:
jordancomley@hotmail.com

But please, so I do not recognize it as spam, put the subject:
'Jord's Custom Mod Pack 2'


********
Credits
********

Original Map models by MakkE.

Thanks to all who have given comments thouought the time that I have been making this mod pack - really have
given me confidence.

Thanks to all who have suggested ideas, and hopefully they are in this mod pack, or future ones!
Thanks, and Have fun!