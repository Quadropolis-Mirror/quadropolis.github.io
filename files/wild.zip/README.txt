Put the files into folder /maps 
Map created by mariana and Raizen in 07/2009.
Enjoy!