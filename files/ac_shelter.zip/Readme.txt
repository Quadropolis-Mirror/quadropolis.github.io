ac_shelter was made by .rG!|S4nzo", .rG!|Galeon, .rG!|#DarKnoT* and .rG!|Brett .

-Do not modify this map or this content
-Do not edit this map


There is a Copyright (c) . 

       Redemption Gam!ng website: www.r-game.c.la 
       Teamspeak: come to ask us ;)
       IRC: #rg-clan @ quakenet.org