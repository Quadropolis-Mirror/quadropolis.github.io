mod file modified by" |ice|sub-zero|L

how to use: for the CFG go to your sauerbraten folder, then go to the "data" folder (BACK UP THIS CFG IN CASE YOU WANT TO USE IT AGAIN!) then move this CFG file in the file so you have this update (skycastle will now be found in "consept maps".

how to use: if you downloaded this and the map wioth it you'll have to now go to folder "packages" then go to folder "base" then move skycastle in.

also calclight is now bound as -1


