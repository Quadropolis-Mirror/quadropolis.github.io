PREVIOUS ADAM PARKER MISSIONS RE-CAP:

On Adam Parker day 1, you kicked-ass on several enemy bases and helped slow the Mutainians from gaining a full and powerful enemy brigade.  You even saved our secret base from an enemy invasion!  NOTE: This is a multiple-mission-map-pack that is NOT included in the official Sauerbraten release.  If you haven't played this epic epidode yet, you should download it here:


On Adam Parker Day 2, we sent you into enemy territory to recover any information you could about a secret stone called "SYON".  Again, you proved your worth to us as you infiltrated their base and brought back to us the numbers that were carved into the SYON stone for decoding.  NOTE: This map is included in Saurbraten, and is called "The Ancient Stone".

(extra special note: the soundtrack for this map is the most daring piece of MIDI music I've made to date.  It contains several unique pieces of music within the same soundtrack and it's 21 minutes long!!)


AND NOW - - - -


ADAM PARKER - DAY THREE:
------------------------
Great job on finding SYON, Adam!!
We knew we could count on you to finish the mission!

We've had our coding deparment working on those numbers you retrieved from SYON yesterday.
They've been here all night long, and have succesfully unscrambled the codes. 

It appears that some of the numbers from SYON are exact directions to the secret hide-out of "QUEEN MARVARIA" - one of the top Mutainian officers!!!  Her hide-out appears to be located in the 7th sector, West of Station Zero. It's gonna be a hard push on our power systems, but we CAN beam you out there!

As you know, Adam - Queen Marvaria has been a thorn in our side for centuries!
She gains her power from the leaves of the "NIGHT-BLOOMING IXIA PLANT" - an extremely rare plant that the queen has possesed for over a thousand years.

Our Sattellite intelligence entercepted an encryted message that the queen will be away from her hide-out for the next 48 hours.  This is our perfect chance to strike, since her forces will be weakend without her presence!

What we hope is that you can find her IXIA Plant, and bring it back to headquarters. 
Legend has it that without her plant, the Queen should wither and perish.

The plant will surely be well guarded, Adam - you'll need to stay on your toes if you plan on coming home alive!  Her soldiers won't let you just walk in and take away their be-loved Queen's power!  

Be sure to keep your eyes peeled for hidden areas as well -- It's been rumored that the Queen's hide-out is WELL STOCKED with plenty of extra ammo in case of an invasion!

We have also heard of a well-stocked SHRINE dedicated to Queen Marvaria where her followers pray to her daily.  It might be wise to try and find this shrine and take what you can!  You can bet that it WON'T be easy to find, so take your time and really poke around!

Lastly, we're aware of Queen Marvaria's use of a special "happy gas" to keep her troops brainwashed.  We've equipped you with a gas mask so this gas will not affect you.

We're counting on you Adam - You MUST NOT FAIL!!  Bring us back the NIGHT-BLOOMING IXIA PLANT!



MAP INFO:
---------
Build Time: MONTHS and MONTHS and MONTHS (WHEW!!!)...
Main Build Version: Spring '07 Release (finished the map with the Summer '07 Release, and just a TOUCH of the "Assasin" Release: one set of exoploding barrels...)

Secret Areas: 5
(these "secret" areas contain small wooden crates that have "SECRET" printed on them,
so you'll know when you find them!  Count them up to make sure you find all five!)

Hidden Areas: 2
(2 official hidden areas which have "HIDDEN AREA" signs)

New Textures from Six Dog Studios: 3
1. computer keyboard "top" 
2. computer keyboard "side"
3. "incubation room" sign

New Mapmodels: 
1. carboard box (by dcp)
2. storage container (by dcp)
3. keycard (by dcp)
4. egg (by tentus)
5. sauerbraten video game console (by dfs)
6. animated video monitors (by geartrooper)
7. crystal (by tentus)

New Sounds: no

Soundtrack: Original fourteen and a half minute MIDI soundrtrack by Junebug featuring SEVEN original pieces of music!

Extra Credits: Special thanks to TmT of SixDogStudios for mapping the "Hidden Shrine" area.  Extra special thanks to TmT for mapping ideas and play-testing APD3 over and over -- so we could get everything just right!



HOW TO INSTALL AND PLAY:
------------------------
Copy the "pacakges" folder from this download into your main SAUERBRATEN directory.
This will NOT overwrite ANY existing files!

Start up SAUER, hit the Tilde "~" key and type

sp apd3

Now -- KICK SOME BUTT AND GET THAT PLANT!!!