struct server_side_vars
{
#ifdef SSVARS_SERVER
	server_side_vars() {}

	struct ssvar_info
	{
		int *storage;
		// The name of the variable on the client.
		string clientname;
		ssvar_info(int &var, const char *_clientname) : storage(&var)
		{
			if(_clientname)
				s_strcpy(clientname, _clientname);
			else
				clientname[0] = '\0';
		}
	};
	vector<ssvar_info> vars;

	void register_ssv(int &var, const char *clientname = NULL)
	{
		vars.add(ssvar_info(var, clientname));
	}

	void server_send_ssvars(ucharbuf &p)
	{
		if(!vars.length())
			return;
		putint(p, SV_SSVARS);
		putint(p, vars.length());
		loopv(vars)
		{
			ssvar_info &var = vars[i];
			sendstring(var.clientname, p);
			putint(p, *var.storage);
		}
	}

	void server_send_ssvars_packet(clientinfo *ci)
	{
		if(!vars.length())
			return;
        ENetPacket *packet = enet_packet_create(NULL, MAXTRANS, ENET_PACKET_FLAG_RELIABLE);
        ucharbuf p(packet->data, packet->dataLength);
		server_send_ssvars(p);
        enet_packet_resize(packet, p.length());
		sendpacket(ci ? ci->clientnum : -1, 1, packet);
        if(!packet->referenceCount) enet_packet_destroy(packet);
	}

#else

	struct ssvar_info
	{
		ident *id;
		identval revert;
		ssvar_info(ident *_id = NULL) : id(_id)
		{
			if(id)
			{
				switch(id->type)
				{
				case ID_VAR:
					revert.i = id->val.i;
					break;
				}
			}
			else
				revert.i = 0;
		}
	};
	vector<ssvar_info> vars;

	void register_ssv(ident *var)
	{
		switch(var->type)
		{
		case ID_VAR:
			vars.add(ssvar_info(var));
			break;
		default:
			conoutf(CON_ERROR, "Registering variable %s: invalid type.  Only VAR and SVAR supported.", var->name);
			break;
		}
	}

	bool client_parse_ssvars(ucharbuf &p)
	{
		int len = getint(p);
		char text[MAXTRANS];

		loopi(len)
		{
			getstring(text, p);
			ssvar_info *var = NULL;
			loopvj(vars)
			{
				if(!strcmp(text, vars[j].id->name))
				{
					var = &vars[j];
					break;
				}
			}
			if (!var)
			{
				conoutf(CON_ERROR, "Invalid server side variable %s.  Is your client up to date?", text);
				return false;
			}
			var->id->val.i = getint(p);
			conoutf("Received Server Side Variable: %s = %d", var->id->name, var->id->val.i);
		}
		return true;
	}

	void revert_vars()
	{
		loopv(vars)
			vars[i].id->val.i = vars[i].revert.i;
	}
#endif
};
