// Original FreezeTag idea (Quake 2&3) by Darrell Bircsak http://freeze.planetquake.gamespy.com/

static const int FTGLOBALTHAWSECONDS = 0;
static const int FTAUTOTHAWSECONDS = 2*60;
static const int FTTHAWSECONDS = 5;
static const int FTTHAWRADIUS = 30;
static const int FTFORCESPAWNSECONDS = 5;

#ifdef FREEZESERV
struct freezeserv
{
	fpsserver &sv;
	int globalthawmillis;

	freezeserv(fpsserver &sv) : sv(sv), globalthawmillis(0)
	{
		if(FTGLOBALTHAWSECONDS)
			globalthawmillis = sv.lastmillis + FTGLOBALTHAWSECONDS*1000;
	}

	struct teaminfo
	{
		string team;
		int score;
		teaminfo() : score(0)
		{
			team[0] = '\0';
		}
	};
	vector<teaminfo> teamscores;

	void score(const char *team)
	{
		teaminfo *t = NULL;

		loopv(teamscores) if(!strcmp(team, teamscores[i].team))
		{
			t = &teamscores[i];
			break;
		}
		if(!t)
		{
			t = &teamscores.add();
			s_strcpy(t->team, team);
		}
		++t->score;
		sendf(-1, 1, "risi", SV_FTSCORE, team, t->score);
	}

	int getscore(const char *team)
	{
		loopv(teamscores) if(!strcmp(team, teamscores[i].team))
			return teamscores[i].score;
		return 0;
	}

	vector<int> thaws;

	void addthaw(clientinfo *ci)
	{
		while(!thaws.inrange(ci->clientnum)) thaws.add(0);
		++thaws[ci->clientnum];
	}

	int getthaws(clientinfo *ci)
	{
		if(!thaws.inrange(ci->clientnum))
			return 0;
		return thaws[ci->clientnum];
	}

	struct freezeinfo
	{
		fpsserver *sv;
		clientinfo *ci;
		clientinfo *thawing;
		int thawmillis;
		int autothawmillis;

		freezeinfo() : sv(NULL), ci(NULL), thawing(NULL), thawmillis(0), autothawmillis(0) {}

		void set(clientinfo *_ci, fpsserver *_sv)
		{
			sv = _sv;
			ci = _ci;
			thawing = NULL;
			thawmillis = 0;
			if(FTAUTOTHAWSECONDS)
				autothawmillis = sv->lastmillis + FTAUTOTHAWSECONDS*1000;
			else
				autothawmillis = 0;
		}

		void reset()
		{
			sv = NULL;
			ci = NULL;
			thawing = NULL;
			thawmillis = 0;
			autothawmillis = 0;
		}
	};
	vector<freezeinfo> frozen;

	void reset()
	{
		teamscores.setsize(0);
		thaws.setsize(0);
		loopv(frozen)
			frozen[i].reset();
	}

	bool isfrozen(clientinfo *ci)
	{
		return ci && frozen.inrange(ci->clientnum) && frozen[ci->clientnum].ci==ci;
	}

	bool canfreeze(clientinfo *ci)
	{
		return sv.svfreezetag && ci && ci->team && (ci->state.state==CS_ALIVE || ci->state.state==CS_DEAD);
	}

	void freeze(clientinfo *ci, clientinfo *actor = NULL)
	{
		if(!canfreeze(ci)) return;
		while(!frozen.inrange(ci->clientnum)) frozen.add();
		freezeinfo &f = frozen[ci->clientnum];
		f.set(ci, &sv);
		sendf(-1, 1, "ri3", SV_FTFREEZE, ci->clientnum, (actor ? actor->clientnum : -1));
	}

	void unfreeze(clientinfo *ci)
	{
		if(!isfrozen(ci)) return;
		frozen[ci->clientnum].reset();
		sendf(-1, 1, "ri2", SV_FTUNFREEZE, ci->clientnum);
	}

	void startthaw(clientinfo *ci, clientinfo *thawing)
	{
		if(!isfrozen(ci)) return;
		if(!thawing || thawing->state.state!=CS_ALIVE || !thawing->team || strcmp(ci->team,thawing->team)) return;
		frozen[ci->clientnum].thawing = thawing;
		if(!frozen[ci->clientnum].thawmillis)
		{
			frozen[ci->clientnum].thawmillis = sv.lastmillis + FTTHAWSECONDS*1000;
			sendf(ci->clientnum, 1, "ri", SV_FTSTARTTHAW);
		}
	}

	void stopthaw(clientinfo *ci)
	{
		if(!isfrozen(ci)) return;
		frozen[ci->clientnum].thawing = NULL;
		frozen[ci->clientnum].thawmillis = 0;
		sendf(ci->clientnum, 1, "ri", SV_FTSTOPTHAW);
	}

	void checkthawed()
	{
		loopv(frozen) if (frozen[i].ci)
		{
			freezeinfo &f = frozen[i];
			if(f.thawing && f.thawmillis && sv.lastmillis >= f.thawmillis)
			{
				sendf(-1, 1, "ri3", SV_FTTHAWED, f.ci->clientnum, f.thawing->clientnum);
				f.reset();
			}
			else if((FTAUTOTHAWSECONDS && sv.lastmillis >= f.autothawmillis) || f.ci->state.o.z <= 0)
			{
				sendf(-1, 1, "ri2", SV_FTUNFREEZE, f.ci->clientnum);
				f.reset();
			}
		}
	}

	void globalthaw()
	{
		loopv(frozen)
			frozen[i].reset();
		sendf(-1, 1, "ri", SV_FTGLOBALTHAW);
		if(FTGLOBALTHAWSECONDS)
			globalthawmillis = sv.lastmillis + FTGLOBALTHAWSECONDS*1000;
	}

	void update()
	{
		// Global thaw timer
		if(FTGLOBALTHAWSECONDS && sv.lastmillis >= globalthawmillis)
		{
			globalthaw();
			return;
		}
		checkthawed();
		const char *oneteam = NULL;
		bool allfrozen = true;
		loopv(sv.clients)
		{
			clientinfo *ci = sv.clients[i];
			if(ci->team && !isfrozen(ci))
			{
				allfrozen = false;
				if(!oneteam)
					oneteam = ci->team;
				else if(strcmp(ci->team, oneteam))
				{
					oneteam = NULL;
					break;
				}
			}
		}
		if(allfrozen)
		{
			globalthaw();
			return;
		}
		if(oneteam)
		{
			// Only one team left standing.  Lets check to see
			// that they had competition before we award a point.
			loopv(sv.clients) if(isfrozen(sv.clients[i]) && strcmp(sv.clients[i]->team, oneteam))
			{
				score(oneteam);
				break;
			}
			globalthaw();
			return;
		}

		loopv(sv.clients) if(sv.clients[i]->team && isfrozen(sv.clients[i]))
		{
			clientinfo *ci = sv.clients[i];
			freezeinfo &f = frozen[i];
			float bestdist = 9999999999.0;
			clientinfo *bestthawing = NULL;

			loopvj(sv.clients) if(i!=j)
			{
				clientinfo *cj = sv.clients[j];

				if(cj->state.state==CS_ALIVE && cj->team && !strcmp(ci->team,cj->team))
				{
					float dist = ci->state.o.dist(cj->state.o);
					if(dist <= FTTHAWRADIUS)
					{
						if(cj==f.thawing)
						{
							bestthawing = cj;
							break;
						}
						else if(!bestthawing || dist < bestdist)
						{
							bestthawing = cj;
							bestdist = dist;
						}
					}
				}
			}

			if(bestthawing)
			{
				if(bestthawing != f.thawing)
					startthaw(ci, bestthawing);
			}
			else
				stopthaw(ci);
		}
	}

	void initfreezeglobal(ucharbuf &p, bool connecting)
	{
		if(!sv.svfreezetag) return;
		putint(p, SV_FTINITFREEZE);
		putint(p, FTGLOBALTHAWSECONDS ? globalthawmillis-sv.lastmillis : 0);
		putint(p, teamscores.length());
		loopv(teamscores)
		{
			sendstring(teamscores[i].team, p);
			putint(p, teamscores[i].score);
		}
	}
};
#else // FREEZESERV
IVAR(freezetag, 0, 0, 1);
struct freezeclient
{
	fpsclient &cl;
	int globalthawmillis;

	freezeclient(fpsclient &cl) : cl(cl), globalthawmillis(0) {}

	struct teaminfo
	{
		string team;
		int score;
		teaminfo() : score(0)
		{
			team[0] = '\0';
		}
	};
	vector<teaminfo> teamscores;

	void setscore(const char *team, int score)
	{
		teaminfo *t = NULL;

		loopv(teamscores) if(!strcmp(team, teamscores[i].team))
		{
			teamscores[i].score = score;
			return;
		}
		t = &teamscores.add();
		s_strcpy(t->team, team);
		t->score = score;
	}

	int getscore(const char *team)
	{
		loopv(teamscores) if(!strcmp(team, teamscores[i].team))
			return teamscores[i].score;
		return 0;
	}

	vector<int> thaws;

	void addthaw(fpsent *d)
	{
		while(!thaws.inrange(d->clientnum)) thaws.add(0);
		++thaws[d->clientnum];
	}

	void setthaws(fpsent *d, int th)
	{
		while(!thaws.inrange(d->clientnum)) thaws.add(0);
		thaws[d->clientnum] = th;
	}

	int getthaws(fpsent *d)
	{
		if(!thaws.inrange(d->clientnum))
			return 0;
		return thaws[d->clientnum];
	}

	struct freezeinfo : movableset::movable
	{
		fpsclient *cl;
		fpsent *owner;
		int thawmillis;
		int autothawmillis;

		freezeinfo() : movableset::movable(entity(), ms), cl(NULL), owner(NULL), thawmillis(0), autothawmillis(0)
		{
			etype = BOX;
			mapmodel = -1;
			weight = movableset::BOXWEIGHT;
		}

		void set(fpsent *_owner, fpsent *_actor, fpsclient *_cl)
		{
			cl = _cl;
			owner = _owner;
			yaw = owner->yaw;
			pitch = owner->pitch;
			o = owner->o;
			owner->vel = vec(0,0,0);
			setbbfrommodel(this, "icecube");
			if(FTAUTOTHAWSECONDS)
				autothawmillis = cl->lastmillis + FTAUTOTHAWSECONDS*1000;
			else
				autothawmillis = 0;
			cl->mo.movables.add() = this;
			cl->gs.removegrapples(owner, true);

			if(_actor)
			{
				vec dir = o;
				dir.sub(_actor->o);
				entinray(this, dir);
			}
			else
				entinmap(this);

			if(owner==cl->player1)
				sendfreezepos();
		}

		void reset()
		{
			if(!owner) return;
			cl->gs.removegrapples(owner, true);
			cl->mo.movables.removeobj(this);
			cl = NULL;
			owner = NULL;
			o = vec(0,0,0);
		}

		void sendfreezepos()
		{
			if(!cl || !owner) return;
			cl->cc.addmsg(SV_FTFREEZEPOS, "ri3", int(o.x*DMF), int(o.y*DMF), int(o.z*DMF));
			owner->o = o;
			owner->resetinterp();
		}
	};

	vector<freezeinfo> frozen;

	void reset()
	{
		teamscores.setsize(0);
		thaws.setsize(0);
		loopv(frozen)
			frozen[i].reset();
	}

	bool isfrozen(fpsent *d)
	{
		return d && frozen.inrange(d->clientnum) && frozen[d->clientnum].owner==d;
	}

	bool canfreeze(fpsent *d)
	{
		return cl.freezetag() && d && d->team && (d->state==CS_ALIVE || d->state==CS_DEAD);
	}

	void freeze(fpsent *d, fpsent *actor)
	{
		if(!canfreeze(d)) return;
		while(!frozen.inrange(d->clientnum)) frozen.add();
		frozen[d->clientnum].set(d, actor, &cl);
		playsoundname("freeze/freeze", (d==cl.player1 ? NULL : &d->o), 400);
		if(actor)
		{
			if(d==cl.player1 && actor==cl.player1)
				conoutf("You froze yourself!");
			else if(d==cl.player1)
				conoutf("%s froze you!", actor->name);
			else if(actor==cl.player1)
				conoutf("You froze %s!", d->name);
			else if(actor==d)
				conoutf("%s froze themself!", d->name);
			else
				conoutf("%s froze %s!", actor->name, d->name);
		}
		else
		{
			if(d==cl.player1)
				conoutf("You were frozen!");
			else
				conoutf("%s was frozen!", d->name);
		}
	}

	void unfreeze(fpsent *d)
	{
		if(!isfrozen(d)) return;
		frozen[d->clientnum].reset();
		if(d==cl.player1)
			conoutf("You've been thawed!");
		else
			conoutf("%s has been thawed!", d->name);
		playsoundname("freeze/thaw", (d==cl.player1 ? NULL : &d->o), 400);
	}

	void startthaw(fpsent *d)
	{
		if(!isfrozen(d)) return;
		frozen[d->clientnum].thawmillis = cl.lastmillis + FTTHAWSECONDS*1000;
	}

	void stopthaw(fpsent *d)
	{
		if(!isfrozen(d)) return;
		frozen[d->clientnum].thawmillis = 0;
	}

	void thawed(fpsent *d, fpsent *actor)
	{
		if(!isfrozen(d)) return;
		unfreeze(d);
		addthaw(actor);
		if(d==cl.player1)
			conoutf("You were thawed by %s!", actor->name);
		else if(actor==cl.player1)
			conoutf("You thawed %s!", d->name);
		else
			conoutf("%s thawed %s!", actor->name, d->name);
		playsoundname("freeze/thaw", &d->o, 400);
	}

	void globalthaw()
	{
		loopv(frozen) if(frozen[i].owner)
		{
			playsoundname("freeze/thaw", &frozen[i].o, 400);
			frozen[i].reset();
		}
		if(FTGLOBALTHAWSECONDS)
			globalthawmillis = cl.lastmillis + FTGLOBALTHAWSECONDS*1000;
	}

	void parsefreezeglobal(ucharbuf &p, bool commit)
	{
		static char text[MAXTRANS];
		int len, val;

		globalthawmillis = getint(p);
		if(globalthawmillis) globalthawmillis += cl.lastmillis;
		len = getint(p);
		loopi(len)
		{
			getstring(text, p);
			val = getint(p);
			if(commit) setscore(text, val);
		}
	}

	void sendfreezeclient(fpsent *o, ucharbuf &p)
	{
		putint(p, SV_FTINITCLIENT);
		putint(p, o->clientnum);
		if(isfrozen(o))
		{
			putint(p, 0x8000 | getthaws(o));
			loopk(3) putint(p, int(o->o[k]*DMF));
		}
		else
			putint(p, getthaws(o));
	}

	void parsefreezeclient(ucharbuf &p, bool commit)
	{
		int ocn = getint(p);
		int val = getint(p);
		vec pos;
		if(val&0x8000)
			loopk(3) pos[k] = getint(p)/DMF;

		if(commit)
		{
			fpsent *o = ocn==cl.player1->clientnum ? cl.player1 : cl.newclient(ocn);
			setthaws(o, val&0x7FFF);
			if(val&0x8000)
			{
				o->newpos = o->o = pos;
				freeze(o, NULL);
			}
		}
	}

	vector<weaponstate::hitmsg> freezehits;
	bool freezehit(dynent *d, int damage, const vec &vel, fpsent *at, int gun, int info = 1)
	{
		fpsent *e = icecube2owner(d);
		if(!e) return false;
		weaponstate::hitmsg &h = freezehits.add();
        h.target = e->clientnum;
        h.lifesequence = e->lifesequence;
        h.info = info;
        h.dir = ivec(int(vel.x*DNF), int(vel.y*DNF), int(vel.z*DNF));
		return true;
	}

	void clearfreezehits()
	{
		freezehits.setsizenodelete(0);
	}

	void sendfreezehits()
	{
		if(freezehits.length())
			cl.cc.addmsg(SV_FTHITS, "riv", freezehits.length(), freezehits.length()*sizeof(weaponstate::hitmsg)/sizeof(int), freezehits.getbuf());
	}

	void ftpush(fpsent *d, fpsent *actor, int gun, int damage, const vec &dir)
	{
		if(!isfrozen(d)) return;
		freezeinfo &f = frozen[d->clientnum];
		playsoundname("freeze/icecube-hit", &f.o, 0);
		f.hitpush(damage, dir, actor, gun);
		if(d==cl.player1)
			f.sendfreezepos();
	}

	void setfrozenpos(fpsent *d, const vec &pos)
	{
		if(!isfrozen(d)) return;
		freezeinfo &f = frozen[d->clientnum];
		d->newpos = d->o = f.newpos = f.o = pos;
		f.resetinterp();
		d->resetinterp();
		d->vel = vec();
		d->moving = false;
		if(d==cl.player1)
			frozen[d->clientnum].sendfreezepos();
	}

	void resetfrozenpos(fpsent *d)
	{
		if(!isfrozen(d)) return;
		setfrozenpos(d, frozen[d->clientnum].o);
	}

	void sendfrozenpos(fpsent *d)
	{
		if(d!=cl.player1 || !isfrozen(d)) return;
		frozen[d->clientnum].sendfreezepos();
	}

	freezeinfo *owner2icecube(physent *owner)
	{
		if(owner->type!=ENT_PLAYER) return NULL;
		fpsent *d = (fpsent *)owner;
		if(isfrozen(d)) return &frozen[d->clientnum];
		return NULL;
	}

	fpsent *icecube2owner(physent *icecube)
	{
		if(!frozen.length()) return NULL;
		freezeinfo *f = (freezeinfo *)icecube;
		if(frozen.inrange(f-&frozen[0])) return f->owner;
		return NULL;
	}

	int respawnwait(fpsent *d)
	{
		if(!isfrozen(d))
			return 0;

		freezeinfo &f = frozen[d->clientnum];
		int wait = 0;

		if(globalthawmillis && (!wait || globalthawmillis < wait))
			wait = globalthawmillis;
		if(f.autothawmillis && (!wait || f.autothawmillis < wait))
			wait = f.autothawmillis;
		if(f.thawmillis && (!wait || f.thawmillis < wait))
			wait = f.thawmillis;
		return wait ? max(0, wait-cl.lastmillis+999)/1000 : -1;
	}

	int respawnforced(fpsent *d)
	{
		if(!FTFORCESPAWNSECONDS || d->state!=CS_DEAD || (isfrozen(d) && respawnwait(d) > 0))
			return -1;
		return max(0, FTFORCESPAWNSECONDS-(cl.lastmillis-d->lastpain+999)/1000);
	}

    void drawradar(float x, float y, float s)
    {
        glTexCoord2f(0.0f, 0.0f); glVertex2f(x,   y);
        glTexCoord2f(1.0f, 0.0f); glVertex2f(x+s, y);
        glTexCoord2f(1.0f, 1.0f); glVertex2f(x+s, y+s);
        glTexCoord2f(0.0f, 1.0f); glVertex2f(x,   y+s);
    }

    void drawblips(fpsent *d, int x, int y, int s, fpsent *e)
    {
		settexture("packages/hud/blip_blue.png");
        float scale = cl.maxradarscale();
        vec dir = e->o;
        dir.sub(d->o);
        dir.z = 0.0f;
        float size = 0.05f,
              xoffset = -size,
              yoffset = -size,
              dist = dir.magnitude();
        if(dist >= scale*(1 - 0.05f)) dir.mul(scale*(1 - 0.05f)/dist);
        dir.rotate_around_z(-d->yaw*RAD);
        glBegin(GL_QUADS);
        drawradar(x + s*0.5f*(1.0f + dir.x/scale + xoffset), y + s*0.5f*(1.0f + dir.y/scale + yoffset), size*s);
        glEnd();
    }

	void drawhud(fpsent *d, int w, int h)
	{
		if(!cl.freezetag()) return;
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        int x = 1800*w/h*34/40, y = 1800*1/40, s = 1800*w/h*5/40;
        glColor3f(1, 1, 1);
        settexture("packages/hud/radar.png");
        glBegin(GL_QUADS);
        drawradar(float(x), float(y), float(s));
        glEnd();
		if (d->team)
		{
			loopv(cl.players) if (cl.players[i])
			{
				fpsent *e = cl.players[i];
				if (e->team && !strcmp(e->team, d->team) && isfrozen(e))
					drawblips(d, x, y, s, e);
			}
        }
        if(d->state==CS_DEAD || globalthawmillis)
        {
			bool dead = (d->state==CS_DEAD);
			int wait;
			const char *color = "";
			if (dead)
			{
				if (isfrozen(d))
					wait = respawnwait(d);
				else if (FTFORCESPAWNSECONDS)
				{
					wait = respawnforced(d);
					color = "\f2";
				}
				else
					wait = 0;
			}
			else if (globalthawmillis)
			{
				wait = max(0,globalthawmillis-cl.lastmillis+999)/1000;
				color = "\f1";
			}

            if(wait>=0)
            {
                glPushMatrix();
                glLoadIdentity();
                glOrtho(0, w*900/h, 900, 0, -1, 1);
				
				if(wait>=60)
					draw_textf("%s%dm", (x+s/2)/2-28, (y+s/2)/2-32, color, (wait+59)/60);
				else
					draw_textf("%s%d", (x+s/2)/2-(wait>=10 ? 28 : 16), (y+s/2)/2-32, color, wait);
                glPopMatrix();
            }
        }
    }

	void rendericecubes()
	{
		fpsent *d = cl.player1;
		loopv(frozen) if(frozen[i].owner)
		{
			freezeinfo &f = frozen[i];
			const char *icecube = !d->team || !f.owner->team ? "icecube" : strcmp(d->team,f.owner->team) ? "icecube/red" : "icecube/blue";
			vec o(f.o);
			o.z -= f.eyeheight;
			rendermodel(NULL, icecube, 0, o, f.yaw, 0, MDL_LIGHT|MDL_FULLBRIGHT|MDL_CULL_VFC|MDL_CULL_DIST|MDL_CULL_OCCLUDED|MDL_CULL_QUERY|MDL_TRANSLUCENT);
		}
	}
};
#endif
