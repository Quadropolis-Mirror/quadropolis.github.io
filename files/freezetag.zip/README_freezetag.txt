Welcome to Freezetag!

========== HISTORY AND ACKNOWLEDGEMENTS ==========

First and foremost, we can't claim to have thought up Freezetag.  That honor belongs to
Darrell Bircsak (http://freeze.planetquake.gamespy.com/).  The source code additions are
of course all of our own (or at least adapted from other parts of Sauer), but it wouldn't
be right not to attribute the original concept!

The grapple idea predates Freezetag and comes from the Quake 1 era.  I'm not sure who
came up with the original concept, but our first introduction to it was in CTF, so it
might have been the Q1 CTF guys.  Whoever it was, a big tip of the hat to you as well.

And of course, the Cube2/Sauerbraten folks -- we wouldn't have any of this without them!

========== LICENCE ==========

We'll follow the Cube2/Sauerbraten model and go with the zlib licence.  Original text can
be found at http://www.opensource.org/licenses/zlib-license.php, but just for completeness
here it is again with my name filled out:
-----------------------------
Freezetag Modification for Cube2/Sauerbraten

Copyright (C) 2008 Erin Moeller & Tim Seever

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
-----------------------------

========== MODIFICATION DETAILS ==========

There are 3 significant components to this mod:
- Freezetag game mod
- Grappling hook
- Server Side Variables

The Freezetag mod server is a standalone server where all team play modes are changed
to Freezetag game play (non-team modes play as normal).  The client can be used for
either Freezetag or regular modes.

The grappling hook mod is also enabled on the Freezetag standalone server.  Clients
can bind a key to 'usegrapple' in order to fire the grappling hook.

Server Side Variables are a little addition I had to come up with in order for the
server to control whether freezetag and/or grapple was enabled.  It simply pushes
the variable values to the clients when they connect and on each map change.
The alternative was to add another 30-40 game modes for things like insta+ctf+ft vs
insta+ctf+grapple+ft vs team dm+grapple vs well.. you get the picture.

========== INSTALLING ==========

I've packaged the Freezetag mod with the executable and batch files renamed so as not
to overwrite the original files.  This will need to be installed onto a fresh copy of
Sauerbraten (2008/06/20 edition with 2008/07/11 patch) as we've not packaged it with
any of the packages or other data files.  Only the source and the FT/grapple data have
been included.

For those who wish to recompile:  Please make note that these changes have been done
under MS Visual C++ Express 2008 (NOT 2005 like the original).  If you prefer to use
2005, you should be able to get away with just copying the solution files from a clean
Sauerbraten install and include the three new files (freeze.h, grapple.h and ssvar.h).

****WARNING****
While the package includes renamed executables, the solution is still set to produce
sauerbraten.exe when you recompile.
***************

Also, the FT mod being of course an new mod and not part of the core package is set to
run on different UDP ports (38785-38787).  Aside from the port change, I've done as
much as I can to keep the client compatible with non-FT servers (the reverse is not
true though -- you will need an FT client to join an FT server).  However it is
recommended that you use the official client to play on non-FT servers until such time
as FT becomes an official mod (well, I can hope can't I;))

========== FREEZETAG GAMEPLAY ==========

For those unfamiliar with Freezetag, it is an additional factor that can be added to any
team play game mode (team DM, CTF, etc).  In that sense, its similar to how most DM modes
can be run in 'insta' mode in order to change the tactics without changing the rules of the
game.

The basic concept is that, when a person's life has been depleted, rather than dying they
become frozen and a big ice block model is drawn on top of their character.  When all
players on one team are frozen simultaneously, the remaining team is awarded a team point
and all of the frozen players are thawed and respawned.  To this end, Freezetag is similar
to an elimination type of game.

The difference is in the ability to thaw your teammates.  If one of your teammates is frozen,
you can stand near their ice block for 5 seconds and this will also thaw the person and allow
them to respawn and re-enter play.  Ice blocks will also move around when you shoot or
grapple them, allowing more advanced players to attempt to bring several frozen teammates
together for a mass thawing.  A player able to do pull off this stunt while avoiding their
enemies can instantly turn the game from a losing round to a winning round for their team.

There is also a reasonably lengthy (2min) automatic thaw timer.  This is in place to limit
situations where for example, there is only one player alive per team on an enormous map and
they can't find each other in a reasonable amount of time.  The automatic thaw timer allows
the frozen players to rejoin the game after a reasonable delay of this type.

Thats pretty much all there is to it.  The basic ideas are fairly simple when its written out
like this, but it brings an entire new dimension to the game!

A note on scoring:  During CTF and Capture games which maintain their own scoreboards, the
Freezetag scoring is suppressed in favor of the base game's mechanisms.  In other modes
however, there are two changes to the scoreboard:  First, the number of thaws a person has
accumulated (that is, how often they've thawed teammates out of their ice blocks).  Secondly,
the team score changes from the sum of all frags to the number of times the team has completely
frozen their rival's team members.

========== KNOWN ISSUES & BUGS ==========

There are a few known issues as of this first release:
- Standing on top of an ice block (or another person if they'll stay still) and grappling it
  allows you to "float" by jumping repeatedly.  This occurs due to the ice block being pulled
  up by the grapple faster than gravity pulls it back down, and your player model "lands" on
  the icecube.  This should be fixed at some point when I'm more familiar with the physics
  system, but in the mean time, I don't expect this to harm gameplay too much - its not a whole
  lot different than simply grappling on the roof (you have a bit of protection thanks to the
  ice block, but one shot from an enemy and it will be moved far enough away to knock you off
  and send you tumbling.)

- Once in a while the grapple "fails" and you fall until you hit the ground at which point
  the grapple takes effect again.  My best guess at this point is that the physics is changing
  to "sliding" mode and messing with the velocity vector in ways that I'd rather it didn't.
  Again though, its something that will have to wait until I'm more familiar with the physics
  engine before I can fix it.  In the meantime, it can serve as a (rather limited) anti-camper
  mechanism.

- Ice blocks frequently "jump" (occasionally quite far) when they're first frozen.  This is due
  to the model for the ice block being larger than the player model.  If the player is too close
  to a wall, it has to shift (jump) him out a bit in order to make room for the ice block.
  Occasionally however, this shifting is unlucky and the spot it finds is further away from the
  kill point than we would like.  I'm not sure what to do about this one and have as yet come
  up with no good solutions other than shrinking the size of the ice block -- which would reduce
  but not eliminate the jumping issue.

- An occasional network end of packet is thrown at the client.  I don't know where this comes
  from (I don't even know for sure if its caused by my mod, though I suspect its something I'm
  doing wrong).  Figuring this one out is likely going to only happen with a stroke of luck or
  by someone having knowledge of a tracing tool that I'm unfamiliar with and gives me some
  pointers.

========== TODO ==========

- Fix the bugs listed above, obviously.

- Make SSVs useful.  The goal was to have a votable option for the server (similar to how the
  game mode can be chosen prior to voting for a map change).  Unfortunately I haven't gotten
  that far yet and at the moment, FT mode and the grapple are hardcoded on the server side
  (though they should push their options to the clients properly at least).

- Add in tracking of "defenses" -- fragging someone who is in the process of thawing a teammate.

- Better ice blocking?  The current mechanism (draw an extra model on top of the player) is
  from the original Q2 version of Freezetag.  In Q3 they did it one better and the "ice block"
  is actually just an effect applied to the player.  I'm not entirely sure this is worthwhile
  though as I actually prefer the look of an actual ice block the glowing look (take a peek at
  Darrell's Freezetag page linked in the Acknowledgements section -- almost all of the images
  are from the Q3 version.. the only Q2 image unfortunately doesn't have a terribly good shot
  of an ice block).

========== THATS ALL FOLKS ==========

Enjoy the game!
- Erin & Tim
