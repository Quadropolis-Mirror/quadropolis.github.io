// High Tech Pistol Mod by ViperX07
// High Tech muzzleflash

// You may distribute both the mod and the muzzleflash 
// This is accepting that you give all Credit and/or attribution to ViperX07 the creator

// Enjoy.