Extract into "packages/base"dir. in Sauerbraten folder.
This is my first try at building and it took about 2 months
The level was redesigned for capture and all sugestions took into consideration.
Hope you enjoy!




   Deathbringer