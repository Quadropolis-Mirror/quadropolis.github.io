Heya guys!
Thanks for downloading the map Novantis(ver. 0.1)!

INSTALLATION NOTES/ HOW TO START THE MAP:
- put the .ogz(mapfile) in ur game directory in the BASE folder (for example: C:/USER/programs/Sauerbraten/packages/base).
- start cube 2 - Sauerbraten and type: 
	
	/map novantis

Thats all have fun on the map!

-TheDragonGER :)
