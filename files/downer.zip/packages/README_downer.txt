####################################################################################
#    ________   ____     ____      ____   __  __         __  ________   ____   __  #
#   /__   __/  /    \   /    |    /    | / / |  |  _    / / /__   __/  /    | / /  #
#     /  /    /  /\ |  /  /| |   /  /| |/ /  |  | / |  / /    /  /    /  /| |/ /   #
#  __/  /__  /  /_/ / /  __  |  /  / |   /   |  |/  |_/ /  __/  /__  /  / |   /    #
# /_______/ /______/ /__/  |_| /__/  |__/    |____/|___/  /_______/ /__/  |__/     #
#                                                                                  #
####################################################################################

A map for sauerbraten (cube 2) made by Idanwin FM Cáel.

--------------------------------------------------------------------------

Instructions:

1. Browse through your "Sauerbraten" directory (usually: "C\Program Files\Sauerbraten").

2. Unzip "downer.zip in your sauerbraten folder.

3. Run Sauerbraten!

4. Load the new map ("downer.ogz"), by pressing "T" during the game, then type "/map downer" and press enter.

--------------------------------------------------------------------------

License:

This software is released under a Creative Commons license:

"Commons Attribution-Noncommercial-Share Alike 3.0 Unported License"


You are free:


* To copy, distribute, display, and perform the work

* To make derivative works Under the following conditions:

* Attribution. You must give the original author (Idanwin FM Cáel) credit.

* Non-Commercial. You may not use this work for commercial purposes.

* Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under a licence identical to this one.

* For any reuse or distribution, you must make clear to others the licence terms of this work.

* Any of these conditions can be waived if you get permission from the copyright holder.

Your fair use and other rights are in no way affected by the above.

Full license (legal code) can be found at:
http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode


--------------------------------------------------------------------------
ADDITIONAL END USER LICENSE AGREEMENT:

IMPORTANT-READ CAREFULLY: This End-User License Agreement ("EULA") is a legal agreement between you (either an individual or a single entity) and Gabriele Magurno ("Gabriele Magurno") for the software identified above, which includes computer software and may include associated media, printed materials, and "online" or electronic documentation (collectively, "SOFTWARE"). By installing, copying, or otherwise using the SOFTWARE, you agree to be bound by the terms of this EULA. If you do not agree to the terms of this EULA, do not install, copy or otherwise use the SOFTWARE.

DISCLAIMER OF WARRANTIES.  To the maximum extent permitted by applicable law, Gabriele Magurno provide the SOFTWARE AS IS AND WITH ALL FAULTS, and hereby disclaim all warranties and conditions, either express, implied or statutory, including, but not limited to, any (if any) implied warranties or conditions of merchantability, of fitness for a particular purpose, of lack of viruses, of accuracy or completeness of responses, of results, and of lack of negligence or lack of workmanlike effort, all with regard to the SOFTWARE, and the provision of or failure to provide Support Services.  ALSO, THERE IS NO WARRANTY OR CONDITION OF TITLE, QUIET ENJOYMENT, QUIET POSSESSION, CORRESPONDENCE TO DESCRIPTION OR NON-INFRINGEMENT, WITH REGARD TO THE SOFTWARE.  THE ENTIRE RISK AS TO THE QUALITY OF OR ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE AND SUPPORT SERVICES, IF ANY, REMAINS WITH YOU.

EXCLUSION OF INCIDENTAL, CONSEQUENTIAL AND CERTAIN OTHER DAMAGES.  TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL Gabriele Magurno BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, BUT NOT LIMITED TO, DAMAGES FOR LOSS OF PROFITS OR CONFIDENTIAL OR OTHER INFORMATION, FOR BUSINESS INTERRUPTION, FOR PERSONAL INJURY, FOR LOSS OF PRIVACY, FOR FAILURE TO MEET ANY DUTY INCLUDING OF GOOD FAITH OR OF REASONABLE CARE, FOR NEGLIGENCE, AND FOR ANY OTHER PECUNIARY OR OTHER LOSS WHATSOEVER) ARISING OUT OF OR IN ANY WAY RELATED TO THE USE OF OR INABILITY TO USE THE SOFTWARE, THE PROVISION OF OR FAILURE TO PROVIDE SUPPORT SERVICES, OR OTHERWISE UNDER OR IN CONNECTION WITH ANY PROVISION OF THIS EULA, EVEN IN THE EVENT OF THE FAULT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, BREACH OF CONTRACT OR BREACH OF WARRANTY OF Gabriele Magurno, AND EVEN IF Gabriele Magurno OR ANY SUPPLIER HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

LIMITATION OF LIABILITY AND REMEDIES. Notwithstanding any damages that you might incur for any reason whatsoever (including, without limitation, all damages referenced above and all direct or general damages), the entire liability of Gabriele Magurno  under any provision of this EULA and your exclusive remedy for all of the foregoing shall be limited to U.S.$0.00.

--------------------------------------------------------------------------
