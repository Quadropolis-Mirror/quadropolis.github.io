fury - by t-chen

Be sure that u have the required trak5-texturepack! If not, you can download it here http://quadropolis.us/node/1877