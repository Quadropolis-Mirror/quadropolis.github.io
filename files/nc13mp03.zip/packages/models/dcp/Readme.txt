model format:	.md2
		designed for use in the game cube
		created 01-04.2k4 using milkshape 3D
		           

creator:	dcp / http://www.dietmarpier.de (go here for mapmodels
		which did not make it into the new release)

stats:		too much typing for this readme... nooo, really, i'm too
		lazy to write down the polycounts of all these models ;-)

description:	several mapmodels to stuff your levels with... don't
		put too many models in your level, especially don't
		try to cover toolarge areas with grass or similar types.
		on my machine (athlon 2400+/geForceFX5200) i did not
		notice a significant performance decrease by using
		larger amounts of these models but i'm sure on slower
		machines you will... 

copyright:	the models were created to use for eveyone who likes
		to put some of them in his levels. if you want to use
		them for something else than cube, please drop me a
		line, i just want to know...

credits:	wouter van oordmerssen aka aardappel (i love cube! it's
		so easy/fun to modify things like models, textures,
		sounds. man, you gave me a new chance to make use of my
		pathologic creativity, since my musical carrier has
		come to a grinding halt...)

		id-software (quake2/.md2)

		chumbalum-soft (milkshape3D, it just took 3 days to
		understand the basics, one more to make my first working
		models for cube)



