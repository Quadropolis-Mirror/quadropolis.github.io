Released the 09/10/08 by Daniel Nautr� Under the GPL License.

The map is based on a template by Bobfrog.
Thanks to Skylax for his help.

I recommend Instagib or Regen Capture for this map.

E-mail at Daniel.Nautre@gmail.com