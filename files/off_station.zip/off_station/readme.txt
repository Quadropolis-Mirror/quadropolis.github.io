Off Station by Mooseguy
Extract off_station.conf, off_station.jpg, and off_station.ogz to your
/packages/base directory.
