You are free to use this map in any YouTube videos, play with your friends online, or hold any competitions with the map "chess". In exchange, you should give the RRR Clan full credit towards creation of the map.

This map is recommended to be played upon the Justice release.

Map by rbbbs.