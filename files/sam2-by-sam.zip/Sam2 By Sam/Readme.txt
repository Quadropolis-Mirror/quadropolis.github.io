Hi user, enjoy the map, host it and make some kills...

Instal: Unzip packages into your game directory or put Sam2.ogz and Sam2.cfg in your packages\base directory...

Leave comments by mail: sam_calgon@hotmail.com
Or add me to msn: sam_calgon@hotmail.com

Have fun.