9 July 2010

Name: evil lair's Quake 3:Arena texture set 7  
Short Name: e7
Author: Yves Allaire aka "evil lair" (author of the original textures) and Suicizer (who made al files which aren't the diffusre or glowmapped textures)
Email: yves@evillair.net (and supersauer@live.nl for contacting Suicizer)
URL: http://evillair.net

[Description]
Quake 3: Arena texture set in a gothic/metal theme. Of course for Cube Engine 2 now too!

[Stuff]
If you use any of the textures it would be cool if you emailed us with the url to some screenshots if possible. 
We really would like to see what uses mappers have made of them.

[Copyright/Permissions]
-You may use these texture in your maps/mods/tcs as long as you give us credit.
-You may not edit, modify or copy any textures within this archive unless given permission to do so by the authors.  
-You may convert these textures to other game formats but only with the authors permission (Yves Allaire and Suicizer).

QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks
of id Software, Inc.


