 -----------------------------------------------------------------------------------------
--SomeDude's "cube_art" script(version 1.1)  and conversion program. (4/20/2012)--
 -----------------------------------------------------------------------------------------

Setup:
  1. Just place everything, except the "SauerImageConverter.exe", into the same directory as "autoexec.cfg". (/Sauerbraten)
  2. Put the "SauerImageConverter.exe" anywhere it's easy to get to. XP
  3. Add the line "exec cube_art.cfg" anywhere in your "autoexec.cfg"
  4. (Optional Keybind) Add the line "editbind N cube_art" anywhere in your "autoexec.cfg"

How to convert an image for use as Cube-Art in-game:
  1. Find a ".bmp" image.
  2. Place the image inside the same directory as the "SauerImageConverter.exe"
     (Make sure the ".bmp" image's name has NO SPACES!)
  3. Run the "SauerImageConverter.exe"
  4. In the Converter: 1.Enter the name of the image.
                       2.Then Enter the name you would like the conversion to be called.
  5. Place the newly created "[name].cfg" file inside the "cube art" folder. (Folder should have been placed in "/Sauerbraten" alongside the script)

How To use in-game: (WITH Keybind)
  1. Press the 'N' key to open the Cube-Art menu and select the image you wish to make.
     (Or whatever subsequent key you may have bound "cube_art" to.)
  2. Raise a stack cubes equal in number to the height of the image displayed on "imgload"(also obtained by calling "/echo (imgh)")
     (Remember that the texture on these cubes will be the texure used when drawing the image)
  3. Click on the side of the top cube, stand back and press the 'N' key again. (*TIP*- if the row gets cut-off, you can redo the row by using "/prevrow", then redrawing it)
  4. Move down to the start of the next row and repeat step 3 until the image is complete.
     (You will be notified when the image is done.)

How To use in-game: (With NO Keybind)
  1. call "/loadimg [name]"  <-- file extension ".cfg" is not manditory here. (nor the file path)
  2. Raise a stack cubes equal in number to the height of the image displayed on "imgload"(also obtained by calling "/echo (imgh)")
     (Remember that the texture on these cubes will be the texure used when drawing the image)
  3. Click on the side of the top cube, stand back and call "/drawrow" (*TIP*- if the row gets cut-off, you can redo the row by using "/prevrow", then redrawing it)
  4. Move down to the start of the next row and repeat step 3 until the image is complete.  XD
    (You will be notified when the image is done.)

Detailed List of in-game commands: (7/28/2011)

  "/colorc"
    -Stands for "Color Conversion".
    -It takes a value with a range of 0...255 and moves it into the 0...1 range.

  "/vcolorc [red] [green] [blue]"
    -Stands for "vcolor Conversion".
    -It is just like "/vcolor" but with color values in the range of 0...255.

  "/prevrow" [how many rows to go back by(optional)]
    -Call this function with no arguments to redo the last row of the image.
    -Pass this function a number of rows to go back by; eg. "/prevrow 4" goes back by 4 rows

  "/setrow" [row number]
    -Call this function to go directly to the row specified.
    -eg. "/setrow 6" will set the next row to be drawn to row number six.
    NOTE- "/setrow 0" and "/setrow 1" do the same thing.

  "/clearimg"
    -This function is the opposite of the "/loadimg" function.
    -It will clear all current "image_data" and reset all variables to their defualts.
    -This function is called at the beginning of every call to "/loadimg"
   NOTE- This function will NOT erase your Cube-Art image file.
   *TIP*-Call this function in-game to empty "image_data" if your "config.cfg" looks too cluttered.(I imagine it may if you load a huge image.)

  "imgw" and "imgh"
    -These functions return the last loaded image's width and height respectively.
    -Use: "/echo (imgw) (imgh)"

  "/drawalpha"
    -This will toggle whether or not to show a cube-art image's alpha channel as alpha material in-game.
    -Defualt: OFF
    -This is automatically disabled after a call to "/loadimg".
   *TIP*-Include a call to "drawalpha" in a cube-art image file to force it as a defualt for that image.

  "/draw_pixel"
    -This is the main drawing function. Each call will draw the next pixel on the selected cube and move on.
    NOTE- I do not recommend EVER using this function directly. It is very time-consuming.
          Instead, set it to a "bind", or just use the "/drawrow" function.

  "/loadimg [cube-art image name]"
    -This is the function that loads a "Cube-Art" image in-game.
    -Each call to this function WILL reset the last image loaded and all accoording operations.(e.g. it disables "/drawimg" and "/drawalpha")
    -The "Cube-Art" image specified does not require the file extension or path. (but it will accept it if it is habbit)
    -"Cube-Art" image files may ONLY be loaded from within the "cube-art" file.

  "/drawrow"
    -This is Cube-Art's 2nd method for adding an image in-game.
    -To Use: 1. Raise a stack of cubes equal in number to the height of your image.
             2. Texture ALL SIDES of the cubes with the texture of your choice. (I recommend a white texture to preserve the colors of your image)
             3. Select a side(NOT THE TOP OR BOTTOM) of the highest cube.(with the mouse)
             4. Move to the opposite side of the stack and remain facing the stack. Try to keep the horizon in-view.
             5. Call "/drawrow" (It will literally draw the whole row of cubes/pixels for you)
             6. Repeat these steps for the remaining stack of cubes. **Remeber to select the same side of the stack as before.














          