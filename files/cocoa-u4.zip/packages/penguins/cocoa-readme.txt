Author: SkiingPenguins
Copyright: Creative Commons (BY-SA) [Creative Commons Attribution-Share Alike]
To Use: /loadsky penguins/cocoa
This skybox may be used in all cube engine games, no matter how it must be altered.
July, 2009