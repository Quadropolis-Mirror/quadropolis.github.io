IN THE CHRISTMAS 2012 CONVERSION PACK:

- gui modification. new menu, menu background, logo (only the smaller) etc.
- new christmas style pickups. ( ammo as a surprise giftbox :D, health, boost, armor, quad, health )
- new grenade projectile ( an ice cristal )
- blood effect removed ( because the kids ... ), new explosion and scorch.
- Ogro model replaced with Santa Claus ( I maked this very fast and maybe not a good optimized model, and a .md3
  format with some simple animations. I replaced the death animation for a "christmas friendly" anim, and it have an old style
  all in one world weapon model.
- hudguns -> sorry but I have not time for this. Incoming in 2013 :).  
- vwep ( world view gun model ) just one snowgun.
- new sounds by me and Audacity as "pain, death, jump..." no weapon sounds.


   How to install:

1. This modification make too many replaces, 
   I recommend you make a new install of Sauerbraten and hold your original game.
   
2. Remove or rename this directories (only the last dir. end of the lines).

Sauerbraten/packages/models/ammo dir.
Sauerbraten/packages/models/armor dir.
Sauerbraten/packages/models/boost dir.
Sauerbraten/packages/models/flags dir.
Sauerbraten/packages/models/health dir.
Sauerbraten/packages/models/ogro dir.
Sauerbraten/packages/models/projectiles/grenade dir.
Sauerbraten/packages/models/quad dir.

3. Unpack the christmas2012.zip package into Sauerbraten head dir.
   ( you will get a popup window, select overwrite all ).
   
4. Start the game and select "Claus" player model from the multiplayer menu
   ( select "Force matching player models" if you want to be all players or bots as Claus )  
   

   
  IN THE COMPLETE CHRISTMAS 2012 PACK:

+ a new map called xmas2012. This is a beta but I have not more time for finish it. Some places on this map are very empty, poor lighning, etc. 
  ( if you are a good mapper, feel to free to finish, I will make it for the next Christmas :) ). 
+ new map models and textures by me. I enabled to re-publish or using in any free, non commercial game.
  ( plase do not modify my models geometry, use the .cfg file to resize/rotate it ).
  
  To install:
  
- Follow the 2. 3. 4. instructions above. 
 
- load the map with command ( /map xmas2012 ), and put some noob bots for your fun :D .

Enjoy, and Merry Christmas for you!