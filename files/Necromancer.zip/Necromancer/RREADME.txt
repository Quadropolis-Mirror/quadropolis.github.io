{\rtf1\mac\ansicpg10000\cocoartf824\cocoasubrtf480
{\fonttbl\f0\fswiss\fcharset77 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 ===========================================================================================\
                          Necromancer\
===========================================================================================\
\
Instalation:\
\
Unzip directly to Sauerbraten main folder.\
\
Mannually:\
"necromancer" map goes inside "Sauerbtraten\\packages\\base" folder.\
"necromancer.cfg" and "necromancer.ogz" should go into "Sauerbtraten\\packages\
===========================================================================================\
\
File Details:\
\
Game:                Sauerbraten (www.sauerbraten.org)\
Game Version:        07-21-2008\
Map Name:            necromancer\
Map Version:         Retail 2.2\
Building Time:       Two months.\
Release Date:        july 21st  2008\
Authors:              Matthew(Matthias),Anon(Dylyn),Patrick(Patrick Duffy),Frank(Suicizer),Anon(Skiing penguins)\
E-Mail:              sk8ermatt3@hotmail.com\
WebSite:             None ATM\
Description:         A rather large regen capture,CTF, for 8-12 players or even more I\
                     think. It's set in a dreary dark tower.\
\
Builders:           Matthias,Patrick and Dylyn\
Lighting:           Suicizer,Matthias\
Ents:                  Skiing Penguins\
                     \
Textures:          Dylyn\
                     \
Skybox:            "socksky/grave"\
                     \
\
===========================================================================================\
\
Map's Story:\
Just an Evil map featuring a dark dreary tower,and a evil demonic pentacle \
this map is meant for regen capture or capture the flag but can be used as insta and such \
===========================================================================================\
\
- Since mappers aren't perfect, neither am I, this map could have some graphical bugs or\
  regarding to gameplay too. So for that, feedback to my mail regarding this point will\
  be very apreciated, also any opinion in general about the map will be apreciated.\
\
===========================================================================================\
\
Version History:\
\
Retail 1.0:\
- Notable graphical changes, much more detail everywhere.\
- New area on the train tracks.\
- Worked more on the lightning.\
- Custom skybox and changed music theme.\
- Entities are now well placed.\
\
Retail 1.1\
- Really minimal bug fixes. You won't even notice them.\
\
Retail 2.0:\
- Ported from Cube to Sauerbraten.\
- Finally lightning looks like it should, added day and night ilumination.\
- Various new details using Sauerbraten new features, and some custom textures.\
- Redistributed entities.\
\
Retail 2.1:\
- Corrected some minimal graphical bugs.\
- Added some general detail and modified a couple of zones.\
\
Retail 2.2:\
- Fixed crazy texture bug from newer Sauerbraten releases.\
- Corrected some minor texture misplacing.\
- Added water to closed railway.\
- Reduced whole file size using a comand to rotate textures instead of another image (lol).\
- Some gameplay fixes.\
\
===========================================================================================\
\
Copyright & Permissions:\
\
Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)\
\
\
Authors may  use this level as a base to build additional levels.\
\
You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other\
electronic medium that is sold for money without my explicit permission!\
\
You MAY use this map's textures as long as you give credit to their respective authors,\
including original readme files.\
\
If you have a mapping website, and you want to upload this map in it, or if you're\
making a map pack and want to include this map, you're totally free to do so. Always\
remember to include all files unmodified. Especially this readme file.\
\
===========================================================================================\
\
OTHER credits\
Builders:           Matthias,Patrick and Dylyn\
Lighting:           Suicizer,Matthias\
Ents:                  Skiing Penguins\
                     \
Textures:          Dylyn\
                     \
Skybox:            "socksky/grave"\
===========================================================================================\
\
}