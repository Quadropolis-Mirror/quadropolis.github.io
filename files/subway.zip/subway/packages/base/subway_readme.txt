--------------------------
Subway by </DarkStar\>
--------------------------

Though this map is finished, it may contain bugs and glitches.
This map is suited to all modes of play, though due to layout, it may not be ideal for deathmatch settings.

Currently this map is for aesthetic perposes only, though a single player mission is currently in development.
Hopefully this map will be updated in the near future, according to critique and suggestions.



-------------
Installation
-------------
Copy all files named "subway" into your Base folder.
On a typical Windows machine, this can be found in "C:\Program Files\Sauerbraten\packages\base"

You can load this map in game by pressing T and typing "/map subway".


------
Notes
------
This map took many weeks of time and effort. Out of respect please do not redistribute.
If you find any bugs or have suggestions, please post them on quadropolis.

Thank you, and have fun!