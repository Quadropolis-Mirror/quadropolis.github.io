<This map was made by TheSharpShooter and should not be edited and published under another name>

- Extract all in the maps folder via packages folder, which should be in your AC folder

- More great maps are available, contact koro-shiya@hotmail.com for more

- Enjoy the map, and please don't forget to add comments/reviews in Quadropolis


~Maps~

ac_ravenholme
ac_storage
ac_dawnville
ac_fortroswell (coop edited with BigSexyPanda)

Other maps are available, although they are test maps and are not as great as these maps
