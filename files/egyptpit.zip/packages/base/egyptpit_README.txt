Egyptian Pit by Pritchard - 3/12/13 - 0.5

3-4 player FFA/Instagib map. No objective entities.

A pretty simple map, small. Not much to say about this one yet.
I'm looking for constructive criticism around this map; things like spawn points and weapon placement probably need tweaking.
