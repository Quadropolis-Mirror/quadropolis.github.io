Derived from high-poly mesh by Superdude123
http://www.turbosquid.com/3d-models/3d-sexy-lady-posing-model/390303