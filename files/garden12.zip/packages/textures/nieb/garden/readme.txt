Textures by Nieb.

Made with sources from:
http://www.cgtextures.com/