This exit sign model is free so use, distribute, or make dirived works from.
If and only if this reade me file and/or the author is given credit.
This was dirived from maKKEs cation sign for ActionCube.

Steve (Death) Burns
E-Mail: xspres.sburns@gmail.com

@ eXplosionStudios