Wolf & Zeta player models

Red Eclipse player models configured & ready to go
Based on Wolf07 model by Gabriella 
Published By TeamXbow

Status - about 90% complete

Instructions

These are arranged in male & female folders like the standard RE models with 1.4

1. You should experiment with a seperate RE install, not your playing one
2. Rename the male and female folders to something else
3. Unzip wolf07_RE14.zip in the actors folder, it will create new male and female folders
4. Start RE, play!

Wolf
Wolf is a character from the SP game in MekAracde. He is wearing a light combat suit

Zeta
Zeta is a warrior clone originally from Zeta Reticularis, who has been stationed on Terra in a secret underground base  under Archuleta Mesa on the Colorado-New Mexico border near the town of Dulce, New Mexico . Zeta, like many of his race, hates humans, has a penchant for cows and is equiped with a fully functional anal probe.  