By Remus

Disclaimer:

The textures are free to use for both personal and commercial purposes. All I ask is that proper credit is provided.