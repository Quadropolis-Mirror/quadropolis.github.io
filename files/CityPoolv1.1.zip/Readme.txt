**************************************
City Pool
Map for Sauerbraten
Created by FIGames
**************************************
To Install (If you don't know how)
Copy fipool.cfg and fipool.ogz into your Sauerbraten/packages/base/ folder
Sauerbraten 12-04 GUI Edition or newer is required www.sauerbraten.org
**************************************
Changes in Version 1.1
Lights added in a corner that was too dark
New hidden weapons room
More Playstarts, from 4 to 9 total
Fixed some texture errors
Fixed an erratic mapmodel placement.
Added some more weapons.
**************************************
To Play
Ingame, press T. then type \map fipool
**************************************
This map was not intended for deathmatch, but can be use for it if you like fighting in a city place :)
It will not work with capture tho.
**************************************
There are 5 major areas in this map. There's the pool, which is in the middle, the the Apartment Complex, with 2 buildings (dont get chased into an apartment or you'll be screwed :D ) One has a maze beneath it. Then the Park, which has a dodgeball court and a small-ish lake and stuff. Also, the Underground Cave (hidden area) has numerous guns and very happy ammo >_<. Then all the houses around the sides has snipings and trees and cool stuff.
**************************************
This map is not supported by the creators of Sauerbraten. But still its pretty cool so give it a try. Sauerbraten is open source and is also free. :) :D lol!
**************************************
Thanks for downloading the map and I hope you have fun playing it!

super_chiken

www.freewebs.com/figames/ (official site)
www.forumsvibe.com/figames/ (forum)
**************************************
IF you have comments bug me at
figames@yahoo.com

(no spam PLEASE!)