Hey, before you play this, there are a few things.

1. Place the picture file and the map in the base file (Sauerbraten/Packages/Base).
2. When you go to play the map, press `, then type "sp Zelda" without quotations.
3. Enjoy

The Legend of Zelda is copyrighted Nintendo 1987-2009 and was used without permission. This is not intended to damage the Zelda series in any way.

This is a Petman1325 map. Do not modify and reproduce this map without permission.