oldschool by rabe (2018)

installation:
- copy the content of the base folder in this zip to the base folder in your user directory
- install the ex512-texturepack (http://quadropolis.us/node/2792)
- install the e8-texturepack (http://quadropolis.us/node/2859)

credits:
- evillair for the textures
- all mappers and players, who gave me feedback

contact:
- pm rabe at quadropolis.us or sauerworld.org