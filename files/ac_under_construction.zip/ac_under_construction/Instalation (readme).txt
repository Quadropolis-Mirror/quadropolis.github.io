-----------------------------------------------------------------------------------------------
MAP INFORMATIONS
-----------------------------------------------------------------------------------------------
name: ac_under_construction
BY: Deathstar
size: 17ko

-----------------------------------------------------------------------------------------------
INSTALATION
-----------------------------------------------------------------------------------------------

1) Put map files ("ac_under_construction.cgz" & "ac_underconstruction.cfg") in:

>>>>>>>>>>>>>>>>>>>>>>>    "assaultcube/packages/maps"  <<<<<<<<<<<<<<<<<<<<<<<<


2) Put The subfile texture (under_construction subfile) in:

>>>>>>>>>>>>>>>>>>>>>>> "assaultcube/packages/textures"<<<<<<<<<<<<<<<<<<<<<<<<<

-----------------------------------------------------------------------------------------------

If you have problem with instalation, post comments on acka website:

http://acka.zeblog.com



