{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf290
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 soviet map by TESLER\
\
includes standard sauerbraten map models, and skybox by blikjebier, which was used in the map frostbite.\
\
this is a work in progress and will evolve over time\
\
if you have questions concerns or recommendations, contact me at tester.warehouse@gmail.com}