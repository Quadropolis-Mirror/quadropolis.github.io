SAUERBRATEN MAP README
======================
Loading Bay
                by StD
======================

Alright, so there we go with another map. After fiddling around for a while
with a map I decided to put lights and entities in it and yeah.. that's it.
There's no deeper thought behind this one whatsoever. Just a basic map, made
for players to frag each other.

It uses only standard textures and the light detail is set to standard, so please
don't ask me why it's still 1.3mb.

However, if you have any questions regarding the map, feel free to send me a
mail at Force19@gmail.com

Have fun fragging!
