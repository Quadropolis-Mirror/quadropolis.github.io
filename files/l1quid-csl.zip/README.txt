L1quid CSL
http://lazyasses.net
l1quidm3th@gmail.com

Time: around a week

1-4 players map

I modeled this map after one of the all time classics CSL for Rogue Spear, I
loved that game =)

INSTALL:
Extract to your packages/base folder
load with /map lcsl3
or
edit your cfg to include it ..


NOTES:
Send me any comments u wish, good or bad i have a delete button =p

Look out for more Rogue Spear inspired maps ( killhouse, bunx, sib1 , ect ect)

Thanks:
The guys who made the game engine, website, forum , and all the info found on
them
Red Storm entertainment for making such a kickass game ( Rogue Spear )
My good friend MrX for giving me vital suggestions and helping me test it
