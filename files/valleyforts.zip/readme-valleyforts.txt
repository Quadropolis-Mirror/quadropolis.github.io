Map by Madrick

Instructions: Extract this archive into your Saurbraten folder. Be sure to allow the folders to merge.

Map Info:

This map is my second release (although it is my 5th real map) and I'm very proud of it. I invested more time into this map than I have for all of my others. ValleyForts is intended for CTF, but can also be played equally well in Capture or Regen Capture.

The map is based in a valley, split into two sides by a river running through the center. Two castles run the length of each side, each has four large battlements which give segmented views of the map. The layout of the map causes the player to cross sides at up to five points to reach the other base (alternate routes may cause this to differ). In the exact center of the map is a building which marks where the "territory" or each side ends. In the middle of the building there is no floor save for a small arena, which houses a capture base in the capture gamemode.

Overall, this is a large CTF castle-themed map with expansive bases and caverns. It is by far my most visually stimulating map and may not run extremely fast on lower-end computers.


Thanks and have fun!
-Mad