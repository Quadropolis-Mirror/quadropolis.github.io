-----------------------------------
-- general information ......... --
-----------------------------------

Title:     stadion
Engine:    Sauerbraten
Creators:  Hero, Finn, some geometry from apflstrudl

-----------------------------------
-- idea ........................ --
-----------------------------------

The idea itself wasn't as young as I thought first. Like you can see in his comment on the quadropolis node, DTurboKiller LT had already created some tennis maps in 2006! I didn't ever saw that and got this idea on a coop server, and afterwards me and apfl created this map and redesign the game rules.

-----------------------------------
-- The Sauerbraten-Tennis rules  --
-----------------------------------

note: the term refill means that you are to refill your ammo, armor and health on the refill station near the court.

1. Goal of this game is that you kill your enemy.
2. 2 Player are playing against each other with grenades. One Player serves from one of the small fields, then he is allowed to move on his half of the court. In the next round, the other player will serve.
3. Both players are shooting alternately! 
5. There are so many rounds to play until one player has 4 points.
6. Points are given
- for a kill 
- for a suicide of the enemy (lava, etc)
- for 2 fouls of the enemy
- fouls are 
-> shoot more than one time on one turn
-> use the pistol/other weapons
-> leave the court or jump over the net during the game
-> stand on the net for a long period of time
7. Refill at the beginning and after each round. A round ends when someone gets a point.
   If you run out of ammo, then JUST refill it, but don't pick up health or armour.
8. Change the halfs after 2 rounds.

The game mode you can use is ffa.

-----------------------------------
-- installation ................ --
-----------------------------------

Extract the ZIP-archive in your Sauerbraten main directory.
This map only makes sense in multiplayer. Be sure, that everyone has it and if not, send him to the quadropolis node.
http://quadropolis.us/node/921

-----------------------------------
-- changelog ................... --
-----------------------------------

Version 1.1
- deeper lava border (exploding grenades were able to hurt a player when he was near the lava)
- added green armors for more possible game modes
- added a "hall of fame" with pictures implemented as new textures on the wall
- added a bathroom
- new welcome message
- advertising for the CSL :D

Version 1.2 
- skipped

Version 1.3
- more and (hopefully) better lighting
- a new entrance hall

Version 1.4
- quite a bunch of design-improvements, including a new refill station
- enlarged hall of fame

Version 1.5
- fixed particles and textures for trooper edition
- major additions: studio, commentator boxes, another underground tennis court, press conference hall...
- toilets in the bathroom
- some texture changes
- improved VIP room above the referees place
- some enhancements on the benches
- yet another refill station

Version 1.5.1
- fixed textures for Justice edition
- bumped up the lighting (turns out editing with gamma 140 isn't too good)
- a few minor texture cleanups

Version 1.6
- added an (inaccessible) security office
- added 3 courts outside so people can play there when tournament matches are going on
- added a fence and high clip around the stadium

Have fun with this idea! :)
Hero
