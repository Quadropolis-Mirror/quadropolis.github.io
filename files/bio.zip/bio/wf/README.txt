Use, Abuse, CREDIT. The only thing I ask is that you CREDIT me if you use. You can modify it if you need, you can use it for your maps, anything. Just make sure to CREDIT. Free for non-commercial use.

The package has approx 125 textures, 31 colors, 4 sizes, and the 'seethrough' sky texture.

There is no particular order to the colors, so it may be hard to find them if scrolling. I'd recommend press F2 to view all of them.

BionicCryonic, neenthecat@yahoo.com