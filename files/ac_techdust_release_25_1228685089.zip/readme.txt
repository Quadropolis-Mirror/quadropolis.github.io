=================AC_Techdust by Sauer2 (C. Hackenberg)==================
The files included in this package are public domain.
You need Assaultcube 1.0 or highter to play this map.


