This was originaly done by (unknown).

Ladder always sucked.  It needed more.  I am on a quest to finish all the unfinished maps.  This time instead of just adding entities and areas, I edited 
the WHOLE map.  As you can see in the screenshot.  I wanted to finish this map, so I went ahead and finished it.  Only one thing, I forgot to calclight, so 
when you download this you will have to do that.  I named to file ladderz.ogz because you might wanna keep ladder insted of this edited version.  But I have the file ladder as this.  Do 
whatever you want with it.  Good luck, have fun.


~w00t