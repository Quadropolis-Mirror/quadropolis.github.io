I named this ladderz instead of ladder.  Go ahead and check it out.  If you like it, and you wanna replace the old one, take away the 'Z' in ladder"z"


~w00t