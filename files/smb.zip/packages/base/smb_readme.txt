Sauer Mario Brothers

About:
It's done bad. I didn't put any thaughts in clean editing.
Just wanted to be the cool guy with the Mario-Map at the next LAN i go to.
I added a bunch of playerstarts, flags and some weapons. 
So you might play it in FFA, EFF, and CTF and some more I guess. 
HF =)

Installation: 
Unzip this to Sauerbraten folder.

Copryright:
Whatever you want, just don't tell me.

