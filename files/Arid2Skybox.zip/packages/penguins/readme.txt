Author: SkiingPenguins
Copyright: Creative Commons (BY-SA) [Creative Commons Attribution-Share Alike 3.0 United States]
Creation Date: April 2010
Please give SkiingPenguins credit, where it is due.
