//Edimmu by Daz aka NeuroCase
//Check out my webby: www.dazpetty.com
//Please include my above website in a readme if you release this in a pack.
//Copyright :: CC-BY-SA
//
//thanks to 'skiingpenguins' for the skybox 
// -> http://www.freezurbern.com/
// Copyright :: CC-BY-SA
//
//thanks to feelgood comics for the rigged, blender skeleton model 
// -> http://www.blendswap.com/user/feelgoodcomics
//textures are modified from cgtextures
// Copyright :: CC-0
//
//
//Just extract this into Tesseract folder