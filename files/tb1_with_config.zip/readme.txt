Name: 		Thunderbird 1
Description: 	An aircrft with variable geometry wing suitable for rapid reponse missions. 
Weight: 	approx 25 tons
File Format 	md3
Animated: 	No
Skun:		Yes
Publisher: 	TeamXbow.org
Release: 	Official release with Mekarcade 0.31
Licence: 	GNU