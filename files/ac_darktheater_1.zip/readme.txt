Help:

Copy the cfg and cgz files into packages\maps directory
then copy the night folder into the packages\textures\skymaps directory

go into ac and type /loadmap ac_nightmap

by Dave