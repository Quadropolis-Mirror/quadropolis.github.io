This map was created on September 18, 2007. It uses basic textures from the default menu, but it is also unique in looks. It has plenty of room to jump around and has some nice curvature to it. I built this thinking of Quake 3 and old style maps and added my own twist. This map should run pretty decent on any computer, but the main lobby(with the water). I wanted this in the contest(August 2007), but it wasn't fully done, so I hope to get it in the next one.


