DISCLAIMER!

This map is complete in the sense that it works properly,
however, I would like to add lots more detail into it. 

Problems I know of:
Needs more detail
Some textures kind of suck :|
If you run through the level too fast the text gets all garbled. If you want the story just take it slower, it's not a marathon.
I don't have the cvs program, as I don't really know what to download. If someone could send me a link to a program that works, please do.
Small and short.

YOU CAN NOT BEAT THE LEVEL BY KILLING ALL THE MONSTERS!
This is done on purpose for story-line reasons, if you could beat it by killing all the monsters it wouldn't make much sense. You practically have to kill them all to win, anyways, so it doesn't really matter.
(There is a monster isolated from the map to prevent you from killing them all. I know. It's there for a reason.

-STORY-:
Your name is Quitaren on a planet in a distant galexy. 
Teleporter technology allows you to teleport to the mines on your planet's moon every day to work. 

But one day something strange happens when you teleport...

The rest of the story is told as you go along in-game.

Place these files in the packages/base folder