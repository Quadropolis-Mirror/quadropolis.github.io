Map:
ac_fetus2

Author:
fetus

What to do:
Place both files into folder: C:/programfiles/AssaultCube/packages/maps

Play it and tell me what sucks.  If it's worth while, we can make it better.  Otherwise we'll trash it.


General Idea:
A small (and crude) deathmatch map for 3 or 4 people.  Made it for me and my brothers.  We were tired of trying to find each other on complex.  

Thanks for playing.