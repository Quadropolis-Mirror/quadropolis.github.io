Hey all I am new, my name is JayTizzle, and this is my first
map.  I hope you enjoy.  If it isn't right, just remip 
and/or calclight.


-- Just extract the folder "packages" into your main
sauerbraten directory, it will not overwrite anything unless
you already have the files. ;]

Credit -- 100% JayTizzle

~JayTizzle

PS-- To load type /map Instagrave
:P