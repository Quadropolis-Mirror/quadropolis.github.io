FrOsTy's Facility v0.3 Alpha
----------------------------

15 hours ont his baby, no idea how much tweaking it'll need but here it is, it's not FINAL but good enough. level should be big enough.etc.
WEBSITE: http://geocities.com/goldeneyecube2/

You are in no way shape or form aloud to edit this without my conscent, AND distribute this as your own work, if you want to fix it up give me a yell at iddjfrosty@yahoo.com, and then give me credit for the original file. 

You can always add comments, sujestions on my website.

Enjoy, Facility v0.3a
---------------------------
INSTALL!
stick it in (C:\Sauerbraten\packages\base) Or where ever you installed it to\Sauerbraten\packages\base

Uses default package, Credits goto those that whom the graphics use in your own cube2/Sauerbraten file.

-------------------------------------

TODO:
I Want to get the undergound corridoor up top working and a way across to the hidden island.


-----------------------
CHANGELOG:
------------------

v0.3a
-Done most of the DAM up top
-Fixed a few bugs here and there.

------------------

v0.2a
I bring you Facility 0.2a!

Changelog:-

-Fix some lighting
-Added spawnpoints
-Added Ammo
-Done the rest of the level
-Various other things

If you know how to make quake 3 guns from scratch let me know I may need someone that's handy with modeling, also importing .md2 characters, so far it's just me doing this.

---------------------------------

V0.1a
Many years have passed it's the year 2050, James bond is going back...back to the facility...

Made with cube 2 engine, This is an alpha version of my map I'm making, recreating golden eye!

I might Make the dam + facility + runway all into 1 mod, A lot of work with the lighting, finishing the rest of the level . etc has to be done (obviously).

As you can see it's lighting effects and the explosions are damn nice!