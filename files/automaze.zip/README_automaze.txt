Automaze by SirAlex
===================

Intro
-----
So I made this whole maze manually, took me a while. I'm just kidding.
I got this idea from Windecker, with his map from over here: http://www.quadropolis.us/node/2620

Generator
---------
I really taunted him of how much work he put into it, so i spent about 2 hours coding a small program in C to generate the maze then I made it into a rec file.
A rec file is a thing that frogmod has, it basically dumps all editing commands into one file, which can be played back later.

Maze Characteristics
--------------------
Based on the algorithm, there should be only 1 way between any 2 points in the maze. So that means no loops, and no isolated sections. Any loops are caused by a packet loss when the recording was played and they should be pretty obvious.
Don't ask me how to solve it, I did not make a solver for it.

Raised Walls
------------
This was another idea from Windecker, which was very easy to implement in code. Basically there's these areas of walls which are higher, and they go along the structure decreasing every few cubes.

Files
-----
You can find all the files over here:
http://csclub.uwaterloo.ca/~amstan/upload/sauer/maze/

Attribution
-----------
If you use my map generator I would appreciate it if you state somewhere if you used my map generator

Contact
-------
You can find me on quakenet and gamesurge with the nickname SirAlex