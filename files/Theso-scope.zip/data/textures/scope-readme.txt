This scope image was created by Theso. Use it however you wish, but credit would be greatly appreciated.

contact: johniwas@gmail.com 