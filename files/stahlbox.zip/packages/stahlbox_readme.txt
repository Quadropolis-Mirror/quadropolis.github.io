stahlbox by rabe (2015)

installation:
- copy the content of the base folder in this zip to the base folder in your user directory
- install the e8-texturepack (http://quadropolis.us/node/2859, version: 22nd May 2015)
- install the eX-texturepack (http://quadropolis.us/node/2792, version: 8th Sept. 2014)

credits:
- evillair for the textures
- all mappers and players, who gave me feedback

contact:
- pm rabe at quadropolis.us or sauerworld.net