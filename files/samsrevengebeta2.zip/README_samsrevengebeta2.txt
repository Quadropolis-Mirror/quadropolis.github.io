Sam's Revenge Map (beta 2)

Game type: DM & TeamDM
Map size: Large
Players: 8-20
Release date: 2007-09-26

This is my first map for Cube2 engine. I wanted to try few ideas at first, and pretty soon they turned into quite big map. However, I could not leave it empty :)

Any feedback, especially about gameplay is very appreciated.

Update (beta2):
Reduced number of items in map. Actually, restored them to the initial amount i had in mind when designing it (all items should have memorable places now).

nercury@gmail.com