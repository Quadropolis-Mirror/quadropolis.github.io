mapping: by deathstar
added texture by Deathstar
other textures from AC (c)

thanks to assault cube program(c)

--------------------------------------------------------------------------------------------------
http://acka.roxorgamers.com
--------------------------------------------------------------------------------------------------