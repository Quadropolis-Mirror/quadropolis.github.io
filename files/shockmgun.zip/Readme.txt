Shockmod Machinegun 

by John Siar a.k.a. Shocktrooper
geargolem@titanium3d.com

Best used with the Shocksuit player mod

Feel free to use, alter or modify at no request.  If you want to give me props, so be it.

Extract into your sauerbraten folder.  The default chaingun will be moved to the CVS folder.  To replace the default, simply cut or copy CVS/skin.jpg and CVS/tris.md2 back into /chaing.