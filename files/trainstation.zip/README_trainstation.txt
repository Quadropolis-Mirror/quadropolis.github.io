Name: trainstation
ID: Created by IndiJan for Sauerbraten
Description: Sauerbraten map inspired by the Antwerp Central Station (Belgium). Beta
Date: Created on 20/08/2008 (and a few days before) for CTF and Capture play
Credits: Thanks to the authors of textures, creators of sauerbraten,...
Contact Information: jancelis@yahoo.com
