Secret Lair by digitalspaghetti
http://digitalspaghetti.me.uk

This is my first map release for Sauerbraten.  It's a simple small deathmatch map.

To install the map, extract the Secret_Lair folder into your packages folder of Sauerbraten.
