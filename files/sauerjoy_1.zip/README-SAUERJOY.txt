   
                 Sauerbraten Game Controller Support
              
                                 by

                      dbox (dwbox@hotmail.com)
-------------------------------------------------------------------------------

STEP 1: Backup the data/keymap.cfg file if you want to keep the original
        (the changes are additive and will not affect the original game):

STEP 2: Extract this archive into your Sauerbraten directory.

STEP 3: Execute the sauerjoy.bat file.

STEP 4: Configure your controller by typing "/joymenu" in-game (without quotes)




Installing the source
-------------------------------------------------------------------------------

Copy the contents of the sauerjoy-src directory into the main sauerbraten
src directory. Keep in mind that this will overwrite the main.cpp
console.cpp files.



Usage
-------------------------------------------------------------------------------

You're free to use the code on two conditions:

   1. Let me know.
   2. Give me props in your documentation.