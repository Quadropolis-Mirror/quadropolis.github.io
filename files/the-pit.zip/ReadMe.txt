The Pit by SirPugglez

Put the map file (the_Pit.ogz) into C:\Program Files\Sauerbraten\packages\base

you may edit this map freely but you must send me the map at sirpugglez@gmail.com and get my permission to post it on the web.

also report any bugs or glitches you might find.