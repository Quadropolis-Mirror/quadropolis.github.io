****To Installl****

*Place both files (fortbase1.3.ogz & fortbase1.3.cfg)
 in you sauerbraten directory eg: 
c:/program files/sauerbraten/packages/base


Map by lakenz

Email:Lakenz1@gmail.com

****To Play****

*Go into sauerbraten and type /map fortbase1.3 .If
You want to play it on a server (online with other players)
then go to sauerbraten forums and ask members!!!!





For Docs,forum and info go to: http://sauerbraten.org/
Or For The Forum: http://www.cubeengine.com/forum.php4