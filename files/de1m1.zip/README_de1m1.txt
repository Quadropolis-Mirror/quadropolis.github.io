Title 			: DooM: E1M1
Release Date 		: 20.05.2010
Author 			: UltimateLorenzo
E-mail Address 		: ultimatelorenzo@gmail.com
Other Files by Author 	: This is my first Sauerbraten map
Misc Author Info 	: DooM fan, I recently started playing and mapping for Cube 2
Additional Credits	: ID Software
Description 		: This map is inspired by the first DooM level, Hangar. I rebuilt it using Sauerbraten resources and monsters.
			  This is a singleplayer map.
Instructions 		: Unzip the de1m1.zip in your Sauerbraten directory. Standard Quadropolis archivation is used.
		 	  In the game, type "mode -3; map de1m1".
Version			: 1.1
Build Time		: One month
Permissions		: Feel free to distribute, modify, or change this map as you prefer, but please remember to credit me!