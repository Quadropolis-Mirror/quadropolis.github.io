Concrete Facility by B}Zarj.
Any changes to this map require the author's explicit permission.
You can contact me at zjullion@ualberta.ca, or via the AssaultCube forums at forum.cubers.net.
Special thanks to o2|Gibstick, eQ|Viper, B}Ronald_Reagan, and the rest of B} clan for their ideas and suggestions.