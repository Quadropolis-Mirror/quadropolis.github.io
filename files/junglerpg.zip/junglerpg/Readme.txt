Made by -=iosq=-
Large Jungleish map.Called junglerpg becuase I think its pretty big... like one of the rpg maps!
Any suggestions/ideas, contact me on quadropolis. I check in about twice a week so it may take a while for response.
THIS IS THE UNFINISHED VERSION - ABOUT ~30 GRUELING HOURS OF EDITING TILL COMPLETION
