This is Babylon.... thats about all I can say about it.
Small, 2 vs. 2 or 1 on 1 deathmatch map. Inspired by my
beautiful woman, Tamira, this map took me around a week to
make. This is the first of many maps that WigSplitta will make
so if you like look around Quadropolis.us for them. Just got
back into mapping and this is my first Sauerbraten map ever!
