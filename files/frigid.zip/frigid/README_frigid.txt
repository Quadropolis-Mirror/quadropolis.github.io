This map was inspired by the popular ctf AssaultCube map bs_dust. 

My brother and I had a lot of fun playing bs_dust, but we came to the conclusion that the map had a few flaws.

frigid attempts to recreate the dynamics of bs_dust, but solve several problems and provide a different aesthetic.

-There aren't any places where you can get stuck
-The bases are designed to be more balanced (but still unique)
-You can't be shot by a teammate by accident when you spawn at the beginning of each game
-There are more routes to the enemy flag
-The map is slightly larger, so hopefully you'll be able to run around a bit longer before getting randomly shot

Constructive criticism is welcome and if you have any ideas, feel free to make your own versions of the map.

I'd like to thank the bs clan for their work and my brother Skyler (aka space_invaders) for his imput.

-Sage Berg (aka turtles)