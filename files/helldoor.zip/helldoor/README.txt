This is my attempt to make something worthwhile for the Metropolis project.
The mansion of an eccentric who built his home on top of an ancient
temple. Legends sya it is a secret doorway to the underworld. The eccentric
hopes to excavate it and use the knowledge and power gained for his own
purposes.

-------------------------------

Very much a work in progress with much detailing and texture tweaking and light
dabbling before I can be happy with it. I figured to show my work in order to
get feedback on ways to improve it.

So far, there are no monstres or ammo. I do intend to write up scripts for
various triggers and SP play. I hope to make a series with this map being the
first. The hell-door would load further maps ( should I get good enough
anyways. )

Once I start on the SP stuff..I also hope to add a few models.
Everything will be given back to the community.

-------------------------------

Feel free to use any part of it for your own purposes, but I'd hope you'd give
some credit to me if you do so.

So far, I am only using officially provided textures and mapmodels. 
I am not using anything from the CVS so that anyone can play with it.

-----------------------------

update #1
did some work in making the house detailed...added furniture and doo-hickeys to
many rooms
fixed a couple of places I didn't like
considering where and how to use boxes and barrels
I'd like some feedback on how I did the doors for non-sp play and if they work

update #2
finished filling out room details and tweaked lighting a bit...I could do more,
but I also don't want to over-do it
did a bit for the outside...trees, nothing fancy 'cause I'm basically lazy
Added some aiclip for future sp play...I hate that monsters are too stupid to
avoid falling into pits
Figured a bit more for the story for future levels

I'm ready to begin packaging it for Metropolis at least.

Captain Ahab