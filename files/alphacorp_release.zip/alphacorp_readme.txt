Alpha Corporation by Pritchard - Release build 20/9/15

This is the "release" build of Alphacorp that is included in the latest Tesseract SVN versions, packaged up here so that I had something to attach to this Quadropolis node. A better way to get the map is probably to download the latest nightly SVN version at: http://mappinghell.net/tesseract/tesseract-nightly.zip

Anyway, I hope you enjoy playing this map! It's definitely the longest I've ever worked on a single map, with work first starting over a year ago. Of course, I wasn't working for a solid year, but it still has taken a really long time! 
The map works in all modes, although you need the latest SVN of Tesseract for it to function properly in teamplay, and take advantage of fancy graphical features like volumetric lighting! Also, this isn't a small map, although it is pretty compact. I would recommend at least 6 or 8 players minimum if you want to have a good time with this map, otherwise it can be hard to find each other.

Although the map is already in the game, if you do notice any errors feel free to let me know, i'll try and get fixes included as soon as I can. Thanks, and have fun!