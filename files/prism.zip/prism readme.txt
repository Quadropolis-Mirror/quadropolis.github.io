prism by mIscreant
-----------------------------
-----------------------------
To play:
-----------------------------
1) Copy the two prism files into the following directory:
	sauerbraten/packages/base

2) Start Sauer and type "/map prism".
------------------------------
------------------------------
Thanks for checking out my map, leave some 
feedback on quadropolis.