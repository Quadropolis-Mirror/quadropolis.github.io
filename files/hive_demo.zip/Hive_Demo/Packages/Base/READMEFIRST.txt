--------------------------
Hive_demo by </DarkStar\>
--------------------------

This map is a work in progress, though it is suitable for play.
This means that it may contain bugs, entity problems and inconsistencies.
Though it has been tested, some problems may still occur during play.

This map is for SINGLE PLAYER ONLY -unless you want to fight in the lobby- as it uses doors and switches.


-------------
Installation
-------------
Copy all files named Hive_demo into your Base folder.
On a typical Windows machine, this can be found in "C:\Program Files\Sauerbraten\packages\base"

You can load this map in game by pressing T and typing "/map Hive_demo".


------
Notes
------
You may modify this map for personal use, but please do not redistribute.
If you find any bugs or have suggestions, please post them on quadropolis.

Thank you, and have fun!