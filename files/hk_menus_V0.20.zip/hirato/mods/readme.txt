hey! hirato here!
These patches will improve (hopefully) your experience with my mod, so enjoy and actually use them

=================
=GETSOUND patch==
=================

changes from sauer
* lists the sample used on the sound entities
* can display the entnameinfo stuff for rpg entities (it's not set up to do so)
* Splits the information up into 2 lines, for better readability
* Displays the texture on the current selection (this is disabled by default due to "Selection not in view" spam the patch disables)

instructions
============
* apply the getsound patch to your source tree
* compile a binary
* open hirato/data/config.cfg and set GETSOUND appropriately

===============
=reverse patch=
===============

changes from sauer
* adds an extra option to sliders that will flip them around, this is great for vertical list sliders

instructions
============
* apply the reverse.diff patch to your source tree
* compile