TOLL - The Old Lost Lair
By SCFR*MaxOfS2D

Last edit: 16:00 20/05/2008 (GMT+1)

Port of the original cube map.

Created under the latest available CVS version at the time of the last edit.

1) Unzip directly in your /sauerbraten/folder.
2) Enjoy :)
3) Feedback? Go to the map's Quadropolis node!