Water Treatment Facility
By Swe�tmiser�
April 2007, re-edited for quadropolis on August 2007.

This is my first map. I created it during april month, but I re-edited it for quadropolis on August
This map using gibbie's textures.


Swe�tMisery