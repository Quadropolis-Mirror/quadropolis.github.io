{\rtf1\ansi\ansicpg1252\cocoartf949\cocoasubrtf540
{\fonttbl\f0\fnil\fcharset0 LucidaGrande;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww13500\viewh9860\viewkind0
\deftab720
\pard\pardeftab720

\f0\fs24 \cf0 texture packages by lux.bleib-bunt.de\
\
please put the folders in your sauerbraten folder\
and load map pzoo1.ogz\
\
its a little piece from a other fun-projekt.\
\
hear this map and have fun :))\
\
\
see you \
\
lux}