//cagedoor and greydoor by Steve Eggleston, January 2008

//Set the following in your map.cfg

mapmodelreset 
mmodel "steve_e/doors/cagedoor"                 //4x5 sized door
mmodel "steve_e/doors/cagedoor/cagedoor_75"     //3x4ish sized door
mmodel "steve_e/doors/cagedoor/cagedoor_150"    //6x8ish sized door
mmodel "steve_e/doors/cagedoor/cagedoor_200"    //8x10 sized door
mmodel "steve_e/doors/greydoor                  //4x6 sized door
mmodel "steve_e/doors/greydoor/greydoor_150     //6x8 sized door
