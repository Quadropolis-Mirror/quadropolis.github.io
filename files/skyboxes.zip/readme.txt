Thank you for downloading SkiingPenguins' Skybox pack.
This "Pack" includes SkiingPenguins' Serenity and Trouble skyboxes.
If you use any of my skyboxes, please give me credit.
to use these skyboxes, please type "/loadsky penguins/trouble" or "/loadsky penguins/serenity" (without the quotes)
SkiingPenguins

February 7th, 2009