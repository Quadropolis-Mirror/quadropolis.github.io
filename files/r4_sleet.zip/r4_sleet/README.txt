"" r4_sleet - From R4zor. "" Completed 21/3/08.

- Theme: A mine area covered in snow. -

Please Note: This is not a ctf map. From the size of the map, I gather it will (if is) be used for Last Swiss 
Standing, One shot One Kill (/team), or deathmatch (/team).

- Skybox created by Shadow. Download from "http://quadropolis.us/node/301" -

- Some custom mapmodels in the map are made by Toca. Download Toca's mapmodels from 
"http://www.quadropolis.us/node/1181" -
Please Note: Though it will not disrupt gameplay as the cameras are well above ground level, if you do not have
the cfg/toca's mapmodels, this may cause confusing when jumping through the "security camera that isnt there".
The other models are out of reach of players, so it will not disrupt gameplay.

- To install:
  -Place cfg and cgz into assaultcube/packages/maps
  -Place the "shadow" folder into packages/textures/skymaps

- Another thanks to Shadow and Toca.

~ R4zor

Hope you enjoy the map!