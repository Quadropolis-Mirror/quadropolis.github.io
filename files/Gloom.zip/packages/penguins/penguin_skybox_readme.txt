All skyboxes created by SkiingPenguins use the CC-BY-SA 3.0 license.
License: Creative Commons Attribution-Share Alike 3.0
License URL: http://creativecommons.org/licenses/by-sa/3.0/
Notes: Originally created for the first person shooter Cube 2: Sauerbraten.
Notes: This Readme MUST be included woth all skybox images.
--Gloom Skybox