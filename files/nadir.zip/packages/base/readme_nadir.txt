Nadir by {QS}Mayhem

Description:
SVN March 21, 2009
WIP
3 large rooms connected with corridors at different levels.

Files:
nadir.cfg  // configuration
nadir.ogz  // map file
nadir.png  // loading image
nadirtitle.png  // title screenshot
readme_nadir.txt  // duh

Creative Commons (BY-NC)