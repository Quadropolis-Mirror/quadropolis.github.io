Gyptek

    /\
   /  \
  /----\
 /      \
/        \ n egyptian themed map. Created by !-!OOD, Razor, happy_sheep, polosson and Calinou (FM clan). Packaged by Calinou.

Description : Small egyptian-themed map for 1on1.

Tip : The healthboost is under the jumppad ;-)


