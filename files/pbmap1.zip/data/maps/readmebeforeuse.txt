pbmap1 by 00Hugo00

To launch the map, type :

/map pbmap1



Please use good gamemode, map only for paintball

Compatible with :

STF, CTF