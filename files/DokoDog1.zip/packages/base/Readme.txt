Map By DokoDog

Extract the files to C:\Program Files\Sauerbraten\packages\base

All right reserved. 2009 Doko