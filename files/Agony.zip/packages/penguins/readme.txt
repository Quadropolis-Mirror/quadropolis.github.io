Author: SkiingPenguins
Copyright: Creative Commons (BY-NC-ND) [Creative Commons Attribution-Noncommercial-No Derivative]
Author's Note: This Skybox may be used in all Cube related engines.
Author's Note2: YOU MAY NOT PASS THIS WORK ON AS YOUR OWN. YOU MUST INCLUDE THIS FILE WITH THE FILES LISTED ABOVE. YOU MUST GIVE ALL CREDIT TO "SkiingPenguins" WHEN USING THIS SKYBOX.
Author's Note3: you may not edit these files in any other way without written permission from the author.