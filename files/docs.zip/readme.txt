 ___________________________________
|              D.O.C.S              |
|____________Space Colony___________|

 a singleplayer map for sauerbraten
  made by Kraid and Brindley|Ubuntu



_______________________
-How to install
_______________________

1.extract the "packages"-folder into
  your sauerbraten-folder.
  For example: 
  C:/programm files/sauerbraten
  ---Nothing will be overwritten!---
2.now start sauerbraten and type:
  /sp docs
3.Its done. Have fun!


_______________________
-Story
_______________________

Jear 4075
You are Stan, an human which Quest
is to defeat the evil aliens who
conquered the D.O.C.S Space Colony.
Mission Objectives:
-Get in the Engine Room
-Turn off the engines
-Get into the Bridge
-Kill the master alien
-escape with the Stargate


_______________________
-Copyright
_______________________

Copyrights of the background music
by Junebug


_______________________
-Contact
_______________________

e-mail: kraid07@web.de
        JunebugTD7@aol.com
homepages: www.nintendo-freaks.de.gg
           www.dcx-clan.dreipage.de


_______________________
-Special Thanks to
_______________________

player:
 
Skyrail
Junebug
Thyrelious

websites:
http://www.electronicsounds.com/
http://www.sixdogstudios.com/
http://www.quadropolis.us/
