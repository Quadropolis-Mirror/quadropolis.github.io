//
// C++ Implementation: cubex_botmanager
//
// Description: Specific botmanager for Cube
//
//
// Author: Rick <rickhelmus@gmail.com>, (C) 2005
//

#include "../cube.h"

#ifdef VANILLA_CUBE

CCubeBotManager BotManager;

extern int maxclients;

// CCubeBotManager class begin

void CCubeBotManager::Init()
{
    LoadBotTeamsFile();
    CBotManager::Init();
}

dynent *CCubeBotManager::CreateBot(char *team, char *skill, char *name)
{
    dynent *b = CBotManager::CreateBot();
    if (!b) return NULL;
    
    CCubeBot *pBot = new CCubeBot;
    pBot->CreateInit(b, name, team, skill);
    b->pBot = pBot;
    
    return b;
}

void CCubeBotManager::EndMap()
{
    // Remove all bots
    loopv(bots)
    {             
        if (!bots[i])
            continue;

        if (ishost()) // Store bots so they can be re-added after map change
        {
            if (bots[i]->pBot && bots[i]->name[0] && bots[i]->team[0])
            {
                CStoredBot *pStoredBot = new CStoredBot(bots[i]->name, bots[i]->team, bots[i]->pBot->m_sSkillNr);
                m_StoredBots.AddNode(pStoredBot);
            }
            delete bots[i]->pBot;
        }
        
        bots[i]->pBot = NULL;
        zapdynent(bots[i]);
    }
    bots.setsize(0);
    m_fReAddBotDelay = lastmillis + 2500;
    CBotManager::EndMap();
}

void CCubeBotManager::RenderBots()
{
    static bool drawblue;
    
    loopv(bots)
    {
        if (bots[i] && (bots[i] != m_pBotToView))
        {
            drawblue = (m_sp || isteam(player1->team, bots[i]->team));
            renderclient(bots[i], drawblue, "monster/ogro", false, 1.0f);
        }
    }
}

void CCubeBotManager::LoadBotTeamsFile()
{
    if (!ishost())
        return;
        
    // Init bot teams array first
    for (int i=0;i<20;i++)
        strcpy(m_szBotTeams[i], "b0ts");
    
    m_sBotTeamCount = 0;
    
    // Load bot file
    char szNameFileName[256];
    MakeBotFileName("bot_teams.txt", NULL, NULL, szNameFileName);
    FILE *fp = fopen(szNameFileName, "r");
    char szNameBuffer[256];
    int iIndex, iStrIndex;
    
    if (!fp)
    {
        conoutf("Warning: Couldn't load bot teams file");
        return;
    }
    
    while ((m_sBotTeamCount < 20) && (fgets(szNameBuffer, 80, fp) != NULL))
    {
        short length = strlen(szNameBuffer);

        if (szNameBuffer[length-1] == '\n')
        {
            szNameBuffer[length-1] = 0;  // remove '\n'
            length--;
        }

        iStrIndex = 0;
        while (iStrIndex < length)
        {
            if ((szNameBuffer[iStrIndex] < ' ') || (szNameBuffer[iStrIndex] > '~') ||
                (szNameBuffer[iStrIndex] == '"'))
            {
                for (iIndex=iStrIndex; iIndex < length; iIndex++)
                    szNameBuffer[iIndex] = szNameBuffer[iIndex+1];
            }
 
            iStrIndex++;
        }

        if (szNameBuffer[0] != 0)
        {
            strn0cpy(m_szBotTeams[m_sBotTeamCount], szNameBuffer, 5);
            m_sBotTeamCount++;
        }
    }
    fclose(fp);
}

char *CCubeBotManager::GetBotTeam()
{
    char *szOutput = NULL;
    TMultiChoice<char *> BotTeamChoices;
    short ChoiceVal;
    
    for(int j=0;j<m_sBotTeamCount;j++)
    {
        ChoiceVal = 50;
        /* UNDONE?
        loopv(players)
        {
            if (players[i] && (!strcasecmp(players[i]->name, m_szBotNames[j])))
                ChoiceVal -= 10;
        }
        
        loopv(bots)
        {
            if (bots[i] && (!strcasecmp(bots[i]->name, m_szBotNames[j])))
                ChoiceVal -= 10;
        }
        
        if (!strcasecmp(player1->name, m_szBotNames[j]))
            ChoiceVal -= 10;
            
        if (ChoiceVal <= 0)
            ChoiceVal = 1;*/
        
        BotTeamChoices.Insert(m_szBotTeams[j], ChoiceVal);
    }
    
    // Couldn't find a selection?
    if (!BotTeamChoices.GetSelection(szOutput))
        szOutput = "b0t";
    
    return szOutput;
}

void CCubeBotManager::PickNextTrigger()
{
    if (!ishost()) return;
    
    short lowest = -1;
    bool found0 = false; // True if found a trigger with nr 0
    
    loopv(ents)
    {
        entity &e = ents[i];
        
        if ((e.type != CARROT) || !e.spawned)
            continue;
        
        if (OUTBORD(e.x, e.y)) continue;
        
        vec o = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };

        node_s *pWptNearEnt = NULL;
        
        pWptNearEnt = WaypointClass.GetNearestTriggerWaypoint(o, 2.0f);
        
        if (pWptNearEnt)
        {
            if ((pWptNearEnt->sTriggerNr > 0) &&
                ((pWptNearEnt->sTriggerNr < lowest) || (lowest == -1)))
                lowest = pWptNearEnt->sTriggerNr;
            if (pWptNearEnt->sTriggerNr == 0) found0 = true;
        }
    }
    
    if ((lowest == -1) && found0) lowest = 0;
    
    if (lowest != -1)
        m_sCurrentTriggerNr = lowest;
}

// CCubeBotManager class end

void addbot(char *arg1, char *arg2, char *arg3)
{
    if (ishost())
    {
        conoutf("Creating bot...\n");

        short num = 0;
        loopv(bots) if (bots[i]) num++;
        if ((num >= getvar("maxbots")) || (num >= (maxclients-1)))
        {
            conoutf("Cannot create bot: max reached");
            return;
        }

        dynent *b = BotManager.CreateBot(arg1, arg2, arg3);
        if (b)
            conoutf("connected: %s", b->name);
        else
            return;
            
        // Increase amount of monsters in dmsp mode...:)
        if (m_dmsp)
        {
            monstercountgrow();
        }        
    }
    else if (clienthost)
    {
       char team[32], name[32];
       int skill = -1;

       team[0] = name[0] = 0;
        
       if (arg1 && arg1[0]) strcpy(team, arg1);
       if (arg3 && arg3[0]) strcpy(name, arg3);
       if (arg2 && arg2[0])
       {
          if (!strcasecmp(arg2, "best")) skill = 0;
          else if (!strcasecmp(arg2, "good")) skill = 1;
          else if (!strcasecmp(arg2, "medium")) skill = 2;
          else if (!strcasecmp(arg2, "worse")) skill = 3;
          else if (!strcasecmp(arg2, "bad")) skill = 4;
       }
        
       ENetPacket *packet = enet_packet_create(NULL, MAXTRANS, ENET_PACKET_FLAG_RELIABLE);
       uchar *start = packet->data;
       uchar *p = start+2;
       putint(p, SV_BOTCOMMAND);
       putint(p, int(COMMAND_ADDBOT)); // Bot command type
       putint(p, 1); // Bot count
       putint(p, skill); // Bot skill
       sendstring(team, p); // Bot team
       sendstring(name, p); // Bot name
       *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
       enet_packet_resize(packet, p-start);
       sendpackettoserv(packet);
    }
}

COMMAND(addbot, ARG_3STR);

void addnbot(char *arg1, char *arg2, char *arg3)
{
    if (!arg1 || !arg1[0]) return;
    
    int i = atoi(arg1);
    
    if (ishost() || (i==1))
    {
       while(i > 0)
        {
            addbot(arg2, arg3, NULL);
            i--;
        }
    }
    else if (clienthost)
    {
        char team[32];
        int skill = -1;
        
        team[0] = 0;
        
        if (arg2 && arg2[0]) strcpy(team, arg2);
//        if (arg4 && arg4[0]) strcpy(name, arg4);
        if (arg3 && arg3[0])
        {
            if (!strcasecmp(arg2, "best")) skill = 0;
            else if (!strcasecmp(arg2, "good")) skill = 1;
            else if (!strcasecmp(arg2, "medium")) skill = 2;
            else if (!strcasecmp(arg2, "worse")) skill = 3;
            else if (!strcasecmp(arg2, "bad")) skill = 4;
        }
        
        ENetPacket *packet = enet_packet_create(NULL, MAXTRANS, ENET_PACKET_FLAG_RELIABLE);
        uchar *start = packet->data;
        uchar *p = start+2;
        putint(p, SV_BOTCOMMAND);
        putint(p, int(COMMAND_ADDBOT)); // Bot command type
        putint(p, i); // Bot count
        putint(p, skill); // Bot skill
        sendstring(team, p); // Bot team
        *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
        enet_packet_resize(packet, p-start);
        sendpackettoserv(packet);
    }    
}

COMMAND(addnbot, ARG_3STR);

#ifndef RELEASE_BUILD

void drawbeamtocarrots()
{
    loopv(ents)
    {
        entity &e = ents[i];
        vec o = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
        if ((e.type != CARROT) || !e.spawned) continue;
        particle_trail(1, 500, player1->o, o);
    }
}

COMMAND(drawbeamtocarrots, ARG_NONE);

void drawbeamtoteleporters()
{
    loopv(ents)
    {
        entity &e = ents[i];
        vec o = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
        if (e.type != TELEPORT) continue;
        particle_trail(1, 500, player1->o, o);
    }
}

COMMAND(drawbeamtoteleporters, ARG_NONE);

#endif

#endif
