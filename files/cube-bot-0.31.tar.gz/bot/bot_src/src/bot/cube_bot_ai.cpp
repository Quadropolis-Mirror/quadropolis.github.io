//
// C++ Implementation: cube_bot_ai
//
// Description: The AI part of the bot for cube is here(navigation, shooting etc)
//
//
// Author:  <rickhelmus@gmail.com>
//



#include "../cube.h"

#ifdef VANILLA_CUBE

weaponinfo_s WeaponInfoTable[MAX_WEAPONS] =
{
     // FIST
     { TYPE_MELEE, 0.0f, 3.5f, 0.0f, 5.0f, 1 },
     // SHOTGUN
     { TYPE_SHOTGUN, 5.0f, 12.0f, 0.0f, 50.0f, 4 },
     // CHAINGUN
     { TYPE_AUTO, 10.0f, 20.0f, 0.0f, 100.0f, 10 },
     // ROCKETLAUNCHER
     { TYPE_ROCKET, 15.0f, 25.0f, 10.0f, 70.0f, 3 },
     // RIFLE
     { TYPE_SNIPER, 12.0f, 25.0f, 0.0f, 100.0f, 4 }
};

// Code of CCubeBot - Start
    
bool CCubeBot::ChoosePreferredWeapon()
{
     if (CBot::ChoosePreferredWeapon())
          return true;
     else
          return SelectGun(GUN_FIST);
}
     
bool CCubeBot::FindEnemy()
{
     // UNDONE: Enemies are now only scored on their distance
    float flDist;
     if (m_pMyEnt->enemy) // Bot already has an enemy 
     {
          // Check if the enemy is still in game
          bool found = IsInGame(m_pMyEnt->enemy);
          
          // Check if the enemy is still ingame, still alive, not joined my team and is visible
          if (found && !isteam(m_pMyEnt->team, m_pMyEnt->enemy->team))
          {
               flDist = GetDistance(m_pMyEnt->enemy->o);
               if ((m_pMyEnt->enemy->state == CS_ALIVE) && (IsVisible(m_pMyEnt->enemy)))
                    return true;
               else
                    m_pPrevEnemy = m_pMyEnt->enemy;
          }
          else
               m_pMyEnt->enemy = NULL;               
     }
     
     if (m_iEnemySearchDelay > lastmillis) return (m_pMyEnt->enemy!=NULL);
     
     m_pMyEnt->enemy = NULL;
          
     // Add enemy searchy delay
     float MinDelay = m_pBotSkill->flMinEnemySearchDelay;
     float MaxDelay = m_pBotSkill->flMaxEnemySearchDelay;
     m_iEnemySearchDelay = lastmillis + int(RandomFloat(MinDelay, MaxDelay) * 1000.0f);
     
     dynent *pNewEnemy = NULL, *d = NULL;
     float flNearestDist = 99999.9f;
     short EnemyVal, BestEnemyVal = -100;
     
     // search for only for monsters when SP mode
     if (m_sp)
     {
          loopv(monsters)
          {
               d = monsters[i]; // Handy shortcut
                        
               if (d->state != CS_ALIVE)
                    continue;
          
               // Check if the enemy is visible
               if(!IsInFOV(d) || !IsVisible(d))
                    continue;
          
               flDist = GetDistance(d->o);
                   
               EnemyVal = ScoreEnemy(d, flDist, flNearestDist);
          
               if (flDist < flNearestDist)
                    flNearestDist = flDist;
               
               if (EnemyVal > BestEnemyVal)
               {
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
               }
          }
     }
     else
     {
          // First loop through all players
          loopv(players)
          {
               d = players[i]; // Handy shortcut
          
               if (!d || isteam(d->team, m_pMyEnt->team) || (d->state != CS_ALIVE))
                    continue;
          
               // Check if the enemy is visible
               if(!IsInFOV(d) || !IsVisible(d))
                    continue;
          
               flDist = GetDistance(d->o);

               EnemyVal = ScoreEnemy(d, flDist, flNearestDist);
          
               if (flDist < flNearestDist)
                    flNearestDist = flDist;
               
               if (EnemyVal > BestEnemyVal)
               {
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
               }
          }
          
          // Then loop through all bots
          loopvj(bots)
          {
               d = bots[j]; // Handy shortcut
          
               if (d == m_pMyEnt)
                    continue;
               
               if (!d || isteam(d->team, m_pMyEnt->team) || (d->state != CS_ALIVE))
                    continue;
          
               // Check if the enemy is visible
               if(!IsInFOV(d) || !IsVisible(d))
                    continue;
          
               flDist = GetDistance(d->o);

               EnemyVal = ScoreEnemy(d, flDist, flNearestDist);
          
               if (flDist < flNearestDist)
                    flNearestDist = flDist;
               
               if (EnemyVal > BestEnemyVal)
               {
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
               }
          }
     
          // Then examine the local player
          if (player1 && !isteam(player1->team, m_pMyEnt->team) &&
              (player1->state == CS_ALIVE))
          {
               // Check if the enemy is visible
               if(IsInFOV(player1) && IsVisible(player1))
               {
                    flDist = GetDistance(player1->o);
                    EnemyVal = ScoreEnemy(player1, flDist, flNearestDist);
          
                    if (flDist < flNearestDist)
                        flNearestDist = flDist;
               
                    if (EnemyVal > BestEnemyVal)
                    {
                        pNewEnemy = player1;
                        BestEnemyVal = EnemyVal;
                    }
               }
          }    
     }
          
     if (pNewEnemy)
     {
          if (!m_pMyEnt->enemy) // Add shoot delay if new enemy is found
          {
               float flMinShootDelay = m_pBotSkill->flMinAttackDelay;
               float flMaxShootDelay = m_pBotSkill->flMaxAttackDelay;
               
               m_iShootDelay = lastmillis + int(RandomFloat(flMinShootDelay,
                                                flMaxShootDelay) * 1000.0f);
          }
     
          if ((m_pMyEnt->enemy != pNewEnemy) && m_pMyEnt->enemy)
               m_pPrevEnemy = m_pMyEnt->enemy;
               
          m_pMyEnt->enemy = pNewEnemy;          
          return true;
     }

     return false;
}

bool CCubeBot::CheckHunt(void)
{
     if (!BotManager.BotsShoot()) return false;
     
     if (m_pHuntTarget) // Bot already has an enemy to hunt
     {
          // Check if the enemy is still in game
          bool found = IsInGame(m_pHuntTarget);
          
          // Check if the enemy is still ingame, still alive, not joined my team and is visible
          if (found && !isteam(m_pMyEnt->team, m_pHuntTarget->team))
          {
               if ((m_pHuntTarget->state == CS_ALIVE) && IsReachable(m_vHuntLocation))
                    return true;
          }
          else     
               m_pHuntTarget = NULL;               
     }
     
     if (m_iHuntDelay > lastmillis) return (m_pHuntTarget!=NULL);
     
     if (!vis(m_vHuntLocation, g_vecZero))
          m_vPrevHuntLocation = m_vHuntLocation;
          
     m_pHuntTarget = NULL;
     m_vHuntLocation = g_vecZero;
          
     // Add enemy hunt search delay
     m_iHuntDelay = lastmillis + 1500;
          
     dynent *pNewEnemy = NULL, *d = NULL;
     float flDist, flNearestDist = 99999.9f, flNearestOldPosDistToEnemy = 99999.9f;
     float flNearestOldPosDistToBot = 99999.9f;
     short EnemyVal, BestEnemyVal = -100;
     vec BestOldPos;
     
     // search only for monsters when SP mode
     if (m_sp)
     {
          loopv(monsters)
          {
               d = monsters[i]; // Handy shortcut
                        
               if (d->state != CS_ALIVE)
                    continue;
                   
               flDist = GetDistance(d->o);
               
               if (flDist > 250.0f) continue;
               
               EnemyVal = 1;
          
               if (flDist < flNearestDist)
               {
                    EnemyVal+=2;
                    flNearestDist = flDist;
               }
               
               if (d == m_pPrevEnemy)
                    EnemyVal+=2;
                    
               if (EnemyVal < BestEnemyVal) continue;
               
               vec bestfromenemy = g_vecZero, bestfrombot = g_vecZero;
               flNearestOldPosDistToEnemy = flNearestOldPosDistToBot = 9999.9f;
               
			   int j;

               // Check previous locations of enemy
               for (j=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(d->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                    if (vis(d->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                    vec v = d->PrevLocations.prevloc[j];
                    
                    flDist = GetDistance(d->o, v);
                    
                    if ((flDist < flNearestOldPosDistToBot) && IsReachable(v))
                    {
                         flNearestOldPosDistToEnemy = flDist;
                         bestfromenemy = v;
                    }
               }

               // Check previous locations of bot hisself
               for (j=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(m_pMyEnt->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                    if (vis(m_pMyEnt->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                    vec v = m_pMyEnt->PrevLocations.prevloc[j];
                    
                    flDist = GetDistance(v);
                    
                    if ((flDist < flNearestOldPosDistToBot) && ::IsVisible(d->o, v) &&
                         IsReachable(v))
                    {
                         flNearestOldPosDistToBot = flDist;
                         bestfrombot = v;
                    }
               }
                                             
               if (!vis(bestfromenemy, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfromenemy;                   
               }
               else if (!vis(bestfrombot, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfrombot;
               }               
          }
     }
     else
     {
          // First loop through all players
          loopv(players)
          {
               d = players[i]; // Handy shortcut
          
               if (!d || isteam(d->team, m_pMyEnt->team) || (d->state != CS_ALIVE))
                    continue;
          
               flDist = GetDistance(d->o);
               
               if (flDist > 250.0f) continue;
               
               EnemyVal = 1;
          
               if (flDist < flNearestDist)
               {
                    EnemyVal+=2;
                    flNearestDist = flDist;
               }
               
               if (d == m_pPrevEnemy)
                    EnemyVal+=2;
                    
               if (EnemyVal < BestEnemyVal) continue;
               
               vec bestfromenemy = g_vecZero, bestfrombot = g_vecZero;
               flNearestOldPosDistToEnemy = flNearestOldPosDistToBot = 9999.9f;
               
			   int j;

               // Check previous locations of enemy
               for (j=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(d->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                    if (vis(d->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                    vec v = d->PrevLocations.prevloc[j];
                    
                    flDist = GetDistance(d->o, v);
                    
                    if ((flDist < flNearestOldPosDistToEnemy) && IsReachable(v))
                    {
                         flNearestOldPosDistToEnemy = flDist;
                         bestfromenemy = v;
                    }
               }
               
               // Check previous locations of bot hisself
               for (j=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(m_pMyEnt->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                    if (vis(m_pMyEnt->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                    vec v = m_pMyEnt->PrevLocations.prevloc[j];
                    
                    flDist = GetDistance(v);
                    
                    if ((flDist < flNearestOldPosDistToBot) && ::IsVisible(d->o, v) &&
                         IsReachable(v))
                    {
                         flNearestOldPosDistToBot = flDist;
                         bestfrombot = v;
                    }
               }
                                             
               if (!vis(bestfromenemy, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfromenemy;                   
               }
               else if (!vis(bestfrombot, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfrombot;
               }               
          }
          
          // Then loop through all bots
          loopvj(bots)
          {
               d = bots[j]; // Handy shortcut
          
               if (d == m_pMyEnt)
                    continue;
               
               if (!d || isteam(d->team, m_pMyEnt->team) || (d->state != CS_ALIVE))
                    continue;
          
               flDist = GetDistance(d->o);
               
               if (flDist > 250.0f) continue;
               
               EnemyVal = 1;
          
               if (flDist < flNearestDist)
               {
                    EnemyVal+=2;
                    flNearestDist = flDist;
               }
               
               if (d == m_pPrevEnemy)
                    EnemyVal+=2;
                    
               if (EnemyVal < BestEnemyVal) continue;
               
               vec bestfromenemy = g_vecZero, bestfrombot = g_vecZero;
               flNearestOldPosDistToEnemy = flNearestOldPosDistToBot = 9999.9f;
               
			   int k;
               // Check previous locations of enemy
               for (k=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(d->PrevLocations.prevloc[k], m_vPrevHuntLocation)) continue;
                    if (vis(d->PrevLocations.prevloc[k], g_vecZero)) continue;
                    
                    vec v = d->PrevLocations.prevloc[k];
                    
                    flDist = GetDistance(d->o, v);
                    
                    if ((flDist < flNearestOldPosDistToEnemy) && IsReachable(v))
                    {
                         flNearestOldPosDistToEnemy = flDist;
                         bestfromenemy = v;
                    }
               }
               
               // Check previous locations of bot hisself
               for (k=0;j<MAX_STORED_LOCATIONS;j++)
               {
                    if (vis(m_pMyEnt->PrevLocations.prevloc[k], m_vPrevHuntLocation)) continue;
                    if (vis(m_pMyEnt->PrevLocations.prevloc[k], g_vecZero)) continue;
                    
                    vec v = m_pMyEnt->PrevLocations.prevloc[k];
                    
                    flDist = GetDistance(v);
                    
                    if ((flDist < flNearestOldPosDistToBot) && ::IsVisible(d->o, v) &&
                         IsReachable(v))
                    {
                         flNearestOldPosDistToBot = flDist;
                         bestfrombot = v;
                    }
               }
                                             
               if (!vis(bestfromenemy, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfromenemy;                   
               }
               else if (!vis(bestfrombot, g_vecZero))
               {                    
                    pNewEnemy = d;
                    BestEnemyVal = EnemyVal;
                    BestOldPos = bestfrombot;
               }               
          }
     
          // Then examine the local player
          if (player1 && !isteam(player1->team, m_pMyEnt->team) &&
              (player1->state == CS_ALIVE) && ((flDist = GetDistance(player1->o)) <= 250.0f))
          {
               d = player1;
               EnemyVal = 1;
          
               if (flDist < flNearestDist)
               {
                    EnemyVal+=2;
                    flNearestDist = flDist;
               }
               
               if (d == m_pPrevEnemy)
                    EnemyVal+=2;
                    
               if (EnemyVal >= BestEnemyVal)
               {    
                    BestEnemyVal = EnemyVal;           
                    vec bestfromenemy = g_vecZero, bestfrombot = g_vecZero;
                    flNearestOldPosDistToEnemy = flNearestOldPosDistToBot = 9999.9f;
               
					int j;
                    // Check previous locations of enemy
                    for (j=0;j<MAX_STORED_LOCATIONS;j++)
                    {
                         if (vis(d->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                         if (vis(d->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                         vec v = d->PrevLocations.prevloc[j];
                    
                         flDist = GetDistance(d->o, v);
                    
                         if ((flDist < flNearestOldPosDistToEnemy) && IsReachable(v))
                         {
                              flNearestOldPosDistToEnemy = flDist;
                              bestfromenemy = v;
                         }
                    }
               
                    // Check previous locations of bot hisself
                    for (j=0;j<MAX_STORED_LOCATIONS;j++)
                    {
                         if (vis(m_pMyEnt->PrevLocations.prevloc[j], m_vPrevHuntLocation)) continue;
                         if (vis(m_pMyEnt->PrevLocations.prevloc[j], g_vecZero)) continue;
                    
                         vec v = m_pMyEnt->PrevLocations.prevloc[j];
                    
                         flDist = GetDistance(v);
                    
                         if ((flDist < flNearestOldPosDistToBot) && ::IsVisible(d->o, v) &&
                             IsReachable(v))
                         {
                              flNearestOldPosDistToBot = flDist;
                              bestfrombot = v;
                         }
                    }
                                             
                    if (!vis(bestfromenemy, g_vecZero))
                    {                    
                         pNewEnemy = d;
                         BestEnemyVal = EnemyVal;
                         BestOldPos = bestfromenemy;                   
                    }
                    else if (!vis(bestfrombot, g_vecZero))
                    {                    
                         pNewEnemy = d;
                         BestEnemyVal = EnemyVal;
                         BestOldPos = bestfrombot;
                    }               
               }    
          }
     }
     
     if (pNewEnemy)
     {
          if (!m_pHuntTarget) // Add shoot delay if new enemy is found
          {
               float flMinShootDelay = m_pBotSkill->flMinAttackDelay;
               float flMaxShootDelay = m_pBotSkill->flMaxAttackDelay;
               
               m_iShootDelay = lastmillis + int(RandomFloat(flMinShootDelay,
                                                flMaxShootDelay) * 1000.0f);
          }
     
          if (!vis(m_vHuntLocation, g_vecZero))
               m_vPrevHuntLocation = m_vHuntLocation;
          
          m_pHuntTarget = pNewEnemy;
          m_vHuntLocation = BestOldPos;
          m_fPrevHuntDist = 0.0f;
          return true;
     }

     return false;
}

entity *CCubeBot::SearchForEnts(bool bUseWPs, float flRange, int type, float flMaxHeight)
{
     /* Entities are scored on the following things:
          - Visibility
          - For ammo: Need(ie has this bot much of this type or not)
          - distance
     */
     
     float flNearestDist = 9999, flDist;
     entity *pNewTargetEnt = NULL;
     bool CheckTeleporters = ((m_iCheckTeleporterDelay < lastmillis) &&
                              (WaypointClass.m_iWaypointCount < 1) &&
                              (m_pMyEnt->enemy == NULL) && !m_classicsp);
     bool CheckJumppads = ((m_iCheckJumppadsDelay < lastmillis) &&
                           (WaypointClass.m_iWaypointCount < 1) &&
                           (m_pMyEnt->enemy == NULL) && !m_classicsp);
     waypoint_s *pWptNearBot = NULL, *pBestWpt = NULL;
     short sScore, sHighestScore = 0;
     
     if (bUseWPs && m_classicsp) bUseWPs = false;

     if ((WaypointClass.m_iWaypointCount >= 1) && bUseWPs)
          pWptNearBot = GetNearestWaypoint(15.0f);

         
     loopv(ents)
     {
          sScore = 0;
          entity &e = ents[i];
          vec o = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
     
          if ((type != -1) && (e.type != type))
              continue;

          if ((e.type == TELEPORT) && !CheckTeleporters)
               continue;

          if ((e.type == JUMPPAD) && !CheckJumppads)
               continue;
          
          if ((!ents[i].spawned) && (e.type != TELEPORT) && (e.type != JUMPPAD)) continue;
          if (OUTBORD(e.x, e.y)) continue;
          
          if (InUnreachableList(&ents[i])) continue;
          
          bool bInteresting = false;
          short sAmmo = 0, sMaxAmmo = itemstats[e.type-I_SHELLS].max;
          
          switch(e.type)
          {
          case TELEPORT:
          case JUMPPAD:
               bInteresting = true;
               sAmmo = sMaxAmmo = -1;
               break;
          case I_SHELLS:
               bInteresting = (m_pMyEnt->ammo[1]<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->ammo[1];
               break;
          case I_BULLETS:
               bInteresting = (m_pMyEnt->ammo[2]<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->ammo[2];
               break;
          case I_ROCKETS:
               bInteresting = (m_pMyEnt->ammo[3]<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->ammo[3];
               break;
          case I_ROUNDS:
               bInteresting = (m_pMyEnt->ammo[4]<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->ammo[4];
               break;              
          case I_HEALTH:
          case I_BOOST:
               bInteresting = (m_pMyEnt->health<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->health;
               break;
          case I_GREENARMOUR:
               bInteresting = ((m_pMyEnt->armour<itemstats[e.type-I_SHELLS].max) &&
                               (m_pMyEnt->armourtype!=A_YELLOW || m_pMyEnt->armour<=66));
               sAmmo = m_pMyEnt->armour;
               break;
          case I_YELLOWARMOUR:
               bInteresting = (m_pMyEnt->armour<itemstats[e.type-I_SHELLS].max);
               sAmmo = m_pMyEnt->armour;
               break;
          case I_QUAD:
               bInteresting = (m_pMyEnt->quadmillis<itemstats[e.type-I_SHELLS].max);
               sAmmo = -1;
               break;
          }
              
          if (!bInteresting)
              continue; // Not an interesting item, skip
          
          // Score on ammo and need
          if (sAmmo == -1)
          {
               // This entity doesn't have/need ammo
               // Score on type instead
               switch(e.type)
               {
               case TELEPORT:
               case JUMPPAD:
                    sScore += 20;
                    break;
               case I_QUAD:
                    sScore += 60;
                    break;
               }
          }
          else
          {
               // Calculate current percentage of max ammo
               float percent = ((float)sAmmo / (float)sMaxAmmo) * 100.0f;
               if (percent > 100.0f) percent = 100.0f;
               sScore += ((100 - short(percent))/2);
          }
               
          flDist = GetDistance(o);
          
          if (flDist > flRange) continue;
          
          // Score on distance
          float f = flDist;
          if (f > 100.0f) f = 100.0f;
          sScore += ((100 - short(f)) / 2);
          
          waypoint_s *pWptNearEnt = NULL;
          // If this entity isn't visible check if there is a nearby waypoint
          if (!IsReachable(o, flMaxHeight))//(!IsVisible(o))
          {
               if ((e.type == TELEPORT) || (e.type == JUMPPAD)) continue;
               if (!pWptNearBot) continue;
               
               pWptNearEnt = GetNearestWaypoint(o, 15.0f);
                    
               if (!pWptNearEnt) continue;                              
          }
                                    
          // Score on visibility
          if (pWptNearEnt == NULL) // Ent is visible
               sScore += 30;
          else
               sScore += 15;
               
          if (sScore > sHighestScore)
          {
               // Found a valid wp near the bot and the ent,so...lets store it :)
               if (pWptNearEnt)
                    pBestWpt = pWptNearEnt;
               else
                    pBestWpt = NULL; // Best ent so far doesn't need any waypoints
               
               sHighestScore = sScore;
               flNearestDist = flDist;
               pNewTargetEnt = &ents[i];
          }
     }
     
     if (pNewTargetEnt)
     {
          if (pNewTargetEnt->type == JUMPPAD)
               m_iCheckJumppadsDelay = lastmillis + 3500;
          else if (pNewTargetEnt->type == TELEPORT)
               m_iCheckTeleporterDelay = lastmillis + 5000;
          
          // Need waypoints to reach it?
          if (pBestWpt)
          {
               ResetWaypointVars();
               SetCurrentWaypoint(pWptNearBot);
               SetCurrentGoalWaypoint(pBestWpt);
          }
               
          m_vGoal.x = pNewTargetEnt->x;
          m_vGoal.y = pNewTargetEnt->y;
          m_vGoal.z = S(pNewTargetEnt->x, pNewTargetEnt->y)->floor+player1->eyeheight;
     }
          
     return pNewTargetEnt;
} 

bool CCubeBot::HeadToTargetEnt()
{
    if (m_pTargetEnt)
    {
        vec o = { m_pTargetEnt->x, m_pTargetEnt->y, S(m_pTargetEnt->x, m_pTargetEnt->y)->floor+m_pMyEnt->eyeheight };

        if ((m_pTargetEnt->spawned || (m_pTargetEnt->type == TELEPORT) ||
            (m_pTargetEnt->type == JUMPPAD)) && (!UnderWater(m_pMyEnt->o) ||
            !UnderWater(o)))
        {
            bool bIsVisible = false;
            if (m_pCurrentGoalWaypoint)
            {
                if ((GetDistance(o) <= 20.0f) && IsReachable(o, 1.0f))
                    bIsVisible = true;
                else if (HeadToGoal())
                {
                    //debugbeam(m_pMyEnt->o, m_pCurrentWaypoint->pNode->v_origin);
                    //debugbeam(m_pMyEnt->o,
                    //            m_pCurrentGoalWaypoint->pNode->v_origin);
                    AddDebugText("Using WPs for ents");
                    return true;
                }
                else // Path failed, try again with other start waypoints
                {/* UNDONE?
                    // First check if current waypoint is outdated
                    waypoint_s *pWptNearBot = GetNearestWaypoint(15.0f), *pGoal = m_pCurrentGoalWaypoint, *pTmp;

                    if (pWptNearBot)
                    {
                        pTmp = m_pCurrentWaypoint;
                        ResetWaypointVars();
                        SetCurrentWaypoint(pWptNearBot);
                        SetCurrentGoalWaypoint(pGoal);

                        if ((pWptNearBot == pTmp) || !HeadToGoal())
                        {
                            // Find another start waypoint(ignoring current)
                            pTmp = pWptNearBot;
                            pWptNearBot = GetNearestWaypoint(15.0f, pTmp);

                            if (pWptNearBot)
                            {
                                ResetWaypointVars();
                                SetCurrentWaypoint(pWptNearBot);
                                SetCurrentGoalWaypoint(pGoal);

                                if (HeadToGoal()) return true;
                            }
                        }
                        else
                            return true;
                    }*/
                }
            }
            else
                bIsVisible = IsVisible(o);
                                   
            if (bIsVisible)
            {
                if (m_pCurrentWaypoint || m_pCurrentGoalWaypoint)
                {
                    condebug("ent is now visible");
                    ResetWaypointVars();
                }
                    
                float flHeightDiff = o.z - m_pMyEnt->o.z;
                bool bToHigh = false;
                if (Get2DDistance(o) <= 2.0f)
                {
                    if (flHeightDiff >= m_pMyEnt->aboveeye)
                    {
                        if (flHeightDiff <= JUMP_HEIGHT)
                        {
#ifndef RELEASE_BUILD                    
                            char sz[64];
                            sprintf(sz, "Ent z diff: %f", o.z-m_pMyEnt->o.z);
                            condebug(sz);
#endif                         
                            // Jump if close to ent and the ent is high
                            m_pMyEnt->jumpnext = true;
                        }
                        else
                            bToHigh = true;
                    }
                }
                    
                if (!bToHigh)
                {
                    if (vis(m_vSecondaryGoal, g_vecZero))
                        AimToVec(o);
                    else
                    {
                        if (m_iMoveTime < lastmillis)
                        {
                            m_iMoveTime = lastmillis + RandomLong(75, 125);
                            m_bAddMoveDir = false;
                            m_iMoveDir = GetDirection(GetViewAngles(), m_pMyEnt->o, o);
                        }
                        AimToVec(m_vSecondaryGoal);
                    }
                    return true;
                }
            }
        }
    }
     
    m_UnreachableEnts.PushNode(new unreachable_ent_s(m_pTargetEnt, lastmillis));

    return false;
}

bool CCubeBot::DoSPStuff()
{
    if (!m_classicsp) return false;

    if (!CheckJump() && CheckStuck())
    {
        // Don't check for triggers a while when stuck
        m_iCheckTriggersDelay = lastmillis + RandomLong(1000, 2000);
        return false;
    }

    if (m_pTargetEnt && (m_pTargetEnt->type == CARROT))
    {
        if (HeadToTargetEnt())
        {
            if (BotManager.BotsShoot() && FindEnemy(/*7.0f*/))
            {
                if (GetDistance(m_pMyEnt->enemy->o) < 7.0f)
                {
                    ResetEntGoal();
                    m_iCheckTriggersDelay = lastmillis + RandomLong(200, 500);
                    return false;
                }
                AddDebugText("has enemy");
                    
                // Shoot at enemy
                ShootEnemy();
                m_vSecondaryGoal = m_pMyEnt->enemy->o;
                
                if (m_bCalculatingAStarPath) DoCombatNav();
            }
            else
                m_vSecondaryGoal = g_vecZero;

            return true;
        }
        
        m_pTargetEnt = NULL;
        m_vGoal = m_vSecondaryGoal = g_vecZero;
        ResetWaypointVars();
        m_iCheckTriggersDelay = lastmillis + RandomLong(200, 500);
    }
          
    if (m_iCheckTriggersDelay > lastmillis)
        return false;
     
    m_iCheckTriggersDelay = lastmillis + RandomLong(100, 150);
     
    waypoint_s *pWptNearBot = NULL;
    waypoint_s *pBestWpt = NULL;
    entity *pNewTargetEnt = NULL;
    float flNearestDist = 9999.0f;
     
    if (WaypointClass.m_iWaypointCount >= 1)
        pWptNearBot = GetNearestWaypoint(15.0f);
          
    loopv(ents)
    {
        entity &e = ents[i];
          
        if (OUTBORD(e.x, e.y)) continue;
          
        vec o = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
     
        if ((e.type != CARROT) || !e.spawned)
            continue;
                       
        if (InUnreachableList(&ents[i])) continue;
          
        float flDist = GetDistance(o);
          
        if (flDist >= flNearestDist) continue;
          
        waypoint_s *pWptNearEnt = NULL;

        pWptNearEnt = GetNearestTriggerWaypoint(o, 2.0f);
                    
        if (!pWptNearEnt)
        {
            if (BotManager.m_sCurrentTriggerNr>0)
                continue;
            pWptNearEnt = GetNearestWaypoint(o, 15.0f);
        }
        else
        {
            if (BotManager.m_sCurrentTriggerNr != pWptNearEnt->pNode->sTriggerNr) continue;
        }
          
        // If this entity isn't visible check if there is a nearby waypoint
        if (!IsReachable(o, JUMP_HEIGHT))//(!IsVisible(o))
        {
            if (!pWptNearBot || !pWptNearEnt) continue;
                                             
            // Found a valid wp near the bot and the ent,so...lets store it :)
            pBestWpt = pWptNearEnt;
        }
        else
            pBestWpt = NULL; // Reset when a better ent found which doesn't need waypoints to reach it
                                    
        flNearestDist = flDist;
        pNewTargetEnt = &ents[i];
     }
     
     if (pNewTargetEnt)
     {
        // Need waypoints to reach it?
        if (pBestWpt)
        {
            ResetWaypointVars();
            SetCurrentWaypoint(pWptNearBot);
            SetCurrentGoalWaypoint(pBestWpt);
        }
               
        m_vGoal.x = pNewTargetEnt->x;
        m_vGoal.y = pNewTargetEnt->y;
        m_vGoal.z = S(pNewTargetEnt->x, pNewTargetEnt->y)->floor+m_pMyEnt->eyeheight;
        m_pTargetEnt = pNewTargetEnt;
          
        AimToVec(m_vGoal);
        return true;
    }
     
    return false;
}
    
// Code of CCubeBot - End

#endif
