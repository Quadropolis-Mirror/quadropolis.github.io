//
// C++ Implementation: bot
//
// Description: 
//
// Header specific for VANILLA CUBE
//
// Author:  Rick <rickhelmus@gmail.com>
//
//
//

#ifndef CUBE_BOT_H
#define CUBE_BOT_H

#ifdef VANILLA_CUBE

#define MAX_WEAPONS      5

class CCubeBot: public CBot
{
    void CheckQuad(int Time);     

public:
    friend class CBotManager;
    friend class CWaypointClass;
     
    virtual void CreateInit(dynent *d, char *name, char *team, char *skill);
    virtual void SendBotInfo(void);
    virtual void CheckItemPickup(void);
    virtual void PickUp(int n);
    virtual void AddItem(int i, int &v, int spawnsec);
     
    // AI Functions
    virtual bool FindEnemy(void);
    virtual bool ChoosePreferredWeapon(void);
    virtual bool CheckHunt(void);
    virtual entity *SearchForEnts(bool bUseWPs, float flRange=9999.0f, int type=-1,
                                  float flMaxHeight=JUMP_HEIGHT);
    virtual bool HeadToTargetEnt(void);
    virtual bool DoSPStuff(void);
             
    virtual void Spawn(void);
    virtual void Think(void);
    virtual void BotPain(int damage, dynent *d);

    virtual bool EntSpawns(int t) { return ((t!=TELEPORT) && (t!=JUMPPAD)); };
};

class CCubeBotManager: public CBotManager
{
protected:
    void LoadBotTeamsFile(void);
    virtual char *GetBotTeam(void);

    friend class CBot;
    friend class CCubeBot;
    
public:
    virtual ~CCubeBotManager(void) { };
    
    virtual void Init(void);
    virtual dynent *CreateBot(char *team, char *skill, char *name);
    virtual void EndMap(void);
    virtual void RenderBots(void);
    virtual void PickNextTrigger(void);
};

extern CCubeWaypointClass WaypointClass;
extern CCubeBotManager BotManager;

class CStoredBot // Used to store bots after mapchange, so that they can be readded
{
     char m_szName[32];
     char m_szTeam[32];
     char m_szModel[32];
     short m_sSkillNr;
     
public:

     CStoredBot(const char *name, const char *team, const short skill) : m_sSkillNr(skill)
          { strcpy(m_szName, name); strcpy(m_szTeam, team); };
     void ReAddBot(void) { BotManager.CreateBot(m_szTeam, SkillNrToSkillName(m_sSkillNr), m_szName); };
};

#endif

#endif
