//
// C++ Implementation: bot
//
// Description: Main bot code for Cube
//
// Main bot file
//
// Author:  Rick <rickhelmus@gmail.com>
//
//
//

#include "../cube.h"

#ifdef VANILLA_CUBE

extern ENetHost *clienthost;
extern vector<server_entity> sents;
extern int triggertime;
extern itemstat itemstats[];
extern void spawnstate(dynent *d);

//Cube Bot class begin

void CCubeBot::CreateInit(dynent *d, char *name, char *team, char *skill)
{
    CBot::CreateInit(d, name, skill);
    
    // Assign team
    if (team && *team)
        strn0cpy(d->team, team, 5);
    else
        strn0cpy(d->team, BotManager.GetBotTeam(), 5);
}

void CCubeBot::SendBotInfo()
{
     if(lastmillis-m_iLastBotUpdate<40) return;    // don't update faster than 25fps
     m_iLastBotUpdate = lastmillis;

     int x = (int)(m_pMyEnt->o.x*DMF);
     int y = (int)(m_pMyEnt->o.y*DMF);
     int z = (int)(m_pMyEnt->o.z*DMF);
     int yaw = (int)(m_pMyEnt->yaw*DAF);
     int pitch = (int)(m_pMyEnt->pitch*DAF);
     int roll = (int)(m_pMyEnt->roll*DAF);
     int velx = (int)(m_pMyEnt->vel.x*DVF);
     int vely = (int)(m_pMyEnt->vel.y*DVF);
     int velz = (int)(m_pMyEnt->vel.z*DVF);
     // pack rest in 1 byte: strafe:2, move:2, onfloor:1, state:3
     int moveflags = (m_pMyEnt->strafe&3) | ((m_pMyEnt->move&3)<<2) |
                                             (((int)m_pMyEnt->onfloor)<<4) |
                                              ((editmode ? CS_EDITING :
                                                m_pMyEnt->state)<<5);
       
     ENetPacket *packet = enet_packet_create (NULL, MAXTRANS, 0);
     uchar *start = packet->data;
     uchar *p = start+2;
        
     putint(p, SV_BOTUPDATE);
     putint(p, BotManager.GetBotIndex(m_pMyEnt));
     putint(p, x); // quantize coordinates to 1/16th of a cube, between 1 and 3 bytes
     putint(p, y);
     putint(p, z);
     putint(p, yaw);
     putint(p, pitch);
     putint(p, roll);
     putint(p, velx);     // quantize to 1/100, almost always 1 byte
     putint(p, vely);
     putint(p, velz);
     // pack rest in 1 byte: strafe:2, move:2, onfloor:1, state:3
     putint(p, moveflags);
     
     if(!m_bSendC2SInit)    // tell other clients who I am
     {
          packet->flags = ENET_PACKET_FLAG_RELIABLE;
          m_bSendC2SInit = true;
          putint(p, SV_ADDBOT);
          putint(p, BotManager.GetBotIndex(m_pMyEnt));
          sendstring(m_pMyEnt->name, p);
          sendstring(m_pMyEnt->team, p);
          putint(p, m_pMyEnt->lifesequence);
     };
     
 
     *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
     enet_packet_resize(packet, p-start);
     incomingdemodata(start, p-start, true);
     if(clienthost)
     {
          enet_host_broadcast(clienthost, 0, packet);
          enet_host_flush(clienthost);
     }
     else
          localclienttoserver(packet);
}

void CCubeBot::Think()
{
     CBot::Think();
     CheckQuad(curtime);
}

void CCubeBot::Spawn()
{
     // Init all bot variabeles
     CBot::Spawn();

     m_pMyEnt->eyeheight = 3.2f;
     m_pMyEnt->aboveeye = 0.7f;
     m_pMyEnt->radius = 1.1f;
         
     spawnplayer(m_pMyEnt);
     
     m_pMyEnt->targetyaw = m_pMyEnt->yaw = m_pMyEnt->targetpitch = m_pMyEnt->pitch = 0.0f;
     m_pMyEnt->move = 0;
     m_pMyEnt->enemy = NULL;
     m_pMyEnt->maxspeed = 22.0f;
     m_pMyEnt->health = 100;
     m_pMyEnt->armour = 50;
     m_pMyEnt->pitch = 0;
     m_pMyEnt->roll = 0;
     m_pMyEnt->state = CS_ALIVE;
     m_pMyEnt->anger = 0;
     m_pMyEnt->pBot = this;     
     loopi(NUMGUNS) m_pMyEnt->ammo[i] = 0;
     m_pMyEnt->ammo[GUN_FIST] = 1;
     if(m_noitems)
     {
          m_pMyEnt->gunselect = GUN_RIFLE;
          m_pMyEnt->armour = 0;
          if(m_noitemsrail)
          {
               m_pMyEnt->health = 1;
               m_pMyEnt->ammo[GUN_RIFLE] = 100;
          }
          else
          {
               if(gamemode==12) // eihrul's secret "instafist" mode
               {
                    m_pMyEnt->gunselect = GUN_FIST;
               }
               else
               {
                    m_pMyEnt->health = 256;
                    if(m_tarena)
                    {
                         int gun1 = rnd(4)+1;
                         botbaseammo(m_pMyEnt->gunselect = gun1, m_pMyEnt);
                         for(;;)
                         {
                              int gun2 = rnd(4)+1;
                              if(gun1!=gun2) { botbaseammo(gun2, m_pMyEnt); break; };
                         }
                    }
                    else if(m_arena)    // insta arena
                    {
                         m_pMyEnt->ammo[GUN_RIFLE] = 100;
                    }
                    else // efficiency
                    {
                         loopi(4) botbaseammo(i+1, m_pMyEnt);
                         m_pMyEnt->gunselect = GUN_CG;
                    }
                    m_pMyEnt->ammo[GUN_CG] /= 2;
               }
          }
     }
     else
     {
          m_pMyEnt->ammo[GUN_SG] = 5;
          SelectGun(GUN_SG);
     }
}

void CCubeBot::BotPain(int damage, dynent *d)
{
     if(m_pMyEnt->state!=CS_ALIVE || editmode || intermission) return;
     int ad = damage*(m_pMyEnt->armourtype+1)*20/100; // let armour absorb when possible
     if(ad>m_pMyEnt->armour) ad = m_pMyEnt->armour;
     m_pMyEnt->armour -= ad;
     damage -= ad;
     float droll = damage/0.5f;
     m_pMyEnt->roll += m_pMyEnt->roll>0 ? droll : (m_pMyEnt->roll<0 ? -droll : (rnd(2) ? droll : -droll));  // give player a kick depending on amount of damage
     if((m_pMyEnt->health -= damage)<=0)
     {
          if (player1 == d)
          {
               int frags;
               if(isteam(player1->team, m_pMyEnt->team))
               {
                    frags = -1;
                    conoutf("you fragged a teammate (%s)", m_pMyEnt->name);
               }
               else
               {
                    frags = 1;
                    conoutf("you fragged %s", m_pMyEnt->name);
               }
               addmsg(1, 2, SV_FRAGS, player1->frags += frags);
               addmsg(1, 4, SV_BOTDIED, BotManager.GetBotIndex(m_pMyEnt), -1, false);
          }
          else if (d->monsterstate)
               conoutf("%s got killed by %s", m_pMyEnt->name, d->name);
          else
          {                 
               int KillerIndex = -1;
         
               if (d == m_pMyEnt)
               {
                    conoutf("%s suicided", d->name);
                    KillerIndex = BotManager.GetBotIndex(d);
                    addmsg(1, 3, SV_BOTFRAGS, KillerIndex, --d->frags);
               }     
               else
               {     
                    if (d->bIsBot)
                    {
                         KillerIndex = BotManager.GetBotIndex(d);
                         addmsg(1, 3, SV_BOTFRAGS, KillerIndex, ++d->frags);             
                    }
                    else
                         loopv(players){ if (players[i] == d) { KillerIndex = i; break;} }
                  
                    if(isteam(m_pMyEnt->team, d->team))
                    {
                         conoutf("%s fragged his teammate (%s)", d->name, m_pMyEnt->name);
                    }
                    else
                    {
                         conoutf("%s fragged %s", d->name, m_pMyEnt->name);
                    }
               }
               addmsg(1, 4, SV_BOTDIED, BotManager.GetBotIndex(m_pMyEnt), KillerIndex,
                      d->bIsBot);
          }

          m_pMyEnt->lifesequence++;
          m_pMyEnt->deaths++;
          m_pMyEnt->attacking = false;
          m_pMyEnt->state = CS_DEAD;
          m_pMyEnt->pitch = 0;
          m_pMyEnt->roll = 60;
          playsound(S_DIE1+rnd(2), &m_pMyEnt->o);
          spawnstate(m_pMyEnt);
          m_pMyEnt->lastaction = lastmillis;
     }
     else
     {
          playsound(S_PAIN1+rnd(5), &m_pMyEnt->o);
     }
}

void CCubeBot::CheckItemPickup()
{
     if(editmode) return;
     loopv(ents)
     {
          entity &e = ents[i];
          if(e.type==NOTUSED) continue;
          if ((e.type != TELEPORT) && (e.type != JUMPPAD))
          {
               if (!e.spawned)
                    continue;
               if ((i < sents.length()) && (!sents[i].spawned))
                    continue;
          }
               
          if(OUTBORD(e.x, e.y)) continue;
          vec v = { e.x, e.y, S(e.x, e.y)->floor+m_pMyEnt->eyeheight };
          vdist(dist, t, m_pMyEnt->o, v);
          if(dist<(e.type==TELEPORT ? 4 : 2.5))
          {
               PickUp(i);
          }
     }
}

void CCubeBot::PickUp(int n)
{
    int np = 1;
    loopv(players) if(players[i] && (players[i]->state != CS_DEDHOST)) np++;
    loopvj(bots) if(bots[j]) np++;
    np = np<3 ? 4 : (np>4 ? 2 : 3); // spawn times are dependent on number of players
    int ammo = np*2;
    switch(ents[n].type)
    {
        case I_SHELLS:  AddItem(n, m_pMyEnt->ammo[1], ammo); break;
        case I_BULLETS: AddItem(n, m_pMyEnt->ammo[2], ammo); break;
        case I_ROCKETS: AddItem(n, m_pMyEnt->ammo[3], ammo); break;
        case I_ROUNDS:  AddItem(n, m_pMyEnt->ammo[4], ammo); break;
        case I_HEALTH:  AddItem(n, m_pMyEnt->health,  np*5); break;
        case I_BOOST:   AddItem(n, m_pMyEnt->health,  60);   break;

        case I_GREENARMOUR:
            // (100h/100g only absorbs 166 damage)
            if(m_pMyEnt->armourtype==A_YELLOW && m_pMyEnt->armour>66) break;
            AddItem(n, m_pMyEnt->armour, 20);
            break;

        case I_YELLOWARMOUR:
            AddItem(n, m_pMyEnt->armour, 20);
            break;

        case I_QUAD:
            AddItem(n, m_pMyEnt->quadmillis, 60);
            break;
            
        case CARROT:
            ents[n].spawned = false;
            triggertime = lastmillis;
            trigger(ents[n].attr1, ents[n].attr2, false);  // needs to go over server for multiplayer
            
            // HACK: Reset ent goal if bot was looking for this ent
            if (m_pTargetEnt == &ents[n])
            {
                ResetEntGoal();
                m_iCheckEntsDelay = lastmillis + RandomLong(5000, 10000);               
            }
            
            BotManager.PickNextTrigger();
            
            break;

        case TELEPORT:
        {
            static int lastteleport = 0;
            if(lastmillis-lastteleport<500) break;
            lastteleport = lastmillis;
            teleport(n, m_pMyEnt);
            
            // HACK: Reset ent goal if bot was looking for this ent
            if (m_pTargetEnt == &ents[n])
            {
               ResetEntGoal();
               m_iCheckEntsDelay = lastmillis + RandomLong(5000, 10000);
            }
            /*else if (m_pCurrentWaypoint && (m_pCurrentWaypoint->pNode->iFlags & W_FL_TELEPORT))
            {
                vec v = { ents[n].x, ents[n].y, ents[n].z };
                if (vis(m_pCurrentWaypoint->pNode->v_origin, v))
                    m_pCurrentWaypoint = NULL;
            }*/
            break;
        };
        
        case JUMPPAD:
        {
            if(lastmillis-m_iLastJumpPad<300) break;
            m_iLastJumpPad = lastmillis;
            vec v = { (int)(char)ents[n].attr3/10.0f, (int)(char)ents[n].attr2/10.0f, ents[n].attr1/10.0f };
            vadd(m_pMyEnt->vel, v);
            botplaysound(S_JUMPPAD, m_pMyEnt);

            // HACK: Reset ent goal if bot was looking for this ent
            if (m_pTargetEnt == &ents[n])
            {
               ResetEntGoal();
               m_iCheckEntsDelay = lastmillis + RandomLong(5000, 10000);
            }        
                                    
            break;
        };
    };
};

void CCubeBot::AddItem(int i, int &v, int spawnsec)
{
     if((i>=sents.length()) || (!sents[i].spawned))
          return;

     if(v>=itemstats[ents[i].type-I_SHELLS].max)  // don't pick up if not needed
          return;
             
     itemstat &is = itemstats[ents[i].type-I_SHELLS];
     ents[i].spawned = false;
     v += is.add;
     if(v>is.max) v = is.max;
     botplaysound(is.sound, m_pMyEnt);
     sents[i].spawned = false;
     sents[i].spawnsecs = spawnsec;
        
     addmsg(1, 4, SV_ITEMPICKUP, i, m_classicsp ? 100000 : spawnsec, false);
        
     // HACK: Reset ent goal if bot was looking for this ent
     if (m_pTargetEnt == &ents[i])
     {
          ResetEntGoal();
          m_iCheckEntsDelay = lastmillis + RandomLong(5000, 10000);
     }        
}

void CCubeBot::CheckQuad(int Time)
{
    if(m_pMyEnt->quadmillis && (m_pMyEnt->quadmillis -= Time)<0)
    {
        m_pMyEnt->quadmillis = 0;
        botplaysound(S_PUPOUT, m_pMyEnt);
        //conoutf("quad damage is over");
    }
}
          
// Cube Bot class end

#endif
