//
// C++ Interface: bot_types
//
// Description: Mod specifc structs, enums etc(mainly stuff that has to be defined before bot classes)
//
//
// Author: Rick <rickhelmus@gmail.com>, (C) 2005
//

#ifndef CUBE_BOT_TYPES_H
#define CUBE_BOT_TYPES_H

enum ECurrentBotState
{
     STATE_ENEMY, // Bot has an enemy
     STATE_HUNT, // Bot is hunting an enemy
     STATE_ENT, // Bot is heading to an entity
     STATE_SP, // Bot is doing sp specific stuff
     STATE_NORMAL // Bot is doing normal navaigation
};

#endif
