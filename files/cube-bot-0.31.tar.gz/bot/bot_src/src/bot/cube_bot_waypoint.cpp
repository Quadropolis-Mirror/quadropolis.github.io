//
// C++ Implementation: cubex_bot_waypoint
//
// Description: Waypoint code specific for CubeX
//
//
// Author: Rick Helmus <rickhelmus@gmail.com>, (C) 2005
//

#include "../cube.h"

#ifdef VANILLA_CUBE

CCubeWaypointClass WaypointClass;

// Code of CCubeWaypointClass - Begin

void CCubeWaypointClass::StartFlood()
{
     // Add wps at triggers and teleporters and their destination
     loopv(ents)
     {
          entity &e = ents[i];
          
          if (OUTBORD(e.x, e.y)) continue;

          if (e.type == TELEPORT)
          {
               vec telepos = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight }, teledestpos = g_vecZero;
          
               // Find the teleport destination          
               int n = -1, tag = e.attr1, beenhere = -1;
               for(;;)
               {
                    n = findentity(TELEDEST, n+1);
                    if(n==beenhere || n<0) { conoutf("no teleport destination for tag %d", tag); break; };
                    if(beenhere<0) beenhere = n;
                    if(ents[n].attr2==tag)
                    {
                         teledestpos.x = ents[n].x;
                         teledestpos.y = ents[n].y;
                         teledestpos.z = S(ents[n].x, ents[n].y)->floor+player1->eyeheight;
                         break;
                    }
               }
          
               if (vis(teledestpos, g_vecZero)) continue;
          
               int flags = (W_FL_FLOOD | W_FL_TELEPORT);
               if (S((int)telepos.x, (int)telepos.y)->tag) flags |= W_FL_INTAG;
               
               // Add waypoint at teleporter and teleport destination
               node_s *pWP = new node_s(telepos, flags, 0);
               
               short i, j;
               GetNodeIndexes(telepos, &i, &j);
               m_Waypoints[i][j].PushNode(pWP);
               BotManager.AddWaypoint(pWP);
               m_iFloodSize += sizeof(node_s);               
               m_iWaypointCount++;
          
               flags = (W_FL_FLOOD | W_FL_TELEPORTDEST);
               if (S((int)teledestpos.x, (int)teledestpos.y)->tag) flags |= W_FL_INTAG;

               node_s *pWP2 = new node_s(teledestpos, flags, 0);
          
               GetNodeIndexes(teledestpos, &i, &j);
               m_Waypoints[i][j].PushNode(pWP2);
               BotManager.AddWaypoint(pWP2);
               m_iFloodSize += sizeof(node_s);               
               m_iWaypointCount++;
          
               // Connect the teleporter waypoint with the teleport-destination waypoint(1 way)
               AddPath(pWP, pWP2);
               
               // Connect with other nearby nodes
               ConnectFloodWP(pWP);               
          }
          else if (e.type == CARROT)
          {
               vec pos = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
               
               int flags = (W_FL_FLOOD | W_FL_TRIGGER);
               if (S(e.x, e.y)->tag) flags |= W_FL_INTAG;
               
               node_s *pWP = new node_s(pos, flags, 0);
               
               short i, j;
               GetNodeIndexes(pos, &i, &j);
               m_Waypoints[i][j].PushNode(pWP);
               BotManager.AddWaypoint(pWP);
               m_iFloodSize += sizeof(node_s);               
               m_iWaypointCount++;
               
               // Connect with other nearby nodes
               ConnectFloodWP(pWP);               
          }
          else if (e.type == MAPMODEL)
          {
               mapmodelinfo &mmi = getmminfo(e.attr2);
               if(!&mmi || !mmi.h || !mmi.rad) continue;
    
               float floor = (float)(S(e.x, e.y)->floor+mmi.zoff+e.attr3)+mmi.h;
              
               float x1 = e.x - mmi.rad;
               float x2 = e.x + mmi.rad;
               float y1 = e.y - mmi.rad;
               float y2 = e.y + mmi.rad;

               // UNDONE?
               for (float x=(x1+1.0f);x<=(x2-1.0f);x++)
               {
                    for (float y=(y1+1.0f);y<=(y2-1.0f);y++)
                    {
                         vec from = { x, y, floor+2.0f };
                         if (GetNearestFloodWP(from, 2.0f, NULL)) continue;
                                       
                         // Add WP
                         int flags = W_FL_FLOOD;
                         if (S((int)x, (int)y)->tag) flags |= W_FL_INTAG;
                         
                         node_s *pWP = new node_s(from, flags, 0);
               
                         short i, j;
                         GetNodeIndexes(from, &i, &j);
                         m_Waypoints[i][j].PushNode(pWP);
                         BotManager.AddWaypoint(pWP);
                         m_iFloodSize += sizeof(node_s);               
                         m_iWaypointCount++;
               
                         // Connect with other nearby nodes
                         ConnectFloodWP(pWP);
                    }
               }
          }    
     }
     CWaypointClass::StartFlood();
}

void CCubeWaypointClass::CreateWPsAtTeleporters()
{
     loopv(ents)
     {
          entity &e = ents[i];
          
          if (e.type != TELEPORT) continue;
          if (OUTBORD(e.x, e.y)) continue;

          vec telepos = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight }, teledestpos = g_vecZero;
          
          // Find the teleport destination          
          int n = -1, tag = e.attr1, beenhere = -1;
          for(;;)
          {
               n = findentity(TELEDEST, n+1);
               if(n==beenhere || n<0) { conoutf("no teleport destination for tag %d", tag); break; };
               if(beenhere<0) beenhere = n;
               if(ents[n].attr2==tag)
               {
                    teledestpos.x = ents[n].x;
                    teledestpos.y = ents[n].y;
                    teledestpos.z = S(ents[n].x, ents[n].y)->floor+player1->eyeheight;
                    break;
               }
          }
          
          if (vis(teledestpos, g_vecZero)) continue;
          
          // Add waypoint at teleporter and teleport destination
          node_s *telewp = AddWaypoint(telepos, false);
          node_s *teledestwp = AddWaypoint(teledestpos, false);
          
          if (telewp && teledestwp)
          {
               // Connect the teleporter waypoint with the teleport-destination waypoint(1 way)
               AddPath(telewp, teledestwp);
               
               // Flag waypoints
               telewp->iFlags = W_FL_TELEPORT;
               teledestwp->iFlags = W_FL_TELEPORTDEST;
          }
     }
}
                         
void CCubeWaypointClass::CreateWPsAtTriggers()
{
     loopv(ents)
     {
          entity &e = ents[i];
          
          if (e.type != CARROT) continue;
          if (OUTBORD(e.x, e.y)) continue;

          vec pos = { e.x, e.y, S(e.x, e.y)->floor+player1->eyeheight };
          
          node_s *wp = AddWaypoint(pos, false);
          
          if (wp)
          {
               // Flag waypoints
               wp->iFlags = W_FL_TRIGGER;
          }
     }
}

// Code of CCubeWaypointClass - End

void addtelewps(void)
{
     WaypointClass.SetWaypointsVisible(true);
     WaypointClass.CreateWPsAtTeleporters();
}

COMMAND(addtelewps, ARG_NONE);

void addtriggerwps(void)
{
     WaypointClass.SetWaypointsVisible(true);
     WaypointClass.CreateWPsAtTriggers();
}

COMMAND(addtriggerwps, ARG_NONE);

#endif
