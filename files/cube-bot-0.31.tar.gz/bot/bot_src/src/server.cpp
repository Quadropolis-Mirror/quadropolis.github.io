// server.cpp: little more than enhanced multicaster
// runs dedicated or as client coroutine

#include "cube.h" 

enum { ST_EMPTY, ST_LOCAL, ST_TCPIP };

struct client                   // server side version of "dynent" type
{
    int type;
    ENetPeer *peer;
    string hostname;
    string mapvote;
    string name;
    int modevote;
    // Added by Rick: For bot voting
    bool addbot, kickbot, changebotskill;
    short botcount;
    string botteam, botname;
    short botskill;
    bool kickallbots;
    // End add
};

vector<client> clients;

int maxclients = 8;
string smapname;

vector<server_entity> sents;

bool notgotitems = true;        // true when map has changed and waiting for clients to send item
int mode = 0;

// Added by Rick
extern void addbot(char *arg1, char *arg2, char *arg3);
extern void kickbot(const char *szName);
extern void kickallbots(void);
extern void getmap();
extern bool hasmap(char *map);
extern string copyname;
// End add

void restoreserverstate(vector<entity> &ents)   // hack: called from savegame code, only works in SP
{
    loopv(sents)
    {
        sents[i].spawned = ents[i].spawned;
        sents[i].spawnsecs = 0;
    }; 
};

int interm = 0, minremain = 0, mapend = 0;
bool mapreload = false;

char *serverpassword = "";

bool isdedicated;
ENetHost * serverhost = NULL;
int bsend = 0, brec = 0, laststatus = 0, lastsec = 0;

#define MAXOBUF 100000

void process(ENetPacket *packet, int sender);
void multicast(ENetPacket *packet, int sender);
void disconnect_client(int n, char *reason);

void send(int n, ENetPacket *packet)
{
	if(!packet) return;
    switch(clients[n].type)
    {
        case ST_TCPIP:
        {
            enet_peer_send(clients[n].peer, 0, packet);
            bsend += packet->dataLength;
            break;
        };

        case ST_LOCAL:
            localservertoclient(packet->data, packet->dataLength);
            break;

    };
};

void send2(bool rel, int cn, int a, int b)
{
    ENetPacket *packet = enet_packet_create(NULL, 32, rel ? ENET_PACKET_FLAG_RELIABLE : 0);
    uchar *start = packet->data;
    uchar *p = start+2;
    putint(p, a);
    putint(p, b);
    *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
    enet_packet_resize(packet, p-start);
    if(cn<0) process(packet, -1);
    else send(cn, packet);
    if(packet->referenceCount==0) enet_packet_destroy(packet);
};

void sendservmsg(char *msg)
{
    ENetPacket *packet = enet_packet_create(NULL, _MAXDEFSTR+10, ENET_PACKET_FLAG_RELIABLE);
    uchar *start = packet->data;
    uchar *p = start+2;
    putint(p, SV_SERVMSG);
    sendstring(msg, p);
    *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
    enet_packet_resize(packet, p-start);
    multicast(packet, -1);
    if(packet->referenceCount==0) enet_packet_destroy(packet);
};

// Added by Rick, send msg to one client
void sendclientmsg(int cn, char *msg)
{
    ENetPacket *packet = enet_packet_create(NULL, _MAXDEFSTR+10, ENET_PACKET_FLAG_RELIABLE);
    uchar *start = packet->data;
    uchar *p = start+2;
    putint(p, SV_SERVMSG);
    sendstring(msg, p);
    *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
    enet_packet_resize(packet, p-start);
    if(cn<0) process(packet, -1);
    else send(cn, packet);
    if(packet->referenceCount==0) enet_packet_destroy(packet);
}
// End add

void disconnect_client(int n, char *reason)
{
    printf("disconnecting client (%s) [%s]\n", clients[n].hostname, reason);
    enet_peer_disconnect(clients[n].peer);
    clients[n].type = ST_EMPTY;
    send2(true, -1, SV_CDIS, n);
};

void resetitems() { sents.setsize(0); notgotitems = true; };

void pickup(uint i, int sec, int sender)         // server side item pickup, acknowledge first client that gets it
{
    if(i>=(uint)sents.length()) return;
    if(sents[i].spawned)
    {
        sents[i].spawned = false;
        sents[i].spawnsecs = sec;
        send2(true, sender, SV_ITEMACC, i);
    };
};

void resetvotes()
{
    loopv(clients) clients[i].mapvote[0] = 0;
};

bool vote(char *map, int reqmode, int sender)
{
    strcpy_s(clients[sender].mapvote, map);
    clients[sender].modevote = reqmode;
    int yes = 0, no = 0; 
    loopv(clients) if(clients[i].type!=ST_EMPTY)
    {
        if(isdedicated && (clients[i].type==ST_LOCAL)) continue; // Added by Rick
        if(clients[i].mapvote[0]) { if(strcmp(clients[i].mapvote, map)==0 && clients[i].modevote==reqmode) yes++; else no++; }
        else no++;
    };
    if(yes==1 && no==0) return true;  // single player
    sprintf_sd(msg)("%s suggests %s on map %s (set map to vote)", clients[sender].name, modestr(reqmode), map);
    sendservmsg(msg);
    if(yes/(float)(yes+no) <= 0.5f) return false;
    sendservmsg("vote passed");
    resetvotes();
    return true;    
};

// Added by Rick: Vote for bot commands
void resetbotvotes()
{
    loopv(clients)
    {
         clients[i].addbot = false;
         clients[i].kickbot = false;
         clients[i].changebotskill = false;
         clients[i].kickallbots = false;
         clients[i].botcount = 0;
         clients[i].botteam[0] = 0;
         clients[i].botname[0] = 0;
         clients[i].botskill = -1;
    }
};

bool addbotvote(int count, char *team, int skill, char *name, int sender)
{
    short num = 0;
    loopv(bots) if (bots[i]) num++;
    if (((num+count) > getvar("maxbots")) || ((num+count) > (maxclients-1)))
    {
        if ((count == 1) || ((num+1)>getvar("maxbots")) || ((num+1)>(maxclients-1)))
        {
            sprintf_sd(msg)("Cannot create bot(s): max reached");
            sendclientmsg(sender, msg);
            printf("%s\n", msg);
            return false;
        }
        else
        {
            sprintf_sd(msg)("Warning: cannot create %d bots, more than maximum allowed", count);
            sendclientmsg(sender, msg);
            printf("%s\n", msg);
            count = getvar("maxbots") - num;
        }
    }

    clients[sender].addbot = true;
    clients[sender].kickbot = false;
    clients[sender].changebotskill = false;
    clients[sender].botcount = (count>=0) ? count : 0;
    if (team && team[0]) strcpy_s(clients[sender].botteam, team);
    else clients[sender].botteam[0] = 0;
    clients[sender].botskill = skill;
    if ((count==1) && name && name[0]) strcpy_s(clients[sender].botname, name);
    else clients[sender].botname[0] = 0;
    int yes = 0, no = 0; 
    loopvj(clients) if(clients[j].type!=ST_EMPTY)
    {
        if(isdedicated && (clients[j].type==ST_LOCAL)) continue;
        if (clients[j].addbot)
        {
            if (count > 1)
            {
                if (!strcmp(clients[j].botteam, team) && (clients[j].botskill == skill) &&
                    (clients[j].botcount == clients[sender].botcount))
                    yes++;
                else
                    no++;
            }
            else
            {
                if (!strcmp(clients[j].botteam, team) && !strcmp(clients[j].botname, name) &&
                    (clients[j].botskill == skill) &&
                    (clients[j].botcount == clients[sender].botcount))
                    yes++;
                else
                    no++;
            }
        }
        else no++;
    }
    if(yes==1 && no==0) return true;  // single player
    string msg;
    if (count > 1)
        sprintf(msg, "%s suggests to add %d bots", clients[sender].name, clients[sender].botcount);
    else
        sprintf(msg, "%s suggests to add a bot", clients[sender].name);
        
    if (team && team[0])
    {
         strcat(msg, " on team ");
         strcat(msg, team);
    }
    
    if (skill!=-1)
    {
         strcat(msg, ", with skill ");
         strcat(msg, SkillNrToSkillName(skill));
    }

    if ((count == 1) && name && name[0])
    {
         strcat(msg, " named ");
         strcat(msg, name);
    }
        
    sendservmsg(msg);
    if(yes/(float)(yes+no) <= 0.5f) return false;
    sendservmsg("vote passed");
    resetbotvotes();
    return true;    
};

bool kickbotvote(int specific, char *name, int sender)
{
    clients[sender].addbot = false;
    clients[sender].kickbot = true;
    clients[sender].changebotskill = false;
    clients[sender].kickallbots = !specific;
    if (specific && name && name[0]) strcpy_s(clients[sender].botname, name);
    else clients[sender].botname[0] = 0;
    int yes = 0, no = 0; 
    loopv(clients) if(clients[i].type!=ST_EMPTY)
    {
        if(isdedicated && (clients[i].type==ST_LOCAL)) continue;
        if (clients[i].kickbot)
        {
             if (clients[sender].kickallbots)
             {
                  if (clients[i].kickallbots) yes++;
                  else no++;
             }
             else
             {
                  if (!clients[i].kickallbots && !strcmp(clients[i].botname, name))
                       yes++;
                  else
                       no++;
             }
        }
        else no++;
    }
    if(yes==1 && no==0) return true;  // single player
    
    char msg[256];
    if (clients[sender].kickallbots)
         sprintf(msg, "%s suggests to kick all bots", clients[sender].name);
    else
         sprintf(msg, "%s suggests to kick bot %s", clients[sender].name,
                         clients[sender].botname);
        
    sendservmsg(msg);
    if(yes/(float)(yes+no) <= 0.5f) return false;
    sendservmsg("vote passed");
    resetbotvotes();
    return true;    
};

bool botskillvote(int skill, int sender)
{
    clients[sender].addbot = false;
    clients[sender].kickbot = false;
    clients[sender].changebotskill = true;
    clients[sender].botskill = skill;
    int yes = 0, no = 0; 
    loopv(clients) if(clients[i].type!=ST_EMPTY)
    {
        if(isdedicated && (clients[i].type==ST_LOCAL)) continue;
        if (clients[i].changebotskill)
        {
             if (clients[sender].botskill == clients[i].botskill) yes++;
             else no++;
        }
        else no++;
    }
    if(yes==1 && no==0) return true;  // single player
    
    sprintf_sd(msg)("%s suggests to change the skill of all bots to: %s", clients[sender].name,
                    SkillNrToSkillName(clients[sender].botskill));
    sendservmsg(msg);
    if(yes/(float)(yes+no) <= 0.5f) return false;
    sendservmsg("vote passed");
    resetbotvotes();
    return true;    
};

void botcommand(uchar *&p, char *text, int sender)
{
    int type = getint(p);
    switch(EBotCommands(type))
    {
        case COMMAND_ADDBOT:
        {
            string name, team;
            name[0] = team[0] = 0;
            int count = getint(p);
            int skill = getint(p);
            sgetstr();
            strcpy(team, text);
            if (count==1)
            {
                sgetstr();
                strcpy(name, text);
            }
            if (getvar("allowaddbotvotes") == 0)
                sendclientmsg(sender, "Clients are not allowed to add bots on this server");
            else if (addbotvote(count, team, skill, name, sender))
            {
                while(count>0)
                {
                    addbot(team, SkillNrToSkillName(skill), name);
                    count--;
                }
            }
            break;
        }
        case COMMAND_KICKBOT:
        {
            int specific = getint(p);
               
            if (specific)
                sgetstr();

            if (getvar("allowkickbotvotes") == 0)
                sendclientmsg(sender, "Clients are not allowed to kick bots on this server");
            else if (kickbotvote(specific, text, sender))
            {
                if (specific)
                    kickbot(text);
                else
                    kickallbots();
            }
            break;
        }
        case COMMAND_BOTSKILL:
        {
            int skill = getint(p);

            if (getvar("allowbotskillvotes") == 0)
                sendclientmsg(sender, "Clients are not allowed to change the bot skill on this server");
            else if (botskillvote(skill, sender))
            {
                BotManager.ChangeBotSkill(skill, NULL);
            }
            break;
        }
     }
}

// End add

// server side processing of updates: does very little and most state is tracked client only
// could be extended to move more gameplay to server (at expense of lag)

void process(ENetPacket * packet, int sender)   // sender may be -1
{
    if(ENET_NET_TO_HOST_16(*(ushort *)packet->data)!=packet->dataLength)
    {
        disconnect_client(sender, "packet length");
        return;
    };
        
    uchar *end = packet->data+packet->dataLength;
    uchar *p = packet->data+2;
    char text[MAXTRANS];
    int cn = -1, type;

    while(p<end) switch(type = getint(p))
    {
        case SV_TEXT:
            sgetstr();
            break;

        case SV_INITC2S:
            sgetstr();
            strcpy_s(clients[cn].name, text);
            sgetstr();
            getint(p);
            break;

	// Added by Rick
        case SV_ADDBOT:
	    getint(p);
            sgetstr();
            //strcpy_s(clients[cn].name, text);
            sgetstr();
            getint(p);
            break;
        case SV_BOTCOMMAND: // Client asked server for a bot command
        {
            botcommand(p, text, sender);
            break;
        }
	// End add by Rick
		        
	case SV_MAPCHANGE:
        {
            sgetstr();
            int reqmode = getint(p);
            if(reqmode<0) reqmode = 0;
            if(smapname[0] && !mapreload && !vote(text, reqmode, sender)) return;
            // Added by Rick: If the server doesn't have this map, request it
            if (!hasmap(text))
            {
                if (!strcmp(copyname, text)) getmap();
                if (!hasmap(text))
                {
                    sendservmsg("Error couldn't load map");
                    break;
                }
            }
            // End add
            mapreload = false;
            mode = reqmode;
            minremain = mode&1 ? 15 : 10;
            mapend = lastsec+minremain*60;
            interm = 0;
            strcpy_s(smapname, text);
            resetitems();
            sender = -1;
            break;
        };
        
        case SV_ITEMLIST:
        {
            int n;
            while((n = getint(p))!=-1) if(notgotitems)
            {
                server_entity se = { false, 0 };
                while(sents.length()<=n) sents.add(se);
                sents[n].spawned = true;
            };
            notgotitems = false;
            break;
        };

        case SV_ITEMPICKUP:
        {
            int n = getint(p);
            int spawnsec = getint(p);
            
            if (getint(p))
                 pickup(n, spawnsec, sender);
            break;
        };

        case SV_PING:
            send2(false, cn, SV_PONG, getint(p));
            break;

        case SV_POS:
        {
            cn = getint(p);
            if(cn<0 || cn>=clients.length() || clients[cn].type==ST_EMPTY)
            {
                disconnect_client(sender, "client num");
                return;
            };
            int size = msgsizelookup(type);
            assert(size!=-1);
            loopi(size-2) getint(p);
            break;
        };

        case SV_SENDMAP:
        {
            // Added by Rick: Check if server need to reply
            if (getint(p) == 1)
                send2(true, sender, SV_SERVRECMAP, 0);
            // End add
            sgetstr();
            int mapsize = getint(p);
            sendmaps(sender, text, mapsize, p);
            return;
        }
        
        case SV_RECVMAP:
               sgetstr(); // Added/modified by Rick
               if (!strcmp(text, "00.00") || !strcmp(text, smapname))
			    send(sender, recvmap(sender));
            return;
        // Added by Rick
        case SV_SERVHASMAP:
             sgetstr();
             send2(true, sender, SV_SERVHASMAP2, (int)hasmap(text));
             return;
        // End add by Rick
        case SV_EXT:   // allows for new features that require no server updates 
        {
            for(int n = getint(p); n; n--) getint(p);
            break;
        };
		
        default:
        {
            int size = msgsizelookup(type);
            if(size==-1) { disconnect_client(sender, "tag type"); return; };
            loopi(size-1) getint(p);
        };
    };

    if(p>end) { disconnect_client(sender, "end of packet"); return; };
    multicast(packet, sender);
};

void send_welcome(int n)
{
    ENetPacket * packet = enet_packet_create (NULL, MAXTRANS, ENET_PACKET_FLAG_RELIABLE);
    uchar *start = packet->data;
    uchar *p = start+2;
    putint(p, SV_INITS2C);
    putint(p, n);
    putint(p, PROTOCOL_VERSION);
    putint(p, smapname[0]);
    sendstring(serverpassword, p);
    putint(p, clients.length()>maxclients);
    if(smapname[0])
    {
        putint(p, SV_MAPCHANGE);
        sendstring(smapname, p);
        putint(p, mode);
        putint(p, SV_ITEMLIST);
        loopv(sents) if(sents[i].spawned) putint(p, i);
        putint(p, -1);
    };
    *(ushort *)start = ENET_HOST_TO_NET_16(p-start);
    enet_packet_resize(packet, p-start);
    send(n, packet);
};

void multicast(ENetPacket *packet, int sender)
{
    loopv(clients)
    {
        if(i==sender) continue;
        send(i, packet);
    };
};

void localclienttoserver(ENetPacket *packet)
{
    process(packet, 0);
    if(!packet->referenceCount) enet_packet_destroy (packet);
};

client &addclient()
{
    loopv(clients) if(clients[i].type==ST_EMPTY) return clients[i];
    return clients.add();
};

void checkintermission()
{
    if(!minremain)
    {
        interm = lastsec+10;
        mapend = lastsec+1000;
    };
    send2(true, -1, SV_TIMEUP, minremain--);
};

void startintermission() { minremain = 0; checkintermission(); };

void resetserverifempty()
{
    //loopv(clients) if(clients[i].type!=ST_EMPTY) return; Modfied by Rick
    loopv(clients)
    {
          if (isdedicated)
          {
               if (clients[i].type == ST_TCPIP) return;
          }
          else if (clients[i].type!=ST_EMPTY) return;
    }
    //clients.setsize(0);
    if (!isdedicated) clients.setsize(0);
    // End add/mod by Rick
    
    smapname[0] = 0;
    resetvotes();
    resetbotvotes(); // Added by Rick
    resetitems();
    mode = 0;
    mapreload = false;
    minremain = 10;
    mapend = lastsec+minremain*60;
    interm = 0;
};

int nonlocalclients = 0;
int lastconnect = 0;

void serverslice(int seconds, unsigned int timeout)   // main server update, called from cube main loop in sp, or dedicated server loop
{
    loopv(sents)        // spawn entities when timer reached
    {
        if(sents[i].spawnsecs && (sents[i].spawnsecs -= seconds-lastsec)<=0)
        {
            sents[i].spawnsecs = 0;
            sents[i].spawned = true;
            send2(true, -1, SV_ITEMSPAWN, i);
        };
    };
    
    lastsec = seconds;
    
    if((mode>1 || (mode==0 && nonlocalclients)) && seconds>mapend-minremain*60) checkintermission();
    if(interm && seconds>interm)
    {
        interm = 0;
        loopv(clients) if(clients[i].type!=ST_EMPTY)
        {
            if ((clients[i].type == ST_LOCAL) && isdedicated) continue; // Added by Rick
            send2(true, i, SV_MAPRELOAD, 0);    // ask a client to trigger map reload
            mapreload = true;
            break;
        };
    };

    resetserverifempty();
    
    if(!isdedicated) return;     // below is network only

	int numplayers = 0;
	//loopv(clients) if(clients[i].type!=ST_EMPTY) ++numplayers; Modified by Rick
     loopvj(clients)
     {
          if (isdedicated)
          {
              if (clients[j].type == ST_TCPIP) ++numplayers;
          }
          else
              if(clients[j].type!=ST_EMPTY) ++numplayers;
     }
     loopvk(bots)
     {
         if (bots[k] && bots[k]->pBot) ++numplayers;
     }
     
	serverms(mode, numplayers, minremain, smapname, seconds, clients.length()>=maxclients);

    if(seconds-laststatus>60)   // display bandwidth stats, useful for server ops
    {
        nonlocalclients = 0;
        loopv(clients) if(clients[i].type==ST_TCPIP) nonlocalclients++;
        laststatus = seconds;     
        if(nonlocalclients || bsend || brec) printf("status: %d remote clients, %.1f send, %.1f rec (K/sec)\n", nonlocalclients, bsend/60.0f/1024, brec/60.0f/1024);
        bsend = brec = 0;
    };

    ENetEvent event;
    if(enet_host_service(serverhost, &event, timeout) > 0)
    {
        switch(event.type)
        {
            case ENET_EVENT_TYPE_CONNECT:
            {
                client &c = addclient();
                c.type = ST_TCPIP;
                c.peer = event.peer;
                c.peer->data = (void *)(&c-&clients[0]);
                char hn[1024];
                strcpy_s(c.hostname, (enet_address_get_host(&c.peer->address, hn, sizeof(hn))==0) ? hn : "localhost");
                printf("client connected (%s)\n", c.hostname);
                send_welcome(lastconnect = &c-&clients[0]);
                break;
            }
            case ENET_EVENT_TYPE_RECEIVE:
                brec += event.packet->dataLength;
                process(event.packet, (int)event.peer->data); 
                if(event.packet->referenceCount==0) enet_packet_destroy(event.packet);
                break;

            case ENET_EVENT_TYPE_DISCONNECT: 
                if((int)event.peer->data<0) break;
                printf("disconnected client (%s)\n", clients[(int)event.peer->data].hostname);
                clients[(int)event.peer->data].type = ST_EMPTY;
                send2(true, -1, SV_CDIS, (int)event.peer->data);
                event.peer->data = (void *)-1;
                break;
        };
        
        if(numplayers>maxclients)   
        {
            disconnect_client(lastconnect, "maxclients reached");
        };
    };
    #ifndef WIN32
        fflush(stdout);
    #endif
};

void cleanupserver()
{
    if(serverhost) enet_host_destroy(serverhost);
};

void localdisconnect()
{
    loopv(clients) if(clients[i].type==ST_LOCAL) clients[i].type = ST_EMPTY;
};

void localconnect()
{
    client &c = addclient();
    c.type = ST_LOCAL;
    strcpy_s(c.hostname, "local");
    send_welcome(&c-&clients[0]); 
};

void initserver(bool dedicated, int uprate, char *sdesc, char *ip, char *master, char *passwd, int maxcl)
{
    serverpassword = passwd;
    maxclients = maxcl;
//	servermsinit(master ? master : "wouter.fov120.com/cube/masterserver/", sdesc, l); Modified by Rick
    servermsinit(master ? master : "cubebot.bots-united.com/cube/masterserver.cgi/", sdesc, dedicated);
    
    if(isdedicated = dedicated)
    {
        ENetAddress address = { ENET_HOST_ANY, CUBE_SERVER_PORT };
        if(*ip && enet_address_set_host(&address, ip)<0) printf("WARNING: server ip not resolved");
        serverhost = enet_host_create(&address, MAXCLIENTS, 0, uprate);
        if(!serverhost) fatal("could not create server host\n");
        loopi(MAXCLIENTS) serverhost->peers[i].data = (void *)-1;
    };

    resetserverifempty();

    if(isdedicated)       // do not return, this becomes main loop
    {
        #ifdef WIN32
        SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
        #endif
        printf("dedicated server started, waiting for clients...\nCtrl-C to exit\n\n");
        atexit(cleanupserver);
        atexit(enet_deinitialize);
        // Modified by Rick
        //for(;;) serverslice(/*enet_time_get_sec()*/time(NULL), 5);
    };
};
