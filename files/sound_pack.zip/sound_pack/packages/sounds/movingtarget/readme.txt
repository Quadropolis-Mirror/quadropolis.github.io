These sounds were picked up by me (MovingTarget) from a site offering a relatively small game sounds pack for free.
Most of the sounds were edited (also by me) and converted to the Microsoft ADPCM sound format from the mp3PRO (FhG)
format.