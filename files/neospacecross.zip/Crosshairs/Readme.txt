Instructions:

Place these in "bloodfrontier > gamedata > textures" after making backups of the standard crosshairs and restart the game if you haven't already.

Enjoy.