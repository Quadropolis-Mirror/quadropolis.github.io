This texturepack has been packaged on the 5ht of January 2014 (by Suicizer), with the goal to complete the ik2k directory of Cube Engine 2 Sauerbraten.
Any other Cube Engine 2 related mod might want to use it as well; I wouldn't have any trouble with it, as long as you include the textures within Sauerbraten as well (else all this would be for nothing).

The original package has been downloaded from the next website:
http://www.celephais.net/board/view_thread.php?id=4&start=12738&end=12762

Some additional textures which are included by one of Iikka Keranen himself can be obtained here:
http://lvlworld.com/media/id:793

I do not claim any warranties neither credits on any of the textures. Just follow their license by the letter and enjoy using them.

Greetings,

Suicizer