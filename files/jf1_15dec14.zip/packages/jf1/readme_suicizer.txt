This texturepack has been packaged on the 10ht of January 2014 (by Suicizer), with the goal to complete the jf1 directory of Cube Engine 2 Sauerbraten.
Any other Cube Engine 2 related mod might want to use it as well; I wouldn't have any trouble with it, as long as you include the textures within Sauerbraten as well (else all this would be for nothing).

The original package has been downloaded from the next website:
http://www.wad-archive.com/wad/jf1.wad

The link to the website of the original author (John Fitzgibbons):
http://www.celephais.net/

I do not claim any warranties neither credits on any of the textures. Just follow their license by the letter and enjoy using them.

Greetings,

Suicizer