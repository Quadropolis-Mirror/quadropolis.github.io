Mapname: w00tablous
Author: Warlord

---

Installation:

Simply unzip the file to .../Sauerbraten/packages/base folder. You can run the map by typeing "/map w00tablus" in the command line.

---

Note:

The map idea comes from Unreal Tournament CTF-w00tablous. The map for Sauerbraten is playable as a classic deathmatch map or as an capture map.
