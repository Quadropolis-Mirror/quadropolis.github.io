
#ifndef CARBON_H_
#define CARBON_H_

/*
** Carbon main namespace
*/
typedef struct hudscolors {
    int r[10];
    int g[10];
    int b[10];
    bool enabled[10];
} rgbarray;
namespace n_div
{
    extern unsigned long cnkills, cngibs, cntkills, cnsuicides, cnflags, cndeaths, cnhits, cnfailhits;
    extern bool tskillmenu;

    extern bool bar;

    extern bool match;
        extern bool ammo_box;
        extern bool score_box;
        extern bool crosshair_name;
    extern rgbarray hcol[5];
    extern int c_r,c_g,c_b,c_a,hud;

    extern int rvsf_frags,cla_frags;
    extern int rvsf_flags,cla_flags;
};

/*
** Opening loading bar
*/

typedef struct s_loadingbar
{
    int total_stades;
    int actual_stade;
} t_load;

/*
** Loading bar function
** void Textff(t_load *load, Texture *logo, const char *cload);
*/

/*
** Init functions
*/

void init();
void initmatch();

/*
** Carbon featz, commands are in the main.cpp file
*/

void cbar();
void ammobox();
void scorebox();
void crosshairname();
void crosshaircolor(int, int, int, int);
void drawrectangle(int,int,int,int);
void applyalpha(bool);
/*
** The skill menu
*/

void pluskills();
void plustkills();
void plusgibs();
void plusdeaths();
void plussuicides();
void plusflags();
void plusfailhit();
void plushit();
void resetscore();
void skillmenu();
void save_skillmenu();
void load_skillmenu();

/*
** Score updating
*/

void updatescores();

/*
** Display skill menu
*/

void displayskillmenu(int, int);

/*
** Display life bars
*/

void displaybar(int, int, bool);

/*
** Display scores box
*/
void displayscore(int);

/*
** Display ammo box
*/

void displayammobox(int, int, playerent*, bool, bool);

/*
** Fullbright the bots, implemented in rendermodel.cpp
** void enablefullbright(model*, batchedmodel&);
*/

#endif

