
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include "pch.h"
#include "cube.h"
#include "carbon.h"

/*
** Carbon main namespace
*/

namespace n_div
{
    unsigned long cnkills,cngibs,cntkills,cnsuicides,cnflags,cndeaths,cnhits,cnfailhits;
    bool tskillmenu;

    bool bar;

    bool match;
    bool ammo_box;
    bool score_box;
    bool crosshair_name;
    int hud = 1;
    int c_r = 255;
    int c_g = 255;
    int c_b = 255;
    int c_a = 255;
    rgbarray hcol[5];
    int rvsf_frags = 0;
    int cla_frags = 0;
    int rvsf_flags = 0;
    int cla_flags = 0;
};

/*
** Init functions
*/

void init(){
    n_div::bar = false;
    n_div::match = false;
    n_div::ammo_box = false;
    n_div::score_box = false;
    n_div::crosshair_name = false;
}

void initmatch(){
    n_div::match = true;
    n_div::ammo_box = true;
    n_div::bar = true;
    n_div::score_box = true;
    n_div::crosshair_name = true;
}

/*
** Skill menu functions
*/

void setrgbfor(int ele,int r,int g,int b){
n_div::hcol[n_div::hud-1].r[ele]=r;
n_div::hcol[n_div::hud-1].g[ele]=g;
n_div::hcol[n_div::hud-1].b[ele]=b;
n_div::hcol[n_div::hud-1].enabled[ele]=true;
hudoutf("Hud [%d] color block [%d] to %d %d %d",n_div::hud,ele,r,g,b);
}
COMMANDN(hudrgb,setrgbfor,ARG_4INT);

void delhudrgb(int block){
n_div::hcol[n_div::hud-1].enabled[block]=false;
hudoutf("Hud [%d] Block [%d] Custom Color Disabled",n_div::hud,block);
}
COMMAND(delhudrgb,ARG_1INT);
void pluskills(){
    n_div::cnkills += 1;
}

void plustkills(){
    n_div::cntkills += 1;
}

void plusgibs(){
    n_div::cngibs += 1;
}

void plusdeaths(){
    n_div::cndeaths += 1;
}

void plussuicides(){
    n_div::cnsuicides += 1;
}

void plusflags(){
    n_div::cnflags += 1;
}

void plusfailhit(){
    n_div::cnfailhits += 1;
}

void plushit(){
    n_div::cnhits += 1;
    if(!playerincrosshair()) { n_div::cnfailhits -= 1; }
}

void resetscore(){
    n_div::cnkills = 0;
    n_div::cntkills = 0;
    n_div::cngibs = 0;
    n_div::cndeaths = 0;
    n_div::cnsuicides = 0;
    n_div::cnflags = 0;
    n_div::cnhits = 0;
    n_div::cnfailhits = 0;
}
COMMAND(resetscore,ARG_NONE);
void save_skillmenu(){
    FILE *f = fopen("config/sst.list", "w");
    fprintf(f, "%ld\n%ld\n%ld\n%ld\n%ld\n%ld\n%d\n%ld\n%ld\nDO NOT MODIFY!",
            n_div::cnkills,
            n_div::cngibs,
            n_div::cntkills,
            n_div::cnsuicides,
            n_div::cnflags,
            n_div::cndeaths,
            n_div::tskillmenu,
            n_div::cnhits,
            n_div::cnfailhits);
    fclose(f);
}
COMMAND(save_skillmenu,ARG_NONE);
void load_skillmenu(){
    FILE *ft = fopen("config/sst.list", "r");
    if (!ft){
        n_div::cnkills = 0;
        n_div::cngibs = 0;
        n_div::cntkills = 0;
        n_div::cnsuicides = 0;
        n_div::cnflags = 0;
        n_div::cndeaths = 0;
        n_div::tskillmenu = 1;
        n_div::cnhits = 0;
        n_div::cnfailhits = 0;
    }
    else {
        long tmenu = 1;
        char buff[9] = {'\0'};
        int item = 1;
        while (fgets(buff, 9, ft) != NULL && item <= 9){
            switch (item){
                case 1:{n_div::cnkills = strtol(buff, NULL, 10); break;}
                case 2:{n_div::cngibs = strtol(buff, NULL, 10); break;}
                case 3:{n_div::cntkills = strtol(buff, NULL, 10); break;}
                case 4:{n_div::cnsuicides = strtol(buff, NULL, 10); break;}
                case 5:{n_div::cnflags = strtol(buff, NULL, 10); break;}
                case 6:{n_div::cndeaths = strtol(buff, NULL, 10); break;}
                case 7:{tmenu = strtol(buff, NULL, 10); break;}
                case 8:{n_div::cnhits = strtol(buff, NULL, 10); break;}
                case 9:{n_div::cnfailhits = strtol(buff, NULL, 10); break;}
                default: break;
            }
            item++;
        }
        fclose(ft);
        if (tmenu == 1){ n_div::tskillmenu = true; }
        else{ n_div::tskillmenu = false; }
    }
}
COMMAND(load_skillmenu,ARG_NONE);
void skillmenu() {
    n_div::tskillmenu=!n_div::tskillmenu;
}
COMMAND(skillmenu,ARG_NONE);
/*
** Some featz of Carbon
*/

void cbar(){
    n_div::bar = !n_div::bar;
}
COMMAND(cbar,ARG_NONE);
void ammobox(){
    n_div::ammo_box = !n_div::ammo_box;
}
COMMAND(ammobox,ARG_NONE);
void scorebox(){
    n_div::score_box = !n_div::score_box;
}
COMMAND(scorebox,ARG_NONE);
void crosshairname(){
    n_div::crosshair_name = !n_div::crosshair_name;
}
COMMAND(crosshairname,ARG_NONE);
void hudstyle(int s){
    if (s>0)
    n_div::hud =s;
}
COMMAND(hudstyle,ARG_1INT);
void crosshaircolor(int r, int g, int b, int a){
    n_div::c_r=r;
    n_div::c_b=b;
    n_div::c_g=g;
    n_div::c_a=a;
}
COMMAND(crosshaircolor,ARG_4INT);
void applyalpha(bool mate){
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    if(!mate) {
        glColor4ub(n_div::c_r, n_div::c_g, n_div::c_b, n_div::c_a);
    } else {
        glColor4ub(255, 0, 0, 255);
    }
}

/*
** Score updating
*/

void updatescores() {
    struct teamscore
    {
        int team, frags, deaths, flagscore;
        vector<playerent *> teammembers;
        teamscore(int t) : team(t), frags(0), deaths(0), flagscore(0) {}

        void inline addscore(playerent *d)
        {
            if(!d) return;
            teammembers.add(d);
            frags += d->frags;
            deaths += d->deaths;
            if(m_flags) flagscore += d->flagscore;
        }
    };
    if(m_teammode)
    {
        teamscore teamscores[2] = { teamscore(TEAM_CLA), teamscore(TEAM_RVSF) };

        loopv(players)
        {
            if(!players[i]) continue;
            teamscores[team_int(players[i]->team)].addscore(players[i]);
        }
        if(!watchingdemo) teamscores[team_int(player1->team)].addscore(player1);
        n_div::rvsf_frags=teamscores[TEAM_RVSF].frags;
        n_div::cla_frags=teamscores[TEAM_CLA].frags;
        if (m_flags){
            n_div::rvsf_flags=teamscores[TEAM_RVSF].flagscore;
            n_div::cla_flags=teamscores[TEAM_CLA].flagscore;
        }
    }
}

/* Display skill menu */

void displayskillmenu(int left, int top){
    if (n_div::tskillmenu){
        float nratio;
        if ((n_div::cnkills+n_div::cngibs*2)<(n_div::cnsuicides+n_div::cntkills)) {
            nratio=0;
        } else {
        if ((n_div::cndeaths+n_div::cnsuicides) > 0) {
            nratio = float (n_div::cnkills+n_div::cngibs*2-n_div::cnsuicides-n_div::cntkills)/float (n_div::cndeaths+n_div::cnsuicides);
        } else {
            nratio = (n_div::cnkills+n_div::cngibs*2-n_div::cnsuicides-n_div::cntkills);
        }
        }
        const int newleft = left-170;
        static Texture *tex = NULL;
        if(!tex) tex = textureload("packages/textures/makke/menu.jpg");
        blendbox(newleft-20, top-345, left+450, top+400, 1, tex->id, NULL);
        draw_textf("\f3Score \f2%d", newleft, top-320, n_div::cnflags*90+n_div::cnkills*10-n_div::cntkills*27+n_div::cngibs*20-n_div::cndeaths*2-n_div::cnsuicides*5);
        if(n_div::cnfailhits == 0 && n_div::cnhits >= 1) {
            draw_textf("\f3accuracy \f2100%s", newleft, top-240,"%");
        } else {
            if (n_div::cnhits == 0)
                draw_textf("\f3accuracy \f20%s", newleft, top-240,"%");
            else
                draw_textf("\f3accuracy \f2%d%s", newleft, top-240, (n_div::cnhits)*100/(n_div::cnhits+n_div::cnfailhits),"%");
        }
        draw_textf("\f3ratio \f2%.2f", newleft, top-160, nratio);
        draw_textf("\f3flags \f2%d", newleft, top-80, n_div::cnflags);
        draw_textf("\f3kills \f2%d", newleft, top, n_div::cnkills);
        draw_textf("\f3gibs \f2%d", newleft, top+80, n_div::cngibs);
        draw_textf("\f3tkills \f2%d", newleft, top+160, n_div::cntkills);
        draw_textf("\f3suicides \f2%d", newleft, top+240, n_div::cnsuicides);
        draw_textf("\f3deaths \f2%d", newleft, top+320, n_div::cndeaths);
    }
}


void drawrectangle(int x1, int y1, int x2, int y2)
{
glDisable(GL_TEXTURE_2D);
glBegin(GL_QUADS);
glVertex2f(x1, y1);
glVertex2f(x2, y1);
glVertex2f(x2, y2);
glVertex2f(x1, y2);
glEnd();
glEnable(GL_TEXTURE_2D);
}
/* Display life bars */
void displaybar(int health, int armour,bool hhe){
if((!hhe) && (n_div::bar))
{
bool blend=glIsEnabled(GL_BLEND);
if(n_div::hud==1) {
    static Texture *tex2 = NULL;
    if(!tex2){ tex2 = textureload("packages/textures/makke/menu.jpg"); }
    static color transparent2(1, 1, 1, 0.75f);
    blendbox(100*4, 850*4, 400+(health)*6, 850*4+100, 2, tex2->id, &transparent2);
	if(armour){ blendbox(400*4, 850*4, 1600+(armour)*6, 850*4+100, 2, tex2->id, &transparent2); }
    draw_textf("%d%s",  96*4, 827*4, health,"%");
	if(armour){ draw_textf("%d%s", 398*4, 827*4, armour,"%"); }
}
else if(n_div::hud==2){
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    const int barblackds=7;
    const int aleft=400;
    const int bleft=1600;
    const int hheight=3370;
    const int hheightplus=70;
    glEnable(GL_BLEND);
    glColor4f(0.6,0.6,0.6,0.3);
    drawrectangle(aleft-barblackds*3, hheight-barblackds*3, aleft+(100)*6+barblackds*3, hheight+hheightplus+barblackds*3);
    if (armour > 0) {
        drawrectangle(bleft-barblackds*3, hheight-barblackds*3, bleft+(100)*6+barblackds*3, hheight+hheightplus+barblackds*3);
    }
    glDisable(GL_BLEND);
    glColor3f(0,0,0);
    drawrectangle(aleft-barblackds, hheight-barblackds, aleft+(100)*6+barblackds, hheight+hheightplus+barblackds);
    if (armour > 0) {
        drawrectangle(bleft-barblackds, hheight-barblackds, bleft+(100)*6+barblackds, hheight+hheightplus+barblackds);
    }
    if(n_div::hcol[1].enabled[0] == true) {
    glColor3ub(n_div::hcol[1].r[0],n_div::hcol[1].g[0],n_div::hcol[1].b[0]);
    } else glColor3ub(255,110,0);
    drawrectangle(aleft, hheight, aleft+(health)*6, hheight+hheightplus);
    if (armour > 0) {
        if(n_div::hcol[1].enabled[1] == true) {
        glColor3ub(n_div::hcol[1].r[1],n_div::hcol[1].g[1],n_div::hcol[1].b[1]);
        } else glColor3ub(0,110,255);
        drawrectangle(bleft, hheight, bleft+(armour)*6, hheight+hheightplus);
    }
}
if(blend==0) glDisable(GL_BLEND); else glEnable(GL_BLEND);
}
}

/* Display scores box */

void displayscore(int top){
    if (n_div::score_box && m_teammode) {
        updatescores();
        bool blend=glIsEnabled(GL_BLEND);
        if(blend==0) glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        static Texture *tex4 = NULL;
        if (!tex4){ tex4 = textureload("packages/misc/score-box.png"); }
        else{
                static color transparent4(1, 1, 1, 1);
                const int xX = VIRTW*2 - 770;
                const int yY = top-2200;
                const int marg = 45;
                int margin_cla = (m_flags ? (n_div::cla_flags > 99 ? marg : 0) : (n_div::cla_frags > 99 ? marg : 0));
                int margin_rvsf = (m_flags ? (n_div::rvsf_flags > 99 ? marg : 0) : (n_div::rvsf_frags > 99 ? marg : 0));
                blendbox(xX, yY, xX+512, yY+100, 0, tex4->id, &transparent4);
                draw_textf("%d",  xX+113-margin_cla, yY+20, m_flags ? n_div::cla_flags : n_div::cla_frags);
                draw_textf("%d",  xX+369-margin_rvsf, yY+20, m_flags ? n_div::rvsf_flags : n_div::rvsf_frags);
        }
        if(blend==0) glDisable(GL_BLEND);
    }
}

/* Display ammo box */

void displayammobox(int left, int top, playerent *p, bool hidehudequipment, bool voting){
    if (n_div::ammo_box && p->state==CS_ALIVE && !hidehudequipment){
        bool blend=glIsEnabled(GL_BLEND);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(1.0f, 1.0f, 1.0f,1.0f);
        int margin = (voting ? 700 : 0);
        static Texture *tex3 = NULL;
        static Texture *tex4 = NULL;
        if(p->primary == 2) { tex3 = textureload("packages/misc/shgun-pic.png"); }
        if(p->primary == 3) { tex3 = textureload("packages/misc/subgun-pic.png"); }
        if(p->primary == 4) { tex3 = textureload("packages/misc/sniper-pic.png"); }
        if(p->primary == 5) { tex3 = textureload("packages/misc/assault-pic.png"); }
        tex4 = textureload("packages/misc/ammo-box.png");
        if(tex3 && tex4) {
            static color transparent3(1, 1, 1, 1);
            const int lo = left-450;
            const int to = 500;
            blendbox(left-lo-400, top-to-630+margin, left-lo+120, top-to-278+margin, 0, tex4->id, &transparent3);
            blendbox(left-lo-400, top-to-800+margin, left-lo+120, top-to-578+margin, 0, tex3->id, &transparent3);
            draw_textf("%d/%d",  left-lo-200, top-to-750+margin, p->weapons[p->primary]->mag, p->weapons[p->primary]->ammo);
            draw_textf("%d",  left-lo-200, top-to-600+margin, p->weapons[6]->mag);
            draw_textf("%d/%d",  left-lo-200, top-to-400+margin, p->weapons[(p->akimbo ?7 : 1)]->mag, p->weapons[(p->akimbo ?7 : 1)]->ammo);
        }
        if(blend==0) glDisable(GL_BLEND); else glEnable(GL_BLEND);
    }

}



