quick notes:

* install command line cvs, include it in your system path variable
* edit the cvs command in exportCVS.bat and set your own username
* install NSIS
* edit ac.nsi and fix the CURPATH variable