#!/bin/sh
# CUBE_DIR should refer to the directory in which Cube is placed.
#CUBE_DIR=~/cube
#CUBE_DIR=/usr/local/cube
CUBE_DIR=./

# CUBE_OPTIONS contains any command line options you would like to start Cube with.
#CUBE_OPTIONS="-f"
CUBE_OPTIONS="--mod=mods\CarbonMod --home=${HOME}/.assaultcube_v1.0 --init"

# SYSTEM_NAME should be set to the name of your operating system.
#SYSTEM_NAME=Linux
SYSTEM_NAME=Carbon_

if [ -x ${CUBE_DIR}/bin_unix/${SYSTEM_NAME}client ]
then
  cd ${CUBE_DIR}
  exec ${CUBE_DIR}/bin_unix/${SYSTEM_NAME}client ${CUBE_OPTIONS} "$@"
else
  echo "Your platform does not have a pre-compiled Cube client."
  echo "Please follow the following steps to build a native client:"
  echo "1) Ensure you have the SDL, SDL-image, OpenAL, and OpenGL libraries installed."
  echo "2) Change directory to source/src/ and type \"make install\"."
  echo "3) If the build succeeds, return to this directory and run this script again."
  exit 1
fi

