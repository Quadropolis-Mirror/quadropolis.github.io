+ 3D shotgun model all rights reserved to MaKKE.

+ Carbon shotgun skin : all right reserved to Deathstar.