Crosshairs by makkE.


EXCEPT:
-------
o.png
o_dot.png
o_x.png

By Topher of Death Illustrated team. 


