        ac_crematorium by #eXa*|Brett, #eXa*|#DarKnoT* and #eXa*|M4ns0n 


Do not broke the ac mapping rules
Do not modify the map. 

If We saw this one modified, you'll be blacklisted on some servers




      Visit www.explosive-alliance.c.la