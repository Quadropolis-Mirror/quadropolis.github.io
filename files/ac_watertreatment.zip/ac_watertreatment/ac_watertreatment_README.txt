ap ac_watertreatment by fetus (Febuary 2009)

If you edit this map, you must acknowledge this work in any derivative works.  Derivative works must be so named as to not cause confusion with the original work.

Go ahead, edit the map and have fun.  Please make sure to give me credit and name your map something different.

This map was concieved for CTF.  Other modes may play well: they may not.

I have FFA spawn points throughout to support experimentation.