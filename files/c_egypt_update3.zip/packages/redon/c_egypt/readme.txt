To start the map "c_egypt" in Sauerbraten:
- Put the Files c_egypt.ogz, c_egypt.cfg and c_egypt.jpg into the sauerbraten/packages/base folder.
- Put the redon folder into the sauerbraten/packages folder.
- Start Sauerbraten and type /map c_egypt

UPDATE 1 (17 May 2008)
- Replaced Lava at the Temple Ruins
- Added more details at the roof of the Temple Ruins
- Added clip and noclip at the Temple Ruins
- Fixed path of the music file in the cfg
- Added a Readme

UPDATE 2 (1 June 2008)
- Replaced the clip wall
- Moved the Quad
- Added two buildings
- Replaced the playerstarts

UPDATE 3 (2 June 2008)
- Removed the big black box under the map
- Removed some healths
- Removed the music file
