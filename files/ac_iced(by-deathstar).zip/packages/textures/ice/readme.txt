Read this for know the textures rights
(from diferents artists)

====================================================================================================
* tile by payne (sauerbraten)
====================================================================================================
The textures in this file are property of Remedy Entertainment Ltd., and can be used only as long as the 
work is recognized as original artwork by Remedy, and no financial profit is made in the process. 

(C)1998-2001 Remedy Entertainment Ltd.

====================================================================================================
* wall & ceiling: from evil_textures (sauerbraten)
====================================================================================================

9/7/01

Name: evil lair's Quake 3:Arena texture set 7  
Short Name: evil7:dismal solace
Author: Yves Allaire aka "evil lair"
Email: hfx@planetquake.com
URL: http://planetquake.com/hfx

[Description]
Quake 3: Arena texture set in a gothic/metal theme.

[instructions for Q3Radient/GTKRadient users]

basic usage:
Place the 'e7' folder inside your "baseq3/textures' folder
Place the e7.shader in your /scripts folder
Add e7 to your shaderlist.txt file to see them in Q3Radient/GTKRadient

suggested usage:
I'd encourage you to make your own directories for my textures for your map like so ... 

"baseq3/textures/mymapname/" (place my textures here.)

"baseq3/scripts/mymapname.shader" (add my shaders here, making sure to edit the paths in the original shader file.)

[Thanks]
Everyone who had kind words to say about my other sets and
the people at the Quake3World.com Level Editing Forum.

Everyone who has used/will use my textures in their maps.
This is why I make them. :)


[Stuff]
If you use any of the textures it would be cool if you emailed me with the url to some screenshots if possible. 
I really would like to see what uses mappers have made of them.

[Copyright/Permissions]
-You may use these texture in your maps/mods/tc�s as long as you give me credit.
-You may not edit, modify any textures within this archive unless given permission to do so by the author.  
-You may convert these textures to other game formats but only with the author�s permission (me).


QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks
of id Software, Inc.


[:Made With A Mac:]

===================================================================================================
* BRICK & BRICK 2:
===================================================================================================

 the files in this folder and subfolders are property of J�sus "aftasardem" Maia.

e-mail: ardemdoem@gmail.com


you are free to use them in sauerbraten/cube maps as long as you:



1- do not make a financial profit out of my hard work (make me your best partner first!)



2- give the original author credit and make this text file accessible.


---TEXTURES------------------------------------------------------------------------------------



3- the textures can be edited and changed as long as you:
   A- credit me as the author of the source material.
   B- include this text file.
   C- AND you must distribute your resulting work under a licence identical to mine!!
 


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
  

os arquivos contidos nesse diret�rio s�o de propriedade de J�sus ""aftasardem" Maia.

e-mail : ardemdoem@gmail.com

voc� pode us�-los em mapas pra sauerbraten/cube, contanto que voc�:

1- n�o fa�a uso comercial (*dinheiro*) com o meu trabalho (me contate primeiro!)

2- mencione e credite o autor original e deixe esse arquivo de texto acess�vel.

----TEXTURAS------------------------------------------------------------------------------------

3- as texturas podem ser editadas ou modificadas, contanto que voc�:
   A- mencione e credite o autor original.  
   B- deixe esse arquivo de texto acess�vel.
   C- E voc� tem que distribuir o trabalho resultante sob uma licen�a de uso id�ntica � minha!


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
acho que � s�...um abra�o e muita boa sorte!

=================================================================================================
* DOOR
=================================================================================================

mm-texture readme.txt

Listed below are the various source material websites I used for creating my "mm-textures" for the SAUERBRATEN engine/game.

All sources I used claimed the textures are free to use for non-commercial use. Each website has there own way of wording it, so if your interested, visit their sites.

http://www.accustudio.com/

http://www.3dcafe.com

http://www.noctua-graphics.de/english/fraset_e.htm

http://www.mayang.com/textures/

http://www.mega-tex.nl/textures.php

None of the textures were "just copied and renamed". All were modified / layered / enhanced / pieced together by me.

Feel free to use my "mm-textures" any way you want, just please give me credit in your readme file.

Enjoy!

MitaMAN (Mike Poeschl)
mitaman1-at-optonline-dot-net
10-24-06

