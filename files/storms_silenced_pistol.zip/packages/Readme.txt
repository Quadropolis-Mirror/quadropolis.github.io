Storm's readme!

Okay so you've just downloaded this and you don't want too much trouble:

1. Completly replace the pistol located at: AssaultCube\packages\models. 

2. Look in the folder Silencer_Sound and place the sound into this folder (Make a backup first!) AssaultCube\packages\audio\sounds



Happy Fragging dudes! Any requests to bc_storm@hotmail.co.uk!
