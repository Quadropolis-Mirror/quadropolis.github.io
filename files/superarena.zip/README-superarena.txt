Map "superarena"
Made by: 0vonix0, SomeDude, Church, GrLx, and Cthulu
Date Made: 10/23/2010
Time Spent Making Map: Roughly 2 Hours

SomeDude's Email: "stevenquack86vg@gmail.com"