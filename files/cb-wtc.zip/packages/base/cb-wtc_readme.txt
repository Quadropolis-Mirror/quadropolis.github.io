================================================================
Title          : wtc
Filename       : cb-wtc.ogz
Author         : Ibrihim
Email Address  : visitor@carlbahr.com
To Run         : See "Additional help" below
================================================================
 Description:

 This is a World Trade Center memorial.  I always wanted to
 visit the WTC but I never did.  Then I though  why not make a
 virtual tourist model so here it is. The scale is 1 standard
 unit is 36".  It is not a 100 percent accurate,
 the real tower had 59 columns 40" on center and was 208 feet
 wide, this one has only 31 columns 72" on center and is 216
 feet wide for easier selection, copy, paste, etc.  The height
 is within a few feet.  On the south tower I have modeled the
 37-39th floors and also the 107 floor observation deck.
 The observation deck is based only on photos and forum
 descriptions so it may not be totally accurate.
 This is my second (released) map and it took me over 5 weeks
 to hammer out.
================================================================
 Additional help:

 Extract the files to "Sauerbraten/packages/base" directory
 In the game console, type /map cb-office
================================================================

* Play Information *

Single Player           : No
Deathmatch              : No
New Sounds              : No
New Graphics            : Map
New Music               : No
Cube Version            : Cube 2: Sauerbraten (Justice Edition)

* Construction *

Map                     : New level from scratch
Known Bugs              : None

================================================================
Licence:

(c) Copyright 2011: Brian Carl Bahr

CC-BY-3.0

 This work is licensed under the
 Creative Commons Attribution 3.0 Unported (CC BY 3.0) License.
 To view a copy of this license visit:
 
  http://creativecommons.org/licenses/by/3.0/

 or send a letter to:

  Creative Commons
  444 Castro Street  Suite 900
  Mountain View, California 94140
  USA
================================================================
