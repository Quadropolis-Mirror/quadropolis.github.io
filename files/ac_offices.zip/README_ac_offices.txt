This map, screenshot, and config was made by TheSharpShooter, or respectively |BC|*~Sharp~* for now

Music was made by Sp1r1T in New Grounds Audio Portal
Music Title - 119806_DOY_Sp1r1T
		Dreaming Of You

Redistribution of these files under a different name is forbidden


Enjoy my map!


*If you have any questions about mapping, how to extract files, or encounter problems with the files, please send an e-mail to koro-shiya@hotmail.com*



