README

===

onto's round crosshairs
Release date: Nov 14, 2009
Version: 0.1
Contact: onto (at) lavabit.com

===


This crosshair package was created by the user onto on www.quadropolis.us for free use in the game sauerbraten. You may use and modify the crosshairs as you wish, but please don't distribute them without asking me first.

I created these crosshairs as I was not satisfied with the current ones. Particularly I wanted clean and round crosshairs that would remain visible on all surfaces and would be fine for shooting and sniping. I also wanted a better kill feedback at small crosshair sizes hence the red color for the 'hit' crosshair. These crosshairs were inspired by the dual crosshairs by PrimeEvil.

These crosshairs work best with crosshair sizes between 4 and 10. Set your crosshair size with /crosshairsize 1-50.


===

Installation:
1. Go to the folder in your Sauerbraten directory where the crosshairs are located (usually in .../data or .../data/crosshairs if you use a script to change the crosshairs).
2. Select the crosshair you would like to use.
3. Rename the crosshair to crosshair.png, the hit crosshair to hit.png and the teammate crosshair to teammate.png
4. Make a backup of the existing crosshairs
5. Replace the existing crosshairs with the new ones
6. Enjoy!


===

WARNING: These crosshairs will dramatically increase your accurary in game so that you will pWn everybody and they will bow to your awesome l33tness forever!
