====== Shack by iCrab ======
a map for Cube 2: Sauerbraten

v1.1

(c) 2013 iCrab

---------

* Story

As you wander aimlessly through the icy mountains of The North, the alarming 
realization sets in that you are hopelessly lost. Seeking food and shelter
for the night, you discover a remote mining village which seems to provide
plenty of both. However, it looks like its occupants deserted the place quite 
recently and you can't help but feel it has something to do with you.

---------

* Completion date: 23/11/2013
* Completion time: About 1 week
* Last updated: 02/12/2013
* Version: Cube 2 Sauerbraten (Collect Edition, Release Version)

---------

* Game modes:

Shack supports all modes related to Deathmatch and Capture.

---------

* Credits

- iCrab
- Sauerbraten Texture Artists, 3D Artists, Environment Artists, Sound Designers
  and other asset providers whose work has been included in this map

---------

* License

You may mess with this map all you want and use it as source of inspiration and / or
material for your own projects with the exception of copying larger segments (or the
map as a whole) and claiming / showcasing them as your own.
Giving credit to the author(s) of this content would always be appreciated.
If you have any questions, I can be reached at
"www.quadropolis.us".

---------

* Have fun!