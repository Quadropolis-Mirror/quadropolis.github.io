Shattered skybox by Mayhem  Licensed under CC-BY-SA

	I used Bryce 6 to create this simple skybox which consists of 6 .jpg files at 1024x1024.