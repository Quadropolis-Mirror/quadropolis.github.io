Messed - By Pritchard, Rilk and Mr_Snuggles 2-26-2013

A medium/large sized FFA map. Objectives could, and should, be added for capture, CTF etc. in a future update (If we get around to it)
Messed is a generic map, asymetrical with high walls and large open spaces. It's got a Quad on it but no HealthBoost. We're just putting it out there to see what people think and get C&Cs. Don't consider this map to be a final product.

