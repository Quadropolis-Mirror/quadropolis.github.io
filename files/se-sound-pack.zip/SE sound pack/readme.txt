Yeah, just put it in main Sauer folder and you're done.

Note that the sounds do not sound as good as in SauerEnhanced because Sauer
doesn't have separate sounds for grenade and rocket explosions and as well
there's just one sample per gun when SE had three of them.
And I was too lazy to create new, universal explosion sound for both of the guns so..
yeah.

Just enjoy and shut up :P
-Q009

License is CC-BY-SA 3.0
Which means:

You are free:

to Share � to copy, distribute and transmit the work
to Remix � to adapt the work
to make commercial use of the work

With the understanding that:

Waiver � Any of the above conditions can be waived if you get permission from the copyright holder.
Public Domain � Where the work or any of its elements is in the public domain under applicable law, that status is in no way affected by the license.
Other Rights � In no way are any of the following rights affected by the license:
Your fair dealing or fair use rights, or other applicable copyright exceptions and limitations;
The author's moral rights;
Rights other persons may have either in the work itself or in how the work is used, such as publicity or privacy rights.itself or in how the work is used, such as publicity or privacy rights.

Full license is in separate file.

Have fun