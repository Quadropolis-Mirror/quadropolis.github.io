.:ORIGIN by Theso:.
[With assistance from: Redon and Suicizer]

	Origin is a small map for use with the Sauerbraten Engine. It supports FFA, Teamplay, Instagib and all other non-objective game modes. I created the original map, and Redon and Suicizer helped with detail, ammo placement, and additional layout. Thanks guys!
	I hereby license this content under the Creative Commons (BY-NC) license. You are free to modify this map and distribute your creation, as long as I am credited as the original author and the content remains non-commercial.

You may contact me at: johniwas@gmail.com


Thank you for downloading my map! 


Theso:.
2009   