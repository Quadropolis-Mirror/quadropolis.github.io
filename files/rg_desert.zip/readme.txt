rg_desert made by .rG!|meganus

Do not broke the mappers rules and do not modify this map or you'll be blacklisted on some servers for map cheating