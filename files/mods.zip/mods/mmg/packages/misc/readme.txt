Original file (C) 2005-2006 makkE 
MMG-9 icon made by sunnyd, 2009.