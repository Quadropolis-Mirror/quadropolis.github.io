Modifications made:
-new weapon model (sub machine gun)
-weapon icon

Please enjoy