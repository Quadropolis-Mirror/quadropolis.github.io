all content by zoozie (except of course the staffy sky and textures.)
this is the basic version and im open for suggestions. if it looks like i copied and pasted the entire map i basically did.