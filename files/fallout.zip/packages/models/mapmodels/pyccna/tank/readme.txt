Leopard2.obj is hereby released under CC-BY-NC 3.0 license.
Leopard2.png is hereby released under MIT license.