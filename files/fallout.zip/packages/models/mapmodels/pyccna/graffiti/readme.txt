The following folders' contents are hereby released under CC-BY-NC 3.0 License:
sniper
nuke
evac
alert