_____________________________________________________________________________________________________
           _______                               _______               __ __              
          |     __|.-----.----.--.--.-----.----.|   |   |.-----.-----.|__|  |_.-----.----.
          |__     ||  -__|   _|  |  |  -__|   _||       ||  _  |     ||  |   _|  _  |   _|
          |_______||_____|__|  \___/|_____|__|  |__|_|__||_____|__|__||__|____|_____|__|  
____________________________________________________________________________________________________

A console server monitor for sauerbraten 2006-04-26 release.
Unpack into your base sauerbraten folder and run the binary for your platform (linux or Win32)
the way you normally run a client.
Copy the BAT file on windows and edit for the name of the server monitor EXE,
for linux there is a bash shell script "use_servermonitor" provided.

This monitor will exclude all servers not using the current protocol (for 2006-04-26 release).
It uses SDL libraries so you'll need them installed - a pure server doesn't, 
but this is basically just outputting the "server browser" menu to your console without firing
up the graphics engine.

For Win32 users the output will go to stdout.txt in their base sauerbraten folder;
on linux to /dev/stdout (wherever that's piped to).

Parameters :

	-sX : scan X times, default is 3, max. 123
	-o  : omit update from master server being called

Author contact : MeatROme@Count0.dynDNS.oRg

version 0.11
____________________________________________________________________________________________________

          8""""8                                8""8""8                                  
          8      eeee eeeee  ee   e eeee eeeee  8  8  8 eeeee eeeee e eeeee eeeee eeeee  
          8eeeee 8    8   8  88   8 8    8   8  8e 8  8 8  88 8   8 8   8   8  88 8   8  
              88 8eee 8eee8e 88  e8 8eee 8eee8e 88 8  8 8   8 8e  8 8e  8e  8   8 8eee8e 
          e   88 88   88   8  8  8  88   88   8 88 8  8 8   8 88  8 88  88  8   8 88   8 
          8eee88 88ee 88   8  8ee8  88ee 88   8 88 8  8 8eee8 88  8 88  88  8eee8 88   8 
____________________________________________________________________________________________________
