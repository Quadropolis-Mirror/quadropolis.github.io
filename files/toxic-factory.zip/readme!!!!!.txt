TOXIC FACTORY(ALPHA) BY KHORNE|CHAOS AND TZEENTCH|CHAOS

/+++++++++++INSTALATION+++++++++++\
MERGE BASE FOLDER WITH THE ONE IN THE PACKAGES DIRECTORY.

COPY FOLDER KAOS INTO THE PACKAGES DIRECTORY

ENJOY


                         -                         
                       -m:                        
                      .dmd-                       
                     `oNNNd.                      
       .o+-`        `/smNNh+` `       -:+.        
        oNNmdh+`  :-:oommms+:.:  `+yhdNNs         
         dNNNmo./smNmdydmmyydNds:.yNNNNh`         
         -d/yNmddh+.- `dmm- -`:yNmNNyym-          
            +NNmNd+    dym.  `omNmNN+ `           
         `-+Nm/-hNNds  yhh.`+mNmy..hNo-`          
       `. :mm/`  .omNmhhmhsmNNo.  `-dN: `.        
   ./sdm/:yNd/:/+/:/dNNddhmNh//-/+--sNd:/dyoo.`   
 :hNNNNNNNNNNNNNNNNNNNmhssdNNNNNNmmNNNNNNNNNNNmh: 
   `/sdN/.yNd.-.--.:hNNmddNNs--.-:.-sNd.-mhoo-`   
       `:`:NN+`  :hNNm+mddodNm+.  `-mN/ `-        
         .-+Nm//mmNm+. dNm. /dmmy..hNh-.          
         ```:mNNNmo.  .dNm-  `sdmmdmo``           
         +dsdNNNNh/.-  dNm. ..+yNmmmyhd.          
        `dNmNNy-:odNdhydNNhddNmh/.+mNNNh`         
        omNNmmh-  ---/+dmmo/--/  .sdmNNNs         
       -o/-.        `/ymNmy+`       `./+h+        
                     :NNNNm/                      
                      /NNN/                       
                       oNo                        
                        /  