Disposal - By JWindecker 6/16/09
Small Dm map- 1 week project, includes waypoints, ambient sounds, plenty of weapons, and is fully lit.
Basic Idea was to make a map of mostly curves ( as lots of people have tried ) within the Cube Engine.

Contact: jacobwindecker@hotmail.com	
Xfire: windecker