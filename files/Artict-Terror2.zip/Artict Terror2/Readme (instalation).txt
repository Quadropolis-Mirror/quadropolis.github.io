Layouts by: Makke (c) 
skins by: Deathstar   / skin.jpg / 320x200 / 50.6 ko
                      / skin_hands.jpg/ 512x512/ 152 ko.

credits: http://acka.roxorgamers.com
License: free for non-comercial.

============================================================================
                             HOW TO INSTAL?
============================================================================
INstal Player Skin:

1) Copy skin.jpg

2) Go to "AssaultCube" folder (c:/)

3) Open "packages/models/playermodels/CLA." 

4) Delet or rename one of the 4 actual skin (01.jpg , 02.jpg, 03.jpg, 04.jpg)

5) And remplace the skin you deleted/renamed by the "skin.jpg" (artict skin) 
   (rename it "01.jpg" if you deleted the old "01.jpg")

6) That's ok the new player skin Work!

_____________________________________________________________________________
Bonus Step: if you want have the good player name in skin setup menu.

1) Go To "AssaultCube" folders (c:/)

2) Open "config" subfile and open with Wordpad "menus.cfg"

3) Search line: << newmenu "cla" >>


4) You have 4 lines after:

<< menuitem "Comandante"           "skin 0" "chmenumdl cla playermodels/CLA/01 all 50 4"
menuitem "Psycho"               "skin 1" "chmenumdl cla playermodels/CLA/02 all 50 4"
menuitem "Bomber"               "skin 2" "chmenumdl cla playermodels/CLA/03 all 50 4"
menuitem "Ripper"               "skin 3" "chmenumdl cla playermodels/CLA/04 all 50 4" >>

If you remplaced 01.jpg you have to modify the 1st line, if 02.jpg the 2nd line etc...



5) We take for example the first line (wich is for "01.jpg")

<< menuitem "Comandante"           "skin 0" "chmenumdl cla playermodels/CLA/01 all 50 4" >>

& change "Comandante" to "Artict Terror"


6) You have this now:
menuitem "Artict Terror"           "skin 0" "chmenumdl cla playermodels/CLA/01 all 50 4" 


7) Save menus.cfg and Run Assault Cube!

___________________________________________________________________________________________

INstal Skin_Hands:

1) Go to AssaultCube folder (c:/)

2) Open "packages/models/weapons"

3) And in all subfiles remplace original "skin_hands.jpg" By the Artict One.

4) Run Assault Cube, and it Works ;) 

