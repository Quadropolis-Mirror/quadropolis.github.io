This texture is a blend of the Lunaran rock tex, and the Gor sand tex. Thanks to the creators of both sets for their fine textures!

SATAN!!! April 24, 2008