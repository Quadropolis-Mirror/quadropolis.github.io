 This skybox, desert04b, is a slightly reorded instance (so the sun is in the right spot) of Desert04, which was created by Dash. Thanks Dash, and thanks to the wadfather site for hosting Dash's skyboxes.
 
SATAN!!! April 24, 2008