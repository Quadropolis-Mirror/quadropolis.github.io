Sauerbraten map: "access"
Created by SATAN!!!, and completed on April 24, 2008.
-----------------------------------------------------


This regen/capture/ffa map was created mainly using Lunaran's excellent q4power texture set. The skybox used is a slightly reorded (so the sun is in the right spot) series created by Dash, found at the Wadfather site. Thanks Lunaran and Dash!

This map requires a build greater-than the "Assassin Edition" version of Cube2/Sauerbraten.


-----------------------------------------------------
SATAN!!! is very thankful for a whole host of people who offered sound advice, encouragement, and excellent feedback, including:
 eihrul
 Drakkar
 Hirato
 Nieb
 Demosthenes
 Pbrane
 clan The Conquerors in general, and in particular:
    Schmutzwurst
    Andi
    Jorge
    Hero
 and all the fine people in #sauerbraten channel on the QuakeNet IRC network.
 
 
-----------------------------------------------------
License:
 This map is released under the Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 United States License, with the following clause: the author will allow for minor bug fixing should the author be unavailable.
 
 You are free to copy, distribute, and display this work. You must attribute the work to the original author, "SATAN!!!" (but not in any way that suggests that the author endorses you or your use of the work).  You may not use this work for commercial purposes. You may not alter, transform, or build upon this work, save for minor bug fixing should the author be unavailable.