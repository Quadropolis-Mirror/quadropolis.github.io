============================================================================================
SunDreamCanyon_Capture by MukiHyena
============================================================================================
08/13/2007
============================================================================================
Installation:

Extract SunDreamCanyon_Capture.jpg, SunDreamCanyon_Capture.ogz, and SunDreamCanyon_Capture.cfg into the Sauerbraten/Packages/Base directory.

Also included is a modified "Menus.cfg" that you may want to put into the Sauerbraten/Data directory; it includes the map in the GUI under the "Capture" map category. However, I suggest reading over the following documentation to understand exactly what I did:

http://cube.wikispaces.com/Script+Demo+-+Map+Menu
============================================================================================
Introduction:
Basically a few months ago, I had a dream about a custom Halo level. Now usually I forget my dreams right after I have them, but for some strange reason this level was stuck in my mind.

After a while, I thought to myself, "That map would actually make for some very interesting gameplay." However, due to my lack of experience in Halo mapping, I turned to Sauerbraten and tried my hand at a first map.

After posting my first SunDreamCanyon map and getting negative feedback, I decided to add what I felt was missing; more tunnels to allow more maneuverability, capture points (BIG improvement), windows that you can jump from, and lighting in the tunnels.

============================================================================================
Contact:

E-Mail: kamunouhyena@gmail.com

MSN: kamunouhyena@hotmail.com

XBox Live: Muki Hyena