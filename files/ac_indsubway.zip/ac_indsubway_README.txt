ac_indsubway_README
----------------------------------------------------------------------
The map ac_indsubway was made by Dvorakk. You are free to play on this map, but you are not allowed to edit this work without permission or claim this work as yours.
---------------------------------------------------------------------------------------------------------------
Intended for CTF matches, but can be played with any other team modes. 4-10 players.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Happy Shooting =D