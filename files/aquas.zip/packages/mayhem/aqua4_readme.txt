Aqua4 skybox by Mayhem  Licensed under CC-BY-SA

	I used Bryce 6 to create this underwater skybox which consists of 6 .jpg files at 1024x1024.  The models seen are from various free download sites.  One of those is www.3dplants.com which provided the aquatic plant models.  The others are lost in obscurity.

	I was inspired by an IRC conversation and though the application of it may be limited, I decided to give it a try.  This is the result.  Enjoy!
