******************************************************************************************
DeathStar's Textures V1.0 2010
******************************************************************************************
NOTE 

Some of the textures were taken by DeathStar and some were found, they can be used on whatever map you want, but only with Sauerbraten. There's allot of textures, its a real mix so pick wisely.

USAGE 

You are free to use these textures on any map, please enjoy!

LICENCE

The textures are under the Zlib license: http://www.zlib.net/zlib_license.html

DIRECTIONS

To load them, save a map, then create a .cfg file for the map with the following text: 

texture 0 "deathstar/nameoftexture.png" 

Save the cfg and load the map, press F2, (mac users FN F2), and go to the last page, one of my textures should be there (last slot) Enjoy! 

If you have a problem or if you need any help, email me: x90265@gmail.com

