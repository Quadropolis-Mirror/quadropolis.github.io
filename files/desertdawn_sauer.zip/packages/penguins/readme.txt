Released under the Creative Commons BY-SA License
http://creativecommons.org/licenses/by-sa/3.0/

sky/cloud boxes created by SkiingPenguins (roy153roy153@yahoo.com)
Originally created for the first person shooter Cube 2: Sauerbraten
This readme must always be included with the skybox files.

I would like to know where and in what games my skyboxes are used.
If you do use them, please send me an email. I'd love to play whatever game you put them in.