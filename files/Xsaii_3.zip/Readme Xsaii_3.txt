How to play this map:

Extract 'xsaii_3.ogz' and 'xsaii_3.cfg' into your 'Sauerbraten/packages/base' folder.

Run Sauerbraten as usual.

Press ` or t (as default) and enter '/map xsaii_3'

Have fun.





~Xsaii

Released on 09/15/2006.

Free to distribute as long as the map, cfg and this readme are together and unedited.