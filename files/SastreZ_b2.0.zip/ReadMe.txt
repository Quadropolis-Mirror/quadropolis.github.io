===========================================================================================
                                     RatBoy's Cubic Maps
===========================================================================================
File Details:

Game:                Cube (www.cubeengine.com)
Game Version:        29-08-2005
Game Mode:           DeathMatch
Map Name:            Anonimous Fortress A.K.A. SastreZ
Map Version:         Beta 2.0
Building Time:       Almost a month.
Release Date:        March 2003
Author:              Pablo "RatBoy" Ciamarra
E-Mail:              ratboy_jo@hotmail.com
Description:         A medium sized deathmatch arena, from 4 to 8 players is recomended
                     but it could hold a little more. It's set in the same futuristic
                     rusty facility thingy as KatreZ.
WQD Count:           Top of 3000 at both bigger areas.
Textures:            Iikka "Fingers" Keranen, Sock, Than & John Fitzgibbons.
Skybox:              "Sock"
                     (www.planetquake.com/simland)

===========================================================================================
Map's Story:

 During the war in the Estrada system, SastreZ was a part of the Feather War Factory that
wasn't even built. When the war was over and the Identi planet finally conquered, the
factory tried to get more commercial, and started producing for other systems and for other
wars. To do so, the SastreZ sector was built, it's purpouse was to be the reception for
visitors, burocratic employees and other stuff like that.

 But one day one visitor's son brought an ear worm he had as pet secretly into the base,
this ear worm escaped this kid's pocket and started reproducing, soon the whole sector was
infested with them, every living being was affected by these worms, and acted irrationally.

 Soldiers began shooting everyone, burocrats began to sue everyone, soon the whole 
sector was dead, and the factory closed. Thats when the owner put both Katrez and SastreZ
sector to the purpouse of deathmatch.

 It's rumored that the ghosts of the burocrats still roam these hallways, annoying everyone
with burocratic crap.

===========================================================================================
Developer Notes:

- This is actually my very first map, originally called Anonimous Fortress, but since it
  uses the same texture set as KatreZ I thought of making it part of the Feather War
  Factory, calling it SastreZ.

- This version of the map got old. If you find any graphical or gameplay bug, try to
  download the last version and see if it is still there, in that case, send it to my mail.
  And if you can with a picture of the bug. Thanks.

- The lighning issue. I simply can't get along with Cube's ilumination system, I just
  can't make it work, this is as far as I could get it to look, anyways, there's always
  the Sauerbraten version ;)

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to Cube main folder.

Mannually:
"sastrez.cfg" and "sastrez.cgz" should go into "Cube\packages\base" folder.

===========================================================================================
Version History:

Beta 2.0:
- Small fixes everywhere, retextured some things and added some detail.
- Every item and playerstart entities were repositioned for better gameplay.
- Added jungly mapmodels to the outside.

===========================================================================================
Copyright & Permissions:

Cube Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.cubeengine.com)

This level is copyrighted by Pablo Ciamarra 2006.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================