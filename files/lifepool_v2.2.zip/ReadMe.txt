===========================================================================================
                               RatBoy's Sauerbraten Cubic Maps
===========================================================================================
File Details:

Game:                Sauerbraten (www.cubeengine.com)
Game Version:        19-08-2007
Game Mode:           DeathMatch
Map Name:            Lifepool
Map Version:         Retail 2.2
Building Time:       One month and a half.
Release Date:        October 17, 2007
Author:              Original map by NEXUS
                     Modified by Pablo "RatBoy" Ciamarra
E-Mail:              NEXUS: F14_A_Tomcat@hotmail.com
                     RatBoy: ratboy_jo@hotmail.com
Description:         A small 1on1 deathmatch map set in a medieval room with many columns
                     and a big beautyfull pool in the middle.
Textures:            Iikka "Fingers" Keranen, Sock & Schwenz.
                     Custom textures by Sean Johnson, Yves Allaire & Speedy.
                     Modified textures and additional normal mapped textures by myself.
Mapmodels:           dcp, makkE & Nieb.
Skybox:              Jose "Jaj" Arcediano
                     (www.planetquake.com/jaj)

===========================================================================================
Map's Story:

 Long ago this was a place of magic, misteries and many battles. But sadly an evil wizard
locked it up for himself, and called it "My Robe's Personal Bathroom", for the only purpose
of washing his mighty robe.

 Time passed and the wizard die drowned by his own magical robe. The place was forgotten
and the robe went on to become a musician. In the present the place was found by a
wandering fella who donated it for deathmatch.

===========================================================================================
Developer Notes:

- The original version made by NEXUS was only released for Cube. I've modified it a lot,
  and after that ported it to Sauerbraten and modified a lot more, there's a lot of new
  textures and a lot of more detail, thanks to Sauer's features.

- Normal, parallax & specular textures were made with CrazyBump (www.crazybump.com). A
  simple and easy but powerfull program, I recommend you all using it for your projects
  (I'm not being paid for this note, nor blackmailed :P). The results were modified with
  Photoshop so they looked better ingame.

- Nobody is perfect. This map could have and probably has bugs, either graphical or of
  gameplay. If you happen to spot any bug, regardless how insignificant it may be, you're
  welcome to send a notice to my mail so I can fix it in a future version. Thanks.

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to Sauerbraten main folder.

Mannually:
"ratboy" folder goes into "Sauerbraten\packages\" folder.
"lifepool.cfg", "lifepool.cgz" & "lifepool.jpg" should go into "Cube\packages\base" folder.

===========================================================================================
Version History:

Retail 1.0:
- Mainly texture changes and some minor detailing.
- Redistributed entities for better gameplay.

Retail 1.1:
- Retextured with Sauerbraten version's textures.
- Corrected some places and minor detailing.

Retail 2.0:
- Ported from Cube to Sauerbraten.
- Improved the detail of the map with Sauer's engine.
- Replaced some of the textures.
- New and kinky lightning all over the place.
- Some mapmodels around to make more detail.

Retail 2.1:
- New and kinky modified textures to suit the archs and borders, by myself with photoshop.
- Removed clipped lamps for better gameplay.
- More detail everywhere.

Retail 2.2:
- Normal mapped the whole level, it looks a lot prettier.
- Added some minor details here and there for better looks.
- Fixed around the lightning entities.

===========================================================================================
Copyright & Permissions:

Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)

This level is copyrighted by NEXUS & Pablo Ciamarra 2006-2007.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================