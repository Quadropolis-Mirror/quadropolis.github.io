industry by shuaRx

first map, it's a small ctf/dm map, maybe up to 8 players. i made it to try out the grenade chutes and sniper boxes. any feedback is greatly appreciated.

some notes (in the case that you get stuck with this stuff):

0	to get out of the grenade chute area, you can weapon jump out, or you can jump up against the corners.

0	the sniper boxes are one-way, and you can only use rifle, rocket launcher, and pistol in it.

0	the grenade area has 6 little boxes, 3 on each side, try shooting a grenade into the grilled part and see what happens.

0	the up chutes, as you might have found out, are one way.

0	there is a secret entrance in lower area.

0	if you fall down at either one of the bridges it is possible to get back up.

0	yes i know it's dark and foggy. (but if you have any input as to lights that would make it better, feel free to comment at Quadropolis)

*notes on using this map*
you can use this map for anything, just don't take or give credit to anyone but me (ShuaRx), you can even say anonymous or just include this README. i just don't want anyone taking credit, but you don't have to ask me to use it for anything, just give me credit, and it you're using it for a mod, i'd like to know out of curiousity.

that's about it.
