A quick remake of the logo I made. I thought it looked interesting so I posted it.
Contact: jacobwindecker@hotmail.com
Xfire: windecker