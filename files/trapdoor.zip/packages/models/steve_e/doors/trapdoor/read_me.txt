//trapdoor by Steve Eggleston, January 2008

//Set the following in your map.cfg

mapmodelreset 
mmodel "steve_e/doors/trapdoor"                 //4x4 sized door
mmodel "steve_e/doors/trapdoor/trapdoor_150"    //6x6 sized door
mmodel "steve_e/doors/trapdoor/trapdoor_200"     //8x8 sized door

