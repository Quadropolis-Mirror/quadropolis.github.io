bfmods by 00Hugo00

To execute a mod, type :

/exec mod/<name of mod>.cfg

replace <name of mod> by a mod name. Look first the mod names !