I am posting this map becuase KI113R can't:



	The Floating Stone Temple

Until the ice age this was a beautiful scenic place of peace and serenity.
Now that the place is ridden with falling ice and snow, it has been used to bring about
death through weapons and hypothermia. The death threw weapons comes about by death
match a brutal sport created by Ogro's in which the objective is to kill one another. As for
hypothermia, ones that are too weak are left to the mercy of the cold fierce winter wind, sure
enough they die. If you�re brave enough ill meet you at this location, bring your rifle or you�re going
to die, no doubt.


Sky Box is by SkiingPenguins

