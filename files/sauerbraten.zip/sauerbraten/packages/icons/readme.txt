=======================================
KIPSTA GRAFIX 2007 - ICONS
=======================================

action.jpg
checkbox_off.jpg
checkbox_on.jpg
exit.jpg
info.jpg
menu.jpg
ogro.jpg
radio_on.jpg
server.jpg

EDITED & MODIFIED by Kipsta 2007
(Originals by Markus "makkE" Bekel)

=======================================

player_blue.jpg
player_red.jpg
player.jpg
radio_off.jpg

CREATED by Kipsta 2007

=======================================

sauer.jpg

EDITED & MODIFIED by Kipsta 2007
(Don't know where original Files from :/ )

=======================================