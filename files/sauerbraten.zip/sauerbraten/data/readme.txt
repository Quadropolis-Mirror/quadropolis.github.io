=======================================
KIPSTA GRAFIX 2007 - GUI / ITEMS
=======================================

guioverlay.png
guiskin.png
guislider.png

EDITED & MODIFIED by Kipsta 2007
(Originals by Markus "makkE" Bekel)

=======================================

radar.png

CREATED by Kipsta 2007

=======================================

guicursor.png
items.png

CREATED by Kipsta 2007

=======================================