README for Core Ravage + License
--------------------------------------------------------------------------

First off, the license.. BY NC SA

You are free to use and distribute this map for NON-PROFIT purposes. You must also acknowledge me (Kedric Bradley) as the creator of whatever content in this folder you distribute. You may not, then, take credit for this work. You can also alter this work so long as you do not alter the license or disassociate this license to the derivative work. If you contact me, you can request to have any of these conditions waived with good reason.

Link to this license:

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/ca/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/2.5/ca/88x31.png" /></a><br /><span xmlns:dc="http://purl.org/dc/elements/1.1/" property="dc:title">Core Transfer</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Kedric Bradley</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/ca/">Creative Commons Attribution-Noncommercial-Share Alike 2.5 Canada License</a>.

--------------------------------------------------------------------------

GAMEPLAY: 

The map was designed with heavy influences from Reissen. This is seen in the architecture, textures, and some parts of the layout. However, it was also designed to function in a much different way than Reissen.

The first notable thing is that the map is in an L-shape. This makes it so that sniping is a little bit more difficult and movement is not entirely focused in one direction. Plus it's a bit easier on the processor, and this map pushed most.

It is possible to get from end to end without using the high platforms, but it's not strategic. The easy routes are the slow ones. The higher platforms give a more tactical edge. However they're also more dangerous: If one falls into the water pits below they die.

This map is intended for CTF. I have playerstarts set up for each team and individuals for DM. Bases are also set up for regen capture, but the layout has been calibrated for CTF mostly. Since there are so many rifle-jump areas, ICTF is likely the game mode of choice here.

Finally, there is a secret route that can, in theory, take one directly to each flag. Hopefully people won't figure it out too soon...


CREDITS

This project has been done entirely on my own. I worked out the .cfg, the map layout, textures, architecture, technical details, and screenshot.
In time people may play a role in playtesting, and if so they may be mentioned here.