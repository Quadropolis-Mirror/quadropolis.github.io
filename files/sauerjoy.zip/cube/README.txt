   
                     Cube Game Controller Support
              
                                 by

                      dbox (dwbox@hotmail.com)
-------------------------------------------------------------------------------

STEP 1: Backup the following files if you want to keep the original version:
        - config.cfg
        - data/keymap.cfg
        - src/engine/main.cpp

STEP 2: Extract this archive into your Sauerbraten directory.

STEP 3: Customize the config.cfg settings for your controller.

STEP 4: Execute the cubejoy.bat file to play.