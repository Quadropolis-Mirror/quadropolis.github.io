   
                 Sauerbraten Game Controller Support
              
                                 by

                      dbox (dwbox@hotmail.com)
-------------------------------------------------------------------------------

STEP 1: Backup the following files if you want to keep the original version:
        - data/keymap.cfg
        - src/engine/console.cpp
        - src/engine/main.cpp
        - src/engine/menus.cpp

STEP 2: Extract this archive into your Sauerbraten directory.

STEP 3: Execute the sauerjoy.bat file.

STEP 4: Configure the joystick using the dynamic menus under Options->Joystick