THE TUNNEL by Acieeed

Relase Date: 3.may 2005

Description: Great deathmatch map with long tunnel passages.

Changes    : Some Textur and model changes. Map look�s better.

This map is inspired by Half-Life and is my first True map for Cube.