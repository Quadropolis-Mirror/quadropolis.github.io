Texures by hipshot @ www.zfight.com
thx hipshot, awesome skyboxes ^_^.

1024^2x6

cuted & named for sauer by sky.
