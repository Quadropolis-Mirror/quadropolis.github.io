Readme for map OverDrive(Version 2) by Greaserpirate

The amazing skybox was made by hipshot (contact him @ www.zfight.com).
The pulsing one-way-gate texture was made my Meister.
None of the textures were modified in any way except by the "vtex" commands.
