Welcome to the Mines of Titan 2 Mod for the Cube Engine.
This is considered version 0.1.2

This file can be unzipped in the cube root directory. It places a motcube.bat file in the directory. There is a new executable called motcube.exe in the bin folder,
and the motcube.bat file calls that file to start the game with a resolution of 1024x768.

In order to use the new menu, use the M key. This menu is set up with the new file, motcube.cfg which is in the data/MoT directory.

exec data\MoT\motcube.cfg

You can also use this line at the console to run the menu script. If this menu is used in regular cube, it may give an error when you try to use the menu to re-roll your character statistics or some other Mines of Titan feature.

Finally, the source code files are unzipped into the Source directory.

Here is a listing of all the files you can look forward to seeing:
. - motcube.bat
.\bin - motcube.exe
.\MoTSource - (Everything you should need to recompile the source code to create the game executable. This directory and its contents are not needed to run the game mod.)
.\data\MoT - (This directory contains the motcube.cfg and StatSheetBackgroundIcon.png files.)

This game should not interfere (much) with your regular cube game, so you won't need to copy the directory.

If you wish to create a simple shortcut to run the game mod in Windows, create a shortcut to the motcube.bat file instead of to the motcube.exe file, so that the .bat file can set the game's resolution.

Please send all advice, comments, inquiries, and questions to jayman29@starspath.com so that I can improve this mod for your tastes.

--- Jay