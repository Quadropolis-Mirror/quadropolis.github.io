// renderhud.cpp: gl render code for the HUD

#include "cube.h"

/* JJT - Standard HUD data is still to be found in the renderextras.cpp file.
*/

void SetHudDisplay (int DisplayNumber) {
	player1->showstatsheet = DisplayNumber;
	};
COMMAND(SetHudDisplay, ARG_1INT);

void DrawHudSkull (int CenterX, int CenterY, int SkullScale) {
	glDepthMask(GL_FALSE);
	glDisable(GL_TEXTURE_2D);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_COLOR);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glColor3d(1.0, 0.0, 0.0);

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX + SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX + SkullScale, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale, CenterY - SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale, CenterY - SkullScale * 6);
	glVertex2i(CenterX + SkullScale, CenterY - SkullScale * 6);
	glVertex2i(CenterX + SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX - SkullScale * 3, CenterY - SkullScale * 4);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 2, CenterY - SkullScale * 6);
	glVertex2i(CenterX - SkullScale, CenterY - SkullScale * 6);
	glVertex2i(CenterX - SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX - SkullScale * 4, CenterY - SkullScale * 4);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX + SkullScale, CenterY - SkullScale * 6);
	glVertex2i(CenterX + SkullScale * 2, CenterY - SkullScale * 6);
	glVertex2i(CenterX + SkullScale * 4, CenterY - SkullScale * 4);
	glVertex2i(CenterX + SkullScale * 3, CenterY - SkullScale * 4);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 4, CenterY - SkullScale * 4);
	glVertex2i(CenterX - SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX - SkullScale * 3, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 4, CenterY - SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX + SkullScale * 3, CenterY - SkullScale * 4);
	glVertex2i(CenterX + SkullScale * 4, CenterY - SkullScale * 4);
	glVertex2i(CenterX + SkullScale * 4, CenterY - SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 3, CenterY - SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 4, CenterY - SkullScale * 2);
	glVertex2i(CenterX, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale, CenterY);
	glVertex2i(CenterX - SkullScale * 4, CenterY);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX, CenterY - SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 4, CenterY - SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 4, CenterY);
	glVertex2i(CenterX + SkullScale, CenterY);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale / 4, CenterY - SkullScale / 3);
	glVertex2i(CenterX + SkullScale / 4, CenterY - SkullScale / 3);
	glVertex2i(CenterX + SkullScale / 4, CenterY);
	glVertex2i(CenterX - SkullScale / 4, CenterY);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 4, CenterY);
	glVertex2i(CenterX + SkullScale * 4, CenterY);
	glVertex2i(CenterX + SkullScale * 2, CenterY + SkullScale);
	glVertex2i(CenterX - SkullScale * 2, CenterY + SkullScale);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 2, CenterY + SkullScale);
	glVertex2i(CenterX + SkullScale * 2, CenterY + SkullScale);
	glVertex2i(CenterX + SkullScale * 2, CenterY + SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 2, CenterY + SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX + SkullScale * 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX + SkullScale, CenterY + SkullScale * 5);
	glVertex2i(CenterX - SkullScale, CenterY + SkullScale * 5);

	glEnd();

	xtraverts = xtraverts + 48;
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(GL_TRUE);
};

void DrawHudCrossBones (int CenterX, int CenterY, int SkullScale) {
	glDepthMask(GL_FALSE);
	glDisable(GL_TEXTURE_2D);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_COLOR);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glColor3d(1.0, 0.0, 0.0);

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 5, CenterY + SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 4, CenterY + SkullScale * 5 / 2);
	glVertex2i(CenterX + SkullScale * 5, CenterY - SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 4, CenterY - SkullScale * 5 / 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX + SkullScale, CenterY + SkullScale);
	glVertex2i(CenterX + SkullScale * 4, CenterY + SkullScale * 5 / 2);
	glVertex2i(CenterX + SkullScale * 5, CenterY + SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 2, CenterY + SkullScale / 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 5, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 2, CenterY - SkullScale / 2);
	glVertex2i(CenterX - SkullScale, CenterY - SkullScale);
	glVertex2i(CenterX - SkullScale * 4, CenterY - SkullScale * 5 / 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX + SkullScale * 9 / 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX + SkullScale * 11 / 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX + SkullScale * 11 / 2, CenterY + SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 9 / 2, CenterY + SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX + SkullScale * 9 / 2, CenterY - SkullScale * 3);
	glVertex2i(CenterX + SkullScale * 11 / 2, CenterY - SkullScale * 3);
	glVertex2i(CenterX + SkullScale * 11 / 2, CenterY - SkullScale * 2);
	glVertex2i(CenterX + SkullScale * 9 / 2, CenterY - SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 11 / 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX - SkullScale * 9 / 2, CenterY + SkullScale * 3);
	glVertex2i(CenterX - SkullScale * 9 / 2, CenterY + SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 11 / 2, CenterY + SkullScale * 2);

	glEnd();

	glBegin(GL_QUADS);

	glVertex2i(CenterX - SkullScale * 11 / 2, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 9 / 2, CenterY - SkullScale * 2);
	glVertex2i(CenterX - SkullScale * 9 / 2, CenterY - SkullScale * 3);
	glVertex2i(CenterX - SkullScale * 11 / 2, CenterY - SkullScale * 3);

	glEnd();

	xtraverts = xtraverts + 28;
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glDepthMask(GL_TRUE);
};

void DrawHudJollyRoger (int CenterX, int CenterY, int SkullScale) {
	DrawHudSkull (CenterX, CenterY - SkullScale * 6, SkullScale);
	DrawHudCrossBones (CenterX, CenterY + SkullScale * 2, SkullScale);
};

void SwitchStatSheet () {
	if (player1->showstatsheet == 0 ) {
		player1->showstatsheet = player1->showstatsheet + 1;
		player1->StatSheetAdjust = 1760;
		}
	else {
		player1->showstatsheet = 0;
		player1->StatSheetAdjust = 0;
		}
};
COMMAND(SwitchStatSheet, ARG_NONE);

void DrawStatLine (float LeftX, float UpperY, float RightX, float LowerY, float RedColor, float GreenColor, float BlueColor) {
	float TextureX = 0.0f;
	float TextureY = 0.0f;

	TextureX = DifferenceFraction(RightX, LeftX);
	TextureY = DifferenceFraction(LowerY, UpperY);

	        glBegin(GL_QUADS);

		glColor3d(RedColor, GreenColor, BlueColor);

		if (player1->showstatsheet == 1 && GreenColor > 0) {
			glColor3d(0.0, 0.0, 0.0);
			}

	        glTexCoord2d(0.0, 0.0);
		glVertex2f(LeftX, LowerY);
        	glTexCoord2d(0.0, TextureY);
		glVertex2f(LeftX, UpperY);
        	glTexCoord2d(TextureX, TextureY);
		glVertex2f(RightX, UpperY);
        	glTexCoord2d(TextureX, 0.0);
		glVertex2f(RightX, LowerY);

        	glEnd();
};

void DrawStatSheetEdgeLeft (int w, int h) {
		glColor3d(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, 22);

		glBegin(GL_POLYGON);

		if (player1->StatSheetAdjust > 0) {
			glTexCoord2f(0.0f, 14.0f);
			glVertex2i(w, 1740 + player1->StatSheetAdjust);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2i(w, 60 + player1->StatSheetAdjust);
			glTexCoord2f(1.0f, 0.0f);
			glVertex2i(w + 60, 60 + player1->StatSheetAdjust);

			loopi(28) {
				glTexCoord2f(1.0f, i / 2 + 1/24);
				glVertex2i(w + 60, i * 60 + 65 + player1->StatSheetAdjust);
				glTexCoord2f(5/6, i / 2 + 1/24);
				glVertex2i(w + 50, i * 60 + 65 + player1->StatSheetAdjust);
				glTexCoord2f(5/6, i / 2 + 23/24);
				glVertex2i(w + 50, i * 60 + 115 + player1->StatSheetAdjust);
				glTexCoord2f(1.0f, i / 2 + 23/24);
				glVertex2i(w + 60, i * 60 + 115 + player1->StatSheetAdjust);
					if (i == 55) {
						glTexCoord2f(1.0f, 14.0f);
						glVertex2i(w + 60, 1740 + player1->StatSheetAdjust);
						}
				}
			}

		else {
			glTexCoord2f(0.0f, 14.0f);
			glVertex2i(w, 1740);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2i(w, 60);
			glTexCoord2f(1.0f, 0.0f);
			glVertex2i(w + 60, 60);

			loopi(28) {
				glTexCoord2f(1.0f, i / 2 + 1/24);
				glVertex2i(w + 60, i * 60 + 65);
				glTexCoord2f(5/6, i / 2 + 1/24);
				glVertex2i(w + 50, i * 60 + 65);
				glTexCoord2f(5/6, i / 2 + 23/24);
				glVertex2i(w + 50, i * 60 + 115);
				glTexCoord2f(1.0f, i / 2 + 23/24);
				glVertex2i(w + 60, i * 60 + 115);
					if (i == 55) {
						glTexCoord2f(1.0f, 14.0f);
						glVertex2i(w + 60, 1740 + player1->StatSheetAdjust);
						}
				}
		}
		glEnd();

		xtraverts += 116;

	};

void DrawStatSheetEdgeRight (int w, int h) {
		glColor3d(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, 22);

		glBegin(GL_POLYGON);

		if (player1->StatSheetAdjust > 0) {
			glTexCoord2f(0.0f, 14.0f);
			glVertex2i(w, 1740 + player1->StatSheetAdjust);

			loopi(28) {
				glTexCoord2f(0.0f, (55-i) / 2 + 23/24);
				glVertex2i(w, (55-i) * 60 + 55 + player1->StatSheetAdjust);
				glTexCoord2f(1/6, (55-i) / 2 + 23/24);
				glVertex2i(w + 10, (55-i) * 60 + 55 + player1->StatSheetAdjust);
				glTexCoord2f(1/6, (55-i) / 2 + 1/24);
				glVertex2i(w + 10, (55-i) * 60 + 5 + player1->StatSheetAdjust);
				glTexCoord2f(0.0f, (55-i) / 2 + 1/24);
				glVertex2i(w, (55-i) * 60 + 5 + player1->StatSheetAdjust);
				if (i == 55) {
					glTexCoord2f(0.0f, 0.0f);
					glVertex2i(w, 60 + player1->StatSheetAdjust);
					}
				}

			glTexCoord2f(1.0f, 0.0f);
			glVertex2i(w + 60, 60 + player1->StatSheetAdjust);
			glTexCoord2f(1.0f, 14.0f);
			glVertex2i(w + 60, 1740 + player1->StatSheetAdjust);
			}

		else {
			glTexCoord2f(0.0f, 14.0f);
			glVertex2i(w, 1740);

			loopi(28) {
				glTexCoord2f(0.0f, (55-i) / 2 + 23/24);
				glVertex2i(w, (55-i) * 60 + 55);
				glTexCoord2f(1/6, (55-i) / 2 + 23/24);
				glVertex2i(w + 10, (55-i) * 60 + 55);
				glTexCoord2f(1/6, (55-i) / 2 + 1/24);
				glVertex2i(w + 10, (55-i) * 60 + 5);
				glTexCoord2f(0.0f, (55-i) / 2 + 1/24);
				glVertex2i(w, (55-i) * 60 + 5);
				if (i == 55) {
					glTexCoord2f(0.0f, 0.0f);
					glVertex2i(w, 60);
					}
				}

			glTexCoord2f(1.0f, 0.0f);
			glVertex2i(w + 60, 60);
			glTexCoord2f(1.0f, 14.0f);
			glVertex2i(w + 60, 1740);
		}

		glEnd();

		xtraverts += 116;

	};

void gl_drawstatsheet (int w, int h, int curfps, int nquads, int curvert)
{
	if (player1->StatSheetAdjust > 0) {
		player1->StatSheetAdjust = player1->StatSheetAdjust - 88;
		}
	if (player1->StatSheetAdjust < 0) {
		player1->StatSheetAdjust = 0;
		}

/* JJT - Leave the left side of the screen clear for messages. */
	int RightStatX = 2200;
	int MoneyStatX = 240;
	int UpperStatY = 90 + player1->StatSheetAdjust*3/2;
	int MoneyStatY = 1080 + player1->StatSheetAdjust*3/2;

    readmatrices();
/*	if(editmode) {
		return;
		}
*/

    glDisable(GL_DEPTH_TEST);
    invertperspective();
    glPushMatrix();  
    glOrtho(0, VIRTW, VIRTH, 0, -1, 1);

/*	if(dblend || underwater) {
		};
		*/

    glEnable(GL_TEXTURE_2D);

    renderscores();
    if(!rendermenu()) {
        glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 1: cross. Type 4: box. */

	if (player1->StatSheetAdjust > 0) {
		DrawTexturedBox(0.0, 0.0, 1.0, 14.0, 60, 60 + player1->StatSheetAdjust, 2340, 1740 + player1->StatSheetAdjust, 22, 1);
		}
	else {
		DrawTexturedBox(0.0, 0.0, 1.0, 14.0, 60, 60, 2340, 1740, 22, 1);
		}

/*	loopi(56) {
		        glBegin(GL_QUADS);
        		glColor3ub(0,0,0);

			if (player1->StatSheetAdjust > 0) {
			        glTexCoord2d(0.0, 1.0);
				glVertex2f(80, i * 30 + 75 + player1->StatSheetAdjust);
	        		glTexCoord2d(1.0, 1.0);
				glVertex2f(90, i * 30 + 65 + player1->StatSheetAdjust);
	        		glTexCoord2d(1.0, 0.0);
				glVertex2f(100, i * 30 + 75 + player1->StatSheetAdjust);
        			glTexCoord2d(0.0, 0.0);
				glVertex2f(90, i * 30 + 85 + player1->StatSheetAdjust);
				}
			else {
			        glTexCoord2d(0.0, 1.0);
				glVertex2f(80, i * 30 + 75);
	        		glTexCoord2d(1.0, 1.0);
				glVertex2f(90, i * 30 + 65);
	        		glTexCoord2d(1.0, 0.0);
				glVertex2f(100, i * 30 + 75);
        			glTexCoord2d(0.0, 0.0);
				glVertex2f(90, i * 30 + 85);
				}

	        	glEnd();

		        glBegin(GL_QUADS);
        		glColor3ub(0,0,0);

			if (player1->StatSheetAdjust > 0) {
				glTexCoord2d(0.0, 1.0);
				glVertex2f(2300, i * 30 + 75 + player1->StatSheetAdjust);
		        	glTexCoord2d(1.0, 1.0);
				glVertex2f(2310, i * 30 + 65 + player1->StatSheetAdjust);
        			glTexCoord2d(1.0, 0.0);
				glVertex2f(2320, i * 30 + 75 + player1->StatSheetAdjust);
        			glTexCoord2d(0.0, 0.0);
				glVertex2f(2310, i * 30 + 85 + player1->StatSheetAdjust);
				}
			else {
			        glTexCoord2d(0.0, 1.0);
				glVertex2f(2300, i * 30 + 75);
	        		glTexCoord2d(1.0, 1.0);
				glVertex2f(2310, i * 30 + 65);
	        		glTexCoord2d(1.0, 0.0);
				glVertex2f(2320, i * 30 + 75);
        			glTexCoord2d(0.0, 0.0);
				glVertex2f(2310, i * 30 + 85);
				}

	        	glEnd();
		}
*/

    glPopMatrix();

    glPushMatrix();    
    glOrtho(0, VIRTW*4/3, VIRTH*4/3, 0, -1, 1);
    renderconsole();

	if(!player1->hidestats) {
	        glPopMatrix();
        	glPushMatrix();
	        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);
        	draw_textf("fps %d", 240, 2520 + player1->StatSheetAdjust, 2, curfps);
	        draw_textf("lod %d", 640, 2520 + player1->StatSheetAdjust, 2, lod_factor());
        	draw_textf("wqd %d", 1040, 2520 + player1->StatSheetAdjust, 2, nquads); 
	        draw_textf("wvt %d", 1440, 2520 + player1->StatSheetAdjust, 2, curvert);
        	draw_textf("evt %d", 1840, 2520 + player1->StatSheetAdjust, 2, xtraverts);

		DisplayCurrentTime(2240, 2520 + player1->StatSheetAdjust);
	};

	draw_textf("Credits:", MoneyStatX, MoneyStatY, 2, player1->agility);
	MoneyStatX = MoneyStatX + 300;
	if (player1->petacredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->petacredits);
		if (player1->petacredits < 10) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->petacredits < 100) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->teracredits == 0) {
				draw_textf(",000", MoneyStatX, MoneyStatY, 2, player1->petacredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->teracredits < 10) {
				draw_textf(",00", MoneyStatX, MoneyStatY, 2, player1->petacredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->teracredits < 100) {
				draw_textf(",0", MoneyStatX, MoneyStatY, 2, player1->petacredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(",", MoneyStatX, MoneyStatY, 2, player1->petacredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->teracredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->teracredits);
		if (player1->teracredits < 10) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->teracredits < 100) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->gigacredits == 0) {
				draw_textf(",000", MoneyStatX, MoneyStatY, 2, player1->teracredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->gigacredits < 10) {
				draw_textf(",00", MoneyStatX, MoneyStatY, 2, player1->teracredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->gigacredits < 100) {
				draw_textf(",0", MoneyStatX, MoneyStatY, 2, player1->teracredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(",", MoneyStatX, MoneyStatY, 2, player1->teracredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->gigacredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->gigacredits);
		if (player1->gigacredits < 10) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->gigacredits < 100) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->megacredits == 0) {
				draw_textf(",000", MoneyStatX, MoneyStatY, 2, player1->gigacredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->megacredits < 10) {
				draw_textf(",00", MoneyStatX, MoneyStatY, 2, player1->gigacredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->megacredits < 100) {
				draw_textf(",0", MoneyStatX, MoneyStatY, 2, player1->gigacredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(",", MoneyStatX, MoneyStatY, 2, player1->gigacredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->megacredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->megacredits);
		if (player1->megacredits < 10) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->megacredits < 100) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->kilocredits == 0) {
				draw_textf(",000", MoneyStatX, MoneyStatY, 2, player1->megacredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->kilocredits < 10) {
				draw_textf(",00", MoneyStatX, MoneyStatY, 2, player1->megacredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->kilocredits < 100) {
				draw_textf(",0", MoneyStatX, MoneyStatY, 2, player1->megacredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(",", MoneyStatX, MoneyStatY, 2, player1->megacredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->kilocredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->kilocredits);
		if (player1->kilocredits < 10) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->kilocredits < 100) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->credits == 0.0) {
				draw_textf(",000", MoneyStatX, MoneyStatY, 2, player1->kilocredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->credits < 10.0) {
				draw_textf(",00", MoneyStatX, MoneyStatY, 2, player1->kilocredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->credits < 100.0) {
				draw_textf(",0", MoneyStatX, MoneyStatY, 2, player1->kilocredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(",", MoneyStatX, MoneyStatY, 2, player1->kilocredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->credits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, int(player1->credits));
		if (player1->credits < 10.0) {
			MoneyStatX = MoneyStatX + 40;
			}
		else if (player1->credits < 100.0) {
			MoneyStatX = MoneyStatX + 80;
			}
		else {
			MoneyStatX = MoneyStatX + 120;
			}
			if (player1->millicredits == 0) {
				draw_textf(".000", MoneyStatX, MoneyStatY, 2, player1->millicredits);
				MoneyStatX = MoneyStatX + 160;
			}
			else if (player1->millicredits < 10) {
				draw_textf(".00", MoneyStatX, MoneyStatY, 2, player1->millicredits);
				MoneyStatX = MoneyStatX + 120;
			}
			else if (player1->millicredits < 100) {
				draw_textf(".0", MoneyStatX, MoneyStatY, 2, player1->millicredits);
				MoneyStatX = MoneyStatX + 80;
			}
			else {
				draw_textf(".", MoneyStatX, MoneyStatY, 2, player1->millicredits);
				MoneyStatX = MoneyStatX + 40;
			}
		}
	if (player1->millicredits > 0) {
		draw_textf("%d", MoneyStatX, MoneyStatY, 2, player1->megacredits);
		MoneyStatX = MoneyStatX + 120;
		}

	if (TrainingReadyCheck(player1) == 1) {
		draw_textf("Ready to Train!", RightStatX + 800, UpperStatY, 2, player1->trainingexp);
	}

	UpperStatY = UpperStatY + 90;	/* JJT - Next Line: Y=240 */

        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);

       	glColor3ub(0,0,0);
        glColor3ub(255,255,255);

	draw_textf("Name: ", RightStatX, UpperStatY, 2, player1->gunselect);
	draw_textf(player1->name, RightStatX + 300, UpperStatY, 2, player1->gunselect);

	UpperStatY = UpperStatY + 180;	/* JJT - Blank Line plus Next Line. 360 */

	/* JJT - Now draw the Strength Bar. */
        draw_textf("Strength: ", RightStatX + 400, UpperStatY, 2, player1->charisma);

		StrengthBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 90;	/* JJT - Blank Line plus Next Line: Y=420 */

	/* JJT - Now draw the Agility Bar. */
        draw_textf("Agility: ", RightStatX + 485, UpperStatY, 2, player1->charisma);

		AgilityBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 90;	/* JJT - Blank Line plus Next Line: Y=480 */

	/* JJT - Now draw the Stamina Bar. */
        draw_textf("Stamina: ", RightStatX + 415, UpperStatY, 2, player1->charisma);

		StaminaBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 90;	/* JJT - Blank Line plus Next Line: Y=540 */

	/* JJT - Now draw the Wisdom Bar. */
        draw_textf("Wisdom: ", RightStatX + 425, UpperStatY, 2, player1->wisdom);

		WisdomBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 90;	/* JJT - Blank Line plus Next Line: Y=600 */

	/* JJT - Now draw the Intel Bar. */
        draw_textf("Intelligence: ", RightStatX + 300, UpperStatY, 2, player1->intel);

		IntelBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 90;	/* JJT - Blank Line plus Next Line: Y=660 */

	/* JJT - Now draw the Charisma Bar. */
        draw_textf("Charisma: ", RightStatX + 375, UpperStatY, 2, player1->charisma);

		CharismaBar(player1, RightStatX + 800, UpperStatY);

	UpperStatY = UpperStatY + 180;	/* JJT - Blank Line plus Next Line: Y=780 */

     if(!player1->hidestats) {

        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);

	if (!player1->hidestats) {
	        draw_textf("Ammo: %d", 240, MoneyStatY-90, 2, player1->ammo[player1->gunselect]);
	        draw_textf("Health Points: %d", 800, MoneyStatY-90, 2, player1->health);
	        if(player1->armour) {
			draw_textf("Armour Points: %d", 1600, MoneyStatY-90, 2, player1->armour);
			}
		}
        glPopMatrix();
	}

        glPushMatrix();
        glOrtho(0, VIRTW, VIRTH, 0, -1, 1);

	/* JJT - Insert skill bars here. Inventory goes below, once implemented.
		*/

        glPopMatrix();
	}

    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
};

void gl_drawsplashscreen (int w, int h)
{
    readmatrices();

    glDisable(GL_DEPTH_TEST);
    invertperspective();
    glPushMatrix();  
    glOrtho(0, VIRTW, VIRTH, 0, -1, 1);

    glEnable(GL_TEXTURE_2D);

			DrawTexturedBox(0.0, 0.0, 1.0, 1.0, 0, 0, 2400, 1800, 4, 1);

	        draw_textfc("Version:", 2100, 1400, 2, player1->water, 0, 191, 0);
	        draw_textfc("0.1.2", 2100, 1490, 2, player1->water, 0, 191, 0);

	        draw_textfc("To begin,", 20, 200, 2, player1->water, 0, 191, 0);
	        draw_textfc("press the", 20, 290, 2, player1->water, 0, 191, 0);
	        draw_textfc("M button,", 20, 380, 2, player1->water, 0, 191, 0);
	        draw_textfc("assuming", 20, 470, 2, player1->water, 0, 191, 0);
	        draw_textfc("that the", 20, 560, 2, player1->water, 0, 191, 0);
	        draw_textfc("original", 20, 650, 2, player1->water, 0, 191, 0);
	        draw_textfc("config", 20, 740, 2, player1->water, 0, 191, 0);
	        draw_textfc("file is", 20, 830, 2, player1->water, 0, 191, 0);
	        draw_textfc("in use.", 20, 920, 2, player1->water, 0, 191, 0);

	renderscores();
	if(!rendermenu()) {
		glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
	        glBindTexture(GL_TEXTURE_2D, 4);

		if (SDL_GetTicks()>3000) {
			DrawTexturedBox(0.0, 0.00, 1.0, 1.0, 360, 60, 2040, 1740, 25, 1);
			glPopMatrix();
			}
		else {
			DrawTexturedBox(0.0, 0.0, 0.5, 1.0, -3240+int(SDL_GetTicks()*1.2), 60, -2400+int(SDL_GetTicks()*1.2), 1740, 25, 1);

			DrawTexturedBox(0.5, 0.0, 1.0, 1.0, 4800-int(SDL_GetTicks()*1.2), 60, 5640-int(SDL_GetTicks()*1.2), 1740, 25, 1);
			}

	        glPopMatrix();
		}
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
};
