#include "tools.h"

/* JJT - The following enum statements are new */

enum {
	Ammo,			/* JJT - 0: Ammunition */
	AmmoClip,		/* JJT - 1: Ammunition Clips */
	Arcgun,			/* JJT - 2: Arcguns */
	Armor,			/* JJT - 3: Armors */
	Automatic,		/* JJT - 4: Automatic guns */
	Blade,			/* JJT - 5: Blades */
	Cell,			/* JJT - 6: Power cells */
	Chemical,		/* JJT - 7: Chemicals */
	Code,			/* JJT - 8: Computer codes */
	Cudgel,			/* JJT - 9: Cudgels/Blunt instruments */
	Explosive,		/* JJT - 10: Explosive items */
	Food,			/* JJT - 11: Edible Items */
	Handgun,		/* JJT - 12: Pistols and Revolvers */
	Liquids,		/* JJT - 13: Drinkable Items */
	Medical,		/* JJT - 14: Medical equipment and supplies */
	Misc,			/* JJT - 15: Shouldn't be used */
	Missile,		/* JJT - 16: Missile weapons */
	Paper,			/* JJT - 17: Paper items */
	Radio,			/* JJT - 18: Radio equipment */
	Rifle,			/* JJT - 19: Rifles */
	Terminal,		/* JJT - 20: Interactive Kiosks */
	Thrown,			/* JJT - 21: Thrown weapons */
	Tool,			/* JJT - 22: Tools */
	NUMITEMTYPES		/* JJT - 23: Total Item Types */
	};

enum {
	admininstration,	/* JJT - 0: Admin */
	arcgun,			/* JJT - 1: guns that fire in an arc */
	armor,			/* JJT - 2: armor */
	autogun,		/* JJT - 3: automatic weaponry */
	blade,			/* JJT - 4: blades */
	handgun,		/* JJT - 5: pistols, revolvers */
	language,		/* JJT - 6: Different languages? */
	medical,		/* JJT - 7: Be a doctor. */
	melee,			/* JJT - 8: If you can't join 'em... */
	mining,			/* JJT - 9: An honest living... */
	programming,		/* JJT - 10: Not so honest living... */
	repair,			/* JJT - 11: Honest living... */
	rifle,			/* JJT - 12: A hunting you will go... */
	swimming,		/* JJT - 13: Good for water encounters... */
	NUMSKILLS		/* JJT - 14: 14 different skills. */
	};

enum {
	NoCal,			/* JJT - 0:  No Calibre */
	Cal22,			/* JJT - 1:  .22  Calibre */
	Cal357,			/* JJT - 2:  .357 Calibre */
	Cal45,			/* JJT - 3:  .45  Calibre */
	Cal44,			/* JJT - 4:  .44  Calibre */
	9mm,			/* JJT - 5:  9 mm Calibre */
	Arrow,			/* JJT - 6:  Arrow */
	Cal762,			/* JJT - 7:  .762 Calibre */
	10mm,			/* JJT - 8:  10 mm Calibre */
	Cal3006,		/* JJT - 9:  30.06 Calibre */
	Gu12,			/* JJT - 10: 12-guage shotgun calibre */
	Gu10,			/* JJT - 11: 10-guage shotgun calibre */
	Gu16,			/* JJT - 12: 16-guage shotgun calibre */
	Cal227,			/* JJT - 13: .227 Calibre */
	NUMCALTYPES		/* JJT - 14: Total number of Ammo Calibres. */
	};

enum {
	NoBulletType,		/* JJT - 0: No Type */
	Bullet,			/* JJT - 1: Bullet Ammo */
	Pellet,			/* JJT - 2: Pellet Ammo, typically multiple rays */
	Broad,			/* JJT - 3: Broadhead Bullet */
	Hollow,			/* JJT - 4: Hollow-Point, blooming Bullet */
	Expl,			/* JJT - 5: Explosive Bullet */
	Ice,			/* JJT - 6: Ice Bullet */
	Silver,			/* JJT - 7: Silver Bullet */
	Gold,			/* JJT - 8: Gold Bullet */
	Wood,			/* JJT - 9: Wooden Bullet */
	NUMBULLETTYPES		/* JJT - 10: 10 Different Bullet Types */
	}

enum {
	Cal22Bullet = 13,	/* JJT - 13: Standard .22 bullet */
	Cal22Hollow,		/* JJT - 14: Hollow-point .22 */
	Cal22Expl,		/* JJT - 15: Explosive .22 */
	Cal357Bullet,		/* JJT - 16: Standard .357 bullet */
	Cal357Hollow,		/* JJT - 17: Hollow-point .357 */
	Cal357Expl,		/* JJT - 18: Explosive .357 */
	Cal45Bullet,		/* JJT - 19: Standard .45 bullet */
	Cal45Hollow,		/* JJT - 20: Hollow-point .45 */
	Cal45Expl,		/* JJT - 21: Explosive .45 */
	Mag44Bullet,		/* JJT - 22: .44 Magnum bullet */
	Mag44Hollow,		/* JJT - 23: Hollow-point .44 Magnum? What's the point? */
	Mag44Expl,		/* JJT - 24: Explosive .44 Magnum. Good against armor. */
	mm9Bullet,		/* JJT - 25: Standard 9mm bullet */
	mm9Hollow,		/* JJT - 26: Hollow-point 9mm bullet */
	mm9Expl,		/* JJT - 27: Explosive 9mm bullet */
	ArrowBullet,		/* JJT - 28: Standard arrow */
	ArrowBroad,		/* JJT - 29: Broadhead arrow */
	ArrowExpl,		/* JJT - 30: Rambo arrows - explosive! */
	/* JJT - Rifles and Autos use unknown ammo, so this will be best-guesses. */
	Cal762Bullet,		/* JJT - 31: Standard .762 bullet */
	Cal762Hollow,		/* JJT - 32: Hollow-point .762 */
	Cal762Expl,		/* JJT - 33: Explosive .762 */
	mm10Bullet,		/* JJT - 34: Standard 10 mm bullet */
	mm10Hollow,		/* JJT - 35: Hollow-point 10 mm */
	mm10Expl,		/* JJT - 36: Explosive 10 mm */
	Cal3006Bullet,		/* JJT - 37: Standard 30-06 bullet */
	Cal3006Hollow,		/* JJT - 38: Hollow-point 30-06 */
	Cal3006Expl,		/* JJT - 39: Explosive 30-06 Elephant Ammo! */
	Gu12Bullet,		/* JJT - 40: 12-guage bullet */
	Gu12Pellet,		/* JJT - 41: 12-guage shot round */
	Gu12Expl,		/* JJT - 42: 12-guage grenade */
	Gu10Bullet,		/* JJT - 43: 10-guage bullet */
	Gu10Pellet,		/* JJT - 44: 10-guage shot round */
	Gu10Expl,		/* JJT - 45: 10-guage grenade */
	Gu16Bullet,		/* JJT - 46: 16-guage bullet */
	Gu16Pellet,		/* JJT - 47: 16-guage shot round */
	Gu16Expl,		/* JJT - 48: 16-guage explosive round */
	Cal227Bullet,		/* JJT - 49: Standard .227 bullet */
	Cal227Hollow,		/* JJT - 50: Hollow-point .227 */
	Cal227Expl,		/* JJT - 51: Explosive .227 */
	NUMAMMOTYPES		/* JJT - 52: 52 Ammo types available. */
	};

enum {
	NoClip,			/* JJT - 0: No clip */
	Cal22Clip10,		/* JJT - 1: .22 Clip that holds 10 rounds */
	Cal22Clip15,		/* JJT - 2: .22 Clip that holds 15 rounds */
	Cal22Clip20,		/* JJT - 3: .22 Clip that holds 20 rounds */
	Cal22Clip30,		/* JJT - 4: .22 Clip that holds 30 rounds */
	Cal22Barrel50,		/* JJT - 5: .22 Barrel Clip that holds 50 rounds */
	Cal22Barrel100,		/* JJT - 6: .22 Barrel Clip that holds 100 rounds */
	Cal357Reloader6,	/* JJT - 7: .357 quick-loading 6-round holder */
	Cal45Clip10,		/* JJT - 8: .45 Clip holding 10 rounds */
	Cal45Clip15,		/* JJT - 9: .45 Clip holding 15 rounds */
	Cal45Barrel30,		/* JJT - 10: .45 Barrel Clip that holds 30 rounds */
	Cal45Barrel60,		/* JJT - 11: .45 Barrel Clip that holds 60 rounds */
	Mag44Reloader6,		/* JJT - 12: .44 quick-loading 6-round holder */
	mm9Clip10,		/* JJT - 13: 9mm Clip holding 10 rounds */
	mm9Clip15,		/* JJT - 14: 9mm Clip holding 15 rounds */
	mm9Clip20,		/* JJT - 15: 9mm Clip holding 20 rounds */
	mm9Barrel50,		/* JJT - 16: 9mm Barrel Clip holding 50 rounds */
	mm9Barrel100,		/* JJT - 17: 9mm Barrel Clip holding 100 rounds */
	Quarrel15,		/* JJT - 18: Quarrel holding 15 bullet arrows or 9 big arrows */
	Quarrel10,		/* JJT - 19: Quarrel holding 10 bullet arrows or 6 big arrows */
	/* JJT - Rifles and Autos use unknown ammo, so this will be best-guesses. */
	Cal762Clip15,		/* JJT - 20: .762 Clip holding 15 rounds */
	Cal762Clip20,		/* JJT - 21: .762 Clip holding 20 rounds */
	Cal762Clip30,		/* JJT - 22: .762 Clip holding 30 rounds */
	mm10Clip10,		/* JJT - 23: 10mm Clip holding 10 rounds */
	mm10Clip15,		/* JJT - 24: 10mm Clip holding 15 rounds */
	mm10Clip20,		/* JJT - 25: 10mm Clip holding 20 rounds */
	mm10Barrel30,		/* JJT - 26: 10mm Barrel Clip holding 30 rounds */
	mm10Barrel60,		/* JJT - 27: 10mm Barrel Clip holding 60 rounds */
	Cal3006Clip3,		/* JJT - 28: 30-06 Clip holding 3 rounds */
	Cal3006Clip5,		/* JJT - 29: 30-06 Clip holding 5 rounds */
	Cal3006Clip7,		/* JJT - 30: 30-06 Clip holding 7 rounds */
	Cal227Clip15,		/* JJT - 31: .227 Clip holding 15 rounds */
	Cal227Clip20,		/* JJT - 32: .227 Clip holding 20 rounds */
	Cal227Clip30,		/* JJT - 33: .227 Clip holding 30 rounds */
	Cal227Barrel50,		/* JJT - 34: .227 Barrel Clip holding 50 rounds */
	Cal227Barrel100,	/* JJT - 35: .227 Barrel Clip holding 100 rounds */
	NUMAMMOCLIPTYPES	/* JJT - 36: Ammo Clip types available. */
	};

enum {
	ArcGun = 0,	/* JJT - 0: Basic electrostatic gun */
	FreezeGun,	/* JJT - 1: Advanced chiller gun */
	Synapser,	/* JJT - 2: Basic Stun gun */
	ChemGun,	/* JJT - 3: Chemical Squirt gun */
	FlameThrower,	/* JJT - 4: Chemical Roaster! */
	StunGun,	/* JJT - 5: Advanced electrostatic gun */
	NUMARCGUNS	/* JJT - 6: 6 different Arcguns */
	};

enum {
	Model10 = 0,	/* JJT - 0: Model 10 */
	Uzi,		/* JJT - 1: Uzi */
	AssaultRifle,	/* JJT - 2: Assault Rifle */
	AutoCarbine,	/* JJT - 3: Automatic Carbine */
	PulseLaser,	/* JJT - 4: Pulse Laser Rifle */
	ParticleBeam,	/* JJT - 5: Particle Beam Rifle */
	NUMAUTOGUNS	/* JJT - 6: 6 Automatic weapons available. */
	};

enum {
	PocketKnife = 0,	/* JJT - 0: Pocket Knife */
	SwitchBlade,		/* JJT - 1: Switch Blade */
	CombatBlade,		/* JJT - 2: Combat Knife */
	Sword,			/* JJT - 3: Short Sword */
	Axe,			/* JJT - 4: Combat Hatchet */
	Broadsword,		/* JJT - 5: Long Sword */
	LightBlade,		/* JJT - 6: Laser Sword */
	EnergyBlade,		/* JJT - 7: Energy Sword */
	NUMBLADES		/* JJT - 8: 8 Bladed weapons available. */
	};

enum {
	Cell1V = 0,		/* JJT - 0: 1.5 Volt Battery */
	Cell3V,			/* JJT - 1: 3 Volt Battery */
	Cell9V,			/* JJT - 2: 9 Volt Battery */
	Cell12V,		/* JJT - 3: 12 Volt Battery */
	Car12V,			/* JJT - 4: Car Battery */
	Marine12V,		/* JJT - 5: Marine Battery */
	Cell24V,		/* JJT - 6: 24 Volt Battery */
	Cell120V,		/* JJT - 7: 120 Volt Battery */
	Cell240V,		/* JJT - 8: 240 Volt Battery */
	Cell480V,		/* JJT - 9: 480 Volt Battery */
	FlashCap,		/* JJT - 10: Small Capacitor */
	ZapCap,			/* JJT - 11: Medium Capacitor */
	CrystalCap,		/* JJT - 12: Large Capacitor */
	NUMCELLS		/* JJT - 13: 13 Different cells. */
	};

enum {
	WaxFuel = 53,		/* JJT - 53: Slow-burning liquid candle */
	TorchFuel,		/* JJT - 54: Torch Fuel */
	Napalm,			/* JJT - 55: Gasoline Gel */
	Starter,		/* JJT - 56: Starter Fluid */
	LiquidCaps,		/* JJT - 57: Napalm in WaxFuel shells */
	SBottle,		/* JJT - 58: Large Fragile chemical Specimen Bottle container */
	Bottle,			/* JJT - 59: Medium Fragile chemical container */
	Beaker,			/* JJT - 60: Small Fragile chemical container */
	TestTube,		/* JJT - 61: Sample-size Fragile chemical container */
	FBottle,		/* JJT - 62: Large Fiberglass chemical container */
	FTube,			/* JJT - 63: Medium Fiberglass chemical container */
	};

enum {
	MineShaft = 0,		/* JJT - 0: Mine Shaft Code */
	PoliceRec,		/* JJT - 1: Police Records Code */
	TerminalRec,		/* JJT - 2: Terminal Records Code */
	WarGames,		/* JJT - 3: War Games Room Code */
	NUMCODES		/* JJT - 4: 4 Different Codes available */
	};

enum {
	BaseballBat = 0,	/* JJT - 0: Baseball bat */
	NightStick,		/* JJT - 1: Police Night Stick */
	BlackJack,		/* JJT - 2: hard heavy hand bag */
	PulseProd,		/* JJT - 3: Cattle Prod */
	NUMCUDGELS		/* JJT - 4: 4 different cudgels */
	};

enum {
	BlastingCap = 0,	/* JJT - 0: Blasting Cap */
	CrystalCap,		/* JJT - 1: Explosive Crystal */
	Dynamite,		/* JJT - 2: TNT in trilobyte crystals */
	C17,			/* JJT - 3: Stable C4 dirivative */
	NUMEXPLOSIVES		/* JJT - 4: different explosives */
	};

enum {
	Leaf = 0,		/* JJT - 0: Basic food */
	Carrot,			/* JJT - 1: What's up, doc? */
	Salad,			/* JJT - 2: Basic food mix */
	Candy,			/* JJT - 3: Basic Candy */
	CandyBar,		/* JJT - 4: Enriched Candy Bar */
	HotDog,			/* JJT - 5: Hot Dog */
	CrusherDog,		/* JJT - 6: Crusher Hot Dog */
	HamBurger,		/* JJT - 7: Basic Hamburger */
	CheeseBurger,		/* JJT - 8: Hamburger with cheese */
	DoubleBurger,		/* JJT - 9: Double Hamburger */
	FriedSteak,		/* JJT - 10: Chicken Fried Steak */
	Steak,			/* JJT - 11: Regular Steak */
	CrusherSteak,		/* JJT - 12: Crusher Steak */
	PowerBar,		/* JJT - 13: Enriched Power Candy Bar */
	Ration,			/* JJT - 14: Enriched Meal Ration */
	NUMFOODS		/* JJT - 15: 15 different dishes available */
	};

enum {
	ZipGun = 0,		/* JJT - 0: One-shot zip gun */
	Pistol22,		/* JJT - 1: .22 Pistol */
	Pistol9,		/* JJT - 2: 9mm Pistol */
	Revolver357,		/* JJT - 3: .357 Revolver */
	Pistol45,		/* JJT - 4: .45 Pistol */
	Revolver44,		/* JJT - 5: .44 Magnum Revolver */
	Mazer,			/* JJT - 6: Focused Microwave Laser gun */
	Phazer,			/* JJT - 7: Focused Particle Gun */
	NUMHANDGUNS		/* JJT - 8: 8 different handguns available */
	};

enum {
	WaterGlass = 0,		/* JJT - 0: Plain Water */
	TeaGlass,		/* JJT - 1: Tea */
	SweetTea,		/* JJT - 2: Sweetened Tea */
	BlackCoffee,		/* JJT - 3: Black Coffee */
	CoffeeCup,		/* JJT - 4: Regular Coffee */
	BelchSoda,		/* JJT - 5: Enriched Soda Pop */
	Liquor,			/* JJT - 6: Mild Alcohol */
	Booze,			/* JJT - 7: Alcohol */
	HardLiquor,		/* JJT - 8: Heavy Alcohol */
	MaltLiquor,		/* JJT - 9: Malted Alcohol */
	Beer,			/* JJT - 10: Classic beer */
	SoftGlass,		/* JJT - 11: Generic Softdrink */
	NUMLIQUIDS		/* JJT - 12: 12 different drinks available */
	};

enum {
	Bandage = 0,		/* JJT - 0: Simple Bandage */
	Injection,		/* JJT - 1: Healing Injection */
	Compress,		/* JJT - 2: Heating Compress */
	HealSalve,		/* JJT - 3: Healing Bandage */
	FirstAid,		/* JJT - 4: Small First Aid Kit */
	MedicalKit,		/* JJT - 5: Medium Medical Kit */
	FieldKit,		/* JJT - 6: Field Surgery Kit */
	SmallSupply,		/* JJT - 7: Small Kit Supply Pack */
	MedSupply,		/* JJT - 8: Medium Kit Supply Pack */
	LargeSupply,		/* JJT - 9: Large Kit Supply Pack */
	NUMMEDS			/* JJT - 10: 10 different medical supplies */
	};

enum {
	NUMMISC = 0			/* JJT - 0: No Misc Items! */
	};

enum {
	BlowGun = 0,		/* JJT - 0: Basic Blow Gun */
	Bow,			/* JJT - 1: Bow shoots arrows */
	CompBow,		/* JJT - 2: Compound Bow shoots arrows faster */
	CrossBow,		/* JJT - 3: Crossbow shoots arrows farther */
	GrenLauncher,		/* JJT - 4: Grenade Launcher */
	NUMMISSILES		/* JJT - 5: 5 different Missile Launchers*/
	};

enum {
	Note,			/* JJT - 0: Basic Note Paper */
	Letter,			/* JJT - 1: Type-written letter */
	Map,			/* JJT - 2: Scribbled Map */
	Receipt,		/* JJT - 3: Paper Receipt */
	HallPass,		/* JJT - 4: Lock-down pass */
	SpeederPass,		/* JJT - 5: Speeder Pass to anywhere */
	NUMPAPERS		/* JJT - 6: 6 different types of paper*/
	};

enum {
	Finder = 0,		/* JJT - 0: Directs user to a beacon. */
	Transmitter,		/* JJT - 1: sends out a radio beacon. */
	CB,			/* JJT - 2: CB Radio */
	WalkieTalkie,		/* JJT - 3: Tunable CB Radio */
	CellPhone,		/* JJT - 4: Cellular Telephone */
	NUMRADIOS		/* JJT - 5: 5 Radio equipment items */
	};

enum {
	TargetRifle = 0,	/* JJT - 0: Basic Target Rifle */
	SportRifle,		/* JJT - 1: Basic Rifle */
	SniperRifle,		/* JJT - 2: Long Rifle with sights */
	CarbineRifle,		/* JJT - 3: Rifle with sights */
	MagnumRifle,		/* JJT - 4: Gas Blow-back Rifle */
	LaserCarbine,		/* JJT - 5: Focused Short Laser Rifle */
	Blaster,		/* JJT - 6: Focused Particle Rifle */
	NUMRIFLES		/* JJT - 7: 7 Different rifles */
	};

enum {
	NoTerminal,		/* JJT - 0: Nothing */
	Computer,		/* JJT - 1: Computer Terminal */
	Hospital,		/* JJT - 2: Medical Hospital/Terminal */
	Gym,			/* JJT - 3: Place to work out */
	Home,			/* JJT - 4: Bed and safety */
	SysOp,			/* JJT - 5: Central Computer Center and System Operator's office */
	Speeder,		/* JJT - 6: Speeder station */
	PawnShop,		/* JJT - 7: Pawn Shop */
	AmmoShop,		/* JJT - 8: Weapon Store */
	University,		/* JJT - 9: Learning Center */
	Precinct,		/* JJT - 10: Police Station */
	MineShaft,		/* JJT - 11: Mine Shaft */
	WarGamesRoom,		/* JJT - 12: War Games Room */
	ArmorShop,		/* JJT - 13: Armor Shop */
	Controller,		/* JJT - 14: Central Admin Office */
	SnackBar,		/* JJT - 15: Food and drinks */
	SocialBar,		/* JJT - 16: Generic Bar */
	TruckStop,		/* JJT - 17: Basic Restaurant */
	Restaurant,		/* JJT - 18: Food and drinks */
	ArmyBarracks,		/* JJT - 19: Army Guys here */
	MarineBarracks,		/* JJT - 20: Marine Guys here */
	TempAgency,		/* JJT - 21: All kinds here */
	Casino,			/* JJT - 22: Not really used */
	Bank,			/* JJT - 23: Financial Institution. Loans? */
	Locker,			/* JJT - 24: Bank for stuff. Comination? */
	NUMTERMINALS		/* JJT - 25: Different Kiosks/places to do business */
	};

enum {
	BarbDart,		/* JJT - 0: Dart with Barbs on the end */
	ThrowingKnife,		/* JJT - 1: Throwing Knife */
	Shuriken,		/* JJT - 2: Throwing Star */
	Molotov,		/* JJT - 3: Molotov Cocktail - Bottle filled with chemicals. */
	HandGren,		/* JJT - 4: Hand Grenade */
	FlashGren,		/* JJT - 5: Flash Grenade */
	Beacon,			/* JJT - 6: Radio Beacon */
	NUMTHROWN		/* JJT - 7: 7 Thrown Items */
	};

enum {
	String = 0,		/* JJT - 0: Simple string */
	Yarn,			/* JJT - 1: Simple yarn */
	Nylon,			/* JJT - 2: Nylon string */
	ZipTie,			/* JJT - 3: Nylon Zip-Tie */
	RubberHose,		/* JJT - 4: Rubber Hose */
	PlasticPipe,		/* JJT - 5: PVC Pipe */
	LeadPipe,		/* JJT - 6: Basic Metal Pipe */
	SteelPipe,		/* JJT - 7: Metal Pipe */
	AlloyPipe,		/* JJT - 8: Advanced Metal Pipe */
	Solder,			/* JJT - 9: Soldering Wire */
	SolderIron,		/* JJT - 10: Soldering Iron */
	VoltMeter,		/* JJT - 11: Volt Meter */
	Tweezers,		/* JJT - 12: Tweezers */
	Screwdriver,		/* JJT - 13: Screwdriver */
	RatchetDriver,		/* JJT - 14: Ratchet Screwdriver */
	PowerDriver,		/* JJT - 15: Electric Screwdriver */
	DriverBits,		/* JJT - 16: Modular Screwdriver Bits */
	Wrench,			/* JJT - 17: Wrench */
	AdjustWrench,		/* JJT - 18: Adjustable Wrench */
	Pliers,			/* JJT - 19: Basic Adjustable Pliers */
	Hammer,			/* JJT - 20: Basic Hammer */
	HandSaw,		/* JJT - 21: Basic Saw */
	PowerSaw,		/* JJT - 22: Electric Mini-circular saw */
	MiningLzr,		/* JJT - 23: Mining Laser */
	MaskTape,		/* JJT - 24: Masking Tape */
	DuctTape,		/* JJT - 25: Duct Tape */
	NUMTOOLS		/* JJT - 26: 26 different tool supplies */
	};

struct inventoryent                           // JJT - Inventory Items
{
    vec o, vel;                         // origin, velocity
    float yaw, pitch, roll;             // used as vec in one place
    float maxspeed;                     // cubes per second. JJT - 480 for rockets?
    bool outsidemap;                    // from his eyes
    bool inwater;
    bool onfloor, jumpnext;
    int move, strafe;

	// JJT - No need for input codes? Could be a remote-controlled turret or something...
//    bool k_left, k_right, k_up, k_down; // see input code  
    int timeinair;                      // used for fake gravity
    float radius, eyeheight, aboveeye;  // bounding box size
    int lastupdate, plag, ping;
    int lifesequence;                   // sequence id for each respawn, used in damage test
    int state;                          // one of CS_* below
    int frags;
    int health, armour, armourtype;	// JJT - Removed quadmillis.
    int gunselect, gunwait;
    int lastaction, lastattackgun, lastmove;
    bool attacking;

	/* JJT - Numbered items: all the same type per container
		or not. bullets, medical supplies, tools. */

	int contents[15];		// JJT - + 15 Item Content Slots 

	// JJT - Inventory Item may have its own ammo.
    int ammo;				// JJT - Removed [NUMGUNS] Array declaration.

//    int monsterstate;                   // one of M_* below, M_NONE means human
//    int mtype;                          // see monster.cpp
    dynent *enemy;                      // JJT - Remote Turret wants to kill this entity.
    float targetyaw;                    // JJT - Item wants to look in this direction
    bool blocked, moving;               // used by physics to signal ai
    int trigger;                        // millis at which transition to another monsterstate takes place
    vec attacktarget;                   // delayed attacks
    int anger;                          // how many times already hit by entity.

    string name, team;			// JJT - Name needed for each object.

	dynent *owner;			// JJT - Every item should have an owner (d).

	/* JJT - Every item needs a base price.
		Other prices can be modified on the fly by
		RPG Attribute Ratings like "charisma". */

	int price;
};
