// JJT - inventoryitems.cpp: items that you can carry around and use
// JJT - This file is based almost entirely on clientgame.cpp.

#include "cube.h"

/* JJT - Struct prototype of inventory content items for reference. */

struct ContentItem {
    vec o, vel;				// origin, velocity
    float yaw, pitch, roll;             // used as vec in one place
    float maxspeed;                     // cubes per second. JJT - 480 for rockets?
    bool inwater;
    bool onfloor, jumpnext;
    int move, strafe;

    int timeinair;                      // used for fake gravity
    float radius, eyeheight, aboveeye;  // bounding box size
    int lastupdate;
    int lifesequence;                   // sequence id for each respawn, used in damage test
    int health, armour, armourtype;	// JJT - Removed quadmillis.
    int gunselect, gunwait;
    int lastaction, lastattackgun, lastmove;
    bool attacking;

	// JJT - Inventory Item may have its own ammo.
	int ClipType, ContentCount;	/* JJT - defines how much ammo is available. */
	int BulletType[ContentCount];	/* JJT - defines ammo behavior. */
	int AmmoType[ContentCount];	/* JJT - defines which bullet in clip is what. */
    int ammo;				// JJT - Removed [NUMGUNS] Array declaration.

    dynent *enemy;                      // JJT - Bullet wants to kill this entity.
    float targetyaw;                    // JJT - Item wants to look in this direction
    bool blocked, moving;               // used by physics to signal ai
    int trigger;                        // millis at which transition to another monsterstate takes place
    vec attacktarget;                   // delayed attacks

    string name;			/* JJT - item name. */
	string ShortDescription;	/* JJT - Quick one-line description. */
	string LongDescription;		/* JJT - Full Description of item. */

	int BuyPrice, SellPrice;	/* JJT - Item prices */
	int Rarity;			/* JJT - Certain items can't be everywhere. */

	int Damage, Part;		/* JJT - Items can be damaged, and can be part
						of something else.
						*/

	dynent *owner;		/* JJT - Every item should have an owner (d). */
	int faction;		/* JJT - Special items may belong to specific factions. */
	}	/* JJT - No semicolon used because inventoryitems list
			will use this struct (structure) to create items
		*/

ContentItems[] = {

	/* JJT - Start of Test Item 1 */
	{
	{0, 0, 0},	/* JJT - o vector (origin) */
	{0, 0, 0},	/* JJT - vec vector (velocity) */
	0.0,		/* JJT - Yaw */
	0.0,		/* JJT - Pitch */
	0.0,		/* JJT - Roll */
	480.0,		/* JJT - Maxspeed */
	false,		/* JJT - Boolian: In water? */
	false,		/* JJT - Boolian: On floor? */
	false,		/* JJT - Boolian: Next jump? */
	0,		/* JJT - Move integer */
	0,		/* JJT - Strafe integer */
	0,		/* JJT - Time In Air integer */
	1.0,		/* JJT - Bounding Box Radius */
	0.5,		/* JJT - Bounding Box Eye Height */
	1.0,		/* JJT - Bounding Box Above Eye */
	0,		/* JJT - Last Update integer */
	0,		/* JJT - Life Sequence integer */
	120,		/* JJT - Health of 120 points integer */
	120,		/* JJT - Armour of 120 points integer */	
	2,		/* JJT - ArmourType #2 (Yellow) integer*/
	0,		/* JJT - Gun selected integer */
	0,		/* JJT - Gun Wait integer */
	0,		/* JJT - Last Action integer */
	0,		/* JJT - Last Attack Gun integer */
	0,		/* JJT - Last Move integer */
	false,		/* JJT - Boolian: Attacking? */

	0,		/* JJT - ClipType */
	0,		/* JJT - ContentCount */
			/* JJT - Two integer arrays: BulletType and AmmoType,
				each of length ContentCount
				*/
	0,		/* JJT - BulletType array */
	0,		/* JJT - AmmoType array */

	0,		/* JJT - Ammunition integer. */

	NULL,		/* JJT - Null Enemy */
	0.0,		/* JJT - Target Yaw: Where it wants to point */
	false,		/* JJT - Boolian: Blocked? */
	false,		/* JJT - Boolian: Moving? */
	0,		/* JJT - Trigger integer */
	{0, 0, 0},	/* JJT - AttackTarget: coordinates being aimed at */
	"Test Content Item 1",	/* JJT - Name string */
	"Content Items",	/* JJT - Short Description string */
	"This content item is for testing purposes only",	/* JJT - Long Description. */

	0,		/* JJT - No buying price. */
	0,		/* JJT - No selling price. */
	16000,		/* JJT - Moderately available (50%). */

	0,		/* JJT - Not damaged or corroded at all. */
	0,		/* JJT - Not a listed part. */

	player1,	/* JJT - dynent Owner */
	0		/* JJT - Faction 0 */
	},
	/* End of Test Content Item 1 */

	/* Start of Test Content Item 2 */
	{
	{0, 0, 0},	/* JJT - o vector (origin) */
	{0, 0, 0},	/* JJT - vec vector (velocity) */
	0.0,		/* JJT - Yaw */
	0.0,		/* JJT - Pitch */
	0.0,		/* JJT - Roll */
	480.0,		/* JJT - Maxspeed */
	false,		/* JJT - Boolian: In water? */
	false,		/* JJT - Boolian: On floor? */
	false,		/* JJT - Boolian: Next jump? */
	0,		/* JJT - Move integer */
	0,		/* JJT - Strafe integer */
	0,		/* JJT - Time In Air integer */
	1.0,		/* JJT - Bounding Box Radius */
	0.5,		/* JJT - Bounding Box Eye Height */
	1.0,		/* JJT - Bounding Box Above Eye */
	0,		/* JJT - Last Update integer */
	0,		/* JJT - Life Sequence integer */
	120,		/* JJT - Health of 120 points integer */
	120,		/* JJT - Armour of 120 points integer */	
	2,		/* JJT - ArmourType #2 (Yellow) integer*/
	0,		/* JJT - Gun selected integer */
	0,		/* JJT - Gun Wait integer */
	0,		/* JJT - Last Action integer */
	0,		/* JJT - Last Attack Gun integer */
	0,		/* JJT - Last Move integer */
	false,		/* JJT - Boolian: Attacking? */

	0,		/* JJT - Ammunition integer. */

	NULL,		/* JJT - Null Enemy */
	0.0,		/* JJT - Target Yaw: Where it wants to point */
	false,		/* JJT - Boolian: Blocked? */
	false,		/* JJT - Boolian: Moving? */
	0,		/* JJT - Trigger integer */
	{0, 0, 0},	/* JJT - AttackTarget: coordinates being aimed at */
	"Test Content Item 1",	/* JJT - Name string */
	"Content Items",	/* JJT - Short Description string */
	"This content item is for testing purposes only",	/* JJT - Long Description. */

	0,		/* JJT - No buying price. */
	0,		/* JJT - No selling price. */
	16000,		/* JJT - Moderately available (50%). */

	0,		/* JJT - Not damaged or corroded at all. */
	0,		/* JJT - Not a listed part. */

	player1,	/* JJT - dynent Owner */
	0		/* JJT - Faction 0 */
	},
	/* End of Test Content Item 2 */

};	/* JJT - End of ContentItems struct listing */

struct inventoryitem {
    vec o, vel;				// origin, velocity
    float yaw, pitch, roll;             // used as vec in one place
    float maxspeed;                     // cubes per second. JJT - 480 for rockets?
    bool inwater;
    bool onfloor, jumpnext;
    int move, strafe;

	// JJT - No need for input codes? Could be a remote-controlled turret or something...
//    bool k_left, k_right, k_up, k_down; // see input code  
    int timeinair;                      // used for fake gravity
    float radius, eyeheight, aboveeye;  // bounding box size
    int lastupdate;
    int lifesequence;                   // sequence id for each respawn, used in damage test
    int health, armour, armourtype;	// JJT - Removed quadmillis.
    int gunselect, gunwait;
    int lastaction, lastattackgun, lastmove;
    bool attacking;
	/* JJT - Item contents: 15x3 array, containing up to 15 types and the amount of contents
		x: Item Type, y: Item Number, z: amount contained
	*/

	int ContentType;		/* JJT - If the content does not match this,
						then the content is rejected. */

	// JJT - Inventory Item may have its own ammo.
    int ammo;				// JJT - Removed [NUMGUNS] Array declaration.

    dynent *enemy;                      // JJT - Remote Turret wants to kill this entity.
    float targetyaw;                    // JJT - Item wants to look in this direction
    bool blocked, moving;               // used by physics to signal ai
    int trigger;                        // millis at which transition to another monsterstate takes place
    vec attacktarget;                   // delayed attacks
    int anger;                          // how many times already hit by entity.

    string name;			/* JJT - item name. */
	string ShortDescription;	/* JJT - Quick one-line description. */
	string LongDescription;		/* JJT - Full Description of item. */

	int QuantityOwned;		/* JJT - How many are in inventory? */
	int Slots;			/* JJT - How many slots are in this item? */
	int MaxQuantity;		/* JJT - How many can be in inventory? */

	int BuyPrice, SellPrice;	/* JJT - Item prices */
	int Rarity;			/* JJT - Certain items can't be everywhere. */

	struct *ContentItem[Slots];	/* JJT - Can contain so many of certain items. */

	int Damage, Part;		/* JJT - Items can be damaged, and can be part
						of something else.
						*/

	dynent *owner;		/* JJT - Every item should have an owner (d). */
	int faction;		/* JJT - Special items may belong to specific factions. */
	}	/* JJT - No semicolon used because inventoryitems list
			will use this struct (structure) to create items
		*/

inventoryitems[] = {

	/* JJT - Start of Test Item 1 */
        {
	{0, 0, 0},	/* JJT - o vector (origin) */
	{0, 0, 0},	/* JJT - vec vector (velocity) */
	0.0,		/* JJT - Yaw */
	0.0,		/* JJT - Pitch */
	0.0,		/* JJT - Roll */
	480.0,		/* JJT - Maxspeed */
	false,		/* JJT - Boolian: In water? */
	false,		/* JJT - Boolian: On floor? */
	false,		/* JJT - Boolian: Next jump? */
	0,		/* JJT - Move integer */
	0,		/* JJT - Strafe integer */
	0,		/* JJT - Time In Air integer */
	1.0,		/* JJT - Bounding Box Radius */
	0.5,		/* JJT - Bounding Box Eye Height */
	1.0,		/* JJT - Bounding Box Above Eye */
	0,		/* JJT - Last Update integer */
	0,		/* JJT - Life Sequence integer */
	120,		/* JJT - Health of 120 points integer */
	120,		/* JJT - Armour of 120 points integer */	
	2,		/* JJT - ArmourType #2 (Yellow) integer*/
	0,		/* JJT - Gun selected integer */
	0,		/* JJT - Gun Wait integer */
	0,		/* JJT - Last Action integer */
	0,		/* JJT - Last Attack Gun integer */
	0,		/* JJT - Last Move integer */
	false,		/* JJT - Boolian: Attacking? */

	0,		/* JJT - Content Type. */
	0,		/* JJT - Ammunition integer. */

	NULL,		/* JJT - Null Enemy */
	0.0,		/* JJT - Target Yaw: Where it wants to point */
	false,		/* JJT - Boolian: Blocked? */
	false,		/* JJT - Boolian: Moving? */
	0,		/* JJT - Trigger integer */
	{0, 0, 0},	/* JJT - AttackTarget: coordinates being aimed at */
	0,		/* JJT - Anger integer */
	"Test Item 1",	/* JJT - Name string */
	"Misc Items",	/* JJT - Short Description string */
	"This item is for testing purposes only",	/* JJT - Long Description. */

	0,		/* JJT - Quantity Owned? */
	0,		/* JJT - This item has no ammo slots. */
	0,		/* JJT - The player can hold zero of this item. */

	0,		/* JJT - No buying price. */
	0,		/* JJT - No selling price. */
	16000,		/* JJT - Moderately available (50%). */

	/* JJT - Loop through the Struct array of contents and set all to Null. */
	NULL,		/* JJT - Struct Array Null */

	0,		/* JJT - Not damaged or corroded at all. */
	0,		/* JJT - Not a listed part. */

	player1		/* JJT - dynent Owner */
	},
	/* End of Test Item 1 */

	/* Start of Item 1 */
        {
	{0, 0, 0},	/* JJT - o vector (origin) */
	{0, 0, 0},	/* JJT - vec vector (velocity) */
	0.0,		/* JJT - Yaw */
	0.0,		/* JJT - Pitch */
	0.0,		/* JJT - Roll */
	480.0,		/* JJT - Maxspeed */
	false,		/* JJT - Boolian: In water? */
	false,		/* JJT - Boolian: On floor? */
	false,		/* JJT - Boolian: Next jump? */
	0,		/* JJT - Move integer */
	0,		/* JJT - Strafe integer */
	0,		/* JJT - Time In Air integer */
	1.0,		/* JJT - Bounding Box Radius */
	0.5,		/* JJT - Bounding Box Eye Height */
	1.0,		/* JJT - Bounding Box Above Eye */
	0,		/* JJT - Last Update integer */
	0,		/* JJT - Life Sequence integer */
	120,		/* JJT - Health of 120 points integer */
	120,		/* JJT - Armour of 120 points integer */	
	2,		/* JJT - ArmourType #2 (Yellow) integer*/
	0,		/* JJT - Gun selected integer */
	0,		/* JJT - Gun Wait integer */
	0,		/* JJT - Last Action integer */
	0,		/* JJT - Last Attack Gun integer */
	0,		/* JJT - Last Move integer */
	false,		/* JJT - Boolian: Attacking? */

	0,		/* JJT - Content Type. */
	0,		/* JJT - Ammunition integer. */

	NULL,		/* JJT - Null Enemy */
	0.0,		/* JJT - Target Yaw: Where it wants to point */
	false,		/* JJT - Boolian: Blocked? */
	false,		/* JJT - Boolian: Moving? */
	0,		/* JJT - Trigger integer */
	{0, 0, 0},	/* JJT - AttackTarget: coordinates being aimed at */
	0,		/* JJT - Anger integer */
	"Test Item 1",	/* JJT - Name string */
	"Misc Items",	/* JJT - Short Description string */
	"This item is for testing purposes only",	/* JJT - Long Description. */

	0,		/* JJT - Quantity Owned? */
	0,		/* JJT - This item has no ammo slots. */
	0,		/* JJT - The player can hold zero of this item. */

	0,		/* JJT - No buying price. */
	0,		/* JJT - No selling price. */
	16000,		/* JJT - Moderately available (50%). */

	/* JJT - Loop through the Struct array of contents and set all to Null. */
	NULL,		/* JJT - Struct Array Null */

	0,		/* JJT - Not damaged or corroded at all. */
	0,		/* JJT - Not a listed part. */

	player1		/* JJT - dynent Owner */
	},

};	/* JJT - End of inventoryitems struct listing */

void spawnstate(inventoryent *d)	// JJT - Reset item states not persistent accross spawns
{
    resetmovement(d);
    d->vel.x = d->vel.y = d->vel.z = 0; 
    d->onfloor = false;
    d->timeinair = 0;

	if (!d->health) { // JJT - If there is no health at all...
		SetHealth(d,100); // Reset items's Health to 100
	}
		
//    d->quadmillis = 0; // JJT - No Quadmillis on items.

	if (!d->gunselect) { // JJT - If there is no gun selected...
//	    d->gunselect = GUN_SG; // JJT - Select Shotgun
	    d->gunselect = GUN_FIST; // JJT - Select Fist instead!
	}

    d->gunwait = 0;
	d->attacking = false;
    d->lastaction = 0;

};
    
inventoryent *newinventoryent()                 // create a new blank item
    inventoryent *d = (inventoryent *)gp()->alloc(sizeof(inventoryent));
    d->o.x = 0;
    d->o.y = 0;
    d->o.z = 0;
    d->yaw = 270;
    d->pitch = 0;
    d->roll = 0;
    d->maxspeed = 20; // JJT - Roving Inventory items?
    d->outsidemap = false;
    d->inwater = false;
    d->radius = 1.1f;
    d->eyeheight = 3.2f;
    d->aboveeye = 0.7f;
    d->frags = 0;
    d->plag = 0;
    d->ping = 0;
    d->lastupdate = lastmillis;
    d->enemy = NULL;
    d->monsterstate = 0;
    d->name[0] = d->team[0] = 0;
    d->blocked = false;
    d->lifesequence = 0;

// JJT - Inventory Settings should go here.

	d->owner = NULL;

// JJT - End of new sections here

    d->state = CS_DEAD;	// JJT- Inventory Items are dead.
	// JJT - Dead state prevents inventory from counting in matches.

    spawnstate(d);
    return d;
};

void zapinventoryent(inventoryent *&d)
{
    if(d) gp()->dealloc(d, sizeof(inventoryent));
    d = NULL;
};

void entinmap(inventoryent *d)    // brute force but effective way to find a free spawn spot in the map
{
    loopi(100)              // try max 100 times
    {
        float dx = (rnd(21)-10)/10.0f*i;  // increasing distance
        float dy = (rnd(21)-10)/10.0f*i;
        d->o.x += dx;
        d->o.y += dy;
        if(collide(d, true, 0, 0)) return;
        d->o.x -= dx;
        d->o.y -= dy;
    };
    conoutf("can't find entity spawn spot! (%d, %d)", (int)d->o.x, (int)d->o.y);
    // leave ent at original pos, possibly stuck
};

void spawnitem(inventoryent *d)   // place at random spawn.
{
    int r = fixspawn-->0 ? 4 : rnd(10)+1;
    loopi(r) spawncycle = findentity(PLAYERSTART, spawncycle+1);
    if(spawncycle!=-1)
    {
        d->o.x = ents[spawncycle].x;
        d->o.y = ents[spawncycle].y;
        d->o.z = ents[spawncycle].z;
        d->yaw = ents[spawncycle].attr1;
        d->pitch = 0;
        d->roll = 0;
    }
    else
    {
        d->o.x = d->o.y = (float)ssize/2;
        d->o.z = 4;
    };
    entinmap(d);
    spawnstate(d);
    d->state = CS_DEAD;
};

// damage arriving from the network, monsters, player, all ends up here.

void itemdamage(int damage, int actor, inventoryent *act)
{
	int ad = 0;		// JJT - Set up Armor Defense variable.

    if(editmode) return;	// JJT - Items invulnerable only during
				// JJT - Edit Mode. Items can still be
				// JJT - destroyed if the player is
				// JJT - Dead, or if the intermission
				// JJT - is running.

    damageblend(damage);
	demoblend(damage);

	// JJT - Adjust armor protection values

/*	// JJT - Set hack for original armor types.
	if (act->armourtype < 3) {
		ad = damage*(act->armourtype+1)*20/100;
	}
*/
	// JJT - Adjust armor rating for other armor types.
	switch (armourtype) {
		case A_BLUE:			// JJT - Original Blue
			ad = damage/5;		// JJT - 20% absorbed
		case A_GREEN:			// JJT - Original Green
			ad = damage*2/5;	// JJT - 40% absorbed
		case A_YELLOW:			// JJT - Original Yellow
			ad = damage*3/5;	// JJT - 60% absorbed
		case A_FLAK:
			ad = damage/10;		// JJT - 10% absorbed
		case A_REFLECT:
			ad = damage/5;	// JJT - 20% absorbed
		case A_MESH:
			ad = damage*3/10;	// JJT - 30% absorbed
		case A_HYDRO:
			ad = damage*2/5;	// JJT - 40% absorbed
		case A_BATTLE:
			ad = damage*3/5;	// JJT - 60% absorbed
		case A_GOLUM:
			ad = damage*4/5;	// JJT - 80% absorbed
	}

    if(ad > act->armour) {		// JJT - If absorbed is more than armor value...
		ad = act->armour;	// JJT - Set absorbed to armor value.
	}

    act->armour -= ad;			// JJT - Take away absorbed from armor value.

    damage -= ad;			// JJT - Reduce damage by absorbed.

    float droll = damage/0.5f;
    act->roll += act->roll>0 ? droll : (act->roll<0 ? -droll : (rnd(2) ? droll : -droll));  // give item a kick depending on amount of damage
    if((act->health -= damage)<=0)
    {
        if(actor==-2)
        {
            conoutf("Item destroyed by %s.", (int)&act->name);
        }
        else if(actor==-1)
        {
            actor = getclientnum();
            conoutf("Item self-destructed.");
        }
        else
        {
            inventoryent *a = getclient(actor);
            if(a)
            {
                   conoutf("Item got fragged by %s.", (int)a->name);
            };
        };

        addmsg(1, 2, SV_DIED, actor);
        act->lifesequence++;
        act->attacking = false;
        act->state = CS_DEAD;
        act->pitch = 0;
        act->roll = 60;
        spawnstate(act);
        act->lastaction = lastmillis;
    }
    else
    {
        playsound(S_LAND);
    };
};

