/* JJT - renderattributes.cpp
	This file contains the RPG attribute hud display functions.
*/

#include "cube.h"

void GreenBlendBox(int x1, int y1, int x2, int y2, bool border)
{
    glDepthMask(GL_FALSE);
    glDisable(GL_TEXTURE_2D);
    glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
    glBegin(GL_QUADS);
    if(border) glColor3d(0.5, 0.3, 0.4); 
    else glColor3d(1.0, 1.0, 1.0);
    glVertex2i(x1, y1);
    glVertex2i(x2, y1);
    glVertex2i(x2, y2);
    glVertex2i(x1, y2);
    glEnd();

    glDisable(GL_BLEND);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glBegin(GL_POLYGON);
		glColor3d(0.2, 0.9, 0.3);
    glVertex2i(x1, y1);
    glVertex2i(x2, y1);
    glVertex2i(x2, y2);
    glVertex2i(x1, y2);
    glEnd();

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    xtraverts += 8;
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glDepthMask(GL_TRUE);
};

void DrawBarBox(int RightHudX, int UpperHudY) {
	int UpperUpperEdge = 0;
	int UpperLowerEdge = 0;
	int LowerUpperEdge = 0;
	int LowerLowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperUpperEdge = 10;
		UpperLowerEdge = 20;
		LowerUpperEdge = 70;
		LowerLowerEdge = 80;
		}
	else if (player1->showstatsheet == 0) {
		UpperUpperEdge = 0;
		UpperLowerEdge = 5;
		LowerUpperEdge = 35;
		LowerLowerEdge = 40;
		}
	else {
		UpperUpperEdge = 0;
		UpperLowerEdge = 5;
		LowerUpperEdge = 35;
		LowerLowerEdge = 40;
		}

	        glColor3ub(0,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX - 10, UpperHudY + UpperUpperEdge, RightHudX + 330, UpperHudY + UpperLowerEdge, 0.0, 0.0, 0.0);

		DrawStatLine (RightHudX - 10, UpperHudY + LowerUpperEdge, RightHudX + 330, UpperHudY + LowerLowerEdge, 0.0, 0.0, 0.0);

	        glBegin(GL_QUADS);

		glColor3d(0, 0, 0);

	if (player1->showstatsheet == 1) {
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX - 20, UpperHudY + 70);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX - 20, UpperHudY + 20);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX - 10, UpperHudY + 10);
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX - 10, UpperHudY + 80);
		}
	else {
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX - 20, UpperHudY + 35);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX - 20, UpperHudY + 5);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX - 10, UpperHudY + 0);
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX - 10, UpperHudY + 40);
		}

	if (player1->showstatsheet == 1) {
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX + 330, UpperHudY + 80);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX + 330, UpperHudY + 10);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX + 340, UpperHudY + 20);
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX + 340, UpperHudY + 70);
		}
	else {
	        glTexCoord2d(0.0, 0.1);
		glVertex2f(RightHudX + 330, UpperHudY + 40);
	        glTexCoord2d(1.0, 0.0);
		glVertex2f(RightHudX + 330, UpperHudY + 0);
	        glTexCoord2d(1.0, 0.1);
		glVertex2f(RightHudX + 340, UpperHudY + 5);
	        glTexCoord2d(0.0, 0.0);
		glVertex2f(RightHudX + 340, UpperHudY + 35);
		}

	        glEnd();
	};

void DrawDirection(float Direction, int MiddleX, int StartY) {
	while (Direction >= 360) {
		Direction = Direction - 360;
		}
	if (Direction <= 22.5 && Direction >= 337.5){
		draw_textf("N", MiddleX-20, StartY, 2, int(Direction));
		}
	else if (Direction > 22.5 && Direction < 67.5){
		draw_textf("NE", MiddleX-40, StartY, 2, int(Direction));
		}
	else if (Direction >= 67.5 && Direction <= 112.5){
		draw_textf("E", MiddleX-20, StartY, 2, int(Direction));
		}
	else if (Direction > 112.5 && Direction < 157.5){
		draw_textf("SE", MiddleX-40, StartY, 2, int(Direction));
		}
	else if (Direction >= 157.5 && Direction <= 202.5){
		draw_textf("S", MiddleX-20, StartY, 2, int(Direction));
		}
	else if (Direction > 202.5 && Direction < 247.5){
		draw_textf("SW", MiddleX-45, StartY, 2, int(Direction));
		}
	else if (Direction >= 247.5 && Direction <= 292.5){
		draw_textf("W", MiddleX-25, StartY, 2, int(Direction));
		}
	else if (Direction > 292.5 && Direction < 337.5){
		draw_textf("NW", MiddleX-45, StartY, 2, int(Direction));
		}
	else if (Direction <= 22.5 || Direction >= 337.5) {
 		draw_textf("N", MiddleX-20, StartY, 2, int(Direction));
		}
	else {
 		draw_textf("%d", MiddleX-50, StartY, 2, int(Direction));
		}
	};

void DrawCompassLines(float Direction, int MiddleX, int StartY, int OffSetX, int MarkWidth) {
	/* JJT - First, set CentralX to the direction.
		Then announce the width of the compass from center.
		Then set the left-most mark to the left of the center by the width.
		Then initialize a count of how far from the left the first mark will be.
		*/
	int CentralX = int(Direction * 10);
	int LeftMostX = MiddleX - OffSetX + MarkWidth;
	int LeftMostMark = CentralX - OffSetX + MarkWidth;

	/* JJT - Find the leftmost mark by finding a degree mark divisible by five.
		*/
	while(abs(LeftMostMark) % 50 > 0) {
		LeftMostX = LeftMostX + 1;
		LeftMostMark = LeftMostMark + 1;
		}

	/* JJT - Up until Right-most location, draw directional lines.
		*/
	while(abs(LeftMostX) < MiddleX + OffSetX - MarkWidth) {

			/* JJT - If the directional value is divisible by 45 degrees,
				set a special mark (maybe draw the direction over that
				mark in future versions or different mods.)
				*/
			if (abs(LeftMostMark) % 450 == 0) {
				/* JJT - Add a switch to allow for future additions,
					such as moving direction indicators.
					*/
				switch (LeftMostMark) {
					case (-3600):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-3150):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-2700):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-2250):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-1800):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-1350):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-900):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (-450):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (0):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (450):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (900):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (1350):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (1800):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (2250):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (2700):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (3150):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (3600):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (4050):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (4500):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (4950):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (5400):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (5850):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (6300):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (6750):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					case (7200):
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 10, LeftMostX + MarkWidth, StartY + 70, true);
					}
				}
			/* JJT - If the degrees are normal, draw a normal mark.
				*/
			else {
						GreenBlendBox(LeftMostX - MarkWidth, StartY + 30, LeftMostX + MarkWidth, StartY + 70, true);
				}

		/* JJT - Set the next 5-degree mark 50 points to the right.
			*/
		LeftMostX = LeftMostX + 50;
		LeftMostMark = LeftMostMark + 50;
		}

		/* JJT - Draw a base line under the degree lines.
			*/
		GreenBlendBox(MiddleX-OffSetX, StartY+80, MiddleX+OffSetX, StartY+100, true);
	};

void DrawCompass(dynent *d) {
        glColor3ub(0,255,0);

	DrawCompassLines(d->yaw, 1800, 2500, 300, 10);

	DrawDirection(d->yaw, 1800, 2420);
	};

void HealthBar(dynent *d, int RightHudX, int UpperHudY, int AverageHolder, int AverageMaxHolder) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (AverageHolder < AverageMaxHolder && AverageMaxHolder > 0) {
	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + AverageHolder, UpperHudY + UpperEdge, RightHudX + AverageMaxHolder, UpperHudY + LowerEdge, 1.0, 0.0, 0.0);
		}

	if (AverageHolder > 0) {
	        glColor3ub(0,255,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + AverageHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

	DrawBarBox(RightHudX, UpperHudY);
};

void PulsateHealthIcon(int RightHudX, int UpperHudY, int LeftX, int LowerY, int AverageHolder, int AverageMaxHolder) {
	float TimerRemainder = player1->TimerTick/30;

	if (player1->TimerCount == 3 || player1->TimerCount == 4) {
	        glColor4f(1.0f, 1.0f, 1.0f, TimerRemainder);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawTexturedBox(0.66f, 0.66f, 1.0, 1.0, RightHudX, UpperHudY, RightHudX + 60, UpperHudY + 60, 5, TimerRemainder);
		}
	else {
	        glColor3ub(255,255,255);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawTexturedBox(0.66f, 0.66f, 1.0, 1.0, RightHudX, UpperHudY, RightHudX + 60, UpperHudY + 60, 5, 1);
		}
};

void AgilityBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->agilitymax > player1->agility && player1->agilitymax > 0) {
		int AgilityHolder = int(player1->agility/100);
		int AgilityMaxHolder = int(player1->agilitymax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + AgilityHolder, UpperHudY + UpperEdge, RightHudX + AgilityMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->agility > 0) {
		int AgilityHolder = int(player1->agility/100);

	        glColor3ub(0,255,0);			/* JJT - Green */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + AgilityHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void CharismaBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->charismamax > player1->charisma && player1->charismamax > 0) {
		int CharismaHolder = int(player1->charisma/100);
		int CharismaMaxHolder = int(player1->charismamax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + CharismaHolder, UpperHudY + UpperEdge, RightHudX + CharismaMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->charisma > 0) {
		int CharismaHolder = int(player1->charisma/100);

	        glColor3ub(0,255,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + CharismaHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void IntelBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->intelmax > player1->intel && player1->intelmax > 0) {
		int IntelHolder = int(player1->intel/100);
		int IntelMaxHolder = int(player1->intelmax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + IntelHolder, UpperHudY + UpperEdge, RightHudX + IntelMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->intel > 0) {
		int IntelHolder = int(player1->intel/100);

	        glColor3ub(0,255,0);			/* JJT - Green */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + IntelHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}
		DrawBarBox(RightHudX, UpperHudY);
};

void StaminaBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->staminamax > player1->stamina && player1->staminamax > 0) {
		int StaminaHolder = int(player1->stamina/100);
		int StaminaMaxHolder = int(player1->staminamax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + StaminaHolder, UpperHudY + UpperEdge, RightHudX + StaminaMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->stamina > 0) {
		int StaminaHolder = int(player1->stamina/100);

	        glColor3ub(0,255,0);			/* JJT - Green */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + StaminaHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void StrengthBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->strengthmax > player1->strength && player1->strengthmax > 0) {
		int StrengthHolder = int(player1->strength/100);
		int StrengthMaxHolder = int(player1->strengthmax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + StrengthHolder, UpperHudY + UpperEdge, RightHudX + StrengthMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->strength > 0) {
		int StrengthHolder = int(player1->strength/100);

	        glColor3ub(0,255,0);			/* JJT - Green */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + StrengthHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void WisdomBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (player1->wisdommax > player1->wisdom && player1->wisdommax > 0) {
		int WisdomHolder = int(player1->wisdom/100);
		int WisdomMaxHolder = int(player1->wisdommax/100);

	        glColor3ub(255,0,0);
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX + WisdomHolder, UpperHudY + UpperEdge, RightHudX + WisdomMaxHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

	if (player1->wisdom > 0) {
		int WisdomHolder = int(player1->wisdom/100);

	        glColor3ub(0,255,0);			/* JJT - Green */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + WisdomHolder, UpperHudY + LowerEdge, 0.0, 0.9, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void HungerBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (d->food < 20000) {
		int HungerHolder = int(playerhunger(player1)/50);

	        glColor3ub(255,127,0);			/* JJT - Red and half green is orange. */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + HungerHolder, UpperHudY + LowerEdge, 1.0, 0.5, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};

void ThirstBar(dynent *d, int RightHudX, int UpperHudY) {
	int UpperEdge = 0;
	int LowerEdge = 0;

	if (player1->showstatsheet == 1) {
		UpperEdge = 30;
		LowerEdge = 60;
		}
	else if (player1->showstatsheet == 0) {
		UpperEdge = 10;
		LowerEdge = 30;
		}
	else {
		UpperEdge = 10;
		LowerEdge = 30;
		}

	if (d->water < 30000) {
		int ThirstHolder = int(playerthirst(player1)/50);

	        glColor3ub(255,0,0);			/* JJT - Red */
	        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 4 is a big square. */

		DrawStatLine (RightHudX, UpperHudY + UpperEdge, RightHudX + ThirstHolder, UpperHudY + LowerEdge, 0.9, 0.0, 0.0);
		}

		DrawBarBox(RightHudX, UpperHudY);
};
