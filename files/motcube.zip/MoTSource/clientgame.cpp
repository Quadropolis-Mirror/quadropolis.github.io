// clientgame.cpp: core game related stuff

#include "cube.h"

int nextmode = 0;         // nextmode becomes gamemode after next map load
VAR(gamemode, 1, 0, 0);

void mode(int n) { addmsg(1, 2, SV_GAMEMODE, nextmode = n); };
COMMAND(mode, ARG_1INT);

bool intermission = false;

dynent *player1 = newdynent();          // our client
dvector players;                        // other clients

VAR(sensitivity, 0, 10, 1000);
VAR(sensitivityscale, 1, 1, 100);
VAR(invmouse, 0, 0, 1);

int lastmillis = 0;
int curtime;
string clientmap;

extern int framesinmap;

char *getclientmap() { return clientmap; };

void resetmovement(dynent *d)
{
    d->k_left = false;
    d->k_right = false;
    d->k_up = false;
    d->k_down = false;  
    d->jumpnext = false;
    d->strafe = 0;
    d->move = 0;
};

int CheckUpperLimit32K(int LimitCheck)
{
	if (LimitCheck > MaxAttrCnt) {
		return MaxAttrCnt;
		}
	else {
		return LimitCheck;
		}
};

int CheckUpperLimit1(int LimitCheck)
{
	if (LimitCheck > MaxAttrCnt) {
		return 1;
		}
	else {
		return (LimitCheck);
		}
};

void SetMaxSpeed(dynent *d)	// JJT - New Function for Health Setting.
{
	    d->maxspeed = int(d->agility/2000)+8;	/* JJT - Set to full speed
								according to agility.
								Range: 8-24
						*/
};

void CreditCorrection(dynent *d) {

	int MilliCreditCounter = 0;
	int KiloCreditCounter = 0;
	int MegaCreditCounter = 0;
	int GigaCreditCounter = 0;
	int TeraCreditCounter = 0;
	int PetaCreditCounter = 0;

		/* JJT - Following: Too many credits? */
		if (d->credits > MaxMoney) {
		/* JJT - reduce credits by how much over MaxMoney it goes. */
		d->credits = d->credits-(int(d->credits-MaxMoney));
		}
		if (d->credits > MoneyLimit*Tera) {
		PetaCreditCounter = int(d->credits/Peta);
		d->credits = d->credits - PetaCreditCounter*Peta;
		}
		if (d->credits > MoneyLimit*Giga) {
		TeraCreditCounter = int((d->credits-PetaCreditCounter*Peta)/Tera);
		d->credits = d->credits - TeraCreditCounter*Tera;
		}
		if (d->credits > MoneyLimit*Mega) {
		GigaCreditCounter = int((d->credits-TeraCreditCounter*Tera)/Giga);
		d->credits = d->credits - GigaCreditCounter*Giga;
		}
		if (d->credits > MoneyLimit*Kilo) {
		MegaCreditCounter = int((d->credits-GigaCreditCounter*Giga)/Mega);
		d->credits = d->credits - MegaCreditCounter*Mega;
		}
		if (d->credits > MoneyLimit) {
		KiloCreditCounter = int((d->credits-MegaCreditCounter*Mega)/Kilo);
		d->credits = d->credits - KiloCreditCounter*Kilo;
		}
		if (d->credits > 0.0) {
		MilliCreditCounter = int(d->credits*1000) - int(d->credits)*1000;
		}

		/* JJT - Now, finally, set credits to an integet between 0 and 999. */
		d->credits = float(int(d->credits));

	d->petacredits = d->petacredits + PetaCreditCounter;
	d->teracredits = d->teracredits + TeraCreditCounter;
	d->gigacredits = d->gigacredits + GigaCreditCounter;
	d->megacredits = d->megacredits + MegaCreditCounter;
	d->kilocredits = d->kilocredits + KiloCreditCounter;
	d->millicredits = d->millicredits + MilliCreditCounter;
};

void AddCredits(dynent *d, float CreditAmount) {
		d->credits = d->credits + CreditAmount;
		CreditCorrection(d);
};
void BadJobCompleted(dynent *d, float Modifier) {
	d->wisdomexp = d->wisdomexp + int(Modifier*(1000 + int(d->intel/32)));
	d->trainingexp = d->trainingexp + int(Modifier*(1000 + int(d->intel/32)));
	}

void GoodJobCompleted(dynent *d, float Modifier, int JobPay) {
	d->trainingexp = d->trainingexp + int(Modifier*(1000 + int(d->intel/32)));
	d->credits = d->credits + (Modifier+1)/2*(JobPay);
	CreditCorrection(d);
};

void SetHealth(dynent *d, int HealthAmount)	// JJT - New Function for Health Setting.
{
	    d->health = HealthAmount; // JJT - Set to full health
};

void SetArmour(dynent *d, int ArmourAmount)	// JJT - New Function for Armor Setting.
{
	    d->armour = ArmourAmount; // JJT - Set armor points
};

void spawnstate(dynent *d)              // reset player state not persistent accross spawns
{
    resetmovement(d);
    d->vel.x = d->vel.y = d->vel.z = 0; 
    d->onfloor = false;
    d->timeinair = 0;

	if (!d->health || d->health <0) {	/* JJT - If there is no health at all...
					Give D 100 Health.
				*/
		SetHealth(d,100);
	}
		
	if (!d->armourtype) {	/* JJT - If there is no armor type...
					Get Blue Armor.
				*/
	    d->armourtype = A_BLUE;
	}

	if (!d->armour || d->armour<0) {	/* JJT - If there is no armor at all...
					Reset D's armor to 50.
				*/
		SetArmour(d,50);
	}

    d->quadmillis = 0;	/* JJT - Reset Quad Timer to 0. */

	if (!d->gunselect) {	/* JJT - If there is no gun selected...
					Then select the fist instead.
				*/
	    d->gunselect = GUN_FIST;
	}

    d->gunwait = 0;
	d->attacking = false;
    d->lastaction = 0;

	loopi(NUMGUNS) {
		if (!d->ammo[i]) {	/* JJT - If the ammo value is null...
						Reset to 0.
					*/
		d->ammo[i] = 0;
		}
		/* JJT - You can now keep ammo. */
	}

	/* JJT - We need at least one fist with which to fight. However, you always have two. No amputations. */
    d->ammo[GUN_FIST] = 2;

    if(m_noitems)
    {
        d->gunselect = GUN_RIFLE;
        d->armour = 0;
        if(m_noitemsrail)
        {
            d->health = 1;
				d->strengthmax = 1;
				d->strength = 1;
				d->staminamax = 10;
				d->stamina = 10;
				d->agilitymax = 24000;
				d->agility = 24000;
            d->ammo[GUN_RIFLE] = 100;
        }
        else
        {
            if(gamemode==12) {
		d->gunselect = GUN_FIST;
		return;
		}  // eihrul's secret "instafist" mode

            d->health = 256;
				d->strengthmax = 1000;
				d->strength = 1000;
				d->staminamax = 10000;
				d->stamina = 10000;
				d->agilitymax = 24000;
				d->agility = 24000;

            if(m_tarena)
            {
                int gun1 = rnd(4)+1;
                baseammo(d->gunselect = gun1);
                for(;;)
                {
                    int gun2 = rnd(4)+1;
                    if(gun1!=gun2) { baseammo(gun2); break; };
                };
            }
            else if(m_arena)    // insta arena
            {
                d->ammo[GUN_RIFLE] = 100;
            }
            else // efficiency
            {
                loopi(4) baseammo(i+1);
                d->gunselect = GUN_CG;
            };
            d->ammo[GUN_CG] /= 2;
        }
    }
    else
    {
	if (d->ammo[GUN_SG] == 0) {
		}
	else if (d->ammo[GUN_SG] < 5) { // JJT - Only reset shotgun ammo if less than 5 shells remain
       		d->ammo[GUN_SG] = 5; // JJT - Set Shotgun ammo to 5
		}
		/* JJT - Removed Shotgun ammo
			Now you start with only the fist!
		*/
    }

};
    
dynent *newdynent()                 // create a new blank player or monster
{
    dynent *d = (dynent *)gp()->alloc(sizeof(dynent));
    d->o.x = 0;
    d->o.y = 0;
    d->o.z = 0;
    d->yaw = 270;
    d->pitch = 0;
    d->roll = 0;

	// JJT - Some of the following should be modified by RPG ratings.

	d->maxspeed = 22; // JJT - This should depend on Agility Rating.

    d->outsidemap = false;
    d->inwater = false;
    d->radius = 1.1f;
    d->eyeheight = 3.2f;
    d->aboveeye = 0.7f;
    d->frags = 0;
    d->plag = 0;
    d->ping = 0;
    d->lastupdate = lastmillis;
    d->enemy = NULL;
    d->monsterstate = 0;
    d->name[0] = d->team[0] = 0;
    d->blocked = false;
    d->lifesequence = 0;
    d->state = CS_ALIVE;

// JJT - Add new sections here for all moving entities (players and monsters)

// JJT - Inventory Settings should go here.

	/* JJT - Reset ammo counters.
	*/
	loopi(NUMGUNS) {
		if (!d->ammo[i]) {
			d->ammo[i]=0;
			}
		}

	/* JJT - RPG Attribute Ratings should go here.
		Attributes except for food and water should
		match Attribute Rating Maximums when the
		player entity first starts existing.
		Exception: NPCs that are not at their best.
	*/

	/* JJT - Banking values */
	
	if (!d->bankaccountnumber) {
		d->bankaccountnumber = 0;
		d->bankaccountnumber = 00000001 + (rand() * 1000);
		}
	if (!d->bankaccountcode) {
		d->bankaccountcode =	00010001;
		}
	if (!d->millicredits) {
		d->millicredits =	0;
		}
	if (!d->credits) {
		d->credits =		0.0;
		}
	if (!d->kilocredits) {
		d->kilocredits =	0;
		}
	if (!d->megacredits) {
		d->megacredits =	0;
		}
	if (!d->gigacredits) {
		d->gigacredits =	0;
		}
	if (!d->teracredits) {
		d->teracredits =	0;
		}
	/* JJT - Following: Generally HACK the player's Petacredit count by 2
		to avoid having too much money in the game. */
	if (!d->petacredits) {
		d->petacredits =	0;
		}
	else if (d->petacredits < 2) {
		d->petacredits =	0;
		}
	else {
		d->petacredits = d->petacredits-2;
		}

	if (!d->trainingexp) {
		d->trainingexp =	1;
		}

	if (!d->food) {
		d->food = 29000;	/* JJT - Basic Hunger */
		}
	if (!d->water) {
		d->water = 29000;	/* JJT - Not thirsty at all. */
	}
	if (!d->agility) {
		d->agility = 20000;	/* JJT - Slow-moving at first. */
	}
	if (!d->stamina) {
		d->stamina = 20000;	/* JJT - Breathless all the time. */
	}
	if (!d->strength) {
		d->strength = 20000;	/* JJT - Can hardly lift a feather. */
	}
	if (!d->charisma) {
		d->charisma = 20000;	/* JJT - Ugly, too. */
	}
	if (!d->intel) {
		d->intel = 20000;	/* JJT - Low intelligence. */
	}
	if (!d->wisdom) {
		d->wisdom = 20000;	/* JJT - Foolish */
	}

	/* JJT - Maxspeed derived from agility.
		This will need to be updated on the fly
		as agility gets upgraded.
		Minimum: 10.00...
		Maximum: 30
	*/

	SetMaxSpeed(d);

	/* JJT - Rating Maximums per entity go here.
		These maximum ratings should match the
		regular Attribute Ratings at the start
		of the entity's lifetime and are meant
		to hold the maximum value attributes can
		reach when "healed".
	*/

	if (!d->agilitymax) {
		d->agilitymax = d->agility;
		}
	if (!d->staminamax) {
		d->staminamax = d->stamina;
		}
	if (!d->strengthmax) {
		d->strengthmax = d->strength;
		}
	if (!d->charismamax) {
		d->charismamax = d->charisma;
		}
	if (!d->intelmax) {
		d->intelmax = d->intel;
		}
	if (!d->wisdommax) {
		d->wisdommax = d->wisdom;
		}

	/* JJT - Rating Experience goes here.
		When experience reaches 32,000,
		increment the rating and rating max
		by 1 point, and reset experience to
		1 point again to start over.
	*/

	d->agilityexp = 1;
	d->staminaexp = 1;
	d->strengthexp = 1;
	d->charismaexp = 1;
	d->intelexp = 1;
	d->wisdomexp = 1;

	/* JJT - Individual Skill Ratings.
		All skills start at 0.
		These can be developed at creation
		time by "rolling" for a starting
		character. Then they can be developed
		by the player over time.
	*/

	d->administration = 0;
	d->language = 0;
	d->medical = 0;
	d->programming = 0;
	d->repair = 0;

	d->armorskill = 0;
	d->melee = 0;
	d->mining = 0;
	d->swimming = 0;

	d->arcgun = 0;
	d->autogun = 0;
	d->blade = 0;
	d->handgun = 0;
	d->rifle = 0;

	/* JJT - Individual Skills Experience.
		When these reach 32,000, increment
		the related skill by 1 and reset
		this experience to 1 to start over.
	*/

	d->adminexp = 1;
	d->languageexp = 1;
	d->medicalexp = 1;
	d->programexp = 1;
	d->repairexp = 1;

	d->armorexp = 1;
	d->meleeexp = 1;
	d->miningexp = 1;
	d->swimexp = 1;

	d->arcgunexp = 1;
	d->autogunexp = 1;
	d->bladeexp = 1;
	d->handgunexp = 1;
	d->rifleexp = 1;

	/* JJT - Faction Section. Default faction 0.
		Default Faction Rep: 15,000 (apathetic)
		Default Faction Rep Max: 30,000 (loved)
		Faction Rep below  5,000: hated
		Faction Rep below 10,000: disliked
		Faction Rep above 20,000: liked
		Faction Rep above 25,000: admired
		Faction Rep about 30,000: loved
	*/

	d->faction = 0;

	for(int factiongroup = 0; factiongroup<(10); factiongroup++) {
		loopi(10) {
			d->factionrep[factiongroup][i] = 15000;
			}
	}

	for(int factiongroup = 0; factiongroup<(10); factiongroup++) {
		loopi(10) {
			d->factionrepmax[factiongroup][i] = 30000;
			}
	}

	d->showstatsheet = 3;
	d->hidestats = 0;
	d->StatSheetAdjust = 0;
	d->TimerTick = 0;
	d->TimerCount = 0;

/* JJT - End of new sections here. */

    spawnstate(d);
    return d;
};

void respawnself()
{
	spawnplayer(player1);
	showscores(false);
};

void arenacount(dynent *d, int &alive, int &dead, char *&lastteam, bool &oneteam)
{
    if(d->state!=CS_DEAD)
    {
        alive++;
        if(lastteam && strcmp(lastteam, d->team)) oneteam = false;
        lastteam = d->team;
    }
    else
    {
        dead++;
    };
};

int arenarespawnwait = 0;
int arenadetectwait  = 0;

void arenarespawn()
{
    if(arenarespawnwait)
    {
        if(arenarespawnwait<lastmillis)
        {
            arenarespawnwait = 0;
            conoutf("new round starting... fight!");
            respawnself();
        };
    }
    else if(arenadetectwait==0 || arenadetectwait<lastmillis)
    {
        arenadetectwait = 0;
        int alive = 0, dead = 0;
        char *lastteam = NULL;
        bool oneteam = true;
        loopv(players) if(players[i]) arenacount(players[i], alive, dead, lastteam, oneteam);
        arenacount(player1, alive, dead, lastteam, oneteam);
        if(dead>0 && (alive<=1 || (m_teammode && oneteam)))
        {
            conoutf("arena round is over! next round in 5 seconds...");
            if(alive) conoutf("team %s is last man standing", (int)lastteam);
            else conoutf("everyone died!");
            arenarespawnwait = lastmillis+5000;
            arenadetectwait  = lastmillis+10000;
            player1->roll = 0;
        }; 
    };
};

void zapdynent(dynent *&d)
{
    if(d) gp()->dealloc(d, sizeof(dynent));
    d = NULL;
};

extern int democlientnum;

void otherplayers()
{
    loopv(players) if(players[i])
    {
        const int lagtime = lastmillis-players[i]->lastupdate;
        if(lagtime>1000 && players[i]->state==CS_ALIVE)
        {
            players[i]->state = CS_LAGGED;
            continue;
        };
        if(lagtime && players[i]->state != CS_DEAD && (!demoplayback || i!=democlientnum)) moveplayer(players[i], 2, false);   // use physics to extrapolate player position
    };
};

int sleepwait = 0;
string sleepcmd;
void sleep(char *msec, char *cmd) { sleepwait = atoi(msec)+lastmillis; strcpy_s(sleepcmd, cmd); };
COMMAND(sleep, ARG_2STR);

void updateworld(int millis)        // main game update loop
{
    if(lastmillis)
    {     
        curtime = millis - lastmillis;
        if(sleepwait && lastmillis>sleepwait) { execute(sleepcmd); sleepwait = 0; };
        physicsframe();
        checkquad(curtime);
		if(m_arena) arenarespawn();
        moveprojectiles((float)curtime);
        demoplaybackstep();
        if(!demoplayback)
        {
            if(getclientnum()>=0) shoot(player1, worldpos);     // only shoot when connected to server
            gets2c();           // do this first, so we have most accurate information when our player moves
		/* JJT - If the health is more than 0, use it to heal other attributes. */
		if (GlobalArrayOutput() < 0.02 && player1->health > 0) {
			SpreadHealthPoints(player1);
			}
		if (player1->stamina < player1->staminamax) {
			player1->stamina = player1->stamina + 1;
			}
        };
        otherplayers();
        if(!demoplayback)
        {
            monsterthink();
            if(player1->state==CS_DEAD)
            {
				if(lastmillis-player1->lastaction<2000)
				{
					player1->move = player1->strafe = 0;
					moveplayer(player1, 10, false);
				};
            }
            else if(!intermission)
            {
                moveplayer(player1, 20, true);
                checkitems();
            };
            c2sinfo(player1);   // do this last, to reduce the effective frame lag
        };
    };
    lastmillis = millis;
};

void entinmap(dynent *d)    // brute force but effective way to find a free spawn spot in the map
{
    loopi(100)              // try max 100 times
    {
        float dx = (rnd(21)-10)/10.0f*i;  // increasing distance
        float dy = (rnd(21)-10)/10.0f*i;
        d->o.x += dx;
        d->o.y += dy;
        if(collide(d, true, 0, 0)) return;
        d->o.x -= dx;
        d->o.y -= dy;
    };
    conoutf("can't find entity spawn spot! (%d, %d)", (int)d->o.x, (int)d->o.y);
    // leave ent at original pos, possibly stuck
};

int spawncycle = -1;
int fixspawn = 2;

void setplayerstats(dynent *d)
{
	/* JJT - Begin setting up player/monster effects.
		This is passed to a separate function called SetRandomStats(d,MinimumStats).
	*/

	SetRandomStats(d, 4000);

	SetRandomSkills(d, 50);

	/* JJT - Maxspeed derived from agility.
		This will need to be updated on the fly
		as agility gets upgraded.
		Minimum: 10.00...
		Maximum: 30
	*/

	SetMaxSpeed(d);

// JJT - End of new sections here

};

void spawnplayer(dynent *d)   // place at random spawn. also used by monsters!
{
    int r = fixspawn-->0 ? 4 : rnd(10)+1;
    loopi(r) spawncycle = findentity(PLAYERSTART, spawncycle+1);
    if(spawncycle!=-1)
    {
        d->o.x = ents[spawncycle].x;
        d->o.y = ents[spawncycle].y;
        d->o.z = ents[spawncycle].z;
        d->yaw = ents[spawncycle].attr1;
        d->pitch = 0;
        d->roll = 0;
    }
    else
    {
        d->o.x = d->o.y = (float)ssize/2;
        d->o.z = 4;
    };
    entinmap(d);
    spawnstate(d);
    d->state = CS_ALIVE;

};

void respawn()
{
    if(player1->state==CS_DEAD)
    { 
        player1->attacking = false;
        if(m_arena) {
		conoutf("waiting for new round to start...");
		return;
		};
        if(m_sp) {	/* JJT - Single Player? Start the same map over again. */
		nextmode = gamemode;
		changemap(clientmap);
		return;
		}
	else {
		spawnstate(player1);
		}
	respawnself();
	}
};

// movement input code

#define dir(name,v,d,s,os) void name(bool isdown) { player1->s = isdown; player1->v = isdown ? d : (player1->os ? -(d) : 0); player1->lastmove = lastmillis; };

dir(backward, move,   -1, k_down,  k_up);
dir(forward,  move,    1, k_up,    k_down);
dir(left,     strafe,  1, k_left,  k_right); 
dir(right,    strafe, -1, k_right, k_left); 

void attack(bool on)
{
	if(player1->showstatsheet == 3) {
		player1->showstatsheet = 0;
		}
		
	if(intermission) {
		return;
		}
	if(editmode) {
		editdrag(on);
		}
	else if(player1->attacking = on) {
		respawn();
		}
};

void jumpn(bool on) {
	if(player1->showstatsheet == 3) {
		player1->showstatsheet = 0;
		}
		
	if(!intermission && (player1->jumpnext = on)) {
		player1->stamina = player1->stamina - 30;
		if (player1->stamina < 0) {
			player1->stamina = 0;
			}
		respawn();
		}
	};

COMMAND(backward, ARG_DOWN);
COMMAND(forward, ARG_DOWN);
COMMAND(left, ARG_DOWN);
COMMAND(right, ARG_DOWN);
COMMANDN(jump, jumpn, ARG_DOWN);
COMMAND(attack, ARG_DOWN);
COMMAND(showscores, ARG_DOWN);

void fixplayer1range()
{
    const float MAXPITCH = 90.0f;
    if(player1->pitch>MAXPITCH) player1->pitch = MAXPITCH;
    if(player1->pitch<-MAXPITCH) player1->pitch = -MAXPITCH;
    while(player1->yaw<0.0f) player1->yaw += 360.0f;
    while(player1->yaw>=360.0f) player1->yaw -= 360.0f;
};

void mousemove(int dx, int dy)
{
    if(player1->state==CS_DEAD || intermission) return;
    const float SENSF = 33.0f;     // try match quake sens
    player1->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
    player1->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
	fixplayer1range();
};

// damage arriving from the network, monsters, yourself, all ends up here.

void selfdamage(int damage, int actor, dynent *act)
{
	int ad = 0;

    if(player1->state!=CS_ALIVE || editmode || intermission) return;
    damageblend(damage);
	demoblend(damage);

	switch (player1->armourtype) {
		case A_BLUE:			// JJT - Original Blue
			ad = int(damage/5);	// JJT - 20% absorbed
		case A_GREEN:			// JJT - Original Green
			ad = int(damage*2/5);	// JJT - 40% absorbed
		case A_YELLOW:			// JJT - Original Yellow
			ad = int(damage*3/5);	// JJT - 60% absorbed
		case A_FLAK:
			ad = int(damage/10);		// JJT - 10% absorbed
			if (damage < 100) {
				damage = ad;
				}
		case A_REFLECT:
			ad = int(damage/5);	// JJT - 20% absorbed
			if (damage < 300) {
				damage = ad;
				}
		case A_MESH:
			ad = int(damage*3/10);	// JJT - 30% absorbed
			if (damage < 600) {
				damage = ad;
				}

		case A_HYDRO:
			ad = int(damage*2/5);	// JJT - 40% absorbed
			if (damage < 1000) {
				damage = ad;
				}
		case A_BATTLE:
			ad = int(damage*3/5);	// JJT - 60% absorbed
			if (damage < 1500) {
				damage = ad;
				}
		case A_GOLUM:
			ad = int(damage*4/5);	// JJT - 80% absorbed
			if (damage < 2500) {
				damage = ad;
				}

	}

    if(ad>player1->armour) {	/* JJT - Is ad damage more than remaining armor?
					Then reduce ad damage to remaining armor.
				*/
	ad = player1->armour;
	}
    player1->armour -= ad;	/* JJT - Take ad damage away from armor. */

    damage -= ad;	/* JJT - Reduce damage by Armor Damage (ad). */
	float droll = damage / 100;	/* JJT - Divide by 50. */

    player1->roll += player1->roll>0 ? droll : (player1->roll<0 ? -droll : (rnd(2) ? droll : -droll));  // give player a kick depending on amount of damage

	SpreadDamagePoints(player1, damage);

	if(CalculateAverageHealth(player1)<1) {
        if(actor==-2)
        {
            conoutf("you got killed by %s!", (int)&act->name);
        }
        else if(actor==-1)
        {
            actor = getclientnum();
            conoutf("you suicided!");
            addmsg(1, 2, SV_FRAGS, --player1->frags);
        }
        else
        {
            dynent *a = getclient(actor);
            if(a)
            {
                if(isteam(a->team, player1->team))
                {
                    conoutf("you got fragged by a teammate (%s)", (int)a->name);
                }
                else
                {
                    conoutf("you got fragged by %s", (int)a->name);
                };
            };
        };
        showscores(true);
        addmsg(1, 2, SV_DIED, actor);
        player1->lifesequence++;
        player1->attacking = false;
        player1->state = CS_DEAD;
        player1->pitch = 0;
        player1->roll = 75;	/* JJT - Roll from 60 to 75 to give a more laying-down POV. */
        playsound(S_DIE1+rnd(2));
        spawnstate(player1);
        player1->lastaction = lastmillis;
    }
    else
    {
        playsound(S_PAIN6);
    };
};

void timeupdate(int timeremain)
{
    if(!timeremain)
    {
        intermission = true;
        player1->attacking = false;
        conoutf("intermission:");
        conoutf("game has ended!");
        showscores(true);
    }
    else
    {
        conoutf("time remaining: %d minutes", timeremain);
    };
};

dynent *getclient(int cn)   // ensure valid entity
{
    if(cn<0 || cn>=MAXCLIENTS)
    {
        neterr("clientnum");
        return NULL;
    };
    while(cn>=players.length()) players.add(NULL);
    return players[cn] ? players[cn] : (players[cn] = newdynent());
};

void initclient()
{
    clientmap[0] = 0;
    initclientnet();
};

void startmap(char *name)   // called just after a map load
{
    if(netmapstart() && m_sp) {
		gamemode = 0;
		conoutf("coop sp not supported yet");
		};
    sleepwait = 0;
    monsterclear();
    projreset(); 
    spawncycle = -1;
    spawnplayer(player1);
    player1->frags = 0;
	if (!m_sp) {
		setplayerstats(player1);	/* JJT - Reset Stats if multiplayer. */
		}
    loopv(players) if(players[i]) players[i]->frags = 0;
    resetspawns();
    strcpy_s(clientmap, name);
    if(editmode) toggleedit();
    setvar("gamespeed", 100);

	/* JJT - This should be adjustable in a menu somewhere.
	*/

	setvar("fog", 180);

	/* JJT - Change to a pink for Titan. From 0x8099B3 to 0xFF7F8F*/
	setvar("fogcolour", 0xFF7F8F);

    showscores(false);
    intermission = false;
    framesinmap = 0;
    conoutf("game mode is %s", (int)modestr(gamemode));
}; 

COMMANDN(map, changemap, ARG_1STR);
