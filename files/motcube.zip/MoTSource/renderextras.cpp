// renderextras.cpp: misc gl render code and the HUD

#include "cube.h"

VAR(crosshairsize, 0, 15, 50);

VAR(crosshairfx, 0, 1, 1);

void line(int x1, int y1, float z1, int x2, int y2, float z2)
{
    glBegin(GL_POLYGON);
    glVertex3f((float)x1, z1, (float)y1);
    glVertex3f((float)x1, z1, y1+0.01f);
    glVertex3f((float)x2, z2, y2+0.01f);
    glVertex3f((float)x2, z2, (float)y2);
    glEnd();
    xtraverts += 4;
};

void linestyle(float width, int r, int g, int b)
{
    glLineWidth(width);
    glColor3ub(r,g,b);
};

void box(block &b, float z1, float z2, float z3, float z4)
{
    glBegin(GL_POLYGON);
    glVertex3f((float)b.x,      z1, (float)b.y);
    glVertex3f((float)b.x+b.xs, z2, (float)b.y);
    glVertex3f((float)b.x+b.xs, z3, (float)b.y+b.ys);
    glVertex3f((float)b.x,      z4, (float)b.y+b.ys);
    glEnd();
    xtraverts += 4;
};

void dot(int x, int y, float z)
{
    const float DOF = 0.1f;
    glBegin(GL_POLYGON);
    glVertex3f(x-DOF, (float)z, y-DOF);
    glVertex3f(x+DOF, (float)z, y-DOF);
    glVertex3f(x+DOF, (float)z, y+DOF);
    glVertex3f(x-DOF, (float)z, y+DOF);
    glEnd();
    xtraverts += 4;
};

void blendbox(int x1, int y1, int x2, int y2, bool border)
{
    glDepthMask(GL_FALSE);
    glDisable(GL_TEXTURE_2D);
    glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
    glBegin(GL_QUADS);
    if(border) glColor3d(0.5, 0.3, 0.4); 
    else glColor3d(1.0, 1.0, 1.0);
    glVertex2i(x1, y1);
    glVertex2i(x2, y1);
    glVertex2i(x2, y2);
    glVertex2i(x1, y2);
    glEnd();

    glDisable(GL_BLEND);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glBegin(GL_POLYGON);
		glColor3d(0.8, 0.8, 0.4);
    glVertex2i(x1, y1);
    glVertex2i(x2, y1);
    glVertex2i(x2, y2);
    glVertex2i(x1, y2);
    glEnd();

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    xtraverts += 8;
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glDepthMask(GL_TRUE);
};

const int MAXSPHERES = 50;
struct sphere { vec o; float size, max; int type; sphere *next; };
sphere spheres[MAXSPHERES], *slist = NULL, *sempty = NULL;
bool sinit = false;

void newsphere(vec &o, float max, int type)
{
    if(!sinit)
    {
        loopi(MAXSPHERES)
        {
            spheres[i].next = sempty;
            sempty = &spheres[i];
        };
        sinit = true;
    };
    if(sempty)
    {
        sphere *p = sempty;
        sempty = p->next;
        p->o = o;
        p->max = max;
        p->size = 1;
        p->type = type;
        p->next = slist;
        slist = p;
    };
};

void renderspheres(int time)
{
    glDepthMask(GL_FALSE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glBindTexture(GL_TEXTURE_2D, 24);  

    for(sphere *p, **pp = &slist; (p = *pp);)
    {
        glPushMatrix();
        float size = p->size/p->max;
        glColor4f(1.0f, 1.0f, 1.0f, 1.0f-size);
        glTranslatef(p->o.x, p->o.z, p->o.y);
        glRotatef(lastmillis/5.0f, 1, 1, 1);
        glScalef(p->size, p->size, p->size);
        glCallList(1);
        glScalef(0.8f, 0.8f, 0.8f);
        glCallList(1);
        glPopMatrix();
        xtraverts += 12*6*2;

        if(p->size>p->max)
        {
            *pp = p->next;
            p->next = sempty;
            sempty = p;
        }
        else
        {
            p->size += time/100.0f;   
            pp = &p->next;
        };
    };

    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
};

string closeent;
char *entnames[] =
{
    "none?", "light", "playerstart",
    "shells", "bullets", "rockets", "riflerounds",
    "health", "healthboost", "greenarmour", "yellowarmour", "quaddamage", 
    "teleport", "teledest", 
    "mapmodel", "monster", "trigger", "jumppad",
    "?", "?", "?", "?", "?", 
};

void renderents()       // show sparkly thingies for map entities in edit mode
{
    closeent[0] = 0;
    if(!editmode) return;
    loopv(ents)
    {
        entity &e = ents[i];
        if(e.type==NOTUSED) continue;
        vec v = { e.x, e.y, e.z };
        particle_splash(2, 2, 40, v);
    };
    int e = closestent();
    if(e>=0)
    {
        entity &c = ents[e];
        sprintf_s(closeent)("closest entity = %s (%d, %d, %d, %d), selection = (%d, %d)", entnames[c.type], c.attr1, c.attr2, c.attr3, c.attr4, getvar("selxs"), getvar("selys"));
    };
};

void loadsky(char *basename)
{
    static string lastsky = "";
    if(strcmp(lastsky, basename)==0) return;
    char *side[] = { "ft", "bk", "lf", "rt", "dn", "up" };
    int texnum = 14;
    loopi(6)
    {
        sprintf_sd(name)("packages/%s_%s.jpg", basename, side[i]);
        int xs, ys;
        if(!installtex(texnum+i, path(name), xs, ys, true)) conoutf("could not load sky textures");
    };
    strcpy_s(lastsky, basename);
};

COMMAND(loadsky, ARG_1STR);

float cursordepth = 0.9f;
GLint viewport[4];
GLdouble mm[16], pm[16];
vec worldpos;

void readmatrices()
{
    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, pm);
};

// stupid function to cater for stupid ATI drivers that return incorrect depth values

float depthcorrect(float d)
{
	//static int when = 0;
	static float factor = 1;
	//if(when++==5) factor = 0.992205f/d;		// this magic value is tied to the fixed start spawn point in metl3
	return d*factor;
};

// find out the 3d target of the crosshair in the world easily and very acurately.
// sadly many very old cards and drivers appear to fail on gluUnProject() and give false
// coordinates, making shooting and such impossible.
// also hits map entities which is unwanted.
// could be replaced by a more acurate version of monster.cpp los() if needed

void readdepth(int w, int h)
{
    glReadPixels(w/2, h/2, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &cursordepth);
    double worldx = 0, worldy = 0, worldz = 0;
    gluUnProject(w/2, h/2, depthcorrect(cursordepth), mm, pm, viewport, &worldx, &worldz, &worldy);
    worldpos.x = (float)worldx;
    worldpos.y = (float)worldy;
    worldpos.z = (float)worldz;
    vec r = { (float)mm[0], (float)mm[4], (float)mm[8] };
    vec u = { (float)mm[1], (float)mm[5], (float)mm[9] };
    setorient(r, u);
};

void drawicon(float tx, float ty, int x, int y)
{
    glBindTexture(GL_TEXTURE_2D, 5);
    glBegin(GL_QUADS);
    tx /= 192;
    ty /= 192;
    float o = 1/3.0f;
    int s = 120;
    glTexCoord2f(tx,   ty);   glVertex2i(x,   y);
    glTexCoord2f(tx+o, ty);   glVertex2i(x+s, y);
    glTexCoord2f(tx+o, ty+o); glVertex2i(x+s, y+s);
    glTexCoord2f(tx,   ty+o); glVertex2i(x,   y+s);
    glEnd();
    xtraverts += 4;
};

void DrawTexturedBox(float TextureXStart, float TextureYStart, float TextureXEnd, float TextureYEnd, int XStart, int YStart, int XEnd, int YEnd, int TextureNumber, float TextureOpacity) {
	glBlendFunc(GL_ONE, GL_ONE);
	glColor3d(TextureOpacity, TextureOpacity, TextureOpacity);
	glDepthMask(GL_FALSE);	/* JJT - May be commented out to make it work. */
	glBindTexture(GL_TEXTURE_2D, TextureNumber);

	glBegin(GL_QUADS);
	glTexCoord2f(TextureXStart, TextureYEnd);
	glVertex2i(XStart, YEnd);
	glTexCoord2f(TextureXStart, TextureYStart);
	glVertex2i(XStart, YStart);
	glTexCoord2f(TextureXEnd, TextureYStart);
	glVertex2i(XEnd, YStart);
	glTexCoord2f(TextureXEnd, TextureYEnd);
	glVertex2i(XEnd, YEnd);
	glEnd();

	glDepthMask(GL_TRUE);	/* JJT - May be commented out to make it work. */
	xtraverts += 4;
};

void invertperspective()
{
    // This only generates a valid inverse matrix for matrices generated by gluPerspective()
    GLdouble inv[16];
    memset(inv, 0, sizeof(inv));

    inv[0*4+0] = 1.0/pm[0*4+0];
    inv[1*4+1] = 1.0/pm[1*4+1];
    inv[2*4+3] = 1.0/pm[3*4+2];
    inv[3*4+2] = -1.0;
    inv[3*4+3] = pm[2*4+2]/pm[3*4+2];

    glLoadMatrixd(inv);
};

int dblend = 0;

/* JJT - Multiply damageblend content by 0.01 to compensate for new weapon values. */
void damageblend(int n) {
dblend += int(n / 100);
};

void gl_drawhud(int w, int h, int curfps, int nquads, int curvert, bool underwater)
{
/* JJT - Leave the left side of the screen clear for messages. */
	int RightHudX = 2200;
	int MoneyHudX = 2200;
	int UpperHudY = 60;
	int MoneyHudY = 60;

	int AverageHealthHolder = int(CalculateAverageHealth(player1)/100);
	int AverageMaxHealthHolder = int(CalculateAverageMaxHealth(player1)/100);

    readmatrices();
    if(editmode)
    {
        if(cursordepth==1.0f) worldpos = player1->o;
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        cursorupdate();
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    };

    glDisable(GL_DEPTH_TEST);
    invertperspective();
    glPushMatrix();  
    glOrtho(0, VIRTW, VIRTH, 0, -1, 1);
    glEnable(GL_BLEND);

    if(dblend || underwater)
    {
        glDepthMask(GL_FALSE);
        glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
        glBegin(GL_QUADS);
        if(dblend) glColor3d(0.0f, 0.9f, 0.9f);
        else glColor3d(0.9f, 0.5f, 0.0f);
        glVertex2i(0, 0);
        glVertex2i(VIRTW, 0);
        glVertex2i(VIRTW, VIRTH);
        glVertex2i(0, VIRTH);
        glEnd();
        glDepthMask(GL_TRUE);
        dblend -= curtime/3;
        if(dblend<0) dblend = 0;
    };

    glEnable(GL_TEXTURE_2D);

    char *command = getcurcommand();
    char *player = playerincrosshair();
    if(command) draw_textf("> %s_", 20, 1570, 2, (int)command);
    else if(closeent[0]) draw_text(closeent, 20, 1570, 2);
    else if(player) {
		draw_textfc(player, 20, 1570, 2, player1->gunselect, 255, 0, 0);
		}

    renderscores();
    if(!rendermenu())
    {
        glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
	glBindTexture(GL_TEXTURE_2D, 4);

        float chsize = float(crosshairsize);

	/* JJT - Outer Upper Left Line */
        glBegin(GL_QUADS);
        glColor3ub(127,127,127);
        if(crosshairfx)
        {
            if(player1->gunwait) glColor3ub(63,63,63);
            else if(AverageHealthHolder<=AverageMaxHealthHolder/10) glColor3ub(255,0,0);
            else if(AverageHealthHolder<=AverageMaxHealthHolder/5) glColor3ub(255,128,0);
        };

        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 12, VIRTH/2 + chsize * 4);
        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 12, VIRTH/2 + chsize * 6);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 + chsize * 7);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 + chsize * 4);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 10, VIRTH/2 + chsize * 8);
        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 8, VIRTH/2 + chsize * 8);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 8, VIRTH/2 + chsize * 7);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 + chsize * 7);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 + chsize * 4);
        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 + chsize * 7);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 12, VIRTH/2 + chsize * 6);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 12, VIRTH/2 + chsize * 4);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 8, VIRTH/2 + chsize * 8);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 10, VIRTH/2 + chsize * 8);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 + chsize * 7);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 8, VIRTH/2 + chsize * 7);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 10, VIRTH/2 - chsize * 8);
        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 - chsize * 7);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 8, VIRTH/2 - chsize * 7);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 8, VIRTH/2 - chsize * 8);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 12, VIRTH/2 - chsize * 6);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 - chsize * 7);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 11, VIRTH/2 - chsize * 4);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 - chsize * 12, VIRTH/2 - chsize * 4);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 8, VIRTH/2 - chsize * 7);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 - chsize * 7);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 10, VIRTH/2 - chsize * 8);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 8, VIRTH/2 - chsize * 8);
        glEnd();

        glBegin(GL_QUADS);

        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 - chsize * 7);
        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 11, VIRTH/2 - chsize * 4);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 + chsize * 12, VIRTH/2 - chsize * 4);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 + chsize * 12, VIRTH/2 - chsize * 6);
        glEnd();

	/* JJT - Core Crosshair section. */

        glBindTexture(GL_TEXTURE_2D, 4);	/* JJT - Type 1: cross. Type 4: box. */

	if (player1->gunselect == GUN_SG) {
			/* JJT - Inner Upper Bead */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 0.5);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize);
	        	glTexCoord2d(0.5, 1.0);
			glVertex2f(VIRTW/2, VIRTH/2);
		        glTexCoord2d(1.0, 0.5);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 - chsize);
		        glTexCoord2d(0.5, 0.0);
			glVertex2f(VIRTW/2, VIRTH/2 - chsize * 2);
	        	glEnd();

			/* JJT - Inner Lower Lines */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 3, VIRTH/2 + chsize * 2);
	        	glTexCoord2d(0.66, 1.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 + chsize * 2);
		        glTexCoord2d(1.0, 0.5);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 + chsize);
		        glTexCoord2d(0.66, 0.0);
			glVertex2f(VIRTW/2 - chsize * 2, VIRTH/2);
	        	glEnd();

		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.33, 1.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 + chsize * 2);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 3, VIRTH/2 + chsize * 2);
		        glTexCoord2d(0.33, 0.0);
			glVertex2f(VIRTW/2 + chsize * 2, VIRTH/2);
		        glTexCoord2d(0.0, 0.5);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 + chsize);
	        	glEnd();
			}
	else if (player1->gunselect == GUN_RL) {
			/* JJT - Inner Upper Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 + chsize * 3);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 + chsize * 3);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize * 2, VIRTH/2 + chsize * 2);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize * 2, VIRTH/2 + chsize * 2);
	        	glEnd();

			/* JJT - Inner Lower Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 2, VIRTH/2 - chsize * 2);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 2, VIRTH/2 - chsize * 2);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 - chsize * 3);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize * 3);
	        	glEnd();
			}
	else if (player1->gunselect == GUN_CG) {
			/* JJT - Inner Upper Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 - chsize);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2 - chsize * 2);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize * 2);
	        	glEnd();

			/* JJT - Inner Lower Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 4, VIRTH/2 + chsize * 2);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 4, VIRTH/2 + chsize * 2);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize * 3, VIRTH/2 + chsize);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize * 3, VIRTH/2 + chsize);
	        	glEnd();
			}
	else if (player1->gunselect == GUN_RIFLE) {
			/* JJT - Inner Upper Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 0.5);
			glVertex2f(VIRTW/2 - chsize/2, VIRTH/2 - chsize);
	        	glTexCoord2d(0.5, 1.0);
			glVertex2f(VIRTW/2, VIRTH/2);
		        glTexCoord2d(1.0, 0.5);
			glVertex2f(VIRTW/2 + chsize/2, VIRTH/2 - chsize);
		        glTexCoord2d(0.5, 0.0);
			glVertex2f(VIRTW/2, VIRTH/2 - chsize * 2);
	        	glEnd();

			/* JJT - Inner Lower Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 2, VIRTH/2 + chsize);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 2, VIRTH/2 + chsize);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize, VIRTH/2);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize, VIRTH/2);
	        	glEnd();
			}
	else if (player1->gunselect == GUN_FIST) {
			/* JJT - Inner Left Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 5, VIRTH/2 + chsize * 3);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 - chsize * 3, VIRTH/2 + chsize * 2);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 - chsize * 3, VIRTH/2 - chsize * 2);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 - chsize * 5, VIRTH/2 - chsize * 3);
	        	glEnd();

			/* JJT - Inner Right Line */
		        glBegin(GL_QUADS);
	        	glColor3ub(255,0,0);

		        glTexCoord2d(0.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 3, VIRTH/2 + chsize * 2);
	        	glTexCoord2d(1.0, 1.0);
			glVertex2f(VIRTW/2 + chsize * 5, VIRTH/2 + chsize * 3);
		        glTexCoord2d(1.0, 0.0);
			glVertex2f(VIRTW/2 + chsize * 5, VIRTH/2 - chsize * 3);
		        glTexCoord2d(0.0, 0.0);
			glVertex2f(VIRTW/2 + chsize * 3, VIRTH/2 - chsize * 2);
	        	glEnd();
		}
	else {
	/* JJT - Inner Upper Line */
        glBegin(GL_QUADS);
        glColor3ub(255,0,0);

        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2, VIRTH/2);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2, VIRTH/2 + chsize);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2 + chsize, VIRTH/2 + chsize * 2);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2 + chsize, VIRTH/2 + chsize);
        glEnd();

	/* JJT - Inner Lower Line */
        glBegin(GL_QUADS);
        glColor3ub(255,0,0);

        glTexCoord2d(0.0, 1.0);
	glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize * 2);
        glTexCoord2d(1.0, 1.0);
	glVertex2f(VIRTW/2 - chsize, VIRTH/2 - chsize);
        glTexCoord2d(1.0, 0.0);
	glVertex2f(VIRTW/2, VIRTH/2);
        glTexCoord2d(0.0, 0.0);
	glVertex2f(VIRTW/2, VIRTH/2 - chsize);
        glEnd();
		}
	};
    glPopMatrix();

    glPushMatrix();    
    glOrtho(0, VIRTW*4/3, VIRTH*4/3, 0, -1, 1);
    renderconsole();

    if(!player1->hidestats)
    {
        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);
        draw_textf("fps %d", 3200, 2320, 2, curfps);
        draw_textf("lod %d", 3200, 2390, 2, lod_factor());
        draw_textf("wqd %d", 3200, 2460, 2, nquads); 
        draw_textf("wvt %d", 3200, 2530, 2, curvert);
        draw_textf("evt %d", 3200, 2600, 2, xtraverts);
    };

	DrawCompass(player1);

	/* JJT - Show small player variables in the corner */

        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);

	draw_textf("Credits:", MoneyHudX, MoneyHudY, 2, player1->agility);
	MoneyHudX = MoneyHudX + 300;
	if (player1->petacredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->petacredits);
		if (player1->petacredits < 10) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->petacredits < 100) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->teracredits == 0) {
				draw_textf(",000", MoneyHudX, MoneyHudY, 2, player1->petacredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->teracredits < 10) {
				draw_textf(",00", MoneyHudX, MoneyHudY, 2, player1->petacredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->teracredits < 100) {
				draw_textf(",0", MoneyHudX, MoneyHudY, 2, player1->petacredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(",", MoneyHudX, MoneyHudY, 2, player1->petacredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->teracredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->teracredits);
		if (player1->teracredits < 10) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->teracredits < 100) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->gigacredits == 0) {
				draw_textf(",000", MoneyHudX, MoneyHudY, 2, player1->teracredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->gigacredits < 10) {
				draw_textf(",00", MoneyHudX, MoneyHudY, 2, player1->teracredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->gigacredits < 100) {
				draw_textf(",0", MoneyHudX, MoneyHudY, 2, player1->teracredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(",", MoneyHudX, MoneyHudY, 2, player1->teracredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->gigacredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->gigacredits);
		if (player1->gigacredits < 10) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->gigacredits < 100) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->megacredits == 0) {
				draw_textf(",000", MoneyHudX, MoneyHudY, 2, player1->gigacredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->megacredits < 10) {
				draw_textf(",00", MoneyHudX, MoneyHudY, 2, player1->gigacredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->megacredits < 100) {
				draw_textf(",0", MoneyHudX, MoneyHudY, 2, player1->gigacredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(",", MoneyHudX, MoneyHudY, 2, player1->gigacredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->megacredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->megacredits);
		if (player1->megacredits < 10) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->megacredits < 100) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->kilocredits == 0) {
				draw_textf(",000", MoneyHudX, MoneyHudY, 2, player1->megacredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->kilocredits < 10) {
				draw_textf(",00", MoneyHudX, MoneyHudY, 2, player1->megacredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->kilocredits < 100) {
				draw_textf(",0", MoneyHudX, MoneyHudY, 2, player1->megacredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(",", MoneyHudX, MoneyHudY, 2, player1->megacredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->kilocredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->kilocredits);
		if (player1->kilocredits < 10) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->kilocredits < 100) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->credits == 0.0) {
				draw_textf(",000", MoneyHudX, MoneyHudY, 2, player1->kilocredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->credits < 10.0) {
				draw_textf(",00", MoneyHudX, MoneyHudY, 2, player1->kilocredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->credits < 100.0) {
				draw_textf(",0", MoneyHudX, MoneyHudY, 2, player1->kilocredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(",", MoneyHudX, MoneyHudY, 2, player1->kilocredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->credits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, int(player1->credits));
		if (player1->credits < 10.0) {
			MoneyHudX = MoneyHudX + 40;
			}
		else if (player1->credits < 100.0) {
			MoneyHudX = MoneyHudX + 80;
			}
		else {
			MoneyHudX = MoneyHudX + 120;
			}
			if (player1->millicredits == 0) {
				draw_textf(".000", MoneyHudX, MoneyHudY, 2, player1->millicredits);
				MoneyHudX = MoneyHudX + 160;
			}
			else if (player1->millicredits < 10) {
				draw_textf(".00", MoneyHudX, MoneyHudY, 2, player1->millicredits);
				MoneyHudX = MoneyHudX + 120;
			}
			else if (player1->millicredits < 100) {
				draw_textf(".0", MoneyHudX, MoneyHudY, 2, player1->millicredits);
				MoneyHudX = MoneyHudX + 80;
			}
			else {
				draw_textf(".", MoneyHudX, MoneyHudY, 2, player1->millicredits);
				MoneyHudX = MoneyHudX + 40;
			}
		}
	if (player1->millicredits > 0) {
		draw_textf("%d", MoneyHudX, MoneyHudY, 2, player1->megacredits);
		MoneyHudX = MoneyHudX + 120;
		}
			UpperHudY = UpperHudY + 60;	/* JJT - Next Line: Y=120 */
	if (TrainingReadyCheck(player1) == 1) {
		draw_textf("Ready to Train!", RightHudX + 800, UpperHudY, 2, player1->trainingexp);
	}

        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);

    if(player1->state==CS_ALIVE)
    {
	if (!player1->hidestats) {
			UpperHudY = UpperHudY + 60;	/* JJT - Next Line: Y=180 */
        draw_textf("%d", RightHudX + 600, UpperHudY, 2, player1->trainingexp);
	draw_textf(" Experience", RightHudX + 900, UpperHudY, 2, player1->trainingexp);

	UpperHudY = UpperHudY + 120;	/* JJT - Blank Line plus Next Line: Y=300 */
		}

        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);

        glColor3ub(255,255,255);

		PulsateHealthIcon(RightHudX + 750, UpperHudY, 40, 40, AverageHealthHolder, AverageMaxHealthHolder);

        glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
	glDisable(GL_BLEND);

		HealthBar(player1, RightHudX + 900, UpperHudY, AverageHealthHolder, AverageMaxHealthHolder);

	UpperHudY = UpperHudY + 120;	/* JJT - Blank Line plus Next Line: Y=480 */

	/* JJT - Now draw the Strength Bar. */
        draw_textf("Strength: ", RightHudX + 510, UpperHudY, 2, player1->strength);

		StrengthBar(player1, RightHudX + 900, UpperHudY);

	UpperHudY = UpperHudY + 60;	/* JJT - Blank Line plus Next Line: Y=600 */

	/* JJT - Now draw the Agility Bar. */
        draw_textf("Agility: ", RightHudX + 595, UpperHudY, 2, player1->agility);

		AgilityBar(player1, RightHudX + 900, UpperHudY);

	UpperHudY = UpperHudY + 60;	/* JJT - Blank Line plus Next Line: Y=600 */

	/* JJT - Now draw the Stamina Bar. */
        draw_textf("Stamina: ", RightHudX + 525, UpperHudY, 2, player1->stamina);

		StaminaBar(player1, RightHudX + 900, UpperHudY);

	UpperHudY = UpperHudY + 120;	/* JJT - Blank Line plus Next Line: Y=600 */

	/* JJT - Now draw the Charisma Bar. */
        draw_textf("Charisma: ", RightHudX + 480, UpperHudY, 2, player1->charisma);

		CharismaBar(player1, RightHudX + 900, UpperHudY);

	UpperHudY = UpperHudY + 120;	/* JJT - Blank Line plus Next Line: Y=600 */

        draw_textfc("Hunger: ", RightHudX + 550, UpperHudY, 2, player1->food, 255, 127, 0);

	HungerBar(player1, RightHudX + 900, UpperHudY);
			UpperHudY = UpperHudY + 60;	/* JJT - Next Line: Y=660 */
        draw_textfc("Thirst: ", RightHudX + 600, UpperHudY, 2, player1->water, 255, 0, 0);

	ThirstBar(player1, RightHudX + 900, UpperHudY);

	glEnable(GL_BLEND);

	if(crosshairfx) {
		if(AverageHealthHolder<AverageMaxHealthHolder/10){
			DrawHudJollyRoger(RightHudX + 600, UpperHudY + 1200, 20);
			}
		}

    if(!player1->hidestats)
    {
        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW*3/2, VIRTH*3/2, 0, -1, 1);
        draw_textf("agility %d", RightHudX+490, UpperHudY + 120, 2, player1->agility);
        draw_textf("stamina %d", RightHudX+420, UpperHudY + 190, 2, player1->stamina); 
        draw_textf("strength %d", RightHudX+400, UpperHudY + 260, 2, player1->strength);
        draw_textf("food %d", RightHudX+490, UpperHudY + 330, 2, player1->water);
        draw_textf("water %d", RightHudX+450, UpperHudY + 400, 2, player1->food);
        draw_textf("agilitymax %d", RightHudX+400, UpperHudY + 470, 2, player1->agilitymax);
        draw_textf("staminamax %d", RightHudX+400, UpperHudY + 540, 2, player1->staminamax); 
        draw_textf("strengthmax %d", RightHudX+400, UpperHudY + 610, 2, player1->strengthmax);
    };

    glPopMatrix();

        glPushMatrix();
        glOrtho(0, VIRTW/2, VIRTH/2, 0, -1, 1);
        draw_textf("%d", 90, 627, 2, player1->ammo[player1->gunselect]);
        draw_textf("%d",  90, 727, 2, player1->health);
        if(player1->armour) {
		draw_textf("%d", 90, 827, 2, player1->armour);
		}
        glPopMatrix();
        glPushMatrix();
        glOrtho(0, VIRTW, VIRTH, 0, -1, 1);
        glDisable(GL_BLEND);
        int g = player1->gunselect;
        int r = 64;
        if(g>2) {
		g -= 3; r = 128;
		};
	/* JJT - How does it know which icon to render?
		3x3 matrix of 64x64 icons in the items.png file.
		Grid:	1.	2.	3.
		1.	Bikini	Tank	Tee
		2.	Fist	Shells	Bullets
		3.	Rocket	Bullet	Health
	*/
        drawicon((float)(g*64), (float)r, 20, 1250);   
        drawicon(128, 128, 20, 1450);
        if(player1->armour) {
		drawicon((float)(player1->armourtype*64), 0, 20, 1650);
		}

        glPopMatrix();
	};

    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
};
