/* JJT - timedate.cpp
	Display time and date wherever it is convenient.
*/

#include "cube.h"

void DisplayCurrentTime(int LeftX, int UpperY) {
	char timeStr[9];

	_strtime(timeStr);

	draw_text(timeStr, LeftX, UpperY, 2);
	};

void DisplayCurrentDate(int LeftX, int UpperY) {
	char dateStr [9];

	_strdate( dateStr);

	draw_text(dateStr, LeftX, UpperY, 2);
	};
