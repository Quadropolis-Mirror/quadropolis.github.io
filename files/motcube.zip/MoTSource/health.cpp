// JJT - health.cpp: This file defines how things work with health.
// JJT - This file is based almost entirely on clientgame.cpp.

#include "cube.h"

void ReduceHealthPoints(dynent *d, int HealAmount) {
	d->health = d->health - HealAmount;
};

void IncreaseHealthPoints(dynent *d, int HealAmount) {
	d->health = d->health + HealAmount;
};

int CheckAgilityHealth(dynent *d) {
	if (d->agility<1) {
		d->agility = 1;
	}
	if (d->agility>MaxAttrCnt) {
		d->agility=(CheckUpperLimit32K(d->agility));
	}
	if (d->agility>=d->agilitymax) {
		return (0);
	}
	else if (d->agility<d->agilitymax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->agilitymax - d->agility);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

int CheckCharismaHealth(dynent *d) {
	if (d->charisma<1) {
		d->charisma = 1;
	}
	if (d->charisma>MaxAttrCnt) {
		d->charisma=(CheckUpperLimit32K(d->charisma));
	}
	if (d->charisma>=d->charismamax) {
		return (0);
	}
	else if (d->charisma<d->charismamax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->charismamax - d->charisma);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

int CheckIntelHealth(dynent *d) {
	if (d->intel<1) {
		d->intel = 1;	/* JJT - Shouldn't be necessary. */
	}
	if (d->intel>MaxAttrCnt) {
		d->intel=(CheckUpperLimit32K(d->intel));
	}
	if (d->intel>=d->intelmax) {
		return (0);
	}
	else if (d->intel<d->intelmax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->intelmax - d->intel);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

int CheckStaminaHealth(dynent *d) {
	if (d->stamina<1) {
		d->stamina = 1;
	}
	if (d->stamina>MaxAttrCnt) {
		d->stamina=(CheckUpperLimit32K(d->stamina));
	}
	if (d->stamina >= d->staminamax) {
		return (0);
	}
	else if (d->stamina<d->staminamax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->staminamax - d->stamina);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

int CheckStrengthHealth(dynent *d) {
	if (d->strength<1) {
		d->strength = 1;
	}
	if (d->strength>MaxAttrCnt) {
		d->strength=(CheckUpperLimit32K(d->strength));
	}
	if (d->strength >= d->strengthmax) {
		return (0);
	}
	else if (d->strength < d->strengthmax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->strengthmax - d->strength);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

int CheckWisdomHealth(dynent *d) {
	if (d->wisdom<1) {
		d->wisdom = 1;
	}
	if (d->wisdom>MaxAttrCnt) {
		d->wisdom=(CheckUpperLimit32K(d->wisdom));
	}
	if (d->wisdom>=d->wisdommax) {
		return (0);
	}
	else if (d->wisdom < d->wisdommax) {
		/* JJT - Not healthy? Return the difference. */
		return (d->wisdommax - d->wisdom);
	}
	else {
	return (-1);	/* JJT - Return Error Code if nothing else. */
	}
};

void CheckAgilityMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->agilitymax * 0.5;

	if (d->agility < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->agilitymax = d->agilitymax - 1;
	}
};

void CheckCharismaMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->charismamax * 0.5;

	if (d->charisma < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->charismamax = d->charismamax - 1;
	}
};

void CheckIntelMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->intelmax * 0.5;

	if (d->intel < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->intelmax = d->intelmax - 1;
	}
};

void CheckStaminaMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->staminamax * 0.5;

	if (d->stamina < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->staminamax = d->staminamax - 1;
	}
};

void CheckStrengthMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->strengthmax * 0.5;

	if (d->strength < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->strengthmax = d->strengthmax - 1;
	}
};

void CheckWisdomMax(dynent *d) {
	float HalfMax = 0.0;

	HalfMax = d->wisdommax * 0.5;

	if (d->wisdom < HalfMax) {
		/* JJT - Subtract half the difference from max. */
		d->wisdommax = d->wisdommax - 1;
	}
};

void HealAgility(dynent *d, int HealAmount) {
	d->agility = d->agility + HealAmount;
};	

void HealCharisma(dynent *d, int HealAmount) {
	d->charisma = d->charisma + HealAmount;
};	

void HealIntel(dynent *d, int HealAmount) {
	d->intel = d->intel + HealAmount;
};	

void HealStamina(dynent *d, int HealAmount) {
	d->stamina = d->stamina + HealAmount;
};	

void HealStrength(dynent *d, int HealAmount) {
	d->strength = d->strength + HealAmount;
};	

void HealWisdom(dynent *d, int HealAmount) {
	d->wisdom = d->wisdom + HealAmount;
};	

void HealMentalAttributes(dynent *d, int HealAmount) {
	if (CheckCharismaHealth(d) > 0) {
		HealCharisma(d,HealAmount);
	}
	if (CheckIntelHealth(d) > 0) {
		HealIntel(d,HealAmount);
	}
	if (CheckWisdomHealth > 0) {
		HealWisdom(d,HealAmount);
	}
};

void SpreadHealthPoints(dynent *d) {
	int agilitydamage = 0;
	int charismadamage = 0;
	int inteldamage = 0;
	int staminadamage = 0;
	int strengthdamage = 0;
	int wisdomdamage = 0;

	agilitydamage = CheckAgilityHealth(d);
	charismadamage = CheckCharismaHealth(d);
	inteldamage = CheckIntelHealth(d);
	staminadamage = CheckStaminaHealth(d);
	strengthdamage = CheckStrengthHealth(d);
	wisdomdamage = CheckWisdomHealth(d);

	if (d->health >= 4) {
		/* JJT - Charisma, Intelligence, and Wisdom get repaired
			for free as long as there are health points available.
		*/
		HealMentalAttributes(d,1);

		if (agilitydamage >= 2) {
			d->agility = d->agility + 2;
			ReduceHealthPoints(d,2);
			SetMaxSpeed(d);
			}
		else if (agilitydamage == 1) {
			d->agility = d->agility + 1;
			ReduceHealthPoints(d,1);
			SetMaxSpeed(d);
			}
		/* JJT - The following should never be necessary. */
		else if (agilitydamage <= 0) {
		/* JJT - Code here for a healthy agility rating. */
			}
		if (staminadamage >= 1) {
			d->stamina = d->stamina + 1;
			ReduceHealthPoints(d,1);
			}
		/* JJT - The following should never be necessary. */
		else if (staminadamage <= 0) {
		/* JJT - Code here for a healthy stamina rating. */
			}
		if (strengthdamage > 0) {
			d->strength = d->strength + 1;
			ReduceHealthPoints(d,1);
			}
		/* JJT - The following should never be necessary. */
		else if (strengthdamage <= 0) {
		/* JJT - Code here for a healthy strength rating. */
			}
		/* JJT - With more health, the entity gets another chance
			to improve charisma, using health points.
		*/
		if (CheckCharismaHealth(d) > 0 && d->health > 0) {
			d->charisma = d->charisma + 1;
			ReduceHealthPoints(d,1);
			}
	}
	else {
	if (d->health > 0) {
		if (agilitydamage > 0) {
			HealAgility(d,1);
			ReduceHealthPoints(d,1);
			SetMaxSpeed(d);
			}
		}
	if (d->health > 0) {
		if (staminadamage > 0) {
			HealStamina(d,1);
			ReduceHealthPoints(d,1);
			}
		}
	if (d->health > 0) {
		if (strengthdamage > 0) {
			HealStrength(d,1);
			ReduceHealthPoints(d,1);
			}
		}
	}
};

void SpreadDamagePoints(dynent *d, int damage) {
	int agilityspread = 0;
	int staminaspread = 0;
	int strengthspread = 0;

	if (damage >= 4) {
		if (d->agility > 0) {
			agilityspread = int(damage/4);
			d->agility = d->agility - agilityspread;
			if (d->agility < 0) d->agility = 0;
			CheckAgilityMax(d);
			SetMaxSpeed(d);
			damage = damage - agilityspread;
			}
		if (d->strength > 0) {
			if (agilityspread > 0) {
				strengthspread = int(damage/3);
				}
			else {
				strengthspread = int(damage/2);
				}
			if (strengthspread > d->strength) {
				strengthspread = d->strength;
				}
		d->strength = d->strength - strengthspread;
		CheckStrengthMax(d);
		damage = damage - strengthspread;
		}
		if (d->stamina > 0) {
		staminaspread = damage;
			if (staminaspread > d->stamina) {
				staminaspread = d->stamina;
				}
		d->stamina = d->stamina - staminaspread;
		CheckStaminaMax(d);
		}
		damage = 0;
		}
	else if (damage >= 1) {
		if (d->stamina > 0) {
			d->stamina = d->stamina - 1;
			damage = damage - 1;
			}
		if (damage >=1 && d->strength > 0) {
			d->strength = d->strength - 1;
			damage = damage - 1;
			}
		else if (damage >=1 && d->agility > 0) {
			d->agility = d->agility - 1;
			damage = damage - 1;
			}
		else if (damage >=1 && d->stamina > 0) {
			d->stamina = d->stamina - 1;
			damage = damage - 1;
			}
		else {
			damage = 0;
			}
		CheckAgilityMax(d);
		CheckStaminaMax(d);
		CheckStrengthMax(d);
		}
	else {	/* JJT - (damage < 1) */
		/* JJT - Victim is only grazed. */
		}
};
