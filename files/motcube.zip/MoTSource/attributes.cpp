/* JJT - attributes.cpp
	This file contains the RPG attribute-related functions.
*/

#include "cube.h"

void ClearCreditAccount(dynent *d) {
		d->millicredits =	0;
		d->credits =		0.0;
		d->kilocredits =	0;
		d->megacredits =	0;
		d->gigacredits =	0;
		d->teracredits =	0;
		d->petacredits =	0;
	};

void DumbDownIntel(dynent *d) {
			d->intel = d->intel / 2;
			d->intelmax = d->intelmax / 2;
	};

void SetAllFactions(dynent *d, int FactionAmount) {
	loopi(int(NUMFACTIONS)) {
		loopk(int(NUMFACTIONS)) {
			d->factionrep[i][k] = FactionAmount;
			}
		}
	};

void CheckPlayerName(dynent *m) {
			if (strcmp(m->name,"Tom Jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tOM jETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"TOM JETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tom jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"T0m J3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"t0M j3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"T0M J3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"t0m j3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}

			if (strcmp(m->name,"Tommy Jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tOMMY jETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"TOMMY JETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tommy jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"T0mmy J3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"t0MMY j3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"T0MMY J3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"t0mmy j3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}

			if (strcmp(m->name,"Thomas Jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tHOMAS jETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"THOMAS JETLAND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"thomas jetland") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"Th0m@5 J3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"tH0m@5 j3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"TH0m@5 J3T1@ND") == 0) {
				strcpy_s(m->name,"Impersonator");
				}
			if (strcmp(m->name,"th0m@5 j3t1@nd") == 0) {
				strcpy_s(m->name,"Impersonator");
				}

			if (strcmp(m->name,"Hal Yu") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"hAL yU") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"HAL YU") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"hal yu") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"H@1 Yu") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"h@1 yU") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"H@1 YU") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"h@1 yu") == 0) {
				strcpy_s(m->name,"Traitor");
				}

			if (strcmp(m->name,"Cornellius Wrak") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"cORNELLIUS wRAK") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"CORNELLIUS WRAK") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"cornellius wrak") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"C0rn311iu5 Wr@k") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"c0RN311IU5 wR@K") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"C0RN311IU5 WR@K") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"c0rn311iu5 wr@k") == 0) {
				strcpy_s(m->name,"Traitor");
				}

			if (strcmp(m->name,"Cornie Wrak") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"cORNIE wRAK") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"CORNIE WRAK") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"cornie wrak") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"C0rni3 Wr@k") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"c0RNI3 wR@K") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"C0RNI3 WR@K") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"c0rni3 wr@k") == 0) {
				strcpy_s(m->name,"Traitor");
				}

			if (strcmp(m->name,"Theodore Farnsworth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"tHEODORE fARNSWORTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"THEODORE FARNSWORTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"theodore farnsworth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"Th30d0r3 F@rn5w0rth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"tH30D0R3 f@RN5W0RTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"TH30D0R3 F@RN5W0RTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"th30d0r3 f@rn5w0rth") == 0) {
				strcpy_s(m->name,"Traitor");
				}

			if (strcmp(m->name,"Theo Farnsworth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"tHEO fARNSWORTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"THEO FARNSWORTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"theo farnsworth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"Th30 F@rn5w0rth") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"tH30 f@RN5W0RTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"TH30 F@RN5W0RTH") == 0) {
				strcpy_s(m->name,"Traitor");
				}
			if (strcmp(m->name,"th30 f@rn5w0rth") == 0) {
				strcpy_s(m->name,"Traitor");
				}

			if (strcmp(m->name,"Impersonator") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"impersonator") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"iMPERSONATOR") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"IMPERSONATOR") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}

			if (strcmp(m->name,"Imp3r50n@t0r") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"imp3r50n@t0r") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"iMP3R50N@T0R") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"IMP3R50N@T0R") == 0) {
				m->factionrep[int(Police)][m->faction] = 20;
				ClearCreditAccount(m);
				}

			if (strcmp(m->name,"Traitor") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"traitor") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"tRAITOR") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"TRAITOR") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}

			if (strcmp(m->name,"Tr@it0r") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"tr@it0r") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"tR@IT0R") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
			if (strcmp(m->name,"TR@IT0R") == 0) {
				DumbDownIntel(m);
				SetAllFactions(m,20);
				ClearCreditAccount(m);
				}
	};

void InputPlayerName (){
/*	scanf("%d", player1->name);	JJT - Keyboard Data Input Not working yet. */
	CheckPlayerName(player1);
	};
COMMAND(InputPlayerName, ARG_NONE);

float DifferenceFraction (float LargerValue, float SmallerValue) {
	float DifferenceFractionAnswer = 0.0f;

	DifferenceFractionAnswer = 1 / (LargerValue - SmallerValue);

	DifferenceFractionAnswer = DifferenceFractionAnswer/10;

	return DifferenceFractionAnswer;
};

int IncrementAttribute(int Attribute, int IncrementAmount)
{
	int xp = 0;

	Attribute = Attribute + IncrementAmount;
	xp=CheckUpperLimit32K(Attribute);
		/* JJT - If the Attribute is not maxed out, return the new value.
		*/
	if (xp < MaxAttrCnt) {
		return xp;
	}
		/* JJT - Attribute maxed out, so return the Max Attribute Count (32,000)
		*/
	else if (xp == MaxAttrCnt) {
		return MaxAttrCnt;
	}
		/* JJT - This is entered as an emergency situation.
		*/
	else {
		return 1;
	}
};

int TrainingReadyCheck(dynent *d) {
	if (d->trainingexp >= 18000) {
		return 1;
	}
	else {
		return 0;
	}
};

void ResetTrainingExp(dynent *d) {
	d->trainingexp = 1;
};

int TrainingGained(dynent *d) {
	int TrainingPoints = 0;
	TrainingPoints = int((d->trainingexp-16000)/2000);
	return TrainingPoints;
};

void IncreaseAgilityExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->agilityexp = d->agilityexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->agilityexp);
	xp1 = CheckUpperLimit1(d->agilityexp);

	/* JJT - Is agility already maxed out? Then max out agility exp and return.
	*/
	if (d->agility == MaxAttrCnt) {
		d->agilityexp = xp32;
	}
	/* JJT - If CheckUpperLimit of agility experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment agility.
	*/
	else if (xp1 == 1) {
		d->agilityexp = 1;		/* JJT - Reset exp points. */
		d->agility = d->agility+1;	/* JJT - Add another agility point. */
		d->agility = CheckUpperLimit32K(d->agility);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure agility doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as agilityexp + IncrementAmount
	*/
};

void IncreaseCharismaExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->charismaexp = d->charismaexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->charismaexp);
	xp1 = CheckUpperLimit1(d->charismaexp);

	/* JJT - Is charisma already maxed out? Then max out charisma exp and return.
	*/
	if (d->charisma == MaxAttrCnt) {
		d->charisma = xp32;
	}
	/* JJT - If CheckUpperLimit of charisma experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment charisma.
	*/
	else if (xp1 == 1) {
		d->charismaexp = 1;		/* JJT - Reset exp points. */
		d->charisma = d->charisma+1;	/* JJT - Add another charisma point. */
		d->charisma = CheckUpperLimit32K(d->charisma);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure charisma doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as charismaexp + IncrementAmount
	*/
};

void IncreaseIntelExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->intelexp = d->intelexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->intelexp);
	xp1 = CheckUpperLimit1(d->intelexp);

	/* JJT - Is intel already maxed out? Then max out intel exp and return.
	*/
	if (d->intel == MaxAttrCnt) {
		d->intel = xp32;
	}
	/* JJT - If CheckUpperLimit of intel experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment intel.
	*/
	else if (xp1 == 1) {
		d->intelexp = 1;		/* JJT - Reset exp points. */
		d->intel = d->intel+1;	/* JJT - Add another intel point. */
		d->intel = CheckUpperLimit32K(d->intel);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure intel doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as intelexp + IncrementAmount
	*/
};

void IncreaseStaminaExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->staminaexp = d->staminaexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->staminaexp);
	xp1 = CheckUpperLimit1(d->staminaexp);

	/* JJT - Is stamina already maxed out? Then max out stamina exp and return.
	*/
	if (d->stamina == MaxAttrCnt) {
		d->stamina = xp32;
	}
	/* JJT - If CheckUpperLimit of stamina experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment stamina.
	*/
	else if (xp1 == 1) {
		d->staminaexp = 1;		/* JJT - Reset exp points. */
		d->stamina = d->stamina+1;	/* JJT - Add another stamina point. */
		d->stamina = CheckUpperLimit32K(d->stamina);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure stamina doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as staminaexp + IncrementAmount
	*/
};

void IncreaseStrengthExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->strengthexp = d->strengthexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->strengthexp);
	xp1 = CheckUpperLimit1(d->strengthexp);

	/* JJT - Is strength already maxed out? Then max out strength exp and return.
	*/
	if (d->strength == MaxAttrCnt) {
		d->strength = xp32;
	}
	/* JJT - If CheckUpperLimit of strength experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment strength.
	*/
	else if (xp1 == 1) {
		d->strengthexp = 1;		/* JJT - Reset exp points. */
		d->strength = d->strength+1;	/* JJT - Add another strength point. */
		d->strength = CheckUpperLimit32K(d->strength);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure strength doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as strengthexp + IncrementAmount
	*/
};

void IncreaseWisdomExp(dynent *d, int IncrementAmount)
{
	int xp32 = 0;
	int xp1 = 0;

	d->wisdomexp = d->wisdomexp + IncrementAmount;

	xp32 = CheckUpperLimit32K(d->wisdomexp);
	xp1 = CheckUpperLimit1(d->wisdomexp);

	/* JJT - Is wisdom already maxed out? Then max out wisdom exp and return.
	*/
	if (d->wisdom == MaxAttrCnt) {
		d->wisdom = xp32;
	}
	/* JJT - If CheckUpperLimit of wisdom experience plus
		IncrementAmount equals 1 again,
		Recycle the exp and increment wisdom.
	*/
	else if (xp1 == 1) {
		d->wisdomexp = 1;		/* JJT - Reset exp points. */
		d->wisdom = d->wisdom+1;	/* JJT - Add another wisdom point. */
		d->wisdom = CheckUpperLimit32K(d->wisdom);
		SetMaxSpeed(d);			/* JJT - Update Speed on entity. */
		/* JJT - Make sure wisdom doesn't exceed MaxAttrCnt
		*/
	}
	/* JJT - Else is implied as wisdomexp + IncrementAmount
	*/
};

int CalculateAverageHealth(dynent *d) {
	int AverageHealth = 0;

	AverageHealth = int((d->agility + d->stamina + d->strength) / 3);

	return AverageHealth;
};

int CalculateAverageMaxHealth(dynent *d) {
	int AverageMaxHealth = 0;

	AverageMaxHealth = int((d->agilitymax + d->staminamax + d->strengthmax) / 3);

	return AverageMaxHealth;
};

int playerhunger(dynent *d)
{
		if (d->food<30000) {
			return int(30000-player1->food);
			}
		else {
			return 0;
		}
};

int playerthirst(dynent *d)
{
	int StartThirst = 30000;

		if (d->water<StartThirst) {
			return int(StartThirst-player1->water);
			}
		else {
			return 0;
		}
};

void SetRandomStats(dynent *d, int StatMinimum) {
	int StatMax = 0;
	StatMax = int(rand());
	StatMax = MaxAttrCnt - StatMinimum;

	d->food = 29000;	// JJT - Not hungry at all.
	d->water = 29000;	// JJT - Not thirsty at all.

	d->agility = 0;
	d->stamina = 0;
	d->strength = 0;
	d->charisma = 0;
	d->intel = 0;
	d->wisdom = 0;

	d->agility = rnd(StatMax) + StatMinimum;
	d->stamina = rnd(StatMax) + StatMinimum;
	d->strength = rnd(StatMax) + StatMinimum;
	d->charisma = rnd(StatMax) + StatMinimum;
	d->intel = rnd(StatMax) + StatMinimum;
	d->wisdom = rnd(StatMax) + StatMinimum;

/*	d->agility = StatMax/2 + StatMinimum;
	d->stamina = StatMax/2 + StatMinimum;
	d->strength = StatMax/2 + StatMinimum;
	d->charisma = StatMax/2 + StatMinimum;
	d->intel = StatMax/2 + StatMinimum;
	d->wisdom = StatMax/2 + StatMinimum;
*/
	/* JJT - Rating Maximums per entity go here.
		These maximum ratings should match the
		regular Attribute Ratings at the start
		of the entity's lifetime and are meant
		to hold the maximum value attributes can
		reach when "healed".
	*/

	d->agilitymax = d->agility;
	d->staminamax = d->stamina;
	d->strengthmax = d->strength;
	d->charismamax = d->charisma;
	d->intelmax = d->intel;
	d->wisdommax = d->wisdom;

	/* JJT - Rating Experience goes here.
		Starts out at 1.
	*/

	d->agilityexp = 1;
	d->staminaexp = 1;
	d->strengthexp = 1;
	d->charismaexp = 1;
	d->intelexp = 1;
	d->wisdomexp = 1;

	/* JJT - Faction Section. Default faction 0.
		Default Faction Rep: 15,000 (apathetic)
		Default Faction Rep Max: 30,000 (loved)
		Faction Rep below  5,000: hated
		Faction Rep below 10,000: disliked
		Faction Rep above 20,000: liked
		Faction Rep above 25,000: admired
		Faction Rep about 30,000: loved
	*/

	d->faction = 0;

	for(int factiongroup = 0; factiongroup<(10); factiongroup++) {
		loopi(10) d->factionrep[factiongroup][i] = int(rand()*StatMax) + StatMinimum;
	}

	for(int factiongroup = 0; factiongroup<(10); factiongroup++) {
		loopi(10) d->factionrepmax[factiongroup][i] = d->factionrep[factiongroup][i];
	}
};

void SetRandomSkills(dynent *d, int StatMinimum) {

	/* JJT - Individual Skill Ratings.
		All skills start at 0.
		These can be developed at creation
		time by "rolling" for a starting
		character. Then they can be developed
		by the player over time.
		Only skills influenced by being a faction member need to be changed from 0.
	*/

	d->administration = 0;
	d->language = 0;
	d->medical = 0;
	d->programming = 0;
	d->repair = 0;

	d->armorskill = 0;
	d->melee = 0;
	d->mining = 0;
	d->swimming = 0;

	d->arcgun = 0;
	d->autogun = 0;
	d->blade = 0;
	d->handgun = 0;
	d->rifle = 0;

	/* JJT - Individual Skills Experience.
		When these reach 32,000, increment
		the related skill by 1 and reset
		this experience to 1 to start over.
	*/

	d->adminexp = 1;
	d->languageexp = 1;
	d->medicalexp = 1;
	d->programexp = 1;
	d->repairexp = 1;

	d->armorexp = 1;
	d->meleeexp = 1;
	d->miningexp = 1;
	d->swimexp = 1;

	d->arcgunexp = 1;
	d->autogunexp = 1;
	d->bladeexp = 1;
	d->handgunexp = 1;
	d->rifleexp = 1;
};

void Reroll()
{
	/* JJT - Begin setting up player/monster effects.
		This is passed to a separate function called SetRandomStats(d,MinimumStats).
	*/

	SetRandomStats(player1, 4000);

	SetRandomSkills(player1, 50);

	/* JJT - Maxspeed derived from agility.
		This will need to be updated on the fly
		as agility gets upgraded.
		Minimum: 10.00...
		Maximum: 30
	*/

	SetMaxSpeed(player1);

};
COMMAND(Reroll, ARG_NONE);
