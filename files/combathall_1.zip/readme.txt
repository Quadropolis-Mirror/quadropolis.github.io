///////////////////Combathall\\\\\\\\\\\\\\\\\\
||||||||||||||||Ripped by Kraid||||||||||||||||
\\\\\\\\\\\\\\\\\\\\\\\\///////////////////////


This map is ripped from Metroid Prime Hunters
for the game Sauerbraten.
Everyone who has Metroid Prime Hunters, Please
mail me to kraid07@web.de for friendcode-
swapping. All copyrights of the soundtrack 
by http://downloads.khinsider.com/
Now enjoy the map!