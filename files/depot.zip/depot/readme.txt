//Deathmatch Map "Depot" by Redon\\

To start the map "depot" in Sauerbraten:
- Put the Files depot.ogz, depot.cfg and depot.jpg into the sauerbraten/packages/base folder.
- Start Sauerbraten and type /map depot
