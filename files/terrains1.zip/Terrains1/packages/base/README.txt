Terrains1 by I.g.(.

first release version

ents in the map:
ictf playerstars
flags
bases


______________________________________
description:
big map tought for ictf
good for capture too
my wish is to give to all [and 
particularly to who likes to snipe]
a good map where have A LOT OF FUN.

the map started on 10 Nov 2008
stopped for some month after December.

All terrains has been made without Hmap,
there is no mapmodels and only the 
skylight.
_______________________________________