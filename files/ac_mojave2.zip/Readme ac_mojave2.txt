Mojave Desertic Area - 2nd Street
by Andrez

*Plot
Mojave, 2nd street of the southbound. The air has gone totally dry and water is almost finished. The war between CLA and RVSF still goes on with no results, and it'll going on for a long time since the street is full of supplies: armours, weapons... CLA is about to take possess of the main tunnel crossing the street, and RVSF must survive until the backup troops coming...

*Modes
All flag/FFA modes.

*License
http://creativecommons.org/licenses/by-nc-sa/2.5/

*Mirrors
http://www.quadropolis.us/node/2993
http://www.akimbo.in/files/index.php?act=view&id=792