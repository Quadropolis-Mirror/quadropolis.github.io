Instruductions:

- Write down following text into your autoexec.cfg (without "- "):
- exec colorchat.cfg
- Copy colorchat.cfg next to your redeclipse.bat
- Start Red Eclipse
- Press "N" (default) to open the gui.

Or:

- Copy autoexec.cfg and colorchat.cfg next to redeclipse.bat
- Start Red Eclipse
- Press "N" (default) to open the gui.

Thanks for downloading!!
ColorChat by Frederik Shull �copyright 08/14.