=====================================================================
File Details:

Game:                Sauerbraten (www.sauerbraten.org)
Map Name:            konkuri-to
Version:             1.0 - Current edition (11 october 2008)
Building Time:       �60 working hours (so far)
Release Date:        May 2008
Author:              Robert "BlikjeBier" van der Veeke
E-Mail:              rjvveeke@caiw.nl
WebSite:             http://home.kabelfoon.nl/~rjvveeke
                     (website is in Dutch)
=====================================================================
Description:         Medium/large map, 5-8 players

Textures:            My own (Concrete, Iron, Ground)
                     rorschach & tech1soc

Music:               Marc "Fanatic" Pullen 
                     (Original Sauerbraten Soundtrack)
                     (http://fanaticalproductions.net)

=====================================================================
Map's Story:         None, no really. Unless you look at the name
                     konkuri-to wich means concrete in Japanese.
=====================================================================
Developer Notes:     1.0 First public release
=====================================================================
Instalation:         Unzip directly to 
			   "Sauerbraten" folder.

Mannually:           "konkuri-to.cfg", "konkuri-to.jpg" and 
                     "konkuri-to.ogz" should go into 
                     "Sauerbraten\packages\base" folder.
                     The ground-folder should go into the folder
                     "Sauerbraten\packages\blikjebier.
                     If this folder "blikjebier" is not present than
                     please update to the current version of
                     Saurbraten at http://sauerbraten.org/
=====================================================================
Copyright & Permissions:

Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)

This level is copyrighted by Robert van der Veeke, 2008.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other electronic medium that is sold for money without my explicit permission!

If you have a mapping website, and you want to upload this map in it, or if you're making a map pack and want to include this map, you're totally free to do so. Always remember to include all files unmodified. Especially this readme file.