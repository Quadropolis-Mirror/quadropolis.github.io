////Red_Crosshair3 by Redon\\\\

//How to use it\\

- Put the "rch3.cfg" file of "red_crosshair3/data" into the "sauerbraten/data" folder.
- Put the folder "redon" of "red_crosshair3/packages" into the "sauerbraten/packages" folder
- Start Sauerbraten and type "/exec data/rch3.cfg"
(Optional) - Set the recommended crosshairsize by typing "/crosshairsize [crosshairsize]", to make the crosshair look best.


Recommended Crosshairsize: 24 - 35, depends on resolution.