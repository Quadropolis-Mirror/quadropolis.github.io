Sky Boxes
by geecee3

--------------------DESCRIPTION--------------------

Five sky boxes.


--------------------INSTRUCTIONS-------------------

Unzip to your skybank folder in the fpsc direcory.


---------------------LICENSE-----------------------

For use in free games made with the tools of the 
community.


---------------------------------------------------


Have fun.