===========================================================================================
                                     RatBoy's Cubic Maps
===========================================================================================
File Details:

Game:                Cube (www.cubeengine.com)
Game Version:        29-08-2005
Game Mode:           DeathMatch
Map Name:            Anonimous Fortress A.K.A. SastreZ
Map Version:         Retail 1.0
Building Time:       Almost a month.
Release Date:        June 23, 2006
Author:              Pablo "RatBoy" Ciamarra
E-Mail:              ratboy_jo@hotmail.com
Description:         A medium sized deathmatch arena, from 4 to 8 players is recomended
                     but it could hold a little more. It's set in the same futuristic
                     rusty facility thingy as KatreZ.
WQD Count:           Top of 3000 at both bigger areas.
Textures:            Iikka "Fingers" Keranen, Sock, Than & John Fitzgibbons.
Skybox:              "Myghty Pete"
                     (http://petes-oasis.com)
Music:               Marc "Fanatic" Pullen (Orginal Cube Soundtrack)
                     (http://fanaticalproductions.net)

===========================================================================================
Map's Story:

 During the war in the Estrada system, SastreZ was a part of the Feather War Factory that
wasn't even built. When the war was over and the Identi planet finally conquered, the
factory tried to get more commercial, and started producing for other systems and for other
wars. To do so, the SastreZ sector was built, it's purpouse was to be the reception for
visitors, burocratic employees and other stuff like that.

 But one day one visitor's son brought an ear worm he had as pet secretly into the base,
this ear worm escaped this kid's pocket and started reproducing, soon the whole sector was
infested with them, every living being was affected by these worms, and acted irrationally.

 Soldiers began shooting everyone, burocrats began to sue everyone, soon the whole 
sector was dead, and the factory closed. Thats when the owner put both Katrez and SastreZ
sector to the purpouse of deathmatch.

 It's rumored that the ghosts of the burocrats still roam these hallways, annoying everyone
with burocratic crap.

===========================================================================================
Developer Notes:

- This is actually my very first map, originally called Anonimous Fortress, but since it
  uses the same texture set as KatreZ I thought of making it part of the Feather War
  Factory, calling it SastreZ.

- Nobody is perfect. This map could have and probably has bugs, either graphical or of
  gameplay. If you happen to spot any bug, regardless how insignificant it may be, you're
  welcome to send a notice to my mail so I can fix it in a future version. Thanks.

- The lighning issue. I simply can't get along with Cube's ilumination system, I just
  can't make it work, this is as far as I could get it to look, hold tight for the
  Sauerbraten port ;)

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to Cube main folder.

Mannually:
"ratboy" folder goes into "Cube\packages\" folder.
"sastrez.cfg" and "sastrez.cgz" should go into "Cube\packages\base" folder.

===========================================================================================
Version History:

Beta 2.0:
- Small fixes everywhere, retextured some things and added some detail.
- Every item and playerstart entities were repositioned for better gameplay.
- Added jungly mapmodels to the outside.

Retail 1.0:
- Reduced the excesive amount of ammo, and corrected playerstarts facing walls.
- Some graphical bugs fixed.
- Added mapmodels to have more life in the level.
- Improved the lightning.
- New custom skybox courtesy of Mighty Pete and changed music theme.
- Some new areas and detail everywhere.

===========================================================================================
Copyright & Permissions:

Cube Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.cubeengine.com)

This level is copyrighted by Pablo Ciamarra 2006.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================