Custom Textures ReadMe:
These files were originally made by Than.
The only thing I've modified was it's rotation so it'd fit in the map.
To contact the author go to www.planetquake.com/cesspit

The water texture was inside a folder full of random textures,
I don't really know who made it, so credits to him.