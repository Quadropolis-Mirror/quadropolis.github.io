#!/usr/bin/python 

#launch with first argument the dir where obj file is
#by gabdab


import string
import sys
import os



true = 1
false = 0


DIR=sys.argv[1]
CFG=DIR+"/obj.cfg"
OBJ_FILE=''
MTL_FILE=''
G=[]
USEMTL=[]
NEWMTL=[]
MAP_KD=[]
OBJSKIN=[]

def parseDir():
  global OBJ_FILE
  global MTL_FILE
  out_file = open(CFG,"w")
  for f in os.listdir(DIR):
   if f.endswith('.obj'):

      OBJ_FILE=f
   if f.endswith('.mtl'):

      MTL_FILE=f


def parseFile():
  global G
  global USEMTL
  
  g=''
  usemtl=''

  in_file = open(DIR+"/"+OBJ_FILE,"r")
  while true:
    in_line = in_file.readline()
    if in_line == "":
        break
    if in_line[0:2]=="g ":
	in_line=in_line[1:]
	if in_line[-1:] == '\n':
	  in_line = in_line[:-1]
	g=in_line

    if in_line[0:7]=="usemtl ":
	in_line = in_line[6:].strip()
	if in_line[-1:] == '\n':
	  in_line = in_line[:-1]
	usemtl=in_line
	u=[g,usemtl]
	USEMTL.append(u)

  in_file.close()

def parseMtl():
 global NEWMTL,MAP_KD
 tot=0
 nmat=0
 mname=''
 in_file = open(DIR+"/"+MTL_FILE,"r")
 while true:
    in_line = in_file.readline()
    if in_line == "":
        break
    if in_line[0:7]=="newmtl ":
	in_line = in_line[6:].strip()
	if in_line[-1:] == '\n':
	  in_line = in_line[:-1]
	NEWMTL.append(in_line) 
	if tot==2:
	 t1=[mname,'']
	 MAP_KD.append(t1)
	else:
	 mname=in_line
	 tot=2


    if in_line[0:7]=="map_Kd ":
	tot=1
	in_line = in_line[6:].strip()
	if in_line[-1:] == '\n':
	  in_line = in_line[:-1]
	a=[mname,in_line]
	MAP_KD.append(a)
 in_file.close()

def construct():
 for x in USEMTL[:]:
  for y in NEWMTL[:]:
   if x[1]==y :
    for z in MAP_KD[:]:
     if z[0]==y:
      print x[0],z[1]
      o=[x[0],z[1]]
      OBJSKIN.append(o)

def save_cfg():
    print "save_cfg " + CFG
    out_file = open(CFG,"w")
    out_file.write("objload \""+OBJ_FILE+"\""+"\n\n")
    for x in OBJSKIN[:]:
     out_file.write("objskin "+x[0]+" "+x[1]+"\n\n\n")
    out_file.write("mdlscale 1500\n")
    out_file.close()

parseDir()
parseFile()
parseMtl()
construct()
save_cfg()


