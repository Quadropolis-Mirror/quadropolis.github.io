Map:
ac_fetus3 

Author:
fetus

What to do:
Place both files into folder: C:/programfiles/AssaultCube/packages/maps

Play it and tell me what sucks.  If it's worth while, we can make it better.  Otherwise we'll trash it.


General Idea:
Team play for me is always crazy until I figure out what the other team looks like.  My biggest gripe with team play is how hard it is to identify targets-- er, teammates-- before the big ugly red letters pop up.  We all look the same...

Yes: we are all the same.  I made a symmetrical map using similar textures for each team to underline this theme.  

They converge on a choke point -- not a very "ac" thing to do, perhaps more a hang over from my UUT2004 days, but there you have it.


