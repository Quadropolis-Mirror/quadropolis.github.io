===========================================================================================
                                     RatBoy's Cubic Maps
===========================================================================================
File Details:

Game:                Cube (www.cubeengine.com)
Game Version:        29-08-2005
Game Mode:           DeathMatch
Map Name:            Lifepool
Map Version:         Beta 1.0
Building Time:       One week.
Release Date:        April 20, 2006
Author:              NEXUS
E-Mail:              F14_A_Tomcat@hotmail.com
Description:         This is actually a map made by my brother a long time ago.
                     It's simple and plain but nice, and that's why I decided to publish
                     it since he didn't want to.
WQD Count:           Top of 7000 at bigger areas.
Textures:            Iikka "Fingers" Keranen, Sock & Schwenz.
Skybox:              "Sock"
                     (www.planetquake.com/simland)

===========================================================================================
Developer Notes:

- As said before, this isn't my artwork, it's my brothers, so any kind of feedback should
  be adressed to him, his e-mail is up there.

- All my levels can be found at Quadropolis (www.quadropolis.us), excelent community site.

===========================================================================================
Instalation:

Unzip directly to Cube main folder.

Mannually:
Extract both .cfg & .cgz files to the folder "Cube\packages\base\".

===========================================================================================
Copyright & Permissions:

Cube Engine by Wouter van Oortmerssen aka Aardappel. (www.cubeengine.com)

This level is copyrighted by NEXUS 2006.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other
electronic medium that is sold for money without my explicit permission!

You MAY use this map's textures as long as you give credit to their respective authors,
including original readme files.

If you have a mapping website, and you want to upload this map in it, or if you're
making a map pack and want to include this map, you're totally free to do so. Always
remember to include all files unmodified. Especially this readme file. Also let me know
about it so I check it out ;)

===========================================================================================