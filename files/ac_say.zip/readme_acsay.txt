                 ______
    //\\        | _____|                         
   //  \\       | |                         
  //====\\      | |        Map ac_say
 //======\\     | |____
//        \\    |______|  



~> This map was made by TheSharpShooter <~


 - Website -

   www.quadropolis.us/1530

 - TheSharpShooter's E-mail -

   koro-shiya@hotmail.com

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
