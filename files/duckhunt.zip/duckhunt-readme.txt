music : Mario Bros Overworld (Summer Party Remix) by DarK Purple arranged by Alex_of_cubefr.

Create a file "sauercube", put the music in.