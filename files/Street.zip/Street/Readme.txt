Things should be in working order, but in case they're not, do say so.  No custom textures
used.  Everything except the geometry of the level belongs to Cube 2's various contributors.