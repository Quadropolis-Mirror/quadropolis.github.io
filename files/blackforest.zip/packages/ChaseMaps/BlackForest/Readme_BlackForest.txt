//This map was made by You(Chasester)//

/* A deep dark hidden forest in the middle of no were... kill or be kill... tons of caves... trees 
and other foresty things/*

// thanks to cube for all the textures 4 cube// 

// So enjoy the map//