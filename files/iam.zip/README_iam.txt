***************************
*                         *
*   Sauerbraten Map       *
*   by MeatROme           *
*                         *
*      Ithaqua's Arena    *
*                         *
***************************

 published : 20061122
  reworked : 20061125 - more lights, towers fleshed out
   - "" -  : 20061129 - removed kitsch
 rerelease : 20061205 - refactored for new release

 contact : MeatROme@Count0.dynDNS.oRg

___________________________________________________________________________________

 This is another homage to a Quake ][ map I once did,
 the first reincarnation "Amores Anarchia Arena" (a101.ogz)
 is a lot bigger and even has bases for capture mode.

 This time round I was more true to the original.
 It's a small 1-on-1 map really,
 can be played in FFA mode - although only rifle and grenade
 ammo are to be found - your mileage may vary.

___________________________________________________________________________________

 The mode of choice should be one of the instagib flavour ;-)
 
 To get more maps/scripts/etc. visit http://www.quadropolis.us/
 This was published as http://www.quadropolis.us/node/381

