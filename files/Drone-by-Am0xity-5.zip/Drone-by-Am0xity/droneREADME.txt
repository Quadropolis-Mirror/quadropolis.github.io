//Drone by Am0xity//
Version: <r028>
-Map is not complete-
Updates: <r018> -Added a new building and additional fixes <r28> -Much retexturing much more additions, better lighting.
feedback is wanted :D
//do not modify//
