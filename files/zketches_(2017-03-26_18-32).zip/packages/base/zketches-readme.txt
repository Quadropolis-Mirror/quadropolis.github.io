Copyright:	2016-2017  meow (& see below)
Licenses:	see below
Contact:	quadropolis.us/node/4254
Title:		zketches
About:		"And now to something completely different... :D"


A sketch is a quick drawing, or a draft of an idea,
/gridpower 3 is a convenient cube size to sit on,
/gridpower 4 is the height of the average Ironsnout,
/gridpower 5 is the smallest size to build here! :D

 When making maps with a 100 people, one good way to keep things
organized are predetermined spots for new players to make their own.

 An inexperienced mapper will be happy for some guide and playable map
in one, and an expert might equally be glad to have enough own space
to get a quick start to make their dreams come true!

 Also, a decent layout with big grids (low poly) everywhere provides
a fast, fun map for everyone! :D

 If you like the idea, it'd be awesome if you would come up with
a sketch / map idea with a large crowd of people in mind!
 
 Btw, I'm not fixed on the term sketches, if anyone has a better
idea please let me know! :D

 I'd like to dedicate these sketches to my amazing sauerbraten friends,
some of the most talented and creative people I've ever met in my life.

love, meow! =)

P.S.: for the actual MMO maps / ideas behind these sketches please see:
zade-forever : I. zombie-apocalypse-dead-end  (city: homes or work for 100 people (http://www.quadropolis.us/node/3716))
zack : III. zombie-apocalypse-creepy-killinggrounds (industry: 10 bosses employ 10 workers each (http://quadropolis.us/node/4253))
zaca : IV. zombie-apocalypse-carnage-aquatic (deep sea shelter: for last 400 zombie apocalypse survivors (http://www.quadropolis.us/node/3980))
cc0 : cube-corp (company: cubicle or favela (36/48) (http://www.quadropolis.us/node/3980))


# Sketch tips! (+ how-to)

* 1. Map direction
The _tiny red cube_ on the bottom right corner of a selection points _south-east_. If you want to stitch sketches together one day, having directions in mind is key, as you can't rotate all textures and entities so easily.

* 2. /allfaces 1 first
Cutting into grass gets you dirt, blowing a hole into a wallpaper brings out the bricks in the wall, etc :D The cube-engine is pretty special in 3D terms as in a way it can consider what something is made off. Maybe one day entire maps are destructible, and you're set for the future! :D Looks much better too, and a lot more solid.

* 3. /gridpower 5 +
Building and using material and textures only in /gridpower 5 and bigger (without /vcommands) on a map sized 11 makes it possible to rescale everything into a /gridpower 6 sized micromap laters. Which then can easily be delivered inside other maps, as an add-on (or easteregg) so to speak. :D

* 4. Walls stay outside
Building walls around the insides - means: a corner is 3 from the outside resized /gridpower 5 + cubes, that are built around the 4th, inside cube, which itself is resized from below, thus making it the ceiling of said inside, as well as the floor of the storey above! O.o ... o.O .... JUST HAVE A LOOK AT THE MAPS WILLL YA!!! xOO *pant*
This will keep your low-poly layout almost indestructible, as editing inside a house with tiny grid may only affect the ceiling(upper floor), and has little to no effect on the walls (unless they're edited, ofc o.O)

E W  (E = Edge-cube; W = Wall-cube; C = Ceiling-cube)
W C


## Step it up another notch! 0.0 (#advancedmode)

* 5. Everything by foot
Trying to make every spot on the map accessible by foot, best without jumppads or teleports (hard: without pistol - nightmare: no jumping allowed!:D) makes the map more accessible and fun for everyone, especially explorers without edit-privileges!

* 6. Big dreams on a small budget
16.000 cubes max ( in /newmap 11 ). No more than 32.000 for /newmap 12, 64k at 13, and so on, in increasing difficulty... :D 

* 7. The empress/emperors new clothes
You heard it! 0.o A beautiful, free map shouldn't look too naked around the cubes! o.O Why not deliver a whole new free texture-set with it? :D www.gimp.org could make it happen!! xO

* 8. Models, Inc.
Why not add free new map-models, while we're at it? :D (e.g. with www.blender.org - examples: blenderartists.org) - Possibly even rigged and animated? ;D



# Licenses:
zade-forever.ogz:	CC0 1.0 Universal (http://creativecommons.org/publicdomain/zero/1.0)
zack.ogz:		all my work on it is <a href ="http://creativecommons.org/publicdomain/zero/1.0">CC0 1.0 Universal. I practically left almost no cube of the original unturned, only most of the church was made by Pob, and some of the shipyard like the girders and roof by I.g.(.. I could redo these if needed. Everything else is a new /gp 5 sketch of the works of Applejack, DarkCat, DeadGioGee, Doko, Fe, I.g.(,, Jaquellz, Lolithia, Mephisto, Misan, Snowy, TK?, ???
zaca.ogz:		CC0 1.0 Universal (http://creativecommons.org/publicdomain/zero/1.0)
cc0.ogz:		CC0 1.0 Universal (http://creativecommons.org/publicdomain/zero/1.0)


# CC0 1.0 Universal Disclaimer:
To the extent possible under law, meow has dedicated all his copyright and related or neighboring rights to his work on zade-forever.ogz, zack.ogz, zaca.ogz & cc0.ogz to the public domain worldwide. This software is distributed without any warranty. ( https://creativecommons.org/publicdomain/zero/1.0 or zketches-CC0.txt )
