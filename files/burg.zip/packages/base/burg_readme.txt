Title: Burg
Author: Tranzcoder aka Q-Tip, Mr. Blister
Date: 03-17-12
Ver.: 1.0

Description: A tiny burg located in the mountains at dusk. 

Design Philosophy: One of the things I like about the map Venice is being able to jump from roof top to roof top or drop in behind someone and �, but I digress.

  In this map I kept the roofs relatively low in order to make it easy to jump up on to them, but made the pitch at 45 to keep you from standing still. I probably should have left out the �hidden� sniper rooms and may have over done the room backdrops, but I think it gives the map more depth.

Notes: None. Comments Welcome.