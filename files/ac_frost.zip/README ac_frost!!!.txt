Frost
by Andrez

Small *TF capable map set in a frost town; maximum of 16 players. Partly inspired by de_dust2 (CounterStrike) and ac_arctic (by Halo)

**License**
http://creativecommons.org/licenses/by-nc-sa/3.0/

**Entstats**
76 light
28 playerstart, 8 CLA, 8 RVSF, 12 FFA
4 pistol
5 ammobox
3 grenades
6 health
5 helmet
1 armour
1 akimbo
102 mapmodel, 41 clipped
2 ctf-flag, 1 CLA, 1 RVSF
1 sound
5 clip
Total entities: 239