Tower Defense Concept

Instructions:

The game is based on the CTF format, although only one team can actually capture the flag.

Team 1 is above the maze, and starts in a bunker.  On the side of the bunker are teleporters to load up on various weapons in the armory.  The stonger the weapon, the further into the armory the teleporter will drop the player, making the time to return to the fight slower.

Team 2 beings in a bunker on the opposite side of the maze.  Dropping into the lower level is the armory, where the attacking team can arm themselves and enter the maze.

At the end of the maze is the Team 1 flag.  When captured, the player scores, and is teleported back to the start of the maze, just like in Tower Defense.

The default 10 minute / 10 capture limit determines the winner.  If the top team defends the maze for 10 minutes, they win, if the bottom team scores 10 times before the time is up, they win.