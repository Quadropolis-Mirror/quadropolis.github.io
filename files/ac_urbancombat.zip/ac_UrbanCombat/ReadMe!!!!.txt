Hi, I hope you will enjoy my map, if you find any bugs, or have an idea how to improve it, report me please. This map is ready for Deathmatch, TeamDeatmatch, CTF, OSOK and TOSOK. There are no paths for bots now, but maybe I make them once :) , if some people wish it. For now - multiplayer rullezzzzzz !!!!! 


INSTRUCTIONS FOR INSTALLING:
        
  1. Copy "ac_UrbanCombat.cgz" and "ac_UrbanCombat.cfg" into       
      C:\Program Files\AssaultCube\packages\maps 

      in your AssaultCube directory.
  
  2. This is a "night map", so it seems better with "galaxy" skybox from 
       |aCKa|Deathstar. For map with galaxy skybox, copy "galaxy"              directory from ac_UrbanCombat into :  
     
      C:\Program Files\AssaultCube\packages\textures\skymaps

  3. If you wanna try to look on it offline, start AssaultCube and type :

      /clearsecuremaps 
         
                                  and right after type:

                                                                           /map ac_UrbanCombat

   4. Thats all :)

STORY OF THE MAP:

23:00 CET
Bratislava, Slovakia, Europe...  

Counterterrorists from RVSF finded out, where CLA terrorist are  fortified. They made their way thru the wall of the CLA house, all on their positions for suprizing snake attack under the cover of the night...

_____________________________________________________

I wish you to have a lot of frags, flags & fun on my map !!!!

                                                                |aCKa|Mile
   
         