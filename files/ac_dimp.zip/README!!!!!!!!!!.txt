***************************************************
ac_dimp by TRA$H_PC      
***************************************************
map ac_dimp for assaultcube 1 beta and assaultcube 1
***************************************************
put this to:     program Files/assaultcube/packages/maps


enjoy! ;) 


                   T R A $ H _ P C