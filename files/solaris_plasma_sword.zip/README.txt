Solaris Plasma Sword by Sgt. Reaver

Installation:

1. Go to packages/models/hudguns and backup and replace the fist folder. (make sure solaris hudguns is already installed)
2. Go to packages/models/vwep and do the same.

Credits:

marvin2k

Q009

Nixot

Everyone else who made the solaris hudguns