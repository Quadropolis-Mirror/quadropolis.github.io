-=-=-=-=-=-=- An instant classic reborn: Return to Kartoffel -=-=-=-=-=-=-

Imported from Cube and enhanced for Sauerbraten by Cryx
Original Cube map author unknown...


- INSTALLATION -

For Mac:

Click and drag the files and folder to their indicated alias folders.

For PC and Linux:

Open the main Sauerbraten folder, place CubeTunes in "Packages", and put kartoffel2.ogz and kartoffel2.cfg into the "base" folder within Packages. Ignore absolutely anything in this folder with "Mac" in its name.


- EXECUTION -

For all:

Change the game mode to SP (singleplayer) and type "/map kartoffel2"


- RELEASE NOTES -

1.0.0 : Initial release. No critical bugs are apparent, however PC and Linux click/drag shortcuts still need to be added to the folder for easier multiplatform installation...

0.7.0 (Pre-Release) : More clipping bugs fixed, including one that became an inescapable trap with the help of a rifle shot, and better quality lighting added (Level 3 lightmaps - 8x antialiasing + mapmodel shadows)

0.4.5 (Pre-Release) : Established a workaround for the critical MIDI bug by using an MP3 instead (the MIDI is still included in the folder if you wish to try to fix this bug for yourself), and added basic lightmaps (Level 0), proper doors and triggers, and fixed a ton of clipping bugs.

0.2.5 (Pre-release) : Played through the original map extensively to check for other errors, and none seem to be apparent, although, the Carrot triggers still won't work, and doors still need to be placed, as I can't seem to think of a way of replicating the vanishing cube trigger from Cube. Also added the theme originally used in the Cube level for a retro feel, but there seems to be a critical bug that causes Sauerbraten to crash when a MIDI finishes playing. Finding a way to resolve this...

0.1.0 (Pre-Release) : Found some stray Monster entities and deleted them. After checking the original map in Cube, they apparently were never there in the first place (likely an import bug known to duplicate ents). The mapmodel replacer lines in the .CFG have also been removed, so I can use newer mapmodels if I need to.

0.0.5 (Pre-Release) : Original import from Cube, and after some trial and error, a .CFG has been created for this map that keeps original Cube textures and mapmodels (open the CFG for details). All light entities have been removed (I'll replace those later...), and debugging of the initial map has begun.