sweetmp9, Iron Tomb by SweetMisery. 

Released the 20 april 2009. 

To install this map, unzip "sweetmp9.zip" in your Sauebraten folder. 