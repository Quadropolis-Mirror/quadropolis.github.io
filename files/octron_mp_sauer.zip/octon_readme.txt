Thankyou for downloading this great map. I hope
you like it. It has a very interesting design.
It's called octron because when I hear the word
octron I always thing of the coulor orange. Well,
This map has been made (orangeish. -not sure if thats a word.)

Extract to your packages folder inside base, to play!

Hope you like it! Thanks.
~ Cube Master