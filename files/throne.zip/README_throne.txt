Cube 2 Sauerbraten map: Throne

Map Author: David Collins

Creation date: November 10, 2010


CONTACT:
-------------------------------
cdsand08@gmail.com

http://dccollection.tumblr.com/
-------------------------------

Extract the archive into the Sauerbraten directory to install the map.
Thanks for downloading! You may distribute freely as long as the archive is intact.