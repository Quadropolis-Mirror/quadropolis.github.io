---------ANGRY GARDENER CAMPAIGN-----------------------
A single player campaign for CUBE
THIS IS A PARTIAL VERSION (3 of 8 levels are done so far)

by Stewart Wilcox
stewbasic@yahoo.com

--INFO-------------------------------------------------------
game: Cube (http://wouter.fov120.com/cube/)
format: single player campaign
base: scratch (assorted sizes)

--INSTALLATION----------------------------------------------
Place all files in the folder

packages/stewart/

within your CUBE folder.

To play: open console using tilde (~) key. Type sp stewart/infest and enter.

--MAP NOTES---------------------------------------------------
Someone has been stealing your carrots and you're not happy about it! Find the culprit and give them what they deserve. Along the way you'll investigate the strange inhabitants of your neighbour's mansion, uncover the high-tech operations base of an evil underground cult and thwart their nefarious schemes which threaten to bring chaos to our world. But for you it's all about the carrots.

These levels focus more on puzzle solving than killing monsters, so you should (I hope) find getting around the level at least as difficult as the combat. If you get really stuck there are some hints below. For those who want more challenging combat, extra monsters are released on skill levels 6 and up. Note however that quicksave does not work correctly with most of these levels due to some triggers toggling edit mode.

--NOVELTY MAPS---------------------------------------------------
I've also included some other small things:
textdemo.cgz	Showcases the text macro defined in text.cfg
mazedemo.cgz	Showcases the random maze generator (which will be :P) featured in level 6 of the campaign
pairs.cgz	The standard memory game... but it gets more dangerous as more pairs are revealed! Skill 1 recommended
array.cfg	Editing macro for producing arrays
maze.cfg	Produces random mazes
text.cfg	Editing macro for drawing text on the ground

--THANKS---------------------------------------------
Aardappel who made Cube
Spentron whose readme format I'm stealing (via Piglet)
The water trigger idea is also from Piglet (packages/pigcam)

--PERMISSIONS/COPYRIGHT-------------------------------
Map design only is copyright 2008 Stewart Wilcox.
You're free to distribute this map as you wish as long as: you make no profit, and leave the files intact. You're free to use the maps as a base for your own work if you tell me about it and give me credit where due.  








































--HINTS---------------------------------------------------

* Infestation
Do the hole third from the right first; if you mess it up you'll have to start the level again. It's opened by the carrot closest to the start.

Coming down from the waterfall: you'll need to move side to side and even backwards sometimes.

1st basement room: Maybe there's some way to trigger a secret door.
2nd basement room: Look for the same type of trigger; find a way to get onto that table.
3rd basement room: When you hear a trigger sound, something in the room has changed. It may be something small so look carefully.

* Enemy base: dock

Holding pen: You don't need to kill all the monsters! The ammo might be useful later...
Greenhouse, first room: You'll need to find all 25 carrots.

---------------------------------------------------------
