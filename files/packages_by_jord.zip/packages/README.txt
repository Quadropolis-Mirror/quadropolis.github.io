*****
NOTE
*****

Make sure though thatwhen you make a map and you upload it, you upload the 
default_map_settings.cfg file or the (mapname).cfg file with it, or they 
will NOT be able to view the map models/textures!



How to set up the config and the custom textures and mapmodels:

*************************************
Textures, Map Models and Map Config.
*************************************

1. Highlight all folders (which are models, textures, and maps), and click copy.
2. Open up your AssaultCube folder.
3. Double click on packages.
4. Right click on an empty space, and click paste.

************
  WARNING
************

Windows may ask if you want to replace the existing folders/files. If so, say 'Yes to all'.
If you do not click this, this custom textures, map models and config file will not work.

How to set up config:

********
Config
********

1. Highlight the config files (deault_map_settings and menus) and click copy.
2. Open up your AssaultCube folder,
2, Double click on the config folder.
3. Right click on an empty space, click paste.


************
  WARNING
************

Windows may ask if you want to replace the existing folders/files. If so, say 'Yes to all'.
If you do not click this, this custom textures, map models and config file will not work.