Game: Sauerbraten
Map: Abandoned
Creator: L. Tempris
=============================================================================================
Game:                   Sauerbraten (www.sauerbraten.org)
Map Name:               Abandoned
Building Time:          �21 working hours
Begin Building Date:    June 17, 2008
Completion Date:        June 18, 2008
Author:                 James "Leviscus Tempris" Steele Seeley
E-Mail:                 l._tempris@hotmail.com
=============================================================================================
Description:            Deathmatch, small sized map, 4-7 players, a small 
                        spaceship like complex with Many 3D Textures on walls 
                        and such, floating with asteroids also...
=============================================================================================
Textures:               All included with Sauerbraten
=============================================================================================
Music:                  All included with Sauerbraten
=============================================================================================
Map's Story:            This ship was once a space bound laboratory that served the Triberian
                        world. After a destructive find, the ship was abandoned and left for
                        dead. After many long years, this ship was descovered. Now dormant in
                        an asteriod belt, it has a new purpose, as a deathmatch arena...
=============================================================================================
Developer Notes:        1.0   1st public release -    Hope to see this map in action!
                                                      Expect Updates-maybe
=============================================================================================
How to install:
                        Place the map 'abandoned.ogz' in ..Sauerbraten\packages\base\.
                        
                        Start Sauerbraten, press � (key under esc) to open the console, type  
                        'map abandoned', press enter and you're all set.

=============================================================================================

If you have any sugestions of improvement, feel free to send a email to: 
l._tempris@hotmail.com

You can also edit and send me the edited version with your improvements listed in a Word or 
Notpad document.

Thanks-A-Bunch!!!


=============================================================================================



=============================================================================================
=============================================================================================
Copyright & Permissions:Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. 
(www.sauerbraten.org)You are NOT allowed to commercially exploit this level, i.e. put it on 
a CD or any other electronic medium that is sold for money without my explicit permission!If 
you have a mapping website, and you want to upload this map in it, or if you're making a map 
pack and want to include this map, you're totally free to do so. Always remember to include 
all files unmodified. Especially this readme file.
=============================================================================================
=============================================================================================