PLANET'S EDGE (skrdm1) - Readme
----------------------------------------------------------------
http://quadropolis.us/node/3728
----------------------------------------------------------------
Title		: Planet's Edge (skrdm1)

Author		: James 'Skur' Rucks

E-mail		: jamesleerucks@gmail.com

Release Date	: 2012-11-29

Version		: 1.2

License		: CC BY-NC-SA 3.0

If you include this map in a mappack or publish it on your website you HAVE to include this readme file.
----------------------------------------------------------------
A small Deathmatchmap for Cube 2: Sauerbraten (sauerbraten.org)
----------------------------------------------------------------
Special thanks to Georges 'TRaK' Grondin for the textures. (trak.mercenariesguild.net)
----------------------------------------------------------------
Happy fragging!

 -Skur

