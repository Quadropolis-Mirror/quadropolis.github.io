Game: Sauerbraten (water edition)
Map: Battle of the Nile
Creator: save


How to install:
Place the map 'battleofthenile.ogz' in ..Sauerbraten\packages\base\.
Start Sauerbraten, press � (key under esc) to open the console, type 'battleofthenile', press enter and you're all set.

If you have any sugestions of improvement, feel free to send a mail to: save@mediamonster.se 