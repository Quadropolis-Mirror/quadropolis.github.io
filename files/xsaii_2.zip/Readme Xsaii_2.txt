How to play this map:

Extract xsaii_2.ogz into your 'Sauerbraten/packages/base' folder.

Run Sauerbraten as usual.

Press ` or t (as default) and enter '/map xsaii_2'

Have fun.





~Xsaii

Released on 09/10/2006.