Angkor - by FAN|Footknight, FAN|Maxpower, FAN|rudi & cm|rabe
(2013)

This is a little, quick and dirty ffa/insta/effic-map for cube2-sauerbraten.

The map was originally intented to look like Angkor, which apparently did not turn out. Creation process wnet its own way. But I am too lazy to find another title.

Storyline: Some ogros found an ancient, abandoned temple and decided to play some ffa/insta/effic-deathmatches there.

The fanatic dudes made all the cool stuff in it, I made all the crap.

Have fun.

License questions? PM rabe on quadropolis.net.