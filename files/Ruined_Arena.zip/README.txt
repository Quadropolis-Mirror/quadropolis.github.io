---------------------Ruined_Arena by Xweert123.
---------------------
Almost every gamemode is avaliable besides Base.
---------------------
It's a very small map, and it has plenty open areas, so don't plan on having alot of people.
---------------------
Okay, let's cut to the chase..
---------------------Hi! I'm Xweert123, this is the first map i've ever uploaded to Quadropolis. It's also the first one i've ever finished.. If you have any feedback, i'd greatly enjoy it. Please, have fun on my map!

 Note: There's two secrets. One you'll have to be in Editor mode to find, and the other; Well.. It's not so hard to find.
---------------------Every texture and model I used was implimented in the Vanilla Sauerbraten game. So I don't need to give any credit to anybody besides the developers and mappers of Sauerbraten.