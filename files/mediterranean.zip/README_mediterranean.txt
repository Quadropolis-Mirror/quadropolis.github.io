Mediterranean by SirAlex
========================

Intro
-----
You know those beloved maps that fighting clans use to test their young, maps like ot and turbine. Well.. I think we need more of those.

Description
-----------
The map is supposed to be a 1v1, for insta duels. I tried to keep a mediterranean architecture(I got inspired by some stairs that were in the sendmap buffer on a server).

Work in Progress
----------------
This map needs a whole lot more work, i only spent about 4 hours on it in total.
It needs:
-a sun
-more respawn points
-lots of noclip, and clip on the sides
-weapon spawns
-interior decorations
-lights in the shadow places

