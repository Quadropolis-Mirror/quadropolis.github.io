______________________                ______________________
|#####################\             /#######################|
|######################\           /########################|
|""""""""""""""""""\####\         /####/""""""""""""""""""""|
| __________________\####\       /####/ __________________  |
|##################|>\####\>>>>>/####/|###################; |
|####################!\####\>>>/####/>|##################;>>|
|###|""""""""""""""""  \####\_/####/  |###|""""""""|####;   |
|###|______             |#########|   |###|        |###;    |
|##########|:>>>>>>>>>>>>|#######|>>>>|###|>>>>>>>>|##;>>>>>|
|##########|:>>>>>>>>>>>>|#######|>>>>|###|>>>>>>>>|#;>>>>> |
|###|""""""             /####"####\   |#############;       |
|###|________________  "####/ \####\  |###""""""""""        |
|####################;/####/>>>\####\>|###|>>>>>>>>>>>>>>>>>|
|##################;/"####/>>>>>\####\|###|>>>>>>>>>>>>>>>>>|
|"""""""""""""""""" "####"       "####""""                  |
|___________________####;         !####____________________ |
|######################;           !########################|
|#####################;             !#######################|
|""""""""""""""""""""                """""""""""""""""""""""|
|####              #                   #                #  #|
|#         ~       #         ~        # #        ~      ## #|
|#                 #                 #####              # ##|
|####              ####              #   #              #  #|
|===========================================================|
|Pac-Man (v1.0) by Friedslick of the Experience clan	    |
|===========================================================|
|ABOUT:							    |
|Pac-Man is exactly that, a perfect pixel-to-cube replica   |
|of the original Pac-Man maze level, with a custom song and |
|custom textures, correct spawn points, pickups in place of |
|powerups and the warp tunnel.				    |
|							    |
|USAGE:							    |
|Intended for team modes with 8-12 players.		    |
|							    |
|NOTE:							    |
|For application of the online-friendly configuration,      |
|navigate to "./packages/maps", then either:		    |
|~ Delete "pac-man.cfg"					    |
|~ Rename "pac-man.cfg(compatible)" to "pac-man.cfg"	    |
|~ Select "pac-man.cgz" from maps menu			    |
|Or:							    |
|~ Copy "pac-man.cgz"					    |
|~ Rename "Copy of pac-man.cgz" to "pac-man(compatible).cgz"|
|~ Select "pac-man(compatible).cgz" from maps menu	    |
|							    |
|TO-DO:							    |
|Add bot waypoints/paths*				    |
|							    |
|CREDIT:						    |
|Wouter van Oortmerssen					    |
|ActionCube/AssaultCube creators			    |
|PAC-MAN� �1980 NAMCO BANDAI Games Inc.			    |
|Song used �2000 Hasbro Interactive			    |
|(Pac-Man Adventures in Time)				    |
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""