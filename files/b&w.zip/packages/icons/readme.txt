This work is licensed under the Creative Commons Attribution-Noncommercial-Share Alike 3.0 Greece License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/gr/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Author: RaZgRiZ
Program Used: Paint.NET
Release Date: 01/01/2010 Friday
Name of Work: Black & White

This pack was inspired off the Mono theme, and is suggested to be used with the Mono gui for the optimal looks.
The icons of ogro, mrfixit, snoutx10k and spectator have been copied from the Mono theme and have been included with permission from the author.
