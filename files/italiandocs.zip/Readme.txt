***Manuale in italiano***
Questo file contiene il manuale di AssaultCube tradotto interamente in italiano, inoltre contiene anche il manuale ingame.

***Installazione***
Per installare il manuale normale basta sostituire il file "reference.xml" con l'originale in AssaultCube\docs\ e il file "cuberef2xhtml.xsd" con l'originale in AssaultCube\docs\transformations\

Per installare quello ingame, basta sostituire il file docs.cfg in config con l'originale in AssaultCube\config\

Ricordo che io, ho SOLO tradotto il manuale, mentre tutto il lavoro � frutto degli sviluppatori di AssaultCube (specie RandumKiwi, che si occupa delle documentazioni) pertanto i crediti vanno principalmente agli sviluppatori. Per questo inoltre ricordo, che potrebbe esserci qualche errore di tanto in tanto, per cui se ne trovate qualcuno, per favore, inviate un e-mail ad assaultcube@altervista.org con la segnalazione.

Grazie :)

by AndreONEz
http://assaultcube.altervista.org

-----------------------------------------------------------

***Italian reference***
This file contains the AssaultCube's reference, totally translated in italian; it also contains the ingame reference.

***How to install***
To install the normal reference you have to replace "reference.xml" with the original one in AssaultCube\docs\ and "cuberef2xhtml.xsd" with the original one in AssaultCube\docs\transformations

To install the ingame reference, just replace docs.cfg with the original one in AssaultCube\config\

I want to remind that I have JUST TRANSLATED this reference, while all the hard work comes from AC's devs (especially RandumKiwi, who mantains docs) so all credits go to them. I also remind that there could be some mistakes, so, if you find one, please send me an e-mail at assaultcube@altervista.org

Thanks
by AndreONEz
http://assaultcube.altervista.org