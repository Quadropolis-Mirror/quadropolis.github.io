 > > > > Urban Mine by Lord Kv < < < <

Curret version: Beta 1.1

Two teams have their bases in towers on the opposite sides of a symmetric futuristic city, which have been built around caves full of precious minerals. Because of the complexity of the city paths, teams prefer caves for fast infiltration of the enemy's side and easy way back to their own base. But city's numerous crooks and squares are perfect for unseen incursion to the enemy territory and shaking off pursuers afterwards. Also, when you are making your way through the city, watch out for snipers on roofs of the city's many buildings and towers. There is a railway bridge leading from one side of the city to the other. The bridge is a perfect way to cross the city effectively. However, there is a safety forcefield in the middle of the bridge, so you must leave the bridge there. If you see an enemy behind the forcefield, don't think you're safe - bullets can pass the forcefield easily. Teams have managed to break into two of the towers accessible from underground caves. Towers contain stairs to the surface and a unique way of getting almost to the top of the city canopy.

That's what this map is about - caves, complex paths (getting lost), jumping between the roofs... That's why it's named Urban Mine (filename is just "mine").

This is the very first map I ever published, hopefully more will be coming soon. 

A bit of map info

Gamemodes: primarily Regen capture and Instagib Flag modes
Players: As much as possible, should be at least 8. Game with less player would be probably boring.
License: CC-BY
Author of the map: Lord Kv
Authors of the textures and sounds: Lunaran, Rorshach, Mayhem, Blindabuser

Special thanks to my brother for advices.

Map is curretly in BETA, so I will be still making changes to it. Main thing I'm not sure about is capture bases' positions. Feel free to create your own bases (NOT flag bases) and remove my own capture bases. Then you can tell me your own bases' positions and how you liked them.

Hope you like and enjoy it, thanks for playing!

Beta 1.1 CHANGELOG
Thanks P1nokjo for helping me find errors

-wider stairs
-wider paths from small squares to stairs
-fixed missing light and dark areas
-fixed clipping
-better stairs
-some models were replaced with cubes
-fixed texture errors
