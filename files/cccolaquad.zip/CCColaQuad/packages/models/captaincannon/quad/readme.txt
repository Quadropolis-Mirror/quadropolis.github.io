Model by Salatiel (@SalatielSauer)

Using textures present in Cube 2 Sauerbraten, except "cc_colatop.jpg" from freestocktextures.com

You are allowed to modify the model and use it in any other project, but make sure to follow the individual licenses of each texture.