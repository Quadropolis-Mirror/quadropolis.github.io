Avor by Zarj
Feel free to edit this map, but please include 'Original by Zarj' in the map message.
This may not be the final version of the map.