Map : AmoresAnarchiaArenas 101

GameModes : all multiplayer modes (0-12)

Author : MeatROme

published : 2006-05-17
re-worked : 2006-05-21

See it's evolution @ http://www.quadropolis.us/node/232
Oh, and thanks to all there for sharing their constructive criticism!

-------------------------------------------------------------------------------

  This map is an attempt at having 
  all multiplayer modes equally well playable on it.

-------------------------------------------------------------------------------

The layout is based on a map I did some years back;
this was for Quake ][ and was a lot smaller,
it was a 1-on-1 RailArena :)

In this arena - like in "Amores Perros", the movie - you will let loose
the hound to track and maim your opponents dogging hide.

The meat roaming orgies of Aztechnology, Azirafael and AllHellBrokeLoose ...
... Enjoy!

Respect Life - Don't kill for pleasure!
