Readme.txt

Um...
type "/map moo-taco" to play. I guess that's it.

Oh, one more thing. I hope to have a permanent m00c0w server soon. Just keep looking for it.

Thanks,
RADIUM-V{m00c0w}