=====================================================================
file details

file:                Spindizzy textures
author:              Robert "BlikjeBier" van der Veeke
Release Date:        October the 18th 2009

E-Mail:              rjvveeke@caiw.nl
WebSite:             http://home.kabelfoon.nl/~rjvveeke
                     (website is in Dutch)

=====================================================================
Copyright & Permissions:

If you use these textures I kindly ask YOU to give me credit for my work within your README file or TEXT file distributed with your map/mod. Also include this README file within the texture map "spind".

=====================================================================
Additional notes:

These textures are based upon an old Sinclair ZX Spectrum game called Spindizzy released by Electric Dreams Software in the UK in 1986. 

EDS still holds the rights to the game and denies distribution of "Spindizzy" for the use on simulators or orginal hardware.

http://www.worldofspectrum.org/infoseekid.cgi?id=0004756
For more details about the original game

Wich is a shame because it is such a fun game of exploring and pixel precision steering and would fit well within the Sauerbraten spin-off called Marble Arena