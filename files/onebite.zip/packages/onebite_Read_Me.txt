=====================================================================
File Details:

Game:                Sauerbraten (www.sauerbraten.org)
Map Name:            One Bite
Version:             1.0 - Trooper edition
Building Time:       �48 working hours
Release Date:        October the 18th 2009
Author:              Robert "BlikjeBier" van der Veeke
E-Mail:              rjvveeke@caiw.nl
WebSite:             http://home.kabelfoon.nl/~rjvveeke
                     (website is in Dutch)
=====================================================================
Description:         Medium/large map, 5-8 players

Textures:            My own fabrication, 
                     copyrighted by Robert van der Veeke, 2009.

Music:               Marc "Fanatic" Pullen 
                     (Original Sauerbraten Soundtrack)
                     (http://fanaticalproductions.net)

=====================================================================
Map's Story:         This map is based on a earlier release called
                     Frostbite hence the name One Bite, i know it
                     should be spelled "One bit".
                     The map "Frostbite" can be found in the current
                     Trooper Edition of Sauerbraten. 
=====================================================================
Developer Notes:     1.0 First public release
=====================================================================
Instalation:         Unzip directly to 
			   "Sauerbraten" folder.

Mannually:           "onebite.cfg", "onebite.jpg" and "onebite.ogz"              
                     should go into "Sauerbraten\packages\base" 
                     folder. The map "spind" should go into the map                      
                     "blikjebier"
=====================================================================
Copyright & Permissions:

Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)

This level is copyrighted by Robert van der Veeke, 2009.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other electronic medium that is sold for money without my explicit permission!

If you have a mapping website, and you want to upload this map in it, or if you're making a map pack and want to include this map, you're totally free to do so. Always remember to include all files unmodified. Especially this readme file.