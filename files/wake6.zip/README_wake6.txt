                        __  |__,  ___         __  
               (__(__( (__( |  \ (__/_ (__(_ |__)
                                             |
2007-12-20 [instagibwake@gmail.com]

This content is distributet under the Public Domain, do with it whatever you want to.
Credits to http://wakeup.rundumbonn.de are appreciated though!
_______________________________________________________________________________________________________________________

wake6 aka unknown is a small but dodgy deathmatch/instagib map for 1on1 or up to 4 players. Capture is planned too.
I think I am the first one who throws a (real) cellshading look into sauer, I hope you will like that swift style and maybe
adapt it. This is a straight step against eye-candyfied maps with horrible gameplay, there are too much of them out there.


Developers:
	wakeup
	feat. rocknrol ;)

Testers:
        Drakas
