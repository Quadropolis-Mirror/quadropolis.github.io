Classic Chaingun by theButcher

Simply copy and paste the "packages" folder into your sauerbraten folder.  Say yes to overwrite.  This restores the original cg model from cube.
Has been tested a bit; but not too much.  I'm not responsible if your box blows up after you install this.
The hudgun model was taken from cube release 2002_10_22.
This is the readme that came with the original cube hudguns (you can also find this in /packages/models/hudguns/ReadmeClassicChaing.txt after you install
this):

___________----1----_____________



M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        Original Picture
Model:           Old one shoot rifle
                 Old rifle

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----2----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        Darthvim
Model:           RL-25
                 My own creation

Readme:          This model is made for cube.
                 

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----3----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        DarthVim
Model:           Chaingun 
                 Oldschool Style

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   

___________----4----_____________


M. Autor:        DarthVim
                 darthvim@gmx.net
S. Autor:        DarthVim
Model:           Double-Barreled-Shotgun 
                 My own creation

Readme:          This model is made for cube.

Copyrihgt info:  Please ask me bevore you want to change things on it and send me you weapon (so that i can have a look on it :=)   




Thanks to the community for their help :)
Special thanks to (mixed)  

Blehbear, Nickster, Carsten, AARD :), Erold, Drakker,Yax ___, Pushplay, Eihrul, Sirlivealot,Gleeb and all the others i forgot, please tell me if you were in the betatest and i haven't put your name down here)


