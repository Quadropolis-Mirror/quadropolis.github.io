//Hyper Frag Instagib Arena by Redon\\
(re-packaged by MeatROme (ex. Hyper Frag BTW) - because the original was mal-packaged and contained copyrighted music)

To start the map "hf_insta" in Sauerbraten:
** the following two are not required anymore (MeatROme)
- Put the Files hf_insta.ogz, hf_insta.cfg and hf_insta.jpg into the sauerbraten/packages/base folder.
- Put the redon folder into the sauerbraten/packages folder.
- Start Sauerbraten and type /map hf_insta
