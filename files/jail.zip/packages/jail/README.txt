Jail - My cheating solution. :|

All files are free.

The Images and Sounds I used are from commons.wikimedia.org