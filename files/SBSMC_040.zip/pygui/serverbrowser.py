#!/usr/bin/env python
#Boa:App:BoaApp

import wx
import sbmain2

modules ={u'sbmain2': [1, 'Main frame of Application', u'sbmain2.py'],
 u'sbsett': [0, '', u'sbsett.py']}

class BoaApp(wx.App):
    def OnInit(self):
        wx.InitAllImageHandlers()
        self.main = sbmain2.create(None)
        self.main.Show()
        self.SetTopWindow(self.main)
        return True

def main():
    application = BoaApp(0)
    application.MainLoop()

if __name__ == '__main__':
    main()
