#Boa:Frame:Frame1

import wx
from wx.lib.anchors import LayoutAnchors
import sbmain2

global ret
ret = '''
'''
def create(parent):
    return Frame1(parent)

[wxID_FRAME1, wxID_FRAME1ABBRECHEN, wxID_FRAME1OK, wxID_FRAME1PANEL1, 
 wxID_FRAME1PANEL2, wxID_FRAME1PANEL3, wxID_FRAME1PANEL4, wxID_FRAME1SB, 
 wxID_FRAME1SMC, wxID_FRAME1STANDARD, wxID_FRAME1STATICTEXT1, 
 wxID_FRAME1TEXTANZ, wxID_FRAME1UEBERNEHMEN, 
] = [wx.NewId() for _init_ctrls in range(13)]

class Frame1(wx.Frame):
    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(307, 175), size=wx.Size(314, 465),
              style=wx.DEFAULT_FRAME_STYLE, title='Config')
        self.SetClientSize(wx.Size(314, 465))
        self.SetBackgroundStyle(wx.BG_STYLE_COLOUR)
        self.SetBackgroundColour(wx.Colour(212, 208, 200))

        self.panel1 = wx.Panel(id=wxID_FRAME1PANEL1, name='panel1', parent=self,
              pos=wx.Point(0, 263), size=wx.Size(314, 101),
              style=wx.TAB_TRAVERSAL)

        self.SMC = wx.TextCtrl(id=wxID_FRAME1SMC, name=u'SMC',
              parent=self.panel1, pos=wx.Point(9, 48), size=wx.Size(247, 25),
              style=0, value=u'linux_ServerMonitorClient')

        self.SB = wx.TextCtrl(id=wxID_FRAME1SB, name=u'SB', parent=self.panel1,
              pos=wx.Point(8, 16), size=wx.Size(248, 25), style=0,
              value=u'sauerbraten')

        self.panel2 = wx.Panel(id=wxID_FRAME1PANEL2, name='panel2', parent=self,
              pos=wx.Point(0, 364), size=wx.Size(314, 100),
              style=wx.TAB_TRAVERSAL)
        self.panel2.SetBestFittingSize(wx.Size(314, 100))
        self.panel2.SetMinSize(wx.Size(314, 100))

        self.OK = wx.Button(id=wxID_FRAME1OK, label=u'OK', name=u'OK',
              parent=self.panel2, pos=wx.Point(8, 16), size=wx.Size(88, 32),
              style=0)
        self.OK.SetConstraints(LayoutAnchors(self.OK, True, True, False, False))
        self.OK.Bind(wx.EVT_BUTTON, self.OnOKButton, id=wxID_FRAME1OK)

        self.UEBERNEHMEN = wx.Button(id=wxID_FRAME1UEBERNEHMEN,
              label=u'Uebernehmen', name=u'UEBERNEHMEN', parent=self.panel2,
              pos=wx.Point(96, 16), size=wx.Size(96, 32), style=0)
        self.UEBERNEHMEN.Bind(wx.EVT_BUTTON, self.OnAPPLYButton,
              id=wxID_FRAME1UEBERNEHMEN)

        self.ABBRECHEN = wx.Button(id=wxID_FRAME1ABBRECHEN, label=u'Abbrechen',
              name=u'ABBRECHEN', parent=self.panel2, pos=wx.Point(192, 16),
              size=wx.Size(96, 32), style=0)
        self.ABBRECHEN.Bind(wx.EVT_BUTTON, self.OnABBRECHENButton,
              id=wxID_FRAME1ABBRECHEN)

        self.panel3 = wx.Panel(id=wxID_FRAME1PANEL3, name='panel3', parent=self,
              pos=wx.Point(0, 1), size=wx.Size(314, 162),
              style=wx.TAB_TRAVERSAL)

        self.staticText1 = wx.StaticText(id=wxID_FRAME1STATICTEXT1,
              label=u"Hier kann die Reihenfolge, wie die Server aufelistet werden, geaendert werden. Es koennen auch Sachen weggelassen werden. Die einzelnen Dinge (player, time, map, mode, server) muessen mit '|' getrennt werden.",
              name='staticText1', parent=self.panel3, pos=wx.Point(7, 0),
              size=wx.Size(300, 100), style=0)
        self.staticText1.SetMaxSize(wx.Size(256, 40))
        self.staticText1.SetSizeHints(0, 0, 256, 40)
        self.staticText1.Center(wx.HORIZONTAL)
        self.staticText1.SetBestFittingSize(wx.Size(300, 100))
        self.staticText1.SetMinSize(wx.Size(300, 100))
        self.staticText1.SetAutoLayout(True)
        self.staticText1.SetConstraints(LayoutAnchors(self.staticText1, True,
              True, True, True))

        self.panel4 = wx.Panel(id=wxID_FRAME1PANEL4, name='panel4', parent=self,
              pos=wx.Point(0, 163), size=wx.Size(314, 100),
              style=wx.TAB_TRAVERSAL)

        self.STANDARD = wx.Button(id=wxID_FRAME1STANDARD, label=u'Standard',
              name=u'STANDARD', parent=self.panel4, pos=wx.Point(186, 61),
              size=wx.Size(120, 32), style=0)
        self.STANDARD.Bind(wx.EVT_BUTTON, self.OnSTANDARDButton,
              id=wxID_FRAME1STANDARD)

        self.textAnz = wx.TextCtrl(id=wxID_FRAME1TEXTANZ, name=u'textAnz',
              parent=self.panel4, pos=wx.Point(8, 6), size=wx.Size(264, 24),
              style=0, value=u'ping|player|map|mode|ip|server|time')
        self.textAnz.SetThemeEnabled(True)

    def __init__(self, parent):
        file1 = file('settings.sbp', 'r')
        file2 = file('language.lngp', 'r')
        self._init_ctrls(parent)
        self.textAnz.SetValue('')
        settings = file1.readlines(0)
        language = file2.readlines(0)
        self.textAnz.SetValue(settings[0][:-1])
        self.SB.SetValue(settings[2][:-1])
        self.SMC.SetValue(settings[1][:-1])
        self.staticText1.SetLabel(language[6][:-1])
        self.staticText1.Wrap(290) # MeatROme
        file1.close()
        file2.close()
        

                
    def getvaluetext(self):
        val = self.textAnz.GetValue()
        #print val
        return val    

    def OnOKButton(self, event):
        file1 = file('settings.sbp', 'w')
        settingsstr = self.textAnz.GetValue() + ret + self.SB.GetValue() + ret + self.SMC.GetValue() + ret
        file1.write(settingsstr)
        file1.close()
        self.Close()

    def OnAPPLYButton(self, event):
        file1 = file('settings.sbp', 'w')
        settingsstr = self.textAnz.GetValue() + ret + self.SB.GetValue() + ret + self.SMC.GetValue() + ret
        file1.write(settingsstr)

    def OnSTANDARDButton(self, event):
        self.textAnz.SetValue('player|time|map|mode|ip|server')
        self.SB.SetValue('sauerbraten')
        self.SMC.SetValue('linux_ServerMonitorClient')

    def OnABBRECHENButton(self, event):
        self.Close()
