#Boa:Frame:Frame1

import wx
from wx.lib.anchors import LayoutAnchors
import time
import sbsett
import os
import subprocess

global ret 
ret = '''
'''

def create(parent):
    return Frame1(parent)

[wxID_FRAME1, wxID_FRAME1LISTBOX1, wxID_FRAME1STATUSBAR1, 
] = [wx.NewId() for _init_ctrls in range(3)]

[wxID_FRAME1MENUFILEEXIT, wxID_FRAME1MENUFILEREFRESH, 
] = [wx.NewId() for _init_coll_menuFile_Items in range(2)]

[wxID_FRAME1MENUEXTRASABOUT, wxID_FRAME1MENUEXTRASSETTINGS, 
] = [wx.NewId() for _init_coll_menuExtras_Items in range(2)]

class Frame1(wx.Frame):
    def _init_coll_menuExtras_Items(self, parent):
        # generated method, don't edit

        parent.Append(help='', id=wxID_FRAME1MENUEXTRASSETTINGS,
              kind=wx.ITEM_NORMAL, text=u'Einstellungen')
        parent.Append(help=u'Ueber Serverbrowser',
              id=wxID_FRAME1MENUEXTRASABOUT, kind=wx.ITEM_NORMAL,
              text=u'Ueber')
        self.Bind(wx.EVT_MENU, self.OnMenuExtrasSettingsMenu,
              id=wxID_FRAME1MENUEXTRASSETTINGS)
        self.Bind(wx.EVT_MENU, self.OnMenuExtrasAboutMenu,
              id=wxID_FRAME1MENUEXTRASABOUT)

    def _init_coll_menuBar1_Menus(self, parent):
        # generated method, don't edit

        parent.Append(menu=self.menuFile, title=u'Datei')
        parent.Append(menu=self.menuExtras, title=u'Extras')

    def _init_coll_menuFile_Items(self, parent):
        # generated method, don't edit

        parent.Append(help=u'Aktualisiere Server',
              id=wxID_FRAME1MENUFILEREFRESH, kind=wx.ITEM_NORMAL,
              text=u'Aktualisieren')
        parent.Append(help=u'Ende', id=wxID_FRAME1MENUFILEEXIT,
              kind=wx.ITEM_NORMAL, text=u'Ende')
        self.Bind(wx.EVT_MENU, self.OnMenuFileExitMenu,
              id=wxID_FRAME1MENUFILEEXIT)
        self.Bind(wx.EVT_MENU, self.OnMenuFileRefreshMenu,
              id=wxID_FRAME1MENUFILEREFRESH)

    def _init_coll_statusBar1_Fields(self, parent):
        # generated method, don't edit
        parent.SetFieldsCount(1)

        parent.SetStatusText(number=0, text=u'Status')

        parent.SetStatusWidths([-1])

    def _init_utils(self):
        # generated method, don't edit
        self.menuFile = wx.Menu(title=u'')

        self.menuExtras = wx.Menu(title=u'')

        self.menuBar1 = wx.MenuBar()

        self._init_coll_menuFile_Items(self.menuFile)
        self._init_coll_menuExtras_Items(self.menuExtras)
        self._init_coll_menuBar1_Menus(self.menuBar1)

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wx.Frame.__init__(self, id=wxID_FRAME1, name='', parent=prnt,
              pos=wx.Point(74, 198), size=wx.Size(601, 421),
              style=wx.DEFAULT_FRAME_STYLE, title='PySBsrvMC')
        self._init_utils()
        self.SetClientSize(wx.Size(601, 421))
        self.SetMenuBar(self.menuBar1)

        self.listBox1 = wx.ListBox(choices=[], id=wxID_FRAME1LISTBOX1,
              name='listBox1', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(601, 382),
              style=wx.LB_HSCROLL | wx.HSCROLL | wx.VSCROLL)
        self.listBox1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.NORMAL, False,
              u'Courier'))
        self.listBox1.Bind(wx.EVT_LISTBOX_DCLICK, self.OnListBox1ListboxDclick,
              id=wxID_FRAME1LISTBOX1)

        self.statusBar1 = wx.StatusBar(id=wxID_FRAME1STATUSBAR1,
              name='statusBar1', parent=self, style=0)
        self._init_coll_statusBar1_Fields(self.statusBar1)
        self.SetStatusBar(self.statusBar1)

    def __init__(self, parent):
        self._init_ctrls(parent)
        try:
            file1 = file('settings.sbp', 'r')
        except:
            file1 = file('settings.sbp', 'w')
            settingsstr = 'player|time|map|mode|ip|server' + ret + 'linux_ServerMonitorClient' + ret + 'sauerbraten' + ret
            file1.write(settingsstr)
            file1.close()
        try:
            file2 = file('language.lngp', 'r')
        except:
            file2 = file('language.lngp', 'w')
            languagestr = 'Datei'+ret + 'Aktualisieren' + ret + 'Ende' + ret + 'Extras' + ret + 'Einstellungen' + ret + 'Ueber' + ret + 'Hier kann die Reihenfoolge wie die Server aufelistet werden geaendert werden. Es koennen auch Sachen weggelassen werden. Die einzelnen Dinge(ping, player, map, mode, server, time) muessen mit \'|\' getrennt werden' + ret
            file2.write(languagestr)
            file2.close()
        try:
            file3 = file('autoexec.cfg', 'r')
        except:
            file3 = file('autoexec.cfg', 'w')
            autoexecstr = '' + ret
            file3.write(autoexecstr)
            file3.close()

            
        file1 = file('settings.sbp', 'r')
        file2 = file('language.lngp', 'r')
        setl = file2.readlines(0)
        self.menuBar1.SetLabelTop(0, setl[0][:-1])
        self.menuBar1.SetLabelTop(1, setl[3][:-1])
        #self.menuFile.SetTitle(setl[0][:-1])
        
        file3 = file('autoexec.cfg', 'r')
        connectstr = file3.readlines()
        i = 0
        execconnectstr = ''
        while True:
            try:
                execconnectstr = execconnectstr + connectstr[i]
            except:
                break
            i += 1
        execconnectstr2 = execconnectstr + ret + 'exec connect.cfg'
        file4 = file('autoexec.cfg', 'w')
        file4.write(execconnectstr2)
        file4.close()

    def __del__(self):
        file3 = file('autoexec.cfg', 'r')
        connectstr = file3.readlines()
        i = 0
        execconnectstr = ''
        for i in range(0,len(connectstr)-1):
            execconnectstr = execconnectstr + connectstr[i]
        execconnectstr2 = execconnectstr[:-1]
        file4 = file('autoexec.cfg', 'w')
        file4.write(execconnectstr2)
        file4.close()
        

    def listserver(self, textAnz):
        f = file('stdout.txt', 'r')
        f2 = file('settings.sbp', 'r')
        pingl = []
        playerl = []
        mappl = []
        model = []
        global ipl
        ipl = []
        serverl = []
        timeel = []
        line = f.readlines()
        #val = sbsett.Frame1.getvaluetext(sbsett.Frame1(self))
        settings = f2.readlines(0)
        val = settings[0][:-1]
        if val.count('|') < 6:
            zahl = 6 - val.count('|')
            val = val + zahl*'|'
        #da = []
        danum = []
        danume = []
        danume.append(val.find('|'))
        danum.append(val[:danume[0]])            
        danume.append(val.find('|', danume[0]+1))
        danum.append(val[danume[0]+1:danume[1]])
        danume.append(val.find('|', danume[1]+1))
        danum.append(val[danume[1]+1:danume[2]])
        danume.append(val.find('|', danume[2]+1))
        danum.append(val[danume[2]+1:danume[3]])
        danume.append(val.find('|', danume[3]+1))
        danum.append(val[danume[3]+1:danume[4]])
        danume.append(val.find('|', danume[4]+1))
        danum.append(val[danume[4]+1:danume[5]])
        danum.append(val[danume[5]+1:])


        
        for i in range(1, 100):
            d = i - i - i
            if line[d].startswith( '###'):
                break
            if line[d].startswith('['):
                continue
            #print line[d],
            playere = line[d].find('|')
            player = line[d][:playere]
            timeee = line[d].find('|', playere+1)
            timee = line[d][playere+1:timeee]
            mape = line[d].find('|', timeee+1)
            mapp = line[d][timeee+1:mape]
            modee = line[d].find('|', mape+1)
            mode = line[d][mape+1:modee]
            ipe = line[d].find('|', modee+1)
            ip =line[d] [modee+1:ipe]
            server = line[d][ipe+1: -1]
  
            
            
            playerl.append(player)
            timeel.append(timee)
            mappl.append(mapp)
            model.append(mode)
            ipl.append(ip)
            serverl.append(server)


        leer = ' '
        i=0
        


        
        for num in playerl: 
            da = ''
            for g in range(0, 7):        
                if danum[g] == 'player':
                    da = da + playerl[i].ljust(7)
                elif danum[g] == 'time':
                    da = da + timeel[i].ljust(8)
                elif danum[g] == 'map':
                    da = da + mappl[i].ljust(15)
                elif danum[g] == 'mode':
                    da = da + model[i].ljust(10)
                elif danum[g] == 'ip':
                    da = da + ipl[i].ljust(16)
                elif danum[g] == 'server':
                    da = da + serverl[i].ljust(20)
                else:
                    pass
                #da = da + danum[g] + 'l[i].ljust(16)'
            #da = pingl[i].ljust(5) + playerl[i].ljust(3) + mappl[i].ljust(15) + model[i].ljust(10) + ipl[i].ljust(16) + serverl[i].ljust(20) + timeel[i].rjust(8)
            
                       
            blabla = [da]
            self.listBox1.InsertItems(blabla, 0)
            i=i+1
        self.statusBar1.SetStatusText('status')
        
    #def openrftxt(self):
    #    f = file('rf.txt', 'r')
    #    a = f.readlines(0)
    #    f.close
    #    print a
        

    def OnMenuFileExitMenu(self, event):
        self.Close()
    
    def setLabels(self):
        filetext = file1.readlines(0)
        self.menuFile.SetLabel(1, filetext[0][:-1])

    def OnMenuFileRefreshMenu(self, event):
        ff = file('settings.sbp', 'r')
        self.statusBar1.SetStatusText('Loading Server...')
        servermonitor = './bin_unix/' + ff.readlines(1)[1]
        print servermonitor
        ff.close()
        process = subprocess.Popen(servermonitor, shell=True, stdout=subprocess.PIPE)
        process.wait()
        abcd = process.stdout.read()
        ff2 = file('./stdout.txt', 'w')
        ff2.write(abcd)
        ff2.close()
        self.statusBar1.SetStatusText('Scanning Servers...')
        self.listBox1.Set('')
        self.listserver(sbsett.Frame1.getvaluetext(sbsett.Frame1(self)))
        #self.listserver()
        self.statusBar1.SetStatusText('Finished')

    def OnListBox1ListboxDclick(self, event):
        #info.SetId()
        ghi = self.listBox1.GetSelection()
        ghi2 = len(ipl) - ghi -1
        connectstr = 'connect ' + ipl[ghi2]
        connectcfg = file('connect.cfg', 'w')
        connectcfg.write(connectstr)
        connectcfg.close()
        print connectstr
        ff = file('settings.sbp', 'r')
        sauerbraten = ff.readlines(2)[1]
        subprocess.Popen(sauerbraten)
        #event.Skip()

    def OnMenuExtrasSettingsMenu(self, event):
        sbsett.Frame1.Show(sbsett.Frame1(self))
        #sett.ShowModal()

        
    def OnMenuExtrasAboutMenu(self, event):
        event.Skip()
