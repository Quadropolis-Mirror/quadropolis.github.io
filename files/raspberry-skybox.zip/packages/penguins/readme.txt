Skybox Author: SkiingPenguins
Copyright: Creative Commons (BY-SA) [Creative Commons Attribution-Share Alike 3.0 United States]
Please give SkiingPenguins credit, where it is due.
