///New Energy V2///

--About me--

Thy for downloading this content, which took me quite a while. Who is me ? My name is Christian Schmied and I am playing "Cube 2" for more than four years now. 
My ingame name is "Mysterious"!

--About the map--

This map shows an roughinery at an unknown asteroid, that consist of valuable energy.
The work started around March 2012 and was completed in Oktober.

--About the mapsounds--

This map comes with three new sounds, that enlarge your choice of sounds in Cube 2. 
All three sounds can be found at "www.freesound.org" and were not done by myself !
I don�t claim any rights for them, I just modified them in order to keep the downloadfile as MB-saving as possible.

--About the gameplay--

My intention was to always confront the player with his enemy, without taking him the possibility to reach the other side.
"New Energy" has two floors:

1. This one is the uppest and consists out of a huge open middle area with some yellow armour on it.
2. This one is the lowest and consist of some different ways and one underground passage with the quaddamage in it.

The map is combatible with all modes that "Cube 2" offers

--Ending--

Well, I hope you all will have fun with this content and enjoy the intensive gameplay.

///Thank you for reading!/// 