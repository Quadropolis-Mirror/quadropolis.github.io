D-Day2_Alpha by Prof.HAX_GER, P-Cok!, Gottzilla and jochi

v0.5.1

First official Alpha-Release on Quadropolis: 08. June 2009 
First official Beta-Release on Quadropolis: 20. June 2009
Next Release about: 15. July 2009, also on quadropolis

Contact:
Jabber: martinum4@jabber.ccc.de
ICQ & AIM: martinum4
Xfire: martinum4
Yahoo: martinum4
Skype: martinum4
Telphone: 0 56 03 - 91 78 48 (from outside Germany call: 0049 5603 917848)

If you got ideas please post them on the Quadropolis-Node.


(c) by Martin Riemenschneider. All Rights reserved.
