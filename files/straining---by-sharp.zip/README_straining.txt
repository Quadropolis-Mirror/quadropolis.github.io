This map "straining" has been made by |BC|*~Sharp~*

It is one of my first Training maps, and it is designed so only the Assault Rifle and
grenades will allow you through the map.

At the end it will say something you deserve, and that is ONLY IF you make it through the map with passing through all sections with the Assault Rifle and/or grenades.

Please don't Edit mode yourself through the way - the map will lose its purpose.


If you have any questions or inquiries, please send an e-mail to

koro-shiya@hotmail.com


If you see a pirated version of this map (edited by someone and/or map author is changed) please send an e-mail giving the name or author of the pirated version.