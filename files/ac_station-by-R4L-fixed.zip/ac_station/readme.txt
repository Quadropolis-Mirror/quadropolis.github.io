To install:

Put ac_station.cgz and ac_station.cfg into packages/maps.

Put the mountain files in the makke folder into packages/textures/skymaps/makke.