Mapname: ac_Midnight
Version: 1.0
Released: Monday, 03 March. 2008


Included files with this zip:
- ac_midnight.cfg 
- ac_midnight.cgz
- readme_ac_midnight.txt
- Night
  -Night skymap
  -skies-kothic.url

This map is my 2nd for assault cube.  I have worked on it for about 3 months
on and off.  I have tried to make it a good large CTF map and with some
eyecandy.  
The theme is centered around a Night time setting in an industral/grassy 
area.  I hope you guys/gals enjoy it I worked hard on this map!

-LICENSE-

This map is for freeware use, you may redistribute the map unmodified for 
AssaultCube distributions(http://assault.cubers.net).
If you want to Modify my map you will need to contact me for permission.
Contact: dogdancing1992@gmail.com

Happy Fraging