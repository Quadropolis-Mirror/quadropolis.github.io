Copyright:	2014  the Zombie-Crew! xD
License:	CC0 1.0 Universal Dedication ( http://creativecommons.org/publicdomain/zero/1.0 )
Contact:	quadropolis.us/node/3980
Title:		zaca-LAYOUT
About:		"Be water, my friends." - Cube Lee


Zombie Apocalypse - Chapter IV : The Carnage Aquatic  (layout)

Forty thousand cubes under the sea, there lies a secret underground facility. A shelter for housings, stores and such, built for the last survivors of a world overcome by zombies. After the outbreak of Dead End, Creepy and Mayhem, nothing was ever the same again. Our earth in state of ruin: wasted cities, polluted air, tainted soil.
 The last 400+ people of our nations are now working together towards a common goal: to wait, to repair things, to reclaim our planet.
 And to kick some serious zombie posterior!! XO

But suddenly... a nearby whale begins to cough. o.O


Disclaimer:	To the extent possible under law, the Zombie-Crew has dedicated all copyright and related or neighboring rights to zaca-LAYOUT to the public domain worldwide. This software is distributed without any warranty. ( http://creativecommons.org/publicdomain/zero/1.0 or packages/base/cube-corp-CC0.txt )
