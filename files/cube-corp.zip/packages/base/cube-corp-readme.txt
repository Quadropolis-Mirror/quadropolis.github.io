Copyright:	2013 - 2014  the cube-corp makers
License:	CC0 1.0 Universal Dedication ( http://creativecommons.org/publicdomain/zero/1.0 )
Contact:	quadropolis.us/node/3980
Title:		cube-corp
About:		"We are not challenging each other, we are challenging ourselves." - The Unknown Artist


CUBE-CORP

By: 8075 8-bit_Music(>.< ac Albert H. [Am0x!ty] Applejack coolgirl Cooper Crap_I'm_Dead DarkCat David DeadGioGee /dev/zero D:_Diamonds_ Dinos Doko Dragon DragonCeBog EA epsilon Extr3m3 Fe Footknight Garfield GirlTerror Glasslike GoodOldJacob Gremlin hbk I.g.(. jangelcangry Jiko Jojo KoreanHero Khorne Krystal Kv Lolithia LR7 LVC4 Mark III MasterTechCC MightyPanda' meow Mephisto Mist Mr.P Neo Nickgr Nieb NOOBMONKEY not sure nSeven Obstriegel ozz73 Pankake Pedro Pengu Pob Pubberry rambam# Rudi Sam Skur Snowy Solohunter SomeDude Sparky4 Stoyer Suicizer Swiss T.G.M. Tux8000 Vice Wybo Yoddle' ZahariaHome Zahnstocher }|{a6a

From: Australia, Austria, Azerbaijan, Belgium, Brazil, Canada, Chile, Czechia, the Emirates, France, Germany, Greece, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Lithuania, the Netherlands, New Zealand, Portugal, Puerto Rico, Romania, Russia, Serbia, Singapore, Slovenia, South Africa, South Korea, Sweden, Switzerland, Turkey, the United Kingdom and the United States



Disclaimer:	To the extent possible under law, the cube-corp makers have dedicated all copyright and related or neighboring rights to cube-corp to the public domain worldwide. This software is distributed without any warranty. ( http://creativecommons.org/publicdomain/zero/1.0 or packages/base/cube-corp-CC0.txt )
