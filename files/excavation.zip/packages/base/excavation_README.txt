=====================================================================
Map Details

Game:                Sauerbraten 2009-05-04 Trooper Edition (www.sauerbraten.org)
Map Name:            Excavation
Map Version:         Version 1.0 - First Public Release
Building Time:       At least six months spare time
Release Date:        November 2009
Author:              Alek Silver - a.k.a LinuxJunkie, OneLeg, or DonQuixote
E-Mail:              aleksilver@yahoo.com	
WebSite:             none, I'm a private person
Files included:	     excavation.jpg
                     excavation.ogz
	             excavation.wpt
                     excavation_README.txt
=====================================================================

Thanks to all who helped test this map out.  There were countless helpers, and I cannot recall them all.

Special thanks to:
Airborne (Stargate idea)
Phaebus (Double Helix Pillars)
ImBeingMe/D-O-B-K (Roman Bath)

=====================================================================
Description:

This is a large map, designed for 8 players or more.  The map's main focus was Capture The Flag, or ctf.  However, the map is set up to play other games as well, such as Free For All (ffa), Protect, and Capture.

The map started out as a larger pyramid temple, but it was too hard to find people, so the walls of the large pyramid were done away with, which left a bunch of pyramid rooms in the ground.  It looked something like a geological excavation, hence the map name "Excavation."

Maps trick, hints, and secrets
------------------------------
1.  Sniper Towers - If you walk under a sniper tower, and you aren't shot up immediately, just jump up, and you will instantly be launched to the top.  You can jump from the red sniper towers to the surrounding terrain, and run along the top.  The center of the platform is made from one-way blocks, which make the transition through the floor more smooth.  If this becomes an issue in future versions of Sauerbraten, teleports and teledests will have to be placed under, and above the platforms.

2.  The quad-damage/health-boost room in the center of the map looks like it only has one entrance, but it actually has two.  You can get in by swimming up a waterfall, and you can also get in by rocket jumping from the fenced area below.

3.  The Roman bath was built for my beautiful, loving, and very patient wife.  It holds a special place in our hearts, so please be respectful while hanging out there.  You can teleport to the top of the Roman Bath from the levitating platforms, in the lava rooms.  Up there, you get a quad damage.  The grill in the bottom of the Roman Bath is a secret passage that takes you through some water tunnels, into the center of the map, or back up to the Roman Bath.

=====================================================================
Textures:            All of the textures in this map are core Sauerbraten textures, and their copyrights go to their respective creators.  You can find the readme files   to all of these texture packages in the sauerbraten/packages directory.  Each texture package has it's own directory, and in that directory is the readme file for those textures.  Most of the textures on this map were authored by "Sock," so special thanks to "Sock" for all of the excellent textures.
                Egyptian textures come from:
                     Date:             13th August 2001.
                     file:             tp-egyptian.zip
                     author:           Sock 
                     email:            sock@planetquake.com
                     URL:              http://www.planetquake.com/simland
                     Version:          1.5

Skymap:              The skymap "staffy" is a core Sauerbraten skymap.
=====================================================================

=====================================================================
Installation:         Unzip into the system sauerbraten directory

Manually:           Extract all of the files into the sauerbraten/packages/base folder.
=====================================================================
Copyright & Permissions:

Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)

This map level is copyleft Alek Silver, and may be used for any purpose anyone wants, private or commercial, with exception to the textures, skymaps, or music, which do not belong to me, so you must obtain permission from the respective artists.  If you use any part of this map, you must give credit to the original author in your derivative works, and you must also give people the same freedom that is given to you with this map.  That is, any of your work that is a derivative of this map, must also be given out freely, to everyone, private or commercial.  If you cannot get the same permissions on the textures, skymap, or music, feel free to change the textures, skymap, or music.
