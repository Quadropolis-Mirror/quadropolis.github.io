Filename: bosurgi_skyboxes.zip

Creation Date: July 28, 2010

Creator: Tom "Bosurgi725" Bosurgi

Contact: bbosurgi@gmail.com

Contents: Four(4) skyboxes made by me.

sp1 - South Pacific - This one is a Pacific Islands type theme. This was the first skybox I ever made...correctly.

arctic1 - Arctic Region - This skybox is very bright, it is intentional, it is to give the "snowblindness" effect of being in such an enviroment.

crater1 - Meteor Crater - This is loosely based off of Meteor Crater in Arizona, USA.

moon1 - Moonscape - This is just a random moon, similar to earths.




