**** Super Mario Pickups****
*** by Andrez ****
This mod replaces default pickups with others based on Super Mario Bros and Super Mario World. They are:
- Mushroom (healthpack)
- 1-up mushroom (kevlar armour)
- Turtle shell (helmet) [4 colours available]
- Power up flower (nades)
- Star (akimbo)
- Cape feather (pistolclips)
- Goomba (ammobox)

*** License ***
http://creativecommons.org/licenses/by-nc-sa/2.5/it/deed.en