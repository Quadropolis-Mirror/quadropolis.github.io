Frozen Structure
By Masterwabbit

Here's the third map I've made. Hope you enjoy it. It was originally supposed to be called "Frozen Monument", but I figured what I built was far from monument like. That's why the ogz, cfg, and all those other files are named frznmon. Just a little trivia for you.

Date - 8/17/07

This map is copylefted Masterwabbit. You're free to edit this map provided I'm thanked in a Readme file in a Zip folder identical to this one.