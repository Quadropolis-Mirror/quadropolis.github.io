****To Installl****

*Place both files (Relic.ogz & Relic.cfg)
 in you sauerbraten directory eg: 
c:/program files/sauerbraten/packages/base


If your main directory isnt c: then put them in the directory that
is your main


Map by lakenz

Email:Lakenz1@gmail.com

****To Play****

*Go into sauerbraten and type /map Relic .If
You want to play it on a server (online with other players)
then go to sauerbraten forums and ask members!!!!





For Docs,forum and info go to: http://sauerbraten.org/
Or For The Forum: http://www.cubeengine.com/forum.php4