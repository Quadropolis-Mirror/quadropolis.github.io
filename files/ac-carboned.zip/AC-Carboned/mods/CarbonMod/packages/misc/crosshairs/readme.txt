Crosshairs by makkE.


EXCEPT:
-------
o.png
o_dot.png
o_x.png

By Topher of Death Illustrated team. 

Every other crosshair has been created by Pedro.


