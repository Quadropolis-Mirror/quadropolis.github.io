  **************************
  *                        *
  * BigBadBase by MeatROme *
  *                        *
  **************************

  This map carries the subtitle:

  -----------------------------
  -Beelzebubs' Building Blocks-
  -----------------------------

  You are required to play at skill 10,
  or be considered too puny to enter the deeper hells - 
  this is just his evil shadows' playground;
  hence the building blocks.

 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  Since his evil shadow has befallen you -
  you have never felt so alone - 
  now even your ####### (*) are filled 
  with his spawn of the pit.

  Always you think you hear music ...
  or song, ... a clear pattern of floating sound ...
  ... sometimes it sounds like angels singing to you in that song.
  then - again, nothing but empty blackness.
  Or, of course, monsters. Loads of monsters.
  You'd prefer listening for that sweet sound from far away
  ... but first these filthy fiends will F R Y !

 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  This map includes many alternate routes to reach your goal,
  you can even manage to finish it without fighting - 
  if that's against your beliefs or something - 
  it just needs a leap of faith :)
  
________ __ _ _ _ __ _ _
  (*) : dreams, cupboards, cereal packets - whatever
|---------------------------------------------------------------------|
|...for our dish-of-the-day : sauerbraten where Kafka did the cooking.|
|---------------------------------------------------------------------|
|author:MeatROme@Count0.dynDNS.oRg | released [20060619] | <<< << << <|
|                                  |  updated [20061229] | <<< << << <|
