*machinegun model from sauerbraten
*01/02/03/fire folders are from dday:normandy (mod based on quakeII)