I, Bryan "Shadow" Shalke, am hereby placing these sounds in the public domain as of Tuesday, June 20, 2006.

Just be nice and include this readme... ok?

Have fun! ^_^