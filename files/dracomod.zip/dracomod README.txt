READ THIS!!!!! OR IT WILL NOT WORK!!!!

Just kidding.  Most of the contents of this mod are from other mods that I've combined together.  

	The guns are from marvin2k's weapon set.

	The shocktrooper and shocktrooper weapons are from shocktrooper's shocktrooper mod.
		
	The shot sounds are from the Eternal Struggle mod, made by LordMuffe, for the Spring Engine.

	The crosshair is from thojoh370's 10 cursor pack.

	The voices are from shadows newvoices pack for Sauerbraten.

	The sniper zoom script is from rootnis's rzoom script, modified the binding to [P] to rezoom.

	The stairs script is CrazyTB's Stairs-O-Matic Script.