GOTHIC.


[ Information ]

Map Name: ac_gothic  || Gothic Empire
Created by: R4zor
Version: Beta #2
Version Date Released: Tuesday 12 August, 2008.
______________________________________________________________________

[ Skymap ]

The skymap "darkland" which was used for this map was downloaded from
http://jaj.planetquake.gamespy.com/ . Credit to Jos� "jaj" Arcediano
for the skymap.

[ Map/Other License ]

The items in these directories are solely distributed as freeware
or under the CC License. The respective map is a product of R4zor,
the skymap a product of Jaj.

[ Contact ]

You can contact myself via IRC, In-game AssaultCube, or via email/msn
at r4zorlive@live.com.au.

[ Installation ]

To install ac_gothic:
	~ Copy ac_gothic.cfg and ac_gothic.cgz to packages/maps.
	~ Copy the folder "jaj" to packages/textures/skymaps.
Alternatively you can extract this folder to the Assaultcube folder
(usually in Program Files for windows users) and merge the folders.