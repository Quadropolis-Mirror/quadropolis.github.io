CESSPOOL V2 by gonads
Copyright (c) 2013 gonads / mrduncalau

DESCRIPTION:
A cesspool... it is what it is.

Modes: CTF, FFA etc.

Files included:
gonads_cesspool.txt (license info)
gonads_cesspool_V2-README.txt (this file)
/packages/base/gonads_cesspool_V2.ogz
/packages/base/gonads_cesspool_V2.jpg

No other extra content (texures,sounds,models)

Hopy you enjoy :)