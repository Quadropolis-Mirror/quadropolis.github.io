                         *******************************
                         *  How change the explosion!? *
                         *******************************
                                          -by aCKa clan-
_________________________________________________________________________________________________
ENGLISH:


1: go to actioncube subfile (default(windows) at: "c:/programfiles/actioncube").

2: after go to "packages/misc", cut "explosion.jpg" and put it somewhere in your computer... 
(or delet it...).

3: Now go to explosions pack(by aCKa clan), open the subfile call: "choose your explosion".
here you find some kind of explosions, copy the picture you want (don't change the name!) and put it
in "actioncube/packages/misc"

4: it's finish... conclusion: the explosion.jpg by acka clan is in "actioncube/packages/misc".
                       It's working too with your own explosions textures!

           IF YOU HAVE SOME PROBLEM, POST COMMANTARY AT: http://acka.zeblog.com

_________________________________________________________________________________________________
FRENCH:

1. Ouvrez le dossier action cube (par default(windows): "c:/programfiles/actioncube").

2. Ensuite allez dans "packages/misc", couper "explosion.jpg" et mettez le n'importe ou
dans votre ordinateur (si vous ne voulez pas le sauver supprim� le...).

3.Maintenant allez dans le pack explosion (par acka clan), ouvrez le dossier appel�:
"choose your explosion". Vous y trouv� plusieur type d'explosion, copiez celle que vous voulez
(mais ne changez surtout pas le nom!)et mettez la dans "actioncube/packages/misc", 
histoire de remplacer l'ancienne image de base.

4. C'est termin�, conclusion: vous avez remplacez l'image "explosion.jpg" de base par l'une que
nous vous avons fournis. Ca fonctionne aussi avec vos propres texture d'explosions!

    VOUS RENCONTREZ ENCORE DES PROBLEMS? POSTEZ VOS COMMENTAIRS SUR: http://acka.zeblog.com