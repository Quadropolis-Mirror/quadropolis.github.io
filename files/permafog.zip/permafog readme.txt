                      A
    ______________________________________                    
   /  ____________________________________\
   \  \  | |_| | / / \ \ |   \ /   \ | ^ |
  __\S \ |  H  | \ \A/ / | D / \ O / | W |
  \____/ |_|�|_| /_/ \_\ |__/   \_/  \/�\/
                                   PRODUCTION



Permafog readme:

Add the code contained in the readme file into your .cfg file

NOTE: If you don't want other people to know what this code does
      to prevent modification, either delete the comments, make 
      the file read-only, or both.