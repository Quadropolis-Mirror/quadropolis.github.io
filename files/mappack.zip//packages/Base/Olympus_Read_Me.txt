=====================================================================
File Details:

Game:                Sauerbraten (www.sauerbraten.org)
Map Name:            Olympus
Version:             0.8 - Current CVS edition (21 may 2008)
Building Time:       �16 working hours (so far)
Release Date:        May 2008
Author:              Robert "BlikjeBier" van der Veeke
E-Mail:              rjvveeke@caiw.nl
WebSite:             http://home.kabelfoon.nl/~rjvveeke
                     (website is in Dutch)
=====================================================================
Description:         Medium/large map, 5-8 players

Textures:            rorschach, subverse and than_ind

Music:               Marc "Fanatic" Pullen 
                     (Original Sauerbraten Soundtrack)
                     (http://fanaticalproductions.net)

=====================================================================
Map's Story:         None, no really.
=====================================================================
Developer Notes:     0.8 First public release
=====================================================================
Instalation:         Unzip directly to 
			   "Sauerbraten" folder.

Mannually:           "olympus.cfg", "olympus.jpg" and "olympus.ogz"              
                     should go into "Sauerbraten\packages\base" 
                     folder.
=====================================================================
Copyright & Permissions:

Sauerbraten Engine/Game by Wouter van Oortmerssen aka Aardappel. (www.sauerbraten.org)

This level is copyrighted by Robert van der Veeke, 2008.
Authors may NOT use this level as a base to build additional levels.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD or any other electronic medium that is sold for money without my explicit permission!

If you have a mapping website, and you want to upload this map in it, or if you're making a map pack and want to include this map, you're totally free to do so. Always remember to include all files unmodified. Especially this readme file.