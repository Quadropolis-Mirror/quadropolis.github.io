Change the file names of all the original files so you do not lose them.  

Move the "autoexec.cfg" file to the base RE directory(on Mac it is under Application Support).  If you no longer want to run the mod, remove the autoexec.


Red Eclipse For Kids by blarg