 ______ __              __     _____   __         __   
|   __ \  |.---.-.----.|  |--.|     |_|__|.-----.|  |_ 
|   __ <  ||  _  |  __||    < |       |  ||__ --||   _|
|______/__||___._|____||__|__||_______|__||_____||____|
                                                       
 _______           __         __              
|   |   |.-----.--|  |.---.-.|  |_.-----.----.
|   |   ||  _  |  _  ||  _  ||   _|  -__|   _|
|_______||   __|_____||___._||____|_____|__|  
         |__|   

+=+Blacklist updater: readme+=+
=+=   Actual version: 1.0   =+=
+=+   Needs: lwp-request    +=+
=+=    OS: Ubuntu 8.04      =+=

Blacklist Updater is a C based tool for AssaultCube 1.0 which can be used to update your blacklists files. 

How does it work ?

The application, when launched in a shell, download several blacklists from the web. The downloaded blacklists are the latest BL files, and are taken from the most popular servers. The last blacklist file you used is saved as backup_serverblacklist.cfg in the same directory, but be careful: if you launch BLU one time, it will make a backup, but if you run it again, the last backup would be overwritten ! So if you want to make regular backups to see the blacklist changing, you will have to rename each backup before updating.

How to use it:

- Copy BlackList Updater and config.cfg in your AC directory.
- Run this application in a shell, with the command './BlackListUpdater'.
- Press enter, and let the application work.

What blacklists are dowloaded to my hard drive ?

The actual config files let the application download the blacklists files from the TyD and the BC servers. Of course you can add
your own web path ;)


