
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

const int true = 0;
const int false = 1;

const int MAX_BL = 100;

void intro();
int read_config( char cbls[MAX_BL][1024], int* );
int download_bl( char cbls[MAX_BL][1024], int );
int reinsert();

int main( int argc, char *argv[] )
{
    intro();

    int sources = 0;
    char cbls[MAX_BL][1024];
    int readed_config = read_config( cbls, &sources );
    if( readed_config == true ){ printf( "The sources path have successfully been loaded.\n" ); }
    else if( readed_config == false ){ printf( "The configuration file could not be loaded.\n" ); return false;}

    int downloaded_bl = download_bl( cbls, sources );
    if( downloaded_bl == true ){ printf( "The latest blacklists are now taking place.\n" ); }
    else if( downloaded_bl == false ){ printf( "The blacklist could not be updated.\n" ); return false;}

    int reinserted = reinsert();
    if( reinserted == true ){ printf( "The banned IPs are now intermingled.\n" ); }
    else if( reinserted == false ){ printf( "The banned IPs mixing failed.\n" ); return false;} 

    return true;
}

void intro()
{
    printf( "BBBBBBBBBBBBBBBBB   LLLLLLLLLLL            UUUUUUUU     UUUUUUUU\n" );
    printf( "B::::::::::::::::B  L:::::::::L            U::::::U     U::::::U\n" );
    printf( "B::::::BBBBBB:::::B L:::::::::L            U::::::U     U::::::U\n" );
    printf( "BB:::::B     B:::::BLL:::::::LL            UU:::::U     U:::::UU\n" );
    printf( "  B::::B     B:::::B  L:::::L               U:::::U     U:::::U \n" );
    printf( "  B::::B     B:::::B  L:::::L               U:::::D     D:::::U \n" );
    printf( "  B::::BBBBBB:::::B   L:::::L               U:::::D     D:::::U \n" );
    printf( "  B:::::::::::::BB    L:::::L               U:::::D     D:::::U \n" );
    printf( "  B::::BBBBBB:::::B   L:::::L               U:::::D     D:::::U \n" );
    printf( "  B::::B     B:::::B  L:::::L               U:::::D     D:::::U \n" );
    printf( "  B::::B     B:::::B  L:::::L               U:::::D     D:::::U \n" );
    printf( "  B::::B     B:::::B  L:::::L         LLLLLLU::::::U   U::::::U \n" );
    printf( "BB:::::BBBBBB::::::BLL:::::::LLLLLLLLL:::::LU:::::::UUU:::::::U \n" );
    printf( "B:::::::::::::::::B L::::::::::::::::::::::L UU:::::::::::::UU  \n" );
    printf( "B::::::::::::::::B  L::::::::::::::::::::::L   UU:::::::::UU    \n" );
    printf( "BBBBBBBBBBBBBBBBB   LLLLLLLLLLLLLLLLLLLLLLLL     UUUUUUUUU     \n" );
}

int read_config( char cbls[MAX_BL][1024], int *sources )
{
    FILE *config = fopen( "./config.cfg", "r" );
    if( !config ){
	printf( "Unable to load the configuration file.\n" );
	return false;
    }

    char buffer[1024] = {'\0'};
    while( fgets( buffer, 1024, config ) != NULL ){
	strcpy( cbls[*sources], buffer );
	(*sources)++;
    }

    fclose( config );
    if( *sources > 0 ){
        printf( "%d source(s) successfully detected.\n", *sources );
	return true;
    }
    else{ return false; }
}

int download_bl( char cbls[MAX_BL][1024], int sources )
{
    FILE *fsb = fopen( "./config/serverblacklistTMP.cfg", "r" );
    if( !fsb ){ fsb = fopen( "./config/serverblacklistTMP.cfg", "w" ); fprintf( fsb, "//File proudly created by BlackList Updater.\n" ); }
    fclose( fsb );

    FILE *sb = fopen( "./config/serverblacklistTMP.cfg", "a" );
    if( !sb ){
        printf( "Unable to load temporary blacklist file.\n" );
       	return false;
    }
    printf( "New blacklist created.\nCopying datas...\n" );

    int obj = 0;
    while( obj < sources ){

	int j = 0;
        while( j < 150 ){
	    if( cbls[obj][j] == '\n' ){
	        cbls[obj][j] = '\0';
	    }
	    j++;
        }
	char cmd[1024] = {'\0'};
	sprintf( cmd, "lwp-request %s > sb.cfg", cbls[obj] ); printf( "cmd: %s\n", cmd );

        system( cmd );
        printf( "Blacklist successfully gotten from source %s.\n", cbls[obj] );

        FILE *tmp = fopen( "sb.cfg", "r" );
        if( !tmp ){
	    printf( "Unable to load temporary file from source %s.\n", cbls[obj] );
	    fclose( sb );
	    return false;
        }
        printf( "Blacklist from source %d opened.\n", obj );

        char buffer[1024] = {'\0'};
        while( fgets( buffer, 1024, tmp ) != NULL ){
        	fprintf( sb, buffer );
        }
        
        fclose( tmp );
        remove( "./sb.cfg" );

	obj++;
    }
    
    rename( "./config/serverblacklist.cfg", "./config/backup_serverblacklist.cfg" );
    printf( "Backup serverblacklist done.\n" );

    rename( "./config/serverblacklistTMP.cfg", "./config/serverblacklist.cfg" );
    printf( "Blacklist successfully updated.\n" );

    fclose( sb );

    return true;
}

int reinsert()
{
    return true;
}



