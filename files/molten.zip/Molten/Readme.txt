Molten (Beta 4) by Mr.Piddly 

For the correct texture configuration, please make sure you have the latest aard/boxtex/alt_package.cfg installed. It can be found in Avacado by Tentus:

http://quadropolis.us/node/1523


IMO, for visual best results enable sobel manually using: 
/setfullscreenshader sobel



Please post any comments or suggestions on quadroplis or send me an email to mrpiddly@yahoo.com. I will try to take all reasonable suggestions into account. 




Ideas for future versions (feel free to comment on these ideas as well): 

-More particle effects (islands)
-Add detail to both volcano and side islands 
-custom map models


Beta Four (August 26, 2008)
-added simple pixelated cloudbox for horizon
-added simple cloudlayer for star twinkling effect
-added mapmodelreset to support future custom map models
-added background sounds 
-reduced health numbers on side islands
-reworked noclip/clip to make them more efficient
-deleted extra geometry
-tried making lights more orange again (now too pink???)
-various other fixes/opimizations


Beta Three (August 21, 2008)
-Added particle effect to volcano chamber and made lighting there more orange
-Alternative lava texture
-Adjusted lava lights to make them more orange
-Deleted some geometry that is on the same level as the lava (looks better)


Beta Two (August 20, 2008)
-adjusted lava glow to make it more red orange and less pink
-added broken walkways in front of castle
-clipped entire top of map
-combined some repeat lights left over from flipping the map
-Lava chamber is more red and darker
-Adjusted lightmaps to reduce map size 
-Added noclip to castle jumppad
-added additional clip to some islands


Beta One (August 19, 2008)
-Map put on Quadropolis