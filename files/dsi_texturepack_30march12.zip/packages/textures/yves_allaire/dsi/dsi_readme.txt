Wednesday, 7 Juli 2010.

Name: Texture set: dsi
Author: Yves Allaire aka evil lair (original author of the plain textures) and Suicizer (made al files named "_n", "_s" or "_z" after the original texture)
Email: yves@evillair.net (and supersauer@live.nl for contacting Suicizer)
URL: http://evillair.net

[Description]
Quake 3: Arena texture set in a sci-fi industrial space station
theme. Of course for Cube Engine too!

[Usage]
The shader files are seperated so you can easily edit them and
copy/past them into your own shader file for release of your maps.

[Thanks]
Maj (http://maj.gamedesign.net/) for helping me with the .shader
files. You the man! :)
(This file isnt included in this zip, just because Cube Engine 2 isnt using such thing)

Bal (http://www.planetquake.com/bal) for the help on how quake3
specific textures are used, since I cannot test them in a map editor.
(Maybe when they make a Mac Q3 editor!! ;)
Everyone who had kind words to say about my other texture sets and
the folks at the Quake3World.com Level Editing Forum.
Everyone who has used/will use our textures in their maps. This is why
We make them. :)

If you use any of the textures please email us with the url to some
screenshots if possible. We really would like to see what uses mappers
have made of them.

[Copyright/Permissions]
-You may not edit, modify any textures within this archive unless given permission to do so by the authors.  
-You may convert these textures to other game formats but only with the authors permission (Yves Allaire and Suicizer).
-You may not use these textures as base for your own. Of course setting up a new package.cfg with different shader-settings and parameter values is allowed.

-You may use these texture in your maps/mods/tcs as long as you give us credit.
-You may rename the textures.


QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks of id
Software, Inc.
