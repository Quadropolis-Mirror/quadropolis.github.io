AC 1.2: 100% ITALIANO
//////
**ITALIANO**
Questo client � modificato in modo tale da tradurre i messaggi del gioco stesso, non traducibili altrimenti.

Allo stato attuale sono tradotti i messaggi pi� importanti, quali i frag, messaggi del server, scoreboard, e cose varie che via via vedrete da soli, durante il gioco.

ATTENZIONE: i messaggi riguardanti le frag (sprayed, picked off, busted, gibbed, etc..) dovete tradurli da voi, tramite le impostazioni di AssaultCube stesso.

Ogni tipo di collaborazione sar� preziosa, per tradurre al meglio; anche perch� � una catorba di lavoro, e data la mancanza di tempo, tradurlo da solo � un casino. ;)


//////
**ENGLISH**
This client is modded so that hardcoded ingame messages get a proper translation (English > Italian) too. No need to read this if you actually are a non-italian speaker. 
Just to let you know, the client is 100% clean from any kind of virus/malware/cheat/dangerous modification that could lead the user to ban/blacklisting.
At the end of the project I will also provide the source back, so you can recompile/verify it by yourself. ;)

by Andrez
AssaultCube Italia - http://acitalia.bokehteknology.net/