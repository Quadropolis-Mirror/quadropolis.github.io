skin by: Deathstar from aCKa Clan 
date: 11/01/09
license: free to use and modify, but credit me ;)

=====================================================================
                            WWW.ACKA.BIZ
=====================================================================
---------------------------------------------------------------------
About Swat:
---------------------------------------------------------------------

SWAT (Special Weapons And Tactics) are elite tactical
 units in American police departments. 
Similar organisations in other areas are Australia's
Police tactical Groups like South Australian 
STAR Force (Special Tasks and Rescue), London's C019 
and Taiwan's Thunder Squad. It is trained to perform 
high-risk operations that fall outside of the abilities
 of regular patrol officers, including serving high-risk
 arrest warrants, barricaded suspects, hostage rescue, 
counter-terrorism, and engaging heavily-armed criminals.
 SWAT teams are often equipped with specialized firearms 
including assault rifles, submachine guns, shotguns, 
carbines, riot control agents, stun grenades, and high-powered 
rifles for snipers. They have specialized equipment
 including heavy body armor, entry tools, armored vehicles,
 advanced night vision optics, and motion detectors for
 covertly determining the positions of hostages or hostage
 takers inside of an enclosed structure.
The first SWAT team was established in the Los Angeles Police 
Department in the 1960s. Since then,
 many American police departments, especially in major cities
 and at the federal and state-levels of 
government, have established their own elite units under
various names; these units, despite their official
 name, are referred to collectively as SWAT units in colloquial usage.

source: wikipedia, 
more about s.w.a.t on wiki: http://en.wikipedia.org/wiki/SWAT

-------------------------------------------------------------------------
