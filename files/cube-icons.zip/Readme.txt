 
This is not my original design
Its the icon from CSL made by Jakub Uhlik  [ aka }TC{Sandman ]
I just did a little tweaking to it to make it "really cool :D"

I noticed that the icons included were not so good looking 
so i am including the standard 256x256 icons in 3 colours in the zip 
use them as u like