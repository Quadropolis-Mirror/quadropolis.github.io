Title: Motel6
Author: Mr.Blister
Date: 02-25-12
Ver.: 1.0
Description: Fun and games at your favorite motel. No custom anything.
Notes: None. Comments Welcome.

 