This map "straining2" has been made by |BC|*~Sharp~*

It is one of my first Training maps, and it is designed so only the Assault Rifle and
grenades will allow you through the map.

If you make it to the end only using the Assault Rifle and grenades, you are probably one of the best/most qualified AR jumpist. 


~If you finish the map before 3 minutes have passed, you're a VERY talented and agile AR shootist. You have mastered the art of AR jumping, angling and timing your shots and jumps. You surpass almost all other AR jumpists

~If you finish the map before 5 minutes have passed, you are pretty good - probably better than most people. However, you could try harder and become better.

~If you finish the map before 10 minutes have passed, you take your time but you're good. Try harder - you might make it before 5 minutes.

~If you finish the map before 15 mins or do not finish, don't worry. Its normal, most people can't finish the map or barely make it. Don't be glad though - you're about average and you might want to train yourself on this map more than twice a week.


Please don't Edit mode yourself through the way - the map will lose its purpose.


If you have any questions or inquiries, please send an e-mail to

koro-shiya@hotmail.com


If you see a pirated version of this map (edited by someone and/or map author is changed) please send an e-mail giving the name or author of the pirated version. Or you can just meet me online =)