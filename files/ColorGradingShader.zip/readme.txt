Simple color grading shader v1.0
It's written in GLSL, also it's my FIRST shader ever.
It's still not finished, needs a few tweaks and stuff but it works.
Yes, desaturation feature IS in plans.
The shader basically lets you add different atmosphere to the map, set colors for shadows, midtones and bright areas.

Also sorry, It's still not saving settings but I'll add feature to add presets later.

USAGE:

Just type in your autoexec.cfg "exec cgrade.cfg"
Then you can bind/use/whatever the cgrade gui or just open it with /showgui cgrade

You may use the shader whereever and however you want but you should credit me then.
Have fun.