                        __  |__,  ___         __  
               (__(__( (__( |  \ (__/_ (__(_ |__) 
                                             |
18.09.2007 [instagibwake@gmail.com]

This content is distributed under the following Creative Commons License.
             Attribution-NonCommercial-ShareAlike 3.0 Unported

You are free:

 * to Share — to copy, distribute and transmit the work
 * to Remix — to adapt the work
        
Under the following conditions:
        
 * Attribution. You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 * Noncommercial. You may not use this work for commercial purposes.
 * Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.
 * For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do this is with a link to this web page.
 * Any of the above conditions can be waived if you get permission from the copyright holder.
 * Nothing in this license impairs or restricts the author's moral rights.
                                                      
                                                      
///////////////////////////////////////////////////////Attributes to http://www.wakeup-4-life.de


wake2 aka Bio-Dome by wakeup is a 1on1/ffa mapfor sauerbraten/cube2. I thought about an research base/exhibition of biologic material in a future where artificial intelligence replaced life. There are two versions included, wake2.ogz/cfg for gameplay and wake2_alpha.ogz/cfg for a visual demonstration of the theme. If you adapt the map, please use wake2_alpha.
Hope you enjoy the map. Please send proposals or critics to [instagibwake@gmail.com]. Thanks to sweetmisery for teleport0.wav.

Developers:
	wakeup

Testers:
        daMfr0^ (special thanks for gameplay ideas)
	rocknrol
	wotwot
        Drakas
        apflstrudl
