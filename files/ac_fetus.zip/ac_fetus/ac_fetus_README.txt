Map:
ac_fetus

Author:
fetus

What to do:
Place both files into folder: C:/programfiles/AssaultCube/packages/maps

Play it and tell me what sucks.  If it's worth while, we can make it better.  Otherwise we'll trash it.


General Idea:
My first map- ever. ever.

It's wicked small- made for 2 or 3 people... 4 tops.  Deathmatch only.
