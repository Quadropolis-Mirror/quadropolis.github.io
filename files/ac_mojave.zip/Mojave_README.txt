Mojave Desertic Area [Southbound] (ac_mojave) - by Andrez

*Plot
It seems that this part of the town is the last one with a consistent supply of water. CLA took its possess, but local citizens didn't agree and started a riot against them, without any success. So RVSF entered the area and closed both accessess to the main street. Now it's only CLA vs RVSF in a bloody war...

*Modes
All flag/FFA modes.

*License
http://creativecommons.org/licenses/by-nc-sa/2.5/


http://assaultcube.altervista.org
