This is my first real attempt to create a Sauerbraten Map. Still working on it.

maptitle: 	DauX Deathmatch 1
filename: 	dxdm1
made by:	DauX
first release:	23.05.2013

Update 24.05.2013:
	-Higher doors.
	-removed one chaingun
	-Replaced yellow armor with green
	-less health pickups
	-removed healthboost
	-higher clips
	-jumppad changed to 20 from 18
	-a bit darker lights
	
	
TO-DO:
	-much better lights
	-more details
