Temple of the Damned By Majikal

Map for sauerbraten CTF Edition

Meant for 6+ Players at all kinds of modes

Creation date 15.3.09

#woop-clan @ irc.gamesurge.net


Thanks for great help, comments and playtesting : tenshi, teppo, rocknrol, Jay-EM, Drakas, ConMan, blahville and eihrul