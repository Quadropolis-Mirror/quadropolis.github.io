== OGROTRAVEL EPISODE 1 - README ==

Author : Max of S2D
Game : Cube Engine (optimized for the August 2005 Release)
E-Mail : Sims2Download *AT* gmail *DOT* com
Build Time : Around 7 months. ^^'

Files : ogrotravel1.cgz ; ogrotravel1.cfg
Installation : Extract in Cube/Packages/Base

Description : The first episode of the campaign i'm working on.

How to play : Launch Cube, open the console by pressing T and type /sp ogrotravel1