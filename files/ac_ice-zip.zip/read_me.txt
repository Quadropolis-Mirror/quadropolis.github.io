			Map by oblivion


	To play place the ac_ice_beta file into your assaultcube folder under packages then maps.
 




	then open ac and type /map ac_ice_beta


