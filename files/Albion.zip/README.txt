Heya guys!
Thanks for downloading the map Albion(ver. 1.3)!

INSTALLATION NOTES/ HOW TO START THE MAP:
- put the .ogz(mapfile) in ur game directory in the BASE folder (for example: C:/USER/programs/Sauerbraten/packages/base).
- start cube 2 - Sauerbraten and type: 
	
	/map albion

Thats all have fun on the map!

-TheDragonGER :)
