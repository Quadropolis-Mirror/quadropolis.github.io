***ALTERNATIVE PICKUPS***
A set of alternative pickups for AssaultCube, that use actual letters mapmodels to describe every single pickup:
- HP (medikit)
- AMMO (ammobox)
- PISTOL (pistol clip)
- NADE (grenade(s))
- ARMOR (kevlar armour)
- HELMET (helmet, duh)
- AKIMBO (guess)

***LICENSE***
http://creativecommons.org/licenses/by-nc-sa/3.0/

Andrez
http://andrezweb.altervista.org
http://assaultcube.altervista.org
http://ac-akimbo.net

