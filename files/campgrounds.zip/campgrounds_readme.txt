================================
About:

This is my adaption of q3dm6.
As "DM-Campgrounds it has already been adapted for UT2004
I did not want to make an 1:1 remake, this is build free hand and 
i tried out own styles and whatever to get familiar with the Sauer-Editor.
It's my second Sauer-Map, please don't expect wonders.

I made it because I like this map in Q3 and it's my favourite map in UT2004.


You might want to watch the video I made to compare the 3 versions of q3_dm6
in UT04, Q3 and Sauer: 

http://vimeo.com/1939460


btw my name is jackycola

================================
Feedback:

Whatever if you see some things you don't like or newbie-mistakes, feel free to email me
to jackycola@gmail.com. I'd like to hear any critic or blame about shit to make same mistake again.


================================
Installation: 

Unzip this to Sauerbraten folder.
Or manually put .cfg and .ogz  to your Sauerbraten/packages/base folder.


================================
Credits:

I'd like to thank everyone who helped me in #sauer-clans and #tc on gamesurge.

================================

Copyright: 

No need. The map sucks anyway.
If you want to do something feel free to do everything that is not commercial.


================================

