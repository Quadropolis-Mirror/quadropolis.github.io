---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ac_vent
Version: 1.0
By Undead[C=64]
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Under BY-NC-SA Creative Commons license.

You are free:
to Share � to copy, distribute and transmit the work.
to Remix � to adapt the work 

Under the following conditions:
Attribution. You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work). 
Noncommercial - You may not use this work for commercial purposes. 
Share Alike. - If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one. 
For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do this is with a link to this web page. 
Any of the above conditions can be waived if you get permission from the copyright holder. 
Nothing in this license impairs or restricts the author's moral rights. 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Instructions:

To use this map, copy and paste "packages" into your AssaultCube folder.
Then, when you enter AssaultCube, if you are playing online, make sure you have master and type /map ac_vent at the end of a game.
If offline simply type /map ac_vent

Enjoy :)
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------