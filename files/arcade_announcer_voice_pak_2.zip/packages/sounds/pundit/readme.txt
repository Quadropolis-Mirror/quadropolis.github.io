The sounds in this directory are all free to use for any purpose. They are all original content. If you have any questions or comments e-mail me PunDit cchristopher01@gmail.com
