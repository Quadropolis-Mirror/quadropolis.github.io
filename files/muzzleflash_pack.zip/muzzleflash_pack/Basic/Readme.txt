This part of the pack include works from makkE

All files (C) 2005-2006 makkE 

RGB modifications, by Deathstar.