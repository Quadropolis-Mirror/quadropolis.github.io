Muzzleflash pack by Deathstar

license: free to use for 
         non-commercial

=>       http://www.acka.biz

-----------------------------------------

"Basic" part is from Makke
read the text file in "basic" folder...

=>       http://assault.cubers.net

-----------------------------------------
=========================================
IN THIS PACK:
=========================================

24 muzzleflash (128x128) for your AC:

- Basic = Basic muzzleflash of AC,
          5 different colors.

- Bubble = Fire bubble muzzleflash
          5 different colors.

- Circle = Big simple circle muzzleflash
           5 differents colors.

- Explosion: Star explosion muzzleflash
             5 different colors.

- Others: Some funny muzzleflashs !

  * Comic = comic style muzzleflash
            1 color version.

  * Paper = Paper muzzleflash.
            1 color version.

  * Fireball = red fire ball muzzleflash
             1 color version.
  
  * Nothing = No muzzleflash.
              1 totaly transparent...

==========================================
              HAVE FUN !!!
==========================================

                       http://www.acka.biz