Troll Smoke - by Andrez
by-nc-sa license