                 ____
    //\\        | ___|                         
   //  \\       | |                         
  //====\\      | |        Skymaps (or Skybox) Pack
 //======\\     | |__ 
//        \\    |____|  

~> These skymaps were made by Scented Nectar        <~
~> These skymaps were rearranged by TheSharpShooter <~

 - Scented Nectar's Website -

   http://www.scentednectar.com/
 
 - Scented Nectar's E-mail  -

   3d@scentednectar.com

 - TheSharpShooter's E-mail -

   koro-shiya@hotmail.com

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 <> I have asked for permission to download these textures and redistribute them in this format. <>
  

 - License -

 These skymaps are under the freeware license; it is free to download and allowed for personal use.
 You are not allowed however, to distribute these in any commercial way, or anyway in which the 
 distributor will benefit moneywise. Users are also not allowed to re-edit or redistribute these in
 a different name or under a different author's name, without the author's explicit consent or
 personal permission. You are allowed to use these skyboxes in your maps, and you may distribute them 
 along with your maps, but you have to have this README in the skymaps folder.
 
 ____________________________________________________________
 
 To make things easier, I will explain it in casual words... Don't pirate these textures! Don't say
 you made them, or put a price on these and sell them! Don't edit and redistribute it! Ask for the
 authors permission first! You can use these skymaps for your maps and distribute them in your maps
 package, as long as you credit the author and... me for rearranging them ;-)
 
 ____________________________________________________________