"Averine" map 


Author: TG

Sauerbraten version: CVS+

Description: My first map with many. many hours of work - on my own.
A medium sized single player map Old English village theme map with many buildings to explore 
Built over many, many months using standard Sauberbraten textures etc.

Copyright/Permission:
You MAY NOT use this level as a base to build additional levels.
You MAY distribute (averine.zip) in any electronic format (BBS, Internet, PC/Game Mag cover-CD, etc...).

