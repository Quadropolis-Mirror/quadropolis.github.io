June 3, 2006

Geezumpy model

modeler:  John Siar

skins:    John Siar

animation:  yep, John Siar

email:   geargolem@titanium3d.com

folder install:  <sauerbraten directory>/packages/models/monster/

description:  The most feared monster of all, the Geezumpy.  He is able to make you feel
2 inches tall with his scalding remarks.  He stinks like poo.  His ears are filled with hair.
Be afraid.  Be very afraid.

specs:  684 verts, tris.
skin:   512x512 jpg.  Scale to 256x256 if you experience slowness.

Copyright (C) 2006  John Siar

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.