Merksa Alpha - 26 March 2011

There are no items
There are no waypoints
There is no lighting
There is no .cfg

extract to /Sauerbraten/packages/base

load map by typing /map merksa

WeirdSexy@Gmail.com




