Author: Acord
Date:   5/15/2007


Instructions:
-------------
1. Extract the zip in Sauerbraten/packages directory
   
2. Add the following line to your map's CFG file to load the skybox:

   loadsky "acord/sky1"

3. If you don't understand what I'm talking about, read the fine manual.

Licenses:
---------
Free to use, so long as you remember to credit the author~!