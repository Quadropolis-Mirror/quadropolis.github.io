"" r4_scorched - From R4zor. ""
Please Note: This is not a ctf map. From the size of the map, I gather it will (if is) be used for Last Swiss 
Standing, One shot One Kill (/team), or deathmatch (/team).

- Skybox created by Acord. Download from "http://www.quadropolis.us/node/617" -

- To install:
  -Place cfg and cgz into assaultcube/packages/maps
  -Place the "acord" folder into packages/textures/skymaps

~~MAP LICENSE~~
This map may not redistributed without my knowledge. Under no circumstances may it be redistributed for
Assaultcube. If you wish to tweak this map for another game, you must give me full credit for the original map.


- Another thanks to Acord.

Hope you enjoy the map!

~R4zor.