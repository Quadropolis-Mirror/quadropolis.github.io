==[Castlegrounds by Cloud]==
===========================================================================
Game: Sauerbraten
Map: 2nd
Released: June 23, 2007
Gametypes: Instagib, Capture, FFA
Fits 5-8 players
Work Time: 5 days
Default textures were used
===========================================================================
Background:
After a fierce war, all that remains of this once eloquent castle is a ravaged battleground. Fight your way through a bombed out building and destroyed castles to claim victory and take back your land.
===========================================================================
Installation:

Unzip directly into Sauerbraten main folder.

To manually install, place castlegrounds.ogz into "Sauerbraten/packages/base"
===========================================================================
Developer Notes:
-I suck at picking names for my maps.
-I also have trouble deciding which textures to use, so that's why anything may look unnatural.
===========================================================================
Created by Cloud
with some help by Kaiser and Antrod

Copyrighted by Josh Edwards 2007

You MAY NOT commercially exploit this map without my strict permission.

You MAY use any models from this map as long as you give credit to the author and include any original readme files.
===========================================================================
Contact me at cloud7654@gmail.com for any questions or comments regarding this map.